import torch
from torch import nn
from torch.nn import functional as F
from .relative_evidence import RelativeEvidenceEncoder
from .backbone import Backbone
from .heads import DetectorHeads
from ..config import validate_config


class Detector(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        validate_config(cfg)
        if cfg["task"]["size_head"] is None:
            raise ValueError("Resolve task.size_head before constructing Detector")
        self.relative_input = cfg["model"]["evidence"]["enabled"]
        needs_condition = cfg["model"]["block"]["conditional_mixing"]
        self.evidence = RelativeEvidenceEncoder(cfg["model"]["evidence"]) if self.relative_input or needs_condition else None
        self.backbone = Backbone(6 if self.relative_input else 1, cfg["model"])
        self.heads = DetectorHeads(cfg["model"]["channels"][0], cfg["model"]["heads"], cfg["task"]["size_head"])

    def forward(self, image, return_features=False, diagnostics=False):
        if image.ndim != 4 or image.shape[1] != 1 or min(image.shape[-2:]) < 32:
            raise ValueError("Expected [B,1,H,W], H,W>=32")
        h, w = image.shape[-2:]
        if self.evidence is not None:
            z, c = self.evidence(image, diagnostics)
        else:
            z, c = None, image.new_zeros(image.shape[0], 4, h, w)
        feature = z if self.relative_input else image
        padding = (0, (-w) % 8, 0, (-h) % 8)
        feature = F.pad(feature, padding, mode="replicate")
        c = F.pad(c, padding, mode="replicate")
        final, target = self.backbone(feature, c, diagnostics)
        outputs = self.heads(final, target)
        outputs = {key: value[..., :h, :w] if value is not None else None for key, value in outputs.items()}
        if return_features:
            outputs["final_features"] = final[..., :h, :w]
        return outputs
