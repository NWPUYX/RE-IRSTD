"""Configuration composition and fail-fast checks for the supported design."""
from copy import deepcopy
from pathlib import Path
import math
import yaml


def merge(base, override):
    result = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merge(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


def load_config(path, experiment=None, override=None):
    path = Path(path)
    with path.open(encoding="utf-8") as stream:
        cfg = yaml.safe_load(stream)
    if experiment:
        with (path.parent / "configs" / "ablations.yaml").open(encoding="utf-8") as stream:
            choices = yaml.safe_load(stream)
        if experiment not in choices:
            raise ValueError(f"Unknown experiment: {experiment}")
        cfg = merge(cfg, choices[experiment])
        cfg["experiment"] = experiment
    if override:
        with Path(override).open(encoding="utf-8") as stream:
            cfg = merge(cfg, yaml.safe_load(stream) or {})
    validate_config(cfg)
    return cfg


def validate_config(cfg, training=False):
    # Reject unsupported choices instead of silently ignoring declared settings.
    fixed = {
        "task.input": "single_frame_grayscale",
        "task.unknown_negative_policy": "ignore",
        "task.coordinate_system": "continuous_image_coordinates",
        "task.output_stride": 1,
        "data.preserve_native_resolution": True,
        "data.imagewise_minmax": False,
        "data.batch_by_same_shape": True,
        "data.pad_to_multiple": 8,
        "data.minimum_size": 32,
        "data.train_crop_size": None,
        "data.allow_incomplete_as_empty_negative": False,
        "model.norm": "group_norm",
        "model.evidence.statistics_dtype": "float32",
        "model.evidence.padding": "reflect",
        "model.evidence.evidence_channels": 6,
        "model.evidence.condition_channels": 4,
        "model.block.kernel_size": 3,
        "model.block.dilations": [1, 2, 3],
        "model.block.depthwise_padding": "reflect",
        "model.heads.offsets": True,
        "model.heads.size_reference": "source_train_box_median",
        "labels.heatmap_composition": "maximum",
        "labels.offset_anchor": "floor_center",
        "labels.reject_unresolved_center_collisions": True,
        "loss.center_reduce": "per_image_sum_div_max_target_count_then_batch_mean",
        "loss.compute_in_float32": True,
        "augmentation.clip_affine_intensity": False,
        "augmentation.donor_must_be_verified_target_free": True,
        "augmentation.donor_source_train_only": True,
        "augmentation.transition": "cosine_distance",
        "train.optimizer": "AdamW",
        "train.no_weight_decay": ["bias", "norm_affine", "residual_gamma"],
        "train.scheduler": "cosine",
        "validation.use_source_validation_only": True,
        "decode.plateau_tie_policy": "deterministic_deduplication",
        "decode.top_k": None,
        "evaluation.matching": "one_to_one_minimum_distance",
        "evaluation.bootstrap_unit": "acquisition_group",
        "evaluation.report": ["recall", "precision", "target_f1", "false_positive_targets_per_image", "false_positive_targets_per_megapixel"],
    }
    for dotted, expected in fixed.items():
        value = cfg
        for key in dotted.split("."):
            value = value[key]
        if value != expected:
            raise ValueError(f"Unsupported {dotted}={value!r}; expected {expected!r}")
    model = cfg["model"]
    annuli = model["evidence"]["annuli"]
    if len(annuli) != 3 or any(len(pair) != 2 or not all(isinstance(x, int) for x in pair)
                               or not (1 <= pair[0] < pair[1] <= 63) or any(x % 2 != 1 for x in pair) for pair in annuli):
        raise ValueError("Three odd annuli 1<=inner<outer<=63 required")
    channels = model["channels"]
    if len(channels) != 4 or any(c <= 0 or c % model["norm_groups"] for c in channels):
        raise ValueError("Four positive channel widths divisible by GN groups required")
    block = model["block"]
    if block["kind"] not in ("static", "relative_evidence"):
        raise ValueError("Unsupported block kind")
    if block["kind"] == "static" and (block["zero_sum_kernel"] or block["conditional_mixing"]):
        raise ValueError("StaticBlock requires unconstrained kernels and fixed mixing")
    if not model.get("full_resolution_enabled", True) and model["heads"]["auxiliary_center"]:
        raise ValueError("Removing T also requires removing its auxiliary head")
    for key in ("encoder_blocks_per_stage", "decoder_blocks_per_stage", "full_resolution_blocks"):
        if not isinstance(model[key], int) or model[key] < 1:
            raise ValueError(f"{key} must be a positive integer")
    if not 0 < model["heads"]["center_init_probability"] < 1:
        raise ValueError("Center initialization probability must lie in (0,1)")
    if model["evidence"]["sigma_floor"] < 0 or model["evidence"]["clip_abs"] <= 0:
        raise ValueError("Invalid evidence floor/clip")
    if cfg["labels"]["heatmap_sigma"] <= 0 or cfg["labels"]["gaussian_truncation_sigma"] <= 0:
        raise ValueError("Heatmap sigma/truncation must be positive")
    if cfg["decode"]["local_peak_kernel"] != 3:
        raise ValueError("First-version decoder requires a 3x3 local peak kernel")
    if not all(0 < x <= 1 for x in cfg["validation"]["threshold_grid"]):
        raise ValueError("Invalid threshold grid")
    if cfg["validation"]["checkpoint_selector"] != "target_f1_pooled":
        raise ValueError("Use target_f1_pooled; optional FP budget constrains its search")
    for key in ("horizontal_flip_probability", "vertical_flip_probability", "paired_sample_probability"):
        if not 0 <= cfg["augmentation"][key] <= 1:
            raise ValueError(f"Invalid probability {key}")
    start, end = (cfg["train"][k] for k in ("consistency_start_fraction", "consistency_full_weight_fraction"))
    if not 0 <= start < end <= 1:
        raise ValueError("Invalid consistency ramp")
    if cfg["task"]["size_head"] not in (None, True, False):
        raise ValueError("size_head must be null or bool")
    if cfg["train"].get("amp_dtype", "auto") not in ("auto", "bfloat16", "float16"):
        raise ValueError("amp_dtype must be auto, bfloat16 or float16")
    if cfg["train"]["epochs"] < 1 or cfg["train"]["effective_batch"] < 1 or cfg["train"]["warmup_epochs"] < 0:
        raise ValueError("Positive epochs/effective_batch and nonnegative warmup required")
    if cfg["train"]["learning_rate"] <= 0 or not 0 <= cfg["train"]["minimum_learning_rate"] <= cfg["train"]["learning_rate"]:
        raise ValueError("Invalid learning-rate range")
    if cfg["train"]["gradient_clip_norm"] <= 0 or not 0 <= cfg["train"]["target_free_sample_fraction_start"] <= 1:
        raise ValueError("Invalid gradient norm/empty sampling fraction")
    if cfg["loss"]["smooth_l1_beta"] <= 0 or cfg["loss"]["consistency_cosine_epsilon"] <= 0:
        raise ValueError("Positive loss beta/epsilon required")
    if cfg["augmentation"]["transition_width"] <= 0:
        raise ValueError("Positive swap transition width required")
    for key in ("affine_intensity_gain", "affine_intensity_bias"):
        values = cfg["augmentation"][key]
        if len(values) != 2 or not all(math.isfinite(x) for x in values) or values[0] > values[1]:
            raise ValueError(f"Invalid diagnostic perturbation range {key}")
    if cfg["augmentation"]["affine_intensity_gain"][0] <= 0:
        raise ValueError("Evidence affine diagnostic requires positive gain")
    point_radius = cfg["augmentation"]["point_protection_radius"]
    if point_radius is not None and (not math.isfinite(point_radius) or point_radius <= 0):
        raise ValueError("Positive finite point protection radius required")
    budget = cfg["validation"]["false_alarm_budget_per_image"]
    if budget is not None and (not math.isfinite(budget) or budget < 0):
        raise ValueError("Nonnegative FP/image budget required")
    if cfg["decode"]["box_nms_iou"] is not None and not 0 <= cfg["decode"]["box_nms_iou"] <= 1:
        raise ValueError("box_nms_iou must be null or in [0,1]")
    scale = cfg["data"]["input_scale"]
    if scale is not None and (not isinstance(scale, (int, float)) or not math.isfinite(scale) or scale <= 0):
        raise ValueError("input_scale is an explicit positive numeric divisor")
    radius = cfg["evaluation"]["point_match_radius"]
    if radius is not None and (not math.isfinite(radius) or radius <= 0):
        raise ValueError("point_match_radius must be positive")
    if training:
        if scale is None or radius is None:
            raise ValueError("Training requires explicit data.input_scale and evaluation.point_match_radius")
        if cfg["task"]["size_head"] is None:
            raise ValueError("Resolve size_head from audited source-train annotations first")

