from pathlib import Path
import json
import random
import time
import numpy as np
from PIL import Image, ImageDraw
import torch
from .models.blocks import REBlock


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def autocast_dtype(device, cfg):
    option = cfg["train"].get("amp_dtype", "auto")
    if option == "bfloat16":
        if device.type == "cuda" and not torch.cuda.is_bf16_supported():
            raise ValueError("Configured BF16 is unsupported by this GPU")
        return torch.bfloat16
    if option == "float16":
        return torch.float16
    if option != "auto":
        raise ValueError("amp_dtype must be auto, bfloat16 or float16")
    return torch.bfloat16 if device.type == "cuda" and torch.cuda.is_bf16_supported() else torch.float16


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def layer_stats(model):
    result = {name: module.last_stats for name, module in model.named_modules() if isinstance(module, REBlock)}
    if model.evidence is not None:
        result["evidence"] = model.evidence.last_stats
    return result


def preview_sample(sample, path, image=None):
    # Display normalization is for inspection only and never enters the model.
    array = (sample["image"] if image is None else image).squeeze(0).cpu().numpy()
    lo, hi = float(array.min()), float(array.max())
    pixels = np.round((array - lo) / max(hi - lo, 1e-8) * 255).clip(0, 255).astype(np.uint8)
    canvas = Image.fromarray(pixels).convert("RGB")
    draw = ImageDraw.Draw(canvas)
    for x1, y1, x2, y2 in sample["boxes"].tolist():
        draw.rectangle((x1, y1, x2, y2), outline="lime", width=1)
    for x, y in sample["points"].tolist():
        draw.line((x - 3, y, x + 3, y), fill="red")
        draw.line((x, y - 3, x, y + 3), fill="red")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    canvas.save(path)


def profile_model(model, shape, device, repetitions=10):
    if repetitions < 1 or min(shape) < 32:
        raise ValueError("Positive repetitions and H,W>=32 required")
    model.eval()
    images = torch.rand(1, 1, *shape, device=device)
    def synchronize():
        if device.type == "cuda":
            torch.cuda.synchronize(device)
    with torch.no_grad():
        for _ in range(3):
            model(images)
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        synchronize()
        start = time.perf_counter()
        for _ in range(repetitions):
            model(images)
        synchronize()
    return {"parameters": sum(p.numel() for p in model.parameters()), "shape": list(shape),
            "device": str(device), "forward_latency_ms": (time.perf_counter() - start) * 1000 / repetitions,
            "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated(device) if device.type == "cuda" else None,
            "scope": "FP32 model forward including evidence and auxiliary head; excludes decode and image IO"}

