"""Exact Euclidean distance transition, without a SciPy runtime dependency."""
import math
import numpy as np
import torch


def _squared_distance_1d(values):
    n = len(values)
    finite = np.flatnonzero(np.isfinite(values))
    if not len(finite):
        return np.full(n, np.inf)
    vertices = np.empty(n, dtype=np.int64)
    bounds = np.empty(n + 1, dtype=np.float64)
    k = 0
    vertices[0] = finite[0]
    bounds[0], bounds[1] = -np.inf, np.inf
    for q in finite[1:]:
        while True:
            p = vertices[k]
            crossing = ((values[q] + q * q) - (values[p] + p * p)) / (2 * (q - p))
            if crossing > bounds[k]:
                break
            k -= 1
        k += 1
        vertices[k], bounds[k], bounds[k + 1] = q, crossing, np.inf
    output = np.empty(n, dtype=np.float64)
    k = 0
    for q in range(n):
        while bounds[k + 1] < q:
            k += 1
        output[q] = (q - vertices[k]) ** 2 + values[vertices[k]]
    return output


def distance_from_protection(protected):
    values = np.where(protected, 0., np.inf)
    row_pass = np.stack([_squared_distance_1d(row) for row in values])
    result = np.stack([_squared_distance_1d(column) for column in row_pass.T], axis=1)
    return np.sqrt(result)


def protection_mask(sample, cfg):
    h, w = sample["image"].shape[-2:]
    protected = np.zeros((h, w), dtype=np.bool_)
    margin = cfg["box_protection_margin"]
    for x1, y1, x2, y2 in sample["boxes"].tolist():
        left, top = max(0, math.floor(x1 - margin)), max(0, math.floor(y1 - margin))
        right, bottom = min(w, math.ceil(x2 + margin)), min(h, math.ceil(y2 + margin))
        protected[top:bottom, left:right] = True
    if len(sample["points"]):
        radius = cfg["point_protection_radius"]
        if radius is None or not cfg.get("point_protection_approved", False):
            raise ValueError("Point swapping requires an inspected and recorded protection radius")
        if radius < cfg["box_protection_margin"]:
            raise ValueError("Point protection must at least cover the evidence/gradient support allowance")
        yy, xx = np.mgrid[:h, :w]
        for x, y in sample["points"].tolist():
            protected |= (xx + .5 - x) ** 2 + (yy + .5 - y) ** 2 <= radius ** 2
    return protected


def swap_background(sample, donor, cfg):
    if not sample["complete"]:
        raise ValueError("Background swap requires complete recipient annotations")
    if (donor["split"] != "source_train" or not donor["complete"] or not donor["verified_target_free"]
            or len(donor["points"]) or len(donor["boxes"])):
        raise ValueError("Donor must be explicitly verified, complete, source-train and target-free")
    if sample["image"].shape != donor["image"].shape:
        raise ValueError("Native-shape donor required; implicit resizing is unsupported")
    distance = distance_from_protection(protection_mask(sample, cfg))
    width = cfg["transition_width"]
    if width <= 0:
        raise ValueError("transition_width must be positive")
    ratio = np.minimum(distance / width, 1.)
    alpha = .5 * (1 - np.cos(np.pi * ratio))
    alpha = torch.as_tensor(alpha, dtype=sample["image"].dtype, device=sample["image"].device)[None]
    swapped = (1 - alpha) * sample["image"] + alpha * donor["image"].to(sample["image"].device)
    return swapped, alpha
