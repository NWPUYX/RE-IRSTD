from .detection import detection_losses
from .consistency import center_consistency

