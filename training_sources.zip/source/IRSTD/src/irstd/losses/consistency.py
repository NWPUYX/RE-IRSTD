import torch
from torch.nn import functional as F
from ..data.targets import gather_centers


def center_consistency(original, swapped, anchors, paired, epsilon=1e-6, target_normalizer=None):
    with torch.autocast(device_type=original.device.type, enabled=False):
        selected = anchors[paired[anchors[:, 0]]] if len(anchors) else anchors
        if not len(selected):
            return (original.float().sum() + swapped.float().sum()) * 0
        u = F.normalize(gather_centers(original.float(), selected), dim=1, eps=epsilon)
        v = F.normalize(gather_centers(swapped.float(), selected), dim=1, eps=epsilon)
        denominator = len(anchors) if target_normalizer is None else target_normalizer
        return ((1 - (u.detach() * v).sum(1)) + (1 - (u * v.detach()).sum(1))).sum() / (2 * max(denominator, 1))

