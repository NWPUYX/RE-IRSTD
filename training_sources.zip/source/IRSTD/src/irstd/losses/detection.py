import torch
from torch.nn import functional as F
from ..data.targets import gather_centers


def center_loss(logits, targets, alpha=2, beta=4):
    logits = logits.float()
    probability = logits.sigmoid()
    positive = targets["positive"]
    negative = targets["negative"]
    logp, log1mp = -F.softplus(-logits), -F.softplus(logits)
    value = -(positive * (1 - probability).pow(alpha) * logp
              + negative * (1 - targets["heatmap"]).pow(beta) * probability.pow(alpha) * log1mp)
    return value.flatten(1).sum(1) / targets["counts"].clamp_min(1)


def detection_losses(outputs, targets, cfg, image_weights=None, normalizers=None):
    """Weighted sums allow paired samples to have 1/2 supervision per view.

    The denominators remain the original batch size/target count; paired views
    therefore do not accidentally double their weight relative to unpaired ones.
    """
    logits = outputs["center_logits"]
    with torch.autocast(device_type=logits.device.type, enabled=False):
        batch = logits.shape[0]
        normalizers = normalizers or {"images": batch, "targets": len(targets["anchors"]), "boxes": int(targets["has_box"].sum())}
        weights = logits.new_ones(batch, dtype=torch.float32) if image_weights is None else image_weights.float()
        center = (center_loss(logits, targets, cfg["center_focal_alpha"], cfg["center_focal_beta"]) * weights).sum() / normalizers["images"]
        auxiliary = logits.float().sum() * 0
        if outputs["auxiliary_center_logits"] is not None:
            auxiliary = (center_loss(outputs["auxiliary_center_logits"], targets, cfg["center_focal_alpha"],
                                     cfg["center_focal_beta"]) * weights).sum() / normalizers["images"]
        anchors = targets["anchors"]
        off = gather_centers(outputs["offsets"].float(), anchors)
        offset = outputs["offsets"].float().sum() * 0
        if len(anchors):
            per_target = F.smooth_l1_loss(off, targets["offsets"], beta=cfg["smooth_l1_beta"], reduction="none").mean(1)
            offset = (per_target * weights[anchors[:, 0]]).sum() / max(normalizers["targets"], 1)
        size_output = outputs["log_size"]
        size = logits.float().sum() * 0 if size_output is None else size_output.float().sum() * 0
        flags = targets["has_box"]
        if size_output is not None and flags.any():
            size_values = gather_centers(size_output.float(), anchors[flags])
            per_box = F.smooth_l1_loss(size_values, targets["sizes"][flags], beta=cfg["smooth_l1_beta"], reduction="none").mean(1)
            size = (per_box * weights[anchors[flags, 0]]).sum() / max(normalizers["boxes"], 1)
        total = (cfg["center_weight"] * center + cfg["auxiliary_weight"] * auxiliary
                 + cfg["offset_weight"] * offset + cfg["size_weight"] * size)
        return {"total": total, "center": center, "auxiliary": auxiliary, "offset": offset, "size": size}

