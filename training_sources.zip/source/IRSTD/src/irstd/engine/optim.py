import math
import torch
from torch import nn


def make_optimizer(model, cfg):
    no_decay = set()
    for module_name, module in model.named_modules():
        if isinstance(module, nn.GroupNorm):
            for name, _ in module.named_parameters(recurse=False):
                no_decay.add(f"{module_name}.{name}" if module_name else name)
    decay, excluded = [], []
    for name, parameter in model.named_parameters():
        if name.endswith(".bias") or name.endswith(".gamma") or name in no_decay:
            excluded.append(parameter)
        else:
            decay.append(parameter)
    return torch.optim.AdamW([{"params": decay, "weight_decay": cfg["weight_decay"]},
                              {"params": excluded, "weight_decay": 0.}],
                             lr=cfg["learning_rate"], betas=tuple(cfg["betas"]))


def learning_rate(progress_epoch, cfg):
    warmup, epochs = cfg["warmup_epochs"], cfg["epochs"]
    peak, minimum = cfg["learning_rate"], cfg["minimum_learning_rate"]
    if warmup and progress_epoch < warmup:
        return peak * max(progress_epoch / warmup, 1e-8)
    fraction = min(max((progress_epoch - warmup) / max(epochs - warmup, 1), 0), 1)
    return minimum + .5 * (peak - minimum) * (1 + math.cos(math.pi * fraction))


def consistency_weight(progress, cfg, loss_cfg):
    start, full = cfg["consistency_start_fraction"], cfg["consistency_full_weight_fraction"]
    return loss_cfg["consistency_max_weight"] * min(max((progress - start) / (full - start), 0), 1)

