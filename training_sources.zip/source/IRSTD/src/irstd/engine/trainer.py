from pathlib import Path
from copy import deepcopy
import json
import random
import time
import torch
from torch.utils.data import DataLoader
import yaml
from ..config import validate_config
from ..data.audit import audit_manifest
from ..data.dataset import InfraredDataset, collate_samples
from ..data.sampler import SameShapeBatchSampler
from ..data.targets import build_targets
from ..data.transforms import geometric_transform
from ..augmentation.background_swap import swap_background
from ..models.detector import Detector
from ..losses.detection import detection_losses
from ..losses.consistency import center_consistency
from ..diagnostics import seed_everything, write_json, layer_stats, autocast_dtype
from .optim import make_optimizer, learning_rate, consistency_weight
from .checkpoint import save_checkpoint, load_checkpoint, restore_rng
from .evaluator import collect_predictions, select_source_threshold


def make_loader(dataset, microbatch=1, training=False, seed=0):
    sampler = SameShapeBatchSampler(dataset, microbatch, shuffle=training,
                                   balanced=dataset.cfg["train"]["source_scene_balanced_sampling"],
                                   empty_fraction=dataset.cfg["train"]["target_free_sample_fraction_start"], seed=seed)
    return DataLoader(dataset, batch_sampler=sampler, collate_fn=collate_samples, num_workers=0)


def accumulation_windows(loader, effective_batch):
    window, count = [], 0
    for images, samples in loader:
        start = 0
        while start < len(samples):
            take = min(effective_batch - count, len(samples) - start)
            window.append((images[start:start + take], samples[start:start + take]))
            start += take
            count += take
            if count == effective_batch:
                yield window
                window, count = [], 0
    if window:
        yield window


def donor_indices(dataset):
    return [i for i, row in enumerate(dataset.records)
            if row.get("verified_target_free") is True
            and row.get("complete", dataset.cfg["task"]["annotation_complete"]) is True
            and not row.get("points") and not row.get("boxes")]


def choose_donor(sample, dataset, candidates, cfg):
    h, w = sample["image"].shape[-2:]
    candidates = [i for i in candidates if dataset.shapes[i] in ((h, w), (w, h))
                  and dataset.records[i]["sample_id"] != sample["sample_id"]]
    if cfg["prefer_different_source_scene"] and sample["scene_id"] is not None:
        cross_scene = [i for i in candidates if dataset.records[i].get("scene_id") is not None
                       and dataset.records[i]["scene_id"] != sample["scene_id"]]
        if cross_scene:
            candidates = cross_scene
    if not candidates:
        return None
    index = random.choice(candidates)
    donor = dataset.raw_sample(index)
    if donor["image"].shape[-2:] != (h, w):
        donor = geometric_transform(donor, (1, False, False))
    return donor


def paired_images(images, samples, dataset, donors, cfg, enabled):
    paired = torch.zeros(len(samples), dtype=torch.bool)
    swapped = images.clone()
    if not enabled:
        return swapped, paired
    for i, sample in enumerate(samples):
        if not sample["complete"] or random.random() >= cfg["paired_sample_probability"]:
            continue
        if len(sample["points"]) and (cfg["point_protection_radius"] is None or not cfg.get("point_protection_approved", False)):
            continue
        donor = choose_donor(sample, dataset, donors, cfg)
        if donor is not None:
            swapped[i], _ = swap_background(sample, donor, cfg)
            paired[i] = True
    return swapped, paired


def train(manifest, cfg, output, device="cpu", microbatch=1, seed=0, resume=None):
    cfg = deepcopy(cfg)
    audit = audit_manifest(manifest, cfg, require_train=True)
    inferred_size_head = audit["source_train_has_boxes"]
    if cfg["task"]["size_head"] is None:
        cfg["task"]["size_head"] = inferred_size_head
    elif cfg["task"]["size_head"] != inferred_size_head:
        raise ValueError("size_head must match presence of true source-train boxes")
    cfg["run_seed"] = seed
    validate_config(cfg, training=True)
    geometry_enabled = (cfg["augmentation"]["rotate_90"] or cfg["augmentation"]["horizontal_flip_probability"] > 0
                        or cfg["augmentation"]["vertical_flip_probability"] > 0)
    if geometry_enabled and not cfg["augmentation"].get("geometry_preview_approved", False):
        raise ValueError("Inspect native-scale geometry previews; record augmentation.geometry_preview_approved=true")
    swap_enabled = cfg["augmentation"]["remote_background_swap"]
    if swap_enabled and not cfg["augmentation"].get("background_swap_preview_approved", False):
        raise ValueError("Inspect swap previews; record augmentation.background_swap_preview_approved=true")
    maximum_radius = max(outer // 2 for _, outer in cfg["model"]["evidence"]["annuli"])
    if swap_enabled and cfg["augmentation"]["box_protection_margin"] < maximum_radius + 2:
        raise ValueError("Protection margin is smaller than evidence+gradient support+one-pixel allowance")
    if microbatch < 1 or microbatch > cfg["train"]["effective_batch"]:
        raise ValueError("microbatch must be between 1 and effective_batch")
    output = Path(output)
    if resume and output.resolve() != Path(resume).resolve().parent:
        raise ValueError("Resume in the existing checkpoint directory to preserve best.pt and its selection history")
    if not resume and ((output / "last.pt").exists() or (output / "metrics.jsonl").exists()):
        raise ValueError("Existing run: choose a new output directory or explicitly resume")
    output.mkdir(parents=True, exist_ok=True)
    seed_everything(seed)
    device = torch.device(device)
    train_data = InfraredDataset(manifest, "source_train", cfg, augment=True, seed=seed)
    val_data = InfraredDataset(manifest, "source_val", cfg)
    donors = donor_indices(train_data)
    if swap_enabled and not donors:
        raise ValueError("E/F require explicitly verified source-train target-free donors")
    if swap_enabled:
        eligible_target_recipients = []
        for i, row in enumerate(train_data.records):
            complete = row.get("complete", cfg["task"]["annotation_complete"]) is True
            point_eligible = not row.get("points") or (cfg["augmentation"]["point_protection_radius"] is not None
                                                     and cfg["augmentation"].get("point_protection_approved", False))
            shape = train_data.shapes[i]
            compatible = any(j != i and train_data.shapes[j] in (shape, shape[::-1]) for j in donors)
            if complete and point_eligible and (row.get("boxes") or row.get("points")) and compatible:
                eligible_target_recipients.append(i)
        if not eligible_target_recipients:
            raise ValueError("E/F have no eligible labeled recipient/donor pairs; cannot run a nominal consistency experiment")
    loader = make_loader(train_data, microbatch, training=True, seed=seed)
    val_loader = make_loader(val_data, microbatch)
    size_reference = audit["size_reference"]
    model = Detector(cfg).to(device)
    optimizer = make_optimizer(model, cfg["train"])
    use_amp = cfg["train"]["mixed_precision_backbone"] and device.type == "cuda"
    amp_type = autocast_dtype(device, cfg)
    scaler = torch.amp.GradScaler(device.type, enabled=use_amp and amp_type == torch.float16)
    start_epoch, best_key = 0, None
    provenance = {"manifest": str(Path(manifest).resolve()), "audit": audit, "microbatch": microbatch,
                  "seed": seed, "torch": str(torch.__version__), "device": str(device),
                  "backbone_autocast_dtype": str(amp_type) if use_amp else "float32"}
    if resume:
        state = load_checkpoint(resume)
        if state["config"] != cfg or state["size_reference"] != size_reference:
            raise ValueError("Resume requires unchanged resolved config and source-train size reference")
        if state["provenance"]["audit"] != audit or state["provenance"]["microbatch"] != microbatch:
            raise ValueError("Resume data provenance or microbatch changed")
        history_path = output / "metrics.jsonl"
        if history_path.exists():
            recorded_epochs = [json.loads(line)["epoch"] for line in history_path.read_text(encoding="utf-8").splitlines() if line.strip()]
            if recorded_epochs and max(recorded_epochs) > state["epoch"]:
                raise ValueError("Checkpoint is older than recorded history; resume the latest last.pt")
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        scaler.load_state_dict(state["scaler"])
        restore_rng(state["rng"])
        start_epoch, best_key = state["epoch"] + 1, state["best_key"]
    write_json(output / "data_audit.json", audit)
    (output / "resolved_config.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding="utf-8")
    write_json(output / "provenance.json", provenance)
    epochs = cfg["train"]["epochs"]
    if epochs <= start_epoch:
        raise ValueError("No epochs remain to execute")
    for epoch in range(start_epoch, epochs):
        train_data.set_epoch(epoch)
        model.train()
        totals = {key: 0. for key in ("total", "center", "auxiliary", "offset", "size", "consistency")}
        counts = {"images": 0, "targets": 0, "boxes": 0, "complete_empty": 0, "paired_images": 0, "paired_targets": 0,
                  "optimizer_steps": 0, "skipped_optimizer_steps": 0}
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        started = time.perf_counter()
        windows = accumulation_windows(loader, cfg["train"]["effective_batch"])
        planned_windows = (len(train_data) + cfg["train"]["effective_batch"] - 1) // cfg["train"]["effective_batch"]
        weight = consistency_weight(epoch / epochs, cfg["train"], cfg["loss"]) if swap_enabled else 0.
        for step, window in enumerate(windows):
            optimizer.zero_grad(set_to_none=True)
            normalizers = {"images": sum(len(samples) for _, samples in window),
                           "targets": sum(len(s["points"]) + len(s["boxes"]) for _, samples in window for s in samples),
                           "boxes": sum(len(s["boxes"]) for _, samples in window for s in samples)}
            prepared = []
            for images, samples in window:
                targets = build_targets(samples, cfg, size_reference, device)
                swapped, paired = paired_images(images, samples, train_data, donors, cfg["augmentation"],
                                               enabled=swap_enabled and epoch / epochs >= cfg["train"]["consistency_start_fraction"])
                paired = paired.to(device)
                prepared.append((images, samples, targets, swapped, paired))
            paired_target_count = sum(int(paired[targets["anchors"][:, 0]].sum()) for _, _, targets, _, paired in prepared)
            lr = learning_rate(epoch + (step + 1) / planned_windows, cfg["train"])
            for group in optimizer.param_groups:
                group["lr"] = lr
            for images, samples, targets, swapped, paired in prepared:
                with torch.autocast(device_type=device.type, enabled=use_amp, dtype=amp_type):
                    original = model(images.to(device), return_features=bool(paired.any()), diagnostics=True)
                    original_weights = torch.where(paired, .5, 1.)
                    losses = detection_losses(original, targets, cfg["loss"], original_weights, normalizers)
                    consistency = original["center_logits"].float().sum() * 0
                    if paired.any():
                        second = model(swapped.to(device), return_features=True)
                        second_losses = detection_losses(second, targets, cfg["loss"], paired.float() * .5, normalizers)
                        losses = {key: value + second_losses[key] for key, value in losses.items()}
                        consistency = center_consistency(original["final_features"], second["final_features"],
                                                         targets["anchors"], paired, cfg["loss"]["consistency_cosine_epsilon"],
                                                         target_normalizer=normalizers["targets"])
                    total = losses["total"] + weight * consistency
                if not torch.isfinite(total):
                    raise FloatingPointError("Non-finite training loss; inspect data and numeric diagnostics")
                scaler.scale(total).backward()
                for key, value in losses.items():
                    if key != "total":
                        totals[key] += float(value.detach())
                totals["total"] += float(total.detach())
                totals["consistency"] += float(consistency.detach())
                counts["images"] += len(samples)
                counts["targets"] += len(targets["anchors"])
                counts["boxes"] += int(targets["has_box"].sum())
                counts["complete_empty"] += sum(s["complete"] and not len(s["points"]) and not len(s["boxes"]) for s in samples)
                counts["paired_images"] += int(paired.sum())
            counts["paired_targets"] += paired_target_count
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["train"]["gradient_clip_norm"], error_if_nonfinite=not scaler.is_enabled())
            previous_scale = scaler.get_scale()
            scaler.step(optimizer)
            scaler.update()
            skipped = scaler.get_scale() < previous_scale
            counts["skipped_optimizer_steps"] += int(skipped)
            counts["optimizer_steps"] += int(not skipped)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        training_seconds = time.perf_counter() - started
        predictions, samples = collect_predictions(model, val_loader, device, cfg, size_reference,
                                                    min(cfg["validation"]["threshold_grid"]))
        selection = select_source_threshold(predictions, samples, cfg)
        is_best = best_key is None or selection["key"] > best_key
        if is_best:
            best_key = selection["key"]
            save_checkpoint(output / "best.pt", model, optimizer, scaler, epoch, cfg, selection["threshold"], size_reference, best_key, provenance)
        save_checkpoint(output / "last.pt", model, optimizer, scaler, epoch, cfg, selection["threshold"], size_reference, best_key, provenance)
        log = {"epoch": epoch, "loss_sum_over_optimizer_windows": totals, "counts": counts, "learning_rate": lr,
               "consistency_weight": weight, "source_validation": selection, "is_best": is_best,
               "training_seconds": training_seconds,
               "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated(device) if device.type == "cuda" else None,
               "configured_empty_sampling_fraction": loader.batch_sampler.actual_empty_fraction,
               "source_scene_balancing_active": loader.batch_sampler.scene_balancing_active,
               "source_validation_inference": model.last_inference_stats,
               "last_training_microbatch_diagnostics": layer_stats(model)}
        with (output / "metrics.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(log, ensure_ascii=False, allow_nan=False) + "\n")
        print(json.dumps({"epoch": epoch, "source_f1": selection["metrics"]["pooled"]["target_f1"],
                          "threshold": selection["threshold"], "training_seconds": training_seconds}), flush=True)
    return {"best_checkpoint": str((output / "best.pt").resolve()), "epochs": epochs, "audit": audit}

