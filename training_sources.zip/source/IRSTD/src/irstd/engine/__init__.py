"""Shared training and source-only model selection for all ablations."""

