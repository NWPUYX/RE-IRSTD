from pathlib import Path
import random
import numpy as np
import torch


def rng_state():
    return {"python": random.getstate(), "numpy": np.random.get_state(), "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"].cpu())
    if state["cuda"] is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all([s.cpu() for s in state["cuda"]])


def save_checkpoint(path, model, optimizer, scaler, epoch, cfg, threshold, size_reference, best_key, provenance):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    state = {"format_version": 1, "model": model.state_dict(), "optimizer": optimizer.state_dict(),
             "scaler": scaler.state_dict(), "epoch": epoch, "config": cfg, "threshold": threshold,
             "size_reference": size_reference, "best_key": best_key, "rng": rng_state(), "provenance": provenance}
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(state, temporary)
    temporary.replace(path)


def load_checkpoint(path, device="cpu"):
    # Locally generated trusted checkpoints contain optimizer/RNG Python objects.
    return torch.load(path, map_location=device, weights_only=False)

