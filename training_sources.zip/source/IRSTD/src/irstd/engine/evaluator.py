import torch
import time
from ..inference.decoder import decode
from ..metrics.detection import count_detections, summarize
from ..metrics.box_ap import box_average_precision
from ..diagnostics import autocast_dtype


@torch.no_grad()
def collect_predictions(model, loader, device, cfg, size_reference, minimum_threshold):
    was_training = model.training
    model.eval()
    predictions, samples = [], []
    elapsed = 0.
    for images, batch_samples in loader:
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        started = time.perf_counter()
        with torch.autocast(device_type=device.type, enabled=cfg["train"]["mixed_precision_backbone"] and device.type == "cuda",
                            dtype=autocast_dtype(device, cfg)):
            outputs = model(images.to(device))
        predictions.extend(decode(outputs, minimum_threshold, cfg["decode"], size_reference))
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        elapsed += time.perf_counter() - started
        samples.extend(batch_samples)
    model.last_inference_stats = {"forward_decode_seconds": elapsed,
                                  "mean_ms_per_image": elapsed * 1000 / max(len(samples), 1),
                                  "images": len(samples), "candidate_floor": minimum_threshold,
                                  "scope": "transfer, forward and decode; excludes disk IO and threshold scan; no warmup exclusion"}
    model.train(was_training)
    return predictions, samples


def at_threshold(predictions, threshold):
    results = []
    for prediction in predictions:
        keep = prediction["scores"] >= threshold
        results.append({key: value[keep] if value is not None else None for key, value in prediction.items()})
    return results


def threshold_key(metrics, cfg):
    pooled = metrics["pooled"]
    budget = cfg["validation"]["false_alarm_budget_per_image"]
    if budget is not None:
        if pooled["false_positive_targets_per_image"] > budget:
            return None
        return (pooled["recall"], -pooled["false_positive_targets_per_image"], pooled["target_f1"])
    return (pooled["target_f1"], -pooled["false_positive_targets_per_image"], pooled["recall"])


def select_source_threshold(predictions, samples, cfg):
    if any(s["split"] != "source_val" for s in samples):
        raise ValueError("Checkpoint/threshold selection is restricted to source_val")
    radius = cfg["evaluation"]["point_match_radius"]
    best, curve = None, []
    for threshold in cfg["validation"]["threshold_grid"]:
        selected = at_threshold(predictions, threshold)
        metrics = summarize([count_detections(p, s, radius) for p, s in zip(selected, samples)], cfg["evaluation"]["group_by"])
        key = threshold_key(metrics, cfg)
        curve.append({"threshold": threshold, **metrics["pooled"]})
        # Stable tie: the lowest threshold in the ordered grid wins.
        if key is not None and (best is None or key > best["key"]):
            best = {"threshold": threshold, "metrics": metrics, "key": key}
    if best is None:
        raise ValueError("No source-validation threshold satisfies the FP budget; no threshold may be selected from test data")
    best["curve"] = curve
    return best


def evaluate_frozen(predictions, samples, cfg, threshold, bootstrap=0):
    selected = at_threshold(predictions, threshold)
    radius = cfg["evaluation"]["point_match_radius"]
    report = summarize([count_detections(p, s, radius) for p, s in zip(selected, samples)],
                       cfg["evaluation"]["group_by"], bootstrap=bootstrap)
    report.update(threshold=threshold, point_match_radius=radius)
    report["radius_sensitivity"] = {str(r): summarize([count_detections(p, s, r) for p, s in zip(selected, samples)])["pooled"]
                                    for r in cfg["evaluation"]["point_radius_sensitivity"]}
    if cfg["task"]["size_head"] and cfg["evaluation"]["box_metrics_if_ground_truth_boxes"]:
        # AP uses the recorded low-score extraction floor, NOT the selected
        # operating threshold. Its separate maxDets=100 convention is reported.
        report["box_metrics"] = box_average_precision(predictions, samples)
    return report

