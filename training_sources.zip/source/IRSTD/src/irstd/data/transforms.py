import torch


def plan_transform(seed, epoch, index, cfg, enabled=True):
    generator = torch.Generator().manual_seed(seed + epoch * 1_000_003 + index * 97)
    if not enabled:
        return 0, False, False
    rotation = int(torch.randint(4, (), generator=generator)) if cfg["rotate_90"] else 0
    horizontal = bool(torch.rand((), generator=generator) < cfg["horizontal_flip_probability"])
    vertical = bool(torch.rand((), generator=generator) < cfg["vertical_flip_probability"])
    return rotation, horizontal, vertical


def geometric_transform(sample, plan):
    result = dict(sample)
    points, boxes = sample["points"].clone(), sample["boxes"].clone()
    image, background, ignore = sample["image"], sample["known_background_mask"], sample["ignore_mask"]
    rotation, horizontal, vertical = plan
    for _ in range(rotation):
        h, w = image.shape[-2:]
        points = torch.stack((points[:, 1], w - points[:, 0]), dim=1)
        boxes = torch.stack((boxes[:, 1], w - boxes[:, 2], boxes[:, 3], w - boxes[:, 0]), dim=1)
        image, background, ignore = (torch.rot90(value, 1, (-2, -1)) for value in (image, background, ignore))
    h, w = image.shape[-2:]
    if horizontal:
        points[:, 0] = w - points[:, 0]
        boxes = boxes[:, [2, 1, 0, 3]]
        boxes[:, [0, 2]] = w - boxes[:, [0, 2]]
        image, background, ignore = (value.flip(-1) for value in (image, background, ignore))
    if vertical:
        points[:, 1] = h - points[:, 1]
        boxes = boxes[:, [0, 3, 2, 1]]
        boxes[:, [1, 3]] = h - boxes[:, [1, 3]]
        image, background, ignore = (value.flip(-2) for value in (image, background, ignore))
    # Boundary points can map to W or H under reflection; retain a valid last cell.
    if len(points):
        bounds = points.new_tensor([w, h])
        upper = torch.nextafter(bounds, torch.zeros_like(bounds))
        points = torch.minimum(points.clamp_min(0), upper)
    result.update(image=image.contiguous(), points=points.contiguous(), boxes=boxes.contiguous(),
                  known_background_mask=background.contiguous(), ignore_mask=ignore.contiguous())
    return result

