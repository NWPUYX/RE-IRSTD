"""A documented JSONL interchange format, rather than a guessed dataset format."""
from pathlib import Path
import json
import numpy as np
from PIL import Image
import torch


def read_manifest(path):
    path = Path(path).resolve()
    records = []
    with path.open(encoding="utf-8-sig") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            if not isinstance(row, dict):
                raise ValueError(f"Manifest line {line_number} must be an object")
            for field in ("image", "known_background_mask", "ignore_mask"):
                if row.get(field):
                    row[field] = str((path.parent / row[field]).resolve())
            records.append(row)
    return records


def read_array(path):
    if Path(path).suffix.lower() == ".npy":
        array = np.load(path, allow_pickle=False)
    else:
        with Image.open(path) as image:
            array = np.array(image)
    if array.ndim != 2:
        raise ValueError(f"Expected a native single-channel 2D image/mask: {path}")
    return array


def read_image(path, scale):
    if scale is None or scale <= 0:
        raise ValueError("Specify the actual encoding divisor data.input_scale, including 1 for unit floats")
    array = np.array(read_array(path), dtype=np.float32, copy=True) / float(scale)
    if not np.isfinite(array).all():
        raise ValueError(f"Non-finite image: {path}")
    return torch.from_numpy(array)[None]


def read_mask(path, shape):
    if not path:
        return torch.zeros((1, *shape), dtype=torch.bool)
    array = read_array(path)
    if tuple(array.shape) != tuple(shape):
        raise ValueError(f"Mask/image shape mismatch: {path}")
    return torch.from_numpy(np.array(array != 0, dtype=np.bool_, copy=True))[None]


def annotations(row, shape, default_complete=None):
    h, w = shape
    points = np.asarray(row.get("points", []), dtype=np.float32).reshape(-1, 2)
    boxes = np.asarray(row.get("boxes", []), dtype=np.float32).reshape(-1, 4)
    convention = row.get("coordinate_format", "continuous")
    if convention == "pixel_center_index":
        points = points + .5
    elif convention != "continuous":
        raise ValueError("coordinate_format must be continuous or pixel_center_index")
    box_convention = row.get("box_format", "xyxy_half_open")
    if box_convention == "xyxy_closed_integer":
        if not np.equal(boxes, np.floor(boxes)).all():
            raise ValueError("Closed integer boxes require integer endpoints")
        boxes = boxes.copy()
        boxes[:, 2:] += 1
    elif box_convention != "xyxy_half_open":
        raise ValueError("Only xyxy_half_open/xyxy_closed_integer boxes supported")
    if not np.isfinite(points).all() or not np.isfinite(boxes).all():
        raise ValueError("Non-finite annotations")
    if len(points) and ((points < 0).any() or (points[:, 0] >= w).any() or (points[:, 1] >= h).any()):
        raise ValueError("Point outside [0,W)x[0,H)")
    if len(boxes) and ((boxes[:, :2] < 0).any() or (boxes[:, [0, 2]] > w).any()
                       or (boxes[:, [1, 3]] > h).any() or (boxes[:, 2:] <= boxes[:, :2]).any()):
        raise ValueError("Invalid/out-of-image box")
    complete = row.get("complete", default_complete)
    if not isinstance(complete, bool):
        raise ValueError(f"Explicit boolean complete required for {row.get('sample_id')}")
    return torch.from_numpy(points.copy()), torch.from_numpy(boxes.copy()), complete

