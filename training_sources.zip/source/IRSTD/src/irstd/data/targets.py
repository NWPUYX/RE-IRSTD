import math
import torch


def centers_and_boxes(sample):
    boxes, points = sample["boxes"], sample["points"]
    centers = torch.cat(((boxes[:, :2] + boxes[:, 2:]) / 2, points), dim=0)
    has_box = torch.cat((torch.ones(len(boxes), dtype=torch.bool), torch.zeros(len(points), dtype=torch.bool)))
    return centers, has_box


def build_targets(samples, cfg, size_reference=None, device="cpu"):
    h, w = samples[0]["image"].shape[-2:]
    heatmaps, positives, negatives, counts = [], [], [], []
    anchors, offsets, sizes, box_flags = [], [], [], []
    sigma = cfg["labels"]["heatmap_sigma"]
    radius = math.ceil(cfg["labels"]["gaussian_truncation_sigma"] * sigma)
    for batch_index, sample in enumerate(samples):
        if sample["image"].shape[-2:] != (h, w):
            raise ValueError("Mixed-shape target batch")
        centers, has_box = centers_and_boxes(sample)
        q = centers.floor().long()
        if len(q) and (q.unique(dim=0).shape[0] != len(q)):
            raise ValueError(f"Unresolved center-cell collision: {sample['sample_id']}")
        if len(q) and ((q < 0).any() or (q[:, 0] >= w).any() or (q[:, 1] >= h).any()):
            raise ValueError("Center outside image")
        positive = torch.zeros(1, h, w, dtype=torch.bool)
        heatmap = torch.zeros(1, h, w)
        for x, y in q.tolist():
            x0, x1, y0, y1 = max(0, x - radius), min(w, x + radius + 1), max(0, y - radius), min(h, y + radius + 1)
            ys, xs = torch.meshgrid(torch.arange(y0, y1), torch.arange(x0, x1), indexing="ij")
            gaussian = torch.exp(-((xs - x).square() + (ys - y).square()) / (2 * sigma ** 2))
            heatmap[0, y0:y1, x0:x1] = torch.maximum(heatmap[0, y0:y1, x0:x1], gaussian)
            positive[0, y, x] = True
        negative = torch.ones_like(positive) if sample["complete"] else sample["known_background_mask"].clone()
        negative &= ~sample["ignore_mask"] & ~positive
        heatmaps.append(heatmap)
        positives.append(positive)
        negatives.append(negative)
        counts.append(len(q))
        anchors.append(torch.cat((torch.full((len(q), 1), batch_index, dtype=torch.long), q), dim=1))
        offsets.append(centers - q)
        box_flags.append(has_box)
        target_sizes = torch.zeros(len(q), 2)
        if has_box.any() and cfg["task"]["size_head"] and size_reference is None:
            raise ValueError("True-box size supervision requires source-train median reference sizes")
        if has_box.any() and size_reference is not None:
            reference = torch.as_tensor(size_reference, dtype=torch.float32)
            if reference.shape != (2,) or not torch.isfinite(reference).all() or (reference <= 0).any():
                raise ValueError("Positive finite width/height references required")
            target_sizes[has_box] = ((sample["boxes"][:, 2:] - sample["boxes"][:, :2]) / reference).log()
        sizes.append(target_sizes)
    return {"heatmap": torch.stack(heatmaps).to(device), "positive": torch.stack(positives).to(device),
            "negative": torch.stack(negatives).to(device), "counts": torch.tensor(counts, device=device),
            "anchors": torch.cat(anchors).to(device), "offsets": torch.cat(offsets).to(device),
            "sizes": torch.cat(sizes).to(device), "has_box": torch.cat(box_flags).to(device)}


def gather_centers(feature, anchors):
    b, x, y = anchors.unbind(dim=1)
    return feature[b, :, y, x]

