from torch.utils.data import Dataset
import torch
from .adapter import read_manifest, read_image, read_mask, read_array, annotations
from .transforms import plan_transform, geometric_transform


class InfraredDataset(Dataset):
    def __init__(self, manifest, split, cfg, augment=False, seed=0):
        self.records = [r for r in read_manifest(manifest) if r.get("split") == split]
        if not self.records:
            raise ValueError(f"No records for split={split}")
        self.cfg, self.split, self.augment, self.seed, self.epoch = cfg, split, augment, seed, 0
        self.shapes = [tuple(read_array(r["image"]).shape) for r in self.records]

    def __len__(self):
        return len(self.records)

    def set_epoch(self, epoch):
        self.epoch = epoch

    def plan(self, index):
        return plan_transform(self.seed, self.epoch, index, self.cfg["augmentation"], self.augment)

    def output_shape(self, index):
        shape = self.shapes[index]
        return shape[::-1] if self.plan(index)[0] % 2 else shape

    def raw_sample(self, index):
        row = self.records[index]
        shape = self.shapes[index]
        points, boxes, complete = annotations(row, shape, self.cfg["task"]["annotation_complete"])
        return {"image": read_image(row["image"], self.cfg["data"]["input_scale"]),
                "points": points, "boxes": boxes, "complete": complete,
                "known_background_mask": read_mask(row.get("known_background_mask"), shape),
                "ignore_mask": read_mask(row.get("ignore_mask"), shape),
                "sample_id": row["sample_id"], "split": self.split,
                "scene_id": row.get("scene_id"), "sensor_id": row.get("sensor_id"),
                "acquisition_group": row.get("acquisition_group"),
                "verified_target_free": row.get("verified_target_free", False)}

    def __getitem__(self, index):
        return geometric_transform(self.raw_sample(index), self.plan(index))


def collate_samples(samples):
    if len({tuple(s["image"].shape) for s in samples}) != 1:
        raise ValueError("Same-shape batching required; do not pad unrelated native shapes")
    return torch.stack([s["image"] for s in samples]), samples

