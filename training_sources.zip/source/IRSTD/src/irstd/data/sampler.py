from collections import Counter, defaultdict
import numpy as np
from torch.utils.data import Sampler


class SameShapeBatchSampler(Sampler):
    """Replacement sampling is explicit; validation visits each image exactly once."""
    def __init__(self, dataset, batch_size, shuffle=False, balanced=False, empty_fraction=.25, seed=0):
        self.dataset, self.batch_size, self.shuffle = dataset, batch_size, shuffle
        self.balanced, self.empty_fraction, self.seed = balanced, empty_fraction, seed
        if batch_size < 1:
            raise ValueError("batch_size must be positive")
        self.actual_empty_fraction = None
        self.scene_balancing_active = False

    def batches(self):
        ds = self.dataset
        rng = np.random.default_rng(self.seed + ds.epoch)
        indices = list(range(len(ds)))
        if self.shuffle:
            empty = np.array([r.get("complete", ds.cfg["task"]["annotation_complete"]) is True
                              and not r.get("points") and not r.get("boxes") for r in ds.records])
            weights = np.ones(len(ds), dtype=np.float64)
            scenes = [r.get("scene_id") for r in ds.records]
            # With missing real scene IDs, do not invent IDs or pretend to balance.
            use_scenes = self.balanced and all(s is not None for s in scenes) and len(set(scenes)) >= 2
            self.scene_balancing_active = use_scenes
            if use_scenes:
                counts = Counter((scene, bool(is_empty)) for scene, is_empty in zip(scenes, empty))
                weights = np.array([1 / counts[(scene, bool(is_empty))] for scene, is_empty in zip(scenes, empty)])
            if empty.any() and (~empty).any():
                fraction = min(self.empty_fraction, float(empty.mean()))
                weights[empty] *= fraction / weights[empty].sum()
                weights[~empty] *= (1 - fraction) / weights[~empty].sum()
                self.actual_empty_fraction = fraction
            else:
                self.actual_empty_fraction = float(empty.mean())
            weights /= weights.sum()
            indices = rng.choice(len(ds), size=len(ds), replace=True, p=weights).tolist()
        buckets = defaultdict(list)
        for i in indices:
            buckets[ds.output_shape(i)].append(i)
        batches = [bucket[j:j + self.batch_size] for bucket in buckets.values()
                   for j in range(0, len(bucket), self.batch_size)]
        if self.shuffle:
            rng.shuffle(batches)
        return batches

    def __iter__(self):
        return iter(self.batches())

    def __len__(self):
        return len(self.batches())

