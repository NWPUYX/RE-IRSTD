from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import numpy as np
from .adapter import read_manifest, read_array, read_mask, annotations
from .targets import centers_and_boxes


def audit_manifest(path, cfg, require_train=False):
    records = read_manifest(path)
    ids, hashes, groups = set(), defaultdict(set), defaultdict(set)
    summary = Counter()
    warnings, train_sizes, negative_evidence = [], [], 0
    train_has_boxes = False
    shape_counts, scene_splits = Counter(), defaultdict(set)
    content_fingerprint = hashlib.sha256(Path(path).read_bytes())
    allowed_splits = {"source_train", "source_val", "test"}
    for row in records:
        sample_id = row.get("sample_id")
        if not isinstance(sample_id, str) or not sample_id or sample_id in ids:
            raise ValueError("Unique nonempty string sample_id required")
        ids.add(sample_id)
        split = row.get("split")
        if split not in allowed_splits:
            raise ValueError(f"Explicit source_train/source_val/test split required: {sample_id}")
        array = read_array(row["image"])
        shape = array.shape
        if min(shape) < 32 or not np.isfinite(array).all():
            raise ValueError(f"Invalid image size/values: {sample_id}")
        points, boxes, complete = annotations(row, shape, cfg["task"]["annotation_complete"])
        if len(points) and "point" not in cfg["task"]["annotation_types"]:
            raise ValueError("Point labels excluded by task.annotation_types")
        if len(boxes) and "box" not in cfg["task"]["annotation_types"]:
            raise ValueError("Box labels excluded by task.annotation_types")
        centers, _ = centers_and_boxes({"points": points, "boxes": boxes})
        q = centers.floor().long()
        if len(q) != q.unique(dim=0).shape[0]:
            raise ValueError(f"Duplicate/overlapping center-cell annotations: {sample_id}")
        background = read_mask(row.get("known_background_mask"), shape)
        ignore = read_mask(row.get("ignore_mask"), shape)
        negative = (~ignore) if complete else (background & ~ignore)
        if len(q):
            negative[0, q[:, 1], q[:, 0]] = False
        if split == "source_train":
            negative_evidence += int(negative.sum())
            train_has_boxes |= len(boxes) > 0
            train_sizes.extend((boxes[:, 2:] - boxes[:, :2]).tolist())
        if split in ("source_val", "test") and not complete:
            raise ValueError(f"Detection evaluation requires complete annotations: {sample_id}")
        if row.get("verified_target_free", False) and (not complete or len(centers)):
            raise ValueError(f"Invalid verified target-free claim: {sample_id}")
        digest = hashlib.sha256(str(shape).encode() + np.ascontiguousarray(array, dtype=np.float32).tobytes()).hexdigest()
        hashes[digest].add(split)
        content_fingerprint.update(sample_id.encode())
        content_fingerprint.update(digest.encode())
        content_fingerprint.update(background.numpy().tobytes())
        content_fingerprint.update(ignore.numpy().tobytes())
        if row.get("acquisition_group") is not None:
            groups[row["acquisition_group"]].add(split)
        if row.get("scene_id") is not None:
            scene_splits[row["scene_id"]].add(split)
        shape_counts[str(shape)] += 1
        summary[f"{split}_images"] += 1
        summary[f"{split}_targets"] += len(centers)
        summary[f"{split}_boxes"] += len(boxes)
        summary[f"{split}_complete_empty"] += int(complete and not len(centers))
    if any(len(splits) > 1 for splits in hashes.values()):
        raise ValueError("Exact duplicate image content across data splits")
    if any(len(splits) > 1 for splits in groups.values()):
        raise ValueError("Acquisition-group leakage across splits")
    if any("test" in splits and len(splits) > 1 for splits in scene_splits.values()):
        warnings.append("Test scene IDs overlap source scenes: this is not unseen-scene testing; review the holdout protocol")
    warnings.append("Exact duplicates checked; near-duplicate and cross-public-dataset overlap still require acquisition/source review")
    if any(not row.get("acquisition_group") for row in records):
        warnings.append("Missing acquisition_group: grouped bootstrap unavailable for affected splits")
    if require_train and (not summary["source_train_images"] or not summary["source_val_images"] or not negative_evidence):
        raise ValueError("Training needs source_train, source_val, and known negative supervision")
    return {"counts": dict(summary), "shape_counts": dict(shape_counts), "warnings": warnings,
            "source_train_has_boxes": train_has_boxes,
            "size_reference": np.median(train_sizes, axis=0).tolist() if train_sizes else None,
            "source_train_negative_pixels": negative_evidence, "acquisition_groups": len(groups),
            "manifest_and_content_sha256": content_fingerprint.hexdigest()}
