import argparse
from pathlib import Path
import json
import torch
from .config import load_config
from .diagnostics import write_json, preview_sample, profile_model


def main(argv=None):
    parser = argparse.ArgumentParser(description="RE-IRSTD-v1: center/offset detection, optional true-box size")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("audit", "preview", "train", "profile"):
        sub = commands.add_parser(name)
        sub.add_argument("--config", default="config_start.yaml")
        sub.add_argument("--experiment", default="D")
        sub.add_argument("--override", help="YAML with explicit data settings or deliberate ablations")
        if name != "profile":
            sub.add_argument("--manifest", required=True)
        if name in ("train", "profile"):
            sub.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
        if name in ("audit", "profile"):
            sub.add_argument("--output")
        if name == "preview":
            sub.add_argument("--output", required=True)
            sub.add_argument("--count", type=int, default=8)
        if name == "train":
            sub.add_argument("--output", required=True)
            sub.add_argument("--seed", type=int, default=0)
            sub.add_argument("--microbatch", type=int, default=1)
            sub.add_argument("--resume")
        if name == "profile":
            sub.add_argument("--shape", type=int, nargs=2, default=[256, 256])
            sub.add_argument("--size-head", action="store_true")
            sub.add_argument("--repetitions", type=int, default=10)
    evaluate = commands.add_parser("evaluate")
    evaluate.add_argument("--checkpoint", required=True)
    evaluate.add_argument("--manifest", required=True)
    evaluate.add_argument("--split", choices=["source_val", "test"], default="test")
    evaluate.add_argument("--output", required=True)
    evaluate.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    evaluate.add_argument("--bootstrap", type=int, default=1000)
    evaluate.add_argument("--ap-score-floor", type=float, default=.001,
                          help="Recorded candidate floor for AP/threshold curves; not the operating threshold")
    predict = commands.add_parser("predict")
    predict.add_argument("--checkpoint", required=True)
    predict.add_argument("--images", nargs="+", required=True)
    predict.add_argument("--output", required=True)
    predict.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args(argv)
    if args.command == "predict":
        from .inference.predictor import Predictor
        predictor = Predictor(args.checkpoint, args.device)
        write_json(args.output, [predictor.predict(path) for path in args.images])
        return
    if args.command == "evaluate":
        from .engine.checkpoint import load_checkpoint
        from .models.detector import Detector
        from .data.dataset import InfraredDataset
        from .data.audit import audit_manifest
        from .engine.trainer import make_loader
        from .engine.evaluator import collect_predictions, evaluate_frozen, at_threshold
        from .metrics.detection import count_detections, summarize
        state = load_checkpoint(args.checkpoint)
        cfg = state["config"]
        audit = audit_manifest(args.manifest, cfg)
        device = torch.device(args.device)
        model = Detector(cfg).to(device)
        model.load_state_dict(state["model"])
        data = InfraredDataset(args.manifest, args.split, cfg)
        floor = min(args.ap_score_floor, state["threshold"], min(cfg["validation"]["threshold_grid"]))
        predictions, samples = collect_predictions(model, make_loader(data), device, cfg, state["size_reference"], floor)
        report = evaluate_frozen(predictions, samples, cfg, state["threshold"], args.bootstrap)
        report.update(split=args.split, ap_candidate_score_floor=floor, data_audit=audit)
        report["posthoc_threshold_curve"] = [
            {"threshold": t, **summarize([count_detections(p, s, cfg["evaluation"]["point_match_radius"])
                                         for p, s in zip(at_threshold(predictions, t), samples)])["pooled"]}
            for t in cfg["validation"]["threshold_grid"]]
        write_json(args.output, report)
        print(json.dumps(report["pooled"], ensure_ascii=False))
        return
    cfg = load_config(args.config, args.experiment, args.override)
    if args.command == "audit":
        from .data.audit import audit_manifest
        result = audit_manifest(args.manifest, cfg)
    elif args.command == "profile":
        from .models.detector import Detector
        cfg["task"]["size_head"] = args.size_head
        device = torch.device(args.device)
        result = profile_model(Detector(cfg).to(device), args.shape, device, args.repetitions)
    elif args.command == "train":
        from .engine.trainer import train
        result = train(args.manifest, cfg, args.output, args.device, args.microbatch, args.seed, args.resume)
    else:
        from .data.audit import audit_manifest
        from .data.dataset import InfraredDataset
        from .engine.trainer import donor_indices, choose_donor
        from .augmentation.background_swap import swap_background
        audit_manifest(args.manifest, cfg)
        dataset = InfraredDataset(args.manifest, "source_train", cfg, augment=True)
        donors, result = donor_indices(dataset), []
        for i in range(min(args.count, len(dataset))):
            sample = dataset[i]
            root = Path(args.output) / f"sample_{i:04d}"
            preview_sample(dataset.raw_sample(i), root.with_name(root.name + "_original.png"))
            preview_sample(sample, root.with_name(root.name + "_geometry.png"))
            record = {"sample_id": sample["sample_id"], "transform": dataset.plan(i)}
            if cfg["augmentation"]["remote_background_swap"] and sample["complete"]:
                donor = choose_donor(sample, dataset, donors, cfg["augmentation"])
                if donor is not None and (not len(sample["points"]) or cfg["augmentation"].get("point_protection_approved", False)):
                    swapped, alpha = swap_background(sample, donor, cfg["augmentation"])
                    preview_sample(sample, root.with_name(root.name + "_swap.png"), swapped)
                    preview_sample(sample, root.with_name(root.name + "_alpha.png"), alpha)
                    record["donor"] = donor["sample_id"]
            result.append(record)
        write_json(Path(args.output) / "preview_manifest.json", result)
    if getattr(args, "output", None) and args.command in ("audit", "profile"):
        write_json(args.output, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
