from pathlib import Path
import torch
from ..models.detector import Detector
from ..data.adapter import read_image
from ..engine.checkpoint import load_checkpoint
from ..diagnostics import autocast_dtype
from .decoder import decode


class Predictor:
    def __init__(self, checkpoint, device="cpu"):
        self.device = torch.device(device)
        state = load_checkpoint(checkpoint)
        self.cfg, self.threshold, self.size_reference = state["config"], state["threshold"], state["size_reference"]
        self.model = Detector(self.cfg).to(self.device).eval()
        self.model.load_state_dict(state["model"])

    @torch.no_grad()
    def predict(self, image_path):
        image = read_image(image_path, self.cfg["data"]["input_scale"])[None].to(self.device)
        with torch.autocast(device_type=self.device.type, enabled=self.cfg["train"]["mixed_precision_backbone"] and self.device.type == "cuda",
                            dtype=autocast_dtype(self.device, self.cfg)):
            outputs = self.model(image)
        result = decode(outputs, self.threshold, self.cfg["decode"], self.size_reference)[0]
        return {"image": str(Path(image_path).resolve()), "threshold": self.threshold,
                **{key: value.tolist() if value is not None else None for key, value in result.items()}}
