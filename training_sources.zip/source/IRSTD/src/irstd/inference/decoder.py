import numpy as np
import torch
from torch.nn import functional as F


def _plateau_representatives(score, candidates):
    """8-connected equal-score local maxima: keep lexicographically first cell."""
    visited = np.zeros_like(candidates, dtype=np.bool_)
    h, w = candidates.shape
    representatives = []
    for y, x in np.argwhere(candidates):
        if visited[y, x]:
            continue
        representatives.append((int(x), int(y)))
        visited[y, x] = True
        stack = [(int(x), int(y))]
        while stack:
            px, py = stack.pop()
            for ny in range(max(0, py - 1), min(h, py + 2)):
                for nx in range(max(0, px - 1), min(w, px + 2)):
                    if candidates[ny, nx] and not visited[ny, nx] and score[ny, nx] == score[py, px]:
                        visited[ny, nx] = True
                        stack.append((nx, ny))
    representatives.sort(key=lambda q: (-float(score[q[1], q[0]]), q[1], q[0]))
    return representatives


def box_iou(box, others):
    left = torch.maximum(box[:2], others[:, :2])
    right = torch.minimum(box[2:], others[:, 2:])
    intersection = (right - left).clamp_min(0).prod(1)
    area = (box[2:] - box[:2]).clamp_min(0).prod()
    other_areas = (others[:, 2:] - others[:, :2]).clamp_min(0).prod(1)
    return intersection / (area + other_areas - intersection).clamp_min(1e-12)


def nms(boxes, scores, threshold):
    order = torch.argsort(scores, descending=True, stable=True)
    keep = []
    while len(order):
        current = order[0]
        keep.append(current)
        order = order[1:]
        if len(order):
            order = order[box_iou(boxes[current], boxes[order]) <= threshold]
    return torch.stack(keep) if keep else torch.empty(0, dtype=torch.long, device=boxes.device)


@torch.no_grad()
def decode(outputs, threshold, cfg, size_reference=None):
    if not 0 < threshold <= 1:
        raise ValueError("Threshold must lie in (0,1]")
    scores = outputs["center_logits"].float().sigmoid()
    if not torch.isfinite(scores).all() or not torch.isfinite(outputs["offsets"]).all():
        raise ValueError("Non-finite model predictions")
    local = F.max_pool2d(scores, 3, stride=1, padding=1)
    candidate_mask = (scores == local) & (scores >= threshold)
    results = []
    for b in range(scores.shape[0]):
        h, w = scores.shape[-2:]
        positions = _plateau_representatives(scores[b, 0].cpu().numpy(), candidate_mask[b, 0].cpu().numpy())
        q = torch.tensor(positions, device=scores.device, dtype=torch.long).reshape(-1, 2)
        x, y = q.unbind(1)
        centers = q.float() + outputs["offsets"][b, :, y, x].transpose(0, 1).float().clamp(0, 1 - 1e-6)
        bounds = centers.new_tensor([w, h])
        centers = torch.minimum(centers, torch.nextafter(bounds, torch.zeros_like(bounds)))
        confidence = scores[b, 0, y, x]
        boxes = None
        if outputs["log_size"] is not None:
            if size_reference is None or min(size_reference) <= 0:
                raise ValueError("Box decoding requires source-train median reference sizes")
            raw_size = outputs["log_size"][b, :, y, x].transpose(0, 1).float()
            if not torch.isfinite(raw_size).all():
                raise ValueError("Non-finite log sizes")
            reference = scores.new_tensor(size_reference)
            upper = (scores.new_tensor([w, h]) / reference).log()
            wh = reference * torch.minimum(raw_size.clamp_min(-20), upper).exp()
            boxes = torch.cat((centers - wh / 2, centers + wh / 2), dim=1)
            boxes[:, [0, 2]] = boxes[:, [0, 2]].clamp(0, w)
            boxes[:, [1, 3]] = boxes[:, [1, 3]].clamp(0, h)
            if cfg["box_nms_iou"] is not None:
                keep = nms(boxes, confidence, cfg["box_nms_iou"])
                centers, confidence, boxes = centers[keep], confidence[keep], boxes[keep]
        results.append({"centers": centers.cpu(), "scores": confidence.cpu(), "boxes": boxes.cpu() if boxes is not None else None})
    return results

