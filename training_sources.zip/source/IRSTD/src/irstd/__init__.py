"""RE-IRSTD-v1. Center responses are detection scores, not segmentation masks."""

__version__ = "0.1.0"

