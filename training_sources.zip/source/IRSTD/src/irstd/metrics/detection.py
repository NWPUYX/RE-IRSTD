from collections import defaultdict
import numpy as np
from .matching import match_centers
from ..data.targets import centers_and_boxes


def count_detections(prediction, sample, radius):
    if not sample["complete"]:
        raise ValueError("Ordinary TP/FP/FN evaluation requires complete labels")
    truth, _ = centers_and_boxes(sample)
    predicted = prediction["centers"]
    if sample["ignore_mask"].any():
        # Ignore GT/predictions in excluded regions using the same center rule.
        def visible(centers):
            q = centers.floor().long()
            return ~sample["ignore_mask"][0, q[:, 1], q[:, 0]]
        truth = truth[visible(truth)]
        predicted = predicted[visible(predicted)]
    pairs = match_centers(predicted.numpy(), truth.numpy(), radius)
    return {"tp": len(pairs), "fp": len(predicted) - len(pairs), "fn": len(truth) - len(pairs),
            "images": 1, "pixels": int((~sample["ignore_mask"]).sum()),
            "scene_id": sample["scene_id"], "sensor_id": sample["sensor_id"],
            "acquisition_group": sample["acquisition_group"]}


def pooled(rows):
    values = {key: sum(row[key] for row in rows) for key in ("tp", "fp", "fn", "images", "pixels")}
    tp, fp, fn = (values[key] for key in ("tp", "fp", "fn"))
    # Zero-denominator conventions are explicit and give empty-only sets F1=0.
    values.update(recall=tp / (tp + fn) if tp + fn else 0.,
                  precision=tp / (tp + fp) if tp + fp else 0.,
                  target_f1=2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.,
                  false_positive_targets_per_image=fp / values["images"] if values["images"] else 0.,
                  false_positive_targets_per_megapixel=fp * 1e6 / values["pixels"] if values["pixels"] else 0.)
    values["pd"] = values["recall"]
    return values


def summarize(rows, group_by=("scene_id", "sensor_id"), bootstrap=0, seed=0):
    result = {"pooled": pooled(rows), "groups": {}}
    for field in group_by:
        grouped = defaultdict(list)
        for row in rows:
            grouped[str(row.get(field))].append(row)
        result["groups"][field] = {key: pooled(value) for key, value in grouped.items()}
    acquisition = defaultdict(list)
    for row in rows:
        acquisition[row.get("acquisition_group")].append(row)
    result["independent_groups"] = len(acquisition) if None not in acquisition else None
    result["acquisition_group_results"] = {str(key): pooled(value) for key, value in acquisition.items()}
    if bootstrap and None not in acquisition and len(acquisition) >= 5:
        keys, samples = list(acquisition), []
        rng = np.random.default_rng(seed)
        for _ in range(bootstrap):
            chosen = rng.choice(len(keys), size=len(keys), replace=True)
            samples.append(pooled([row for i in chosen for row in acquisition[keys[i]]]))
        fields = ("recall", "precision", "target_f1", "false_positive_targets_per_image", "false_positive_targets_per_megapixel")
        result["bootstrap_95_ci"] = {field: np.percentile([s[field] for s in samples], [2.5, 97.5]).tolist() for field in fields}
    elif bootstrap:
        result["bootstrap_status"] = "Not computed: missing group IDs or fewer than 5 independent groups; inspect per-group results"
    return result

