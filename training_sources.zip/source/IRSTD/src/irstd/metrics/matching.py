import numpy as np


def linear_assignment(cost):
    """Rectangular Hungarian algorithm (rows <= columns), deterministic on ties."""
    cost = np.asarray(cost, dtype=np.float64)
    n, m = cost.shape
    if n > m or not np.isfinite(cost).all():
        raise ValueError("Finite cost with rows<=columns required")
    u, v = np.zeros(n + 1), np.zeros(m + 1)
    p, way = np.zeros(m + 1, dtype=int), np.zeros(m + 1, dtype=int)
    for i in range(1, n + 1):
        p[0] = i
        minimum = np.full(m + 1, np.inf)
        used = np.zeros(m + 1, dtype=np.bool_)
        j0 = 0
        while True:
            used[j0] = True
            i0 = p[j0]
            remaining = np.flatnonzero(~used[1:]) + 1
            current = cost[i0 - 1, remaining - 1] - u[i0] - v[remaining]
            better = current < minimum[remaining]
            changed = remaining[better]
            minimum[changed] = current[better]
            way[changed] = j0
            j1 = remaining[np.argmin(minimum[remaining])]
            delta = minimum[j1]
            u[p[used]] += delta
            v[used] -= delta
            minimum[~used] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    assigned = np.empty(n, dtype=int)
    for j in range(1, m + 1):
        if p[j]:
            assigned[p[j] - 1] = j - 1
    return assigned


def match_centers(predicted, truth, radius):
    predicted = np.asarray(predicted, dtype=np.float64).reshape(-1, 2)
    truth = np.asarray(truth, dtype=np.float64).reshape(-1, 2)
    if radius <= 0 or not np.isfinite(predicted).all() or not np.isfinite(truth).all():
        raise ValueError("Finite centers and positive radius required")
    if not len(predicted) or not len(truth):
        return []
    transposed = len(predicted) > len(truth)
    rows, columns = (truth, predicted) if transposed else (predicted, truth)
    distances = np.linalg.norm(rows[:, None] - columns[None], axis=2)
    # Dummy penalty dominates the sum of all feasible distances: maximize TP
    # first, then minimize total Euclidean distance among feasible matchings.
    penalty = (len(rows) + 1) * (radius + 1)
    costs = np.concatenate((np.where(distances <= radius, distances, 2 * penalty),
                            np.full((len(rows), len(rows)), penalty)), axis=1)
    assignment = linear_assignment(costs)
    pairs = []
    for row, column in enumerate(assignment):
        if column < len(columns) and distances[row, column] <= radius:
            pairs.append((int(column), int(row)) if transposed else (int(row), int(column)))
    return sorted(pairs)

