"""Single-category COCO-style AP, all area sizes, maxDets=100, 101 recall points.

Only complete, entirely box-annotated images without ignore masks are eligible.
This is not segmentation AP, nor the additional COCO crowd/area metrics.
"""
import numpy as np


def _iou(box, boxes):
    box, boxes = np.asarray(box, dtype=np.float64), np.asarray(boxes, dtype=np.float64)
    intersection = np.maximum(0, np.minimum(box[2:], boxes[:, 2:]) - np.maximum(box[:2], boxes[:, :2])).prod(1)
    area = np.maximum(0, box[2:] - box[:2]).prod()
    other = np.maximum(0, boxes[:, 2:] - boxes[:, :2]).prod(1)
    return intersection / np.maximum(area + other - intersection, 1e-12)


def box_average_precision(predictions, samples):
    eligible = [(prediction, sample) for prediction, sample in zip(predictions, samples)
                if sample["complete"] and not len(sample["points"]) and not sample["ignore_mask"].any()]
    ground_truth_count = sum(len(sample["boxes"]) for _, sample in eligible)
    if not ground_truth_count:
        return {"status": "No eligible ground-truth boxes", "eligible_images": len(eligible)}
    if any(prediction["boxes"] is None for prediction, _ in eligible):
        return {"status": "Size head unavailable", "eligible_images": len(eligible)}
    aps = []
    for threshold in np.linspace(.5, .95, 10):
        scores, true_positive = [], []
        for prediction, sample in eligible:
            truth = sample["boxes"].numpy()
            matched = np.zeros(len(truth), dtype=np.bool_)
            order = np.argsort(-prediction["scores"].numpy(), kind="stable")[:100]
            for index in order:
                box = prediction["boxes"][index].numpy()
                overlaps = _iou(box, truth)
                available = np.flatnonzero((overlaps >= min(threshold, 1 - 1e-10)) & ~matched)
                hit = bool(len(available))
                if hit:
                    # COCO's sequential >= comparison takes the last GT on an
                    # exact IoU tie; stable score/GT order is part of the metric.
                    highest = overlaps[available].max()
                    selected = available[overlaps[available] == highest][-1]
                    matched[selected] = True
                scores.append(float(prediction["scores"][index]))
                true_positive.append(hit)
        order = np.argsort(-np.asarray(scores), kind="stable")
        tp = np.cumsum(np.asarray(true_positive)[order])
        fp = np.cumsum(~np.asarray(true_positive, dtype=np.bool_)[order])
        recall = tp / ground_truth_count
        precision = tp / np.maximum(tp + fp, 1)
        precision = np.maximum.accumulate(precision[::-1])[::-1]
        values = [precision[recall >= r].max() if np.any(recall >= r) else 0. for r in np.linspace(0, 1, 101)]
        aps.append(float(np.mean(values)))
    return {"AP50": aps[0], "AP": float(np.mean(aps)), "iou_thresholds": "0.50:0.05:0.95",
            "eligible_images": len(eligible), "ground_truth_boxes": ground_truth_count,
            "max_detections_per_image_for_AP": 100, "recall_interpolation_points": 101}
