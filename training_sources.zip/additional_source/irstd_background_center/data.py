from collections import defaultdict
import math
from pathlib import Path
import random
import sys
import numpy as np
import torch
from torch.utils.data import Dataset,DataLoader
from irstd_v2.data import Data,collate
from data_pipeline import worker_seed
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor_sota'))
from scipy.ndimage import distance_transform_edt


def fast_distance(protected):
    if not protected.any():return np.full(protected.shape,np.inf)
    return distance_transform_edt(~protected)


def union_swap(recipient,donor,cfg):
    if not recipient['complete'] or not donor['complete'] or donor.get('split')!='source_train':
        raise ValueError('Requires complete source-train donor labels')
    protected=(~(recipient['valid_mask']&donor['valid_mask']))[0].numpy().copy()
    for boxes in [recipient['boxes'],donor['boxes']]:
        for x1,y1,x2,y2 in boxes.tolist():
            m=cfg['protection_margin']
            left,top,right,bottom=max(0,math.floor(x1-m)),max(0,math.floor(y1-m)),min(512,math.ceil(x2+m)),min(512,math.ceil(y2+m))
            protected[top:bottom,left:right]=True
    distance=fast_distance(protected)
    a=.5*(1-np.cos(np.pi*np.minimum(distance/cfg['transition_width'],1.)))
    alpha=torch.from_numpy(a.astype(np.float32))[None]
    return (1-alpha)*recipient['image']+alpha*donor['image'],alpha,torch.from_numpy(protected)[None]


class Pairs(Dataset):
    def __init__(self,cfg,split='train',seed=3407):
        self.cfg=cfg;self.base=Data('DAUB-R',split,cfg);self.donors=Data('DAUB-R','train',cfg)
        self.records=self.base.records;self.seed=seed;self.epoch=0
        groups=defaultdict(list)
        for i,r in enumerate(self.records):groups[r['group']].append(i)
        self.indices=list(range(len(self.records))) if split=='train' else [ids[j] for ids in groups.values() for j in np.linspace(0,len(ids)-1,min(12,len(ids)),dtype=int)]
        donor_groups=defaultdict(list)
        for i,r in enumerate(self.donors.records):donor_groups[r['group']].append(i)
        self.eligible={g:[i for dg,ids in donor_groups.items() if dg!=g for i in ids] for g in groups}
        assert all(self.eligible.values())

    def __len__(self):return len(self.indices)

    def __getitem__(self,index):
        i=self.indices[index];sample=self.base.base_sample(i)
        rng=random.Random(self.seed+self.epoch*1000003+i*97)
        if self.base.split=='source_train' and rng.random()<.5:
            sample=dict(sample);sample['image']=sample['image'].flip(-1)
            sample['boxes']=sample['boxes'][:,[2,1,0,3]].clone();sample['boxes'][:,[0,2]]=512-sample['boxes'][:,[0,2]]
            for field in ['valid_mask','ignore_mask','known_background_mask']:sample[field]=sample[field].flip(-1)
        donor_index=rng.choice(self.eligible[self.records[i]['group']]);donor=self.donors.base_sample(donor_index)
        image,alpha,_=union_swap(sample,donor,self.cfg);assert alpha.max()>0
        original={**sample,'view_type':'native'}
        swapped={**sample,'image':image,'view_type':'background_swap','donor_id':donor['sample_id']}
        return original,swapped


def collate_pairs(batch):
    original,swapped=zip(*batch);return collate([*original,*swapped])


def loader(cfg,split='train'):
    data=Pairs(cfg,split)
    return DataLoader(data,batch_size=2,shuffle=split=='train',num_workers=cfg['workers'],collate_fn=collate_pairs,
        worker_init_fn=worker_seed,persistent_workers=False,pin_memory=False,
        generator=torch.Generator().manual_seed(3407),drop_last=False)


class SwappedValidation(Dataset):
    def __init__(self,cfg):self.pairs=Pairs(cfg,'val');self.records=self.pairs.records
    def __len__(self):return len(self.pairs)
    def __getitem__(self,i):return self.pairs[i][1]


def swapped_loader(cfg):
    return DataLoader(SwappedValidation(cfg),batch_size=4,num_workers=cfg['workers'],collate_fn=collate,
        worker_init_fn=worker_seed,persistent_workers=False,pin_memory=False)
