"""Frozen-body center-head background robustness experiment."""
