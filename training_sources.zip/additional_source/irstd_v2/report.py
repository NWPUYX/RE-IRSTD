import json
import statistics
from .settings import ROOT, HOME, DOMAINS, SEEDS, write_json, now


def promotion():
    baseline = json.loads((HOME / "baselines" / "DAUB-R_seed3407.json").read_text(encoding="utf-8"))
    candidate = json.loads((HOME / "runs" / "DAUB-R" / "seed_3407" / "best_source_validation.json").read_text(encoding="utf-8"))
    cfg = json.loads((HOME / "recipe.json").read_text(encoding="utf-8"))
    b, v = baseline["validation"], candidate["validation"]
    bp, vp = baseline["geometry_probe"], candidate["geometry_probe"]
    gates = {
        "source_group_AP50_retained": v["group_macro_AP50"] >= b["group_macro_AP50"] - cfg["promotion"]["maximum_group_AP50_drop"],
        "source_pooled_AP50_retained": v["pooled"]["AP50"] >= b["pooled"]["AP50"] - cfg["promotion"]["maximum_pooled_AP50_drop"],
        "source_geometry_error_improved": vp["log_size_error"] <= bp["log_size_error"] * cfg["promotion"]["maximum_geometry_log_error_ratio"],
    }
    result = {"passed": all(gates.values()), "gates": gates, "baseline": {"validation": b, "geometry": bp},
              "candidate": candidate, "scope": "Source-validation only; no target test scores read for promotion", "updated_at": now()}
    write_json(HOME / "promotion.json", result)
    return result


def summarize():
    records = {}
    for path in (HOME / "runs").glob("*/seed_*/results.json"):
        for row in json.loads(path.read_text(encoding="utf-8")):
            key = (row["source"], row["target"], row["seed"])
            if key in records:
                raise ValueError("Duplicate v2 result cell")
            records[key] = row
    lines = ["# IRSTD-v2优化实验状态与结果", "", f"[COMPUTED｜HIGH] 已完成{len(records)}/48个正式测试单元。更新时间：{now()}。", "",
             "[KNOWN｜HIGH] 首轮为P1连续几何增强＋P2轻量GIoU监督＋P5源验证组选模。核心参数量808,952；P3/P4首轮关闭。", "",
             "[KNOWN｜HIGH] 先在DAUB-R/3407完成源验证验收，通过预设标准后自动扩展；失败则停止并保存证据。旧测试反馈已用于提出本轮方案，因此最终测试属回顾性比较。", "",
             "| 训练源 \\ 测试域 | " + " | ".join(DOMAINS) + " |", "|---|---|---|---|---|"]
    for source in DOMAINS:
        cells = []
        for target in DOMAINS:
            values = [records[(source, target, seed)] for seed in SEEDS if (source, target, seed) in records]
            if not values:
                cells.append("未完成")
            elif len(values) == 3:
                numbers = [r["AP50"] * 100 for r in values]
                cells.append(f"{statistics.mean(numbers):.2f}±{statistics.stdev(numbers):.2f}")
            else:
                cells.append(f"{statistics.mean(r['AP50']*100 for r in values):.2f}（部分n={len(values)}）")
        lines.append("| " + source + " | " + " | ".join(cells) + " |")
    lines += ["", "[KNOWN｜HIGH] 单元格为AP50百分数；三种子齐全才报告样本标准差。源验证/几何探针/短运行不填入测试表。"]
    if (HOME / "promotion.json").exists():
        p = json.loads((HOME / "promotion.json").read_text(encoding="utf-8"))
        lines += ["", f"[COMPUTED｜HIGH] 单源验收：{'通过，允许扩展矩阵' if p['passed'] else '未通过，队列停止扩展'}。"]
        for name, passed in p["gates"].items():
            lines.append(f"- [COMPUTED｜HIGH] {name}: {'通过' if passed else '未通过'}")
    if len(records) == 48:
        current = [r for r in records.values() if r["source"] != r["target"]]
        old = [r for path in (ROOT / "runs" / "IRSTD").glob("*/seed_*/results.json") for r in json.loads(path.read_text(encoding="utf-8"))
               if r["source"] != r["target"]]
        gain = statistics.mean(r["AP50"] for r in current) - statistics.mean(r["AP50"] for r in old)
        lines += ["", f"[COMPUTED｜HIGH] 相对v1的12个跨域单元宏平均AP50变化：{gain*100:+.3f}个百分点。"]
    HOME.mkdir(parents=True, exist_ok=True)
    (HOME / "结果与进度.md").write_text("\n".join(lines), encoding="utf-8")
    write_json(HOME / "result_cells.json", list(records.values()))
    return len(records)


if __name__ == "__main__":
    summarize()
