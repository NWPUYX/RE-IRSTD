import copy
import torch
from torch import nn
from torch.nn import functional as F
from irstd.models.detector import Detector
from irstd.models.relative_evidence import RelativeEvidenceEncoder
from irstd_adapter import model_config


class SoftEvidence(RelativeEvidenceEncoder):
    def __init__(self, cfg):
        adjusted = copy.deepcopy(cfg)
        self.condition_clip = cfg["clip_abs"]
        adjusted["clip_abs"] = 1e6  # No hard z clipping for finite unit images/floor=1e-3.
        super().__init__(adjusted)

    def forward(self, image, diagnostics=False):
        z, c = super().forward(image, diagnostics)
        signed = torch.asinh(z[:, :3])
        return torch.cat((signed, signed.abs()), 1), c.clamp(-self.condition_clip, self.condition_clip)


class MaskedGN(nn.GroupNorm):
    mask = None

    def forward(self, value):
        if self.mask is None:
            raise ValueError("Masked GN requires a valid-region mask")
        mask = F.interpolate(self.mask.float(), value.shape[-2:], mode="area")
        b, c, h, w = value.shape
        grouped = value.float().view(b, self.num_groups, c // self.num_groups, h, w)
        weights = mask[:, None]
        count = (weights.sum((-2, -1), keepdim=True) * (c // self.num_groups)).clamp_min(1)
        mean = (grouped * weights).sum((2, 3, 4), keepdim=True) / count
        var = ((grouped - mean).square() * weights).sum((2, 3, 4), keepdim=True) / count
        out = ((grouped - mean) * torch.rsqrt(var + self.eps)).reshape_as(value)
        if self.affine:
            out = out * self.weight[None, :, None, None] + self.bias[None, :, None, None]
        return out * mask


class Model(Detector):
    def __init__(self, recipe):
        cfg = model_config()
        super().__init__(cfg)
        self.recipe = recipe
        if recipe["soft_relative_evidence"]:
            self.evidence = SoftEvidence(cfg["model"]["evidence"])
        if recipe["masked_group_norm"]:
            for module in list(self.modules()):
                for name, child in list(module.named_children()):
                    if isinstance(child, nn.GroupNorm):
                        new = MaskedGN(child.num_groups, child.num_channels, child.eps, child.affine)
                        new.load_state_dict(child.state_dict())
                        setattr(module, name, new)

    def forward(self, image, valid_mask=None, return_features=False, diagnostics=False):
        if valid_mask is None:
            valid_mask = torch.ones_like(image, dtype=torch.bool)
        if self.recipe["masked_group_norm"]:
            for module in self.modules():
                if isinstance(module, MaskedGN):
                    module.mask = valid_mask
        if not self.recipe["valid_region_evidence"]:
            return super().forward(image, return_features, diagnostics)
        z_all, c_all = [], []
        for x, mask in zip(image, valid_mask):
            locations = mask[0].nonzero()
            if not len(locations):
                raise ValueError("Empty valid image region")
            y0, x0 = locations.min(0).values.tolist()
            y1, x1 = (locations.max(0).values + 1).tolist()
            z, c = self.evidence(x[None, :, y0:y1, x0:x1], diagnostics)
            pad = (x0, image.shape[-1] - x1, y0, image.shape[-2] - y1)
            z_all.append(F.pad(z, pad))
            c_all.append(F.pad(c, pad))
        final, target = self.backbone(torch.cat(z_all), torch.cat(c_all), diagnostics)
        output = self.heads(final, target)
        if return_features:
            output["final_features"] = final
        return output
