from pathlib import Path
import copy
import hashlib
import json
import os
import re
from datetime import datetime, timezone, timedelta

ROOT = Path(__file__).resolve().parents[1]
TAG = os.environ.get("IRSTD_V2_EXPERIMENT", "geometry_giou_groupval_v1")
if not re.fullmatch(r"[A-Za-z0-9_-]+", TAG):
    raise ValueError("Experiment tag must be a simple directory name")
HOME = ROOT / "experiments" / "IRSTD_v2" / TAG
DOMAINS = ["DAUB-R", "IRDST-H", "IRSTD-UAV", "ITSDT-15K"]
SEEDS = [3407, 2026, 17]

# Experimental starting choices, frozen before the first candidate is trained.
# They are not claimed to be optimal hyperparameters.
RECIPE = {
    "name": "geometry_giou_groupval_v1", "initialization": "random",
    "epochs": 100, "batch": 4, "microbatch": 4, "workers": 2,
    "precision": "float32", "learning_rate": .000625, "weight_decay": .0005,
    "gradient_clip": 10., "validation_interval": 5, "patience_checks": 10, "minimum_epochs": 30,
    "geometry": {"enabled": True, "scale_jitter": [.5, 1.5], "shift_fraction": .125,
                 "minimum_box_side": 2., "maximum_attempts": 32, "horizontal_flip_probability": .5},
    "ignore_synthetic_padding": True,
    "giou_weight": .1, "geometry_equivariance_weight": 0.,
    "soft_relative_evidence": False, "valid_region_evidence": False, "masked_group_norm": False,
    "background_swap": False, "paired_probability": .5, "protection_margin": 14,
    "transition_width": 8, "consistency_weight": .05, "consistency_start_epoch": 3,
    "consistency_full_epoch": 8,
    "selection": "source_group_macro_AP50_then_pooled_AP50",
    "probe_samples_per_group": 12, "probe_scales": [.6, 1.4],
    "promotion": {"maximum_group_AP50_drop": .02, "maximum_pooled_AP50_drop": .02,
                  "maximum_geometry_log_error_ratio": .8},
    "postprocess": {"floor": 1e-5, "pre_nms": 1000, "nms_iou": .5, "max_detections": 100},
}


def now():
    return datetime.now(timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temp.replace(path)


def recipe(override=None):
    result = copy.deepcopy(RECIPE)
    configuration = HOME / "recipe.json"
    if configuration.exists():
        supplied = json.loads(configuration.read_text(encoding="utf-8"))
        for key, value in supplied.items():
            if key not in result:
                raise ValueError(f"Unknown recipe option: {key}")
            if isinstance(value, dict) and isinstance(result[key], dict):
                result[key].update(value)
            else:
                result[key] = value
    if override:
        for key, value in override.items():
            if isinstance(value, dict) and isinstance(result.get(key), dict):
                result[key].update(value)
            else:
                result[key] = value
    if result["microbatch"] > result["batch"] or result["microbatch"] < 1:
        raise ValueError("Invalid microbatch")
    if result["epochs"] < 2:
        raise ValueError("At least two scheduled epochs required")
    if (result["background_swap"] or result["geometry_equivariance_weight"]) and result["microbatch"] > 1:
        raise ValueError("Paired graphs require microbatch=1 to bound FP32 GPU memory")
    return result


def fingerprints():
    paths = list((ROOT.parent / "IRSTD" / "src" / "irstd").rglob("*.py"))
    paths += list((ROOT / "irstd_v2").glob("*.py"))
    paths += [ROOT / name for name in ("irstd_adapter.py", "data_pipeline.py", "evaluation.py")]
    return {str(p.relative_to(ROOT.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def split_hashes():
    return {f"{d}_{s}": hashlib.sha256((ROOT / "splits" / f"{d}_{s}.json").read_bytes()).hexdigest()
            for d in DOMAINS for s in ("train", "val", "test")}
