import torch
from torch.nn import functional as F
from irstd.data.targets import gather_centers
from irstd.losses.detection import detection_losses


def decoded_geometry(output, target, reference):
    anchors = target["anchors"]
    centers = anchors[:, 1:].float() + gather_centers(output["offsets"].float(), anchors)
    wh = torch.as_tensor(reference, device=centers.device) * gather_centers(output["log_size"].float(), anchors).clamp(-10, 10).exp()
    return centers, wh


def giou_pairs(pred, truth):
    intersection = (torch.minimum(pred[:, 2:], truth[:, 2:]) - torch.maximum(pred[:, :2], truth[:, :2])).clamp_min(0).prod(1)
    areas = (pred[:, 2:] - pred[:, :2]).clamp_min(0).prod(1) + (truth[:, 2:] - truth[:, :2]).clamp_min(0).prod(1)
    union = (areas - intersection).clamp_min(1e-7)
    enclosure = (torch.maximum(pred[:, 2:], truth[:, 2:]) - torch.minimum(pred[:, :2], truth[:, :2])).clamp_min(0).prod(1).clamp_min(1e-7)
    return intersection / union - (enclosure - union) / enclosure


def supervised(output, target, cfg, reference, recipe, weights=None, normalizers=None):
    terms = detection_losses(output, target, cfg["loss"], weights, normalizers)
    anchors, has_box = target["anchors"], target["has_box"]
    geom = output["log_size"].float().sum() * 0
    if has_box.any():
        centers, wh = decoded_geometry(output, target, reference)
        true_centers = anchors[:, 1:].float() + target["offsets"]
        true_wh = torch.as_tensor(reference, device=wh.device) * target["sizes"].exp()
        pred = torch.cat((centers - wh / 2, centers + wh / 2), 1)[has_box]
        truth = torch.cat((true_centers - true_wh / 2, true_centers + true_wh / 2), 1)[has_box]
        values = 1 - giou_pairs(pred, truth)
        if weights is not None:
            values = values * weights[anchors[has_box, 0]]
        denominator = max(normalizers["boxes"], 1) if normalizers else max(int(has_box.sum()), 1)
        geom = values.sum() / denominator
    terms["giou"] = geom
    terms["total"] = terms["total"] + recipe["giou_weight"] * geom
    return terms


def equivariance(first, second, first_target, second_target, first_samples, second_samples, reference, normalizer):
    c1, wh1 = decoded_geometry(first, first_target, reference)
    c2, wh2 = decoded_geometry(second, second_target, reference)
    if not len(c1):
        return (first["offsets"].sum() + second["offsets"].sum()) * 0
    if len(c1) != len(c2):
        raise ValueError("Geometric views must retain all targets in the same order")
    scales, shifts = [], []
    for a, b in zip(first_samples, second_samples):
        p, q = a["geometry_plan"], b["geometry_plan"]
        scale = [q["sx"] / p["sx"], q["sy"] / p["sy"]]
        shift = [q["tx"] - scale[0] * p["tx"], q["ty"] - scale[1] * p["ty"]]
        scales.extend([scale] * len(a["boxes"]))
        shifts.extend([shift] * len(a["boxes"]))
    scale = c1.new_tensor(scales)
    shift = c1.new_tensor(shifts)
    center = F.smooth_l1_loss((c2 - c1 * scale - shift) / 512., torch.zeros_like(c1), reduction="none").mean(1)
    size = F.smooth_l1_loss(wh2.log() - wh1.log() - scale.abs().log(), torch.zeros_like(wh1), reduction="none").mean(1)
    return (center + size).sum() / max(normalizer, 1)
