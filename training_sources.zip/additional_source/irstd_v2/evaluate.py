from collections import defaultdict
import hashlib
import json
import random
import numpy as np
import torch
from evaluation import postprocess, match_frame, metrics, select_threshold
from irstd.inference.decoder import decode
from irstd_adapter import targets, model_config
from .data import Data, choose_plan, render
from .losses import decoded_geometry, giou_pairs


@torch.inference_mode()
def evaluate(model, data_loader, device, reference, path=None, limit=None):
    model.eval()
    frames, predictions = [], []
    for batch_index, (images, samples) in enumerate(data_loader):
        if limit is not None and batch_index >= limit:
            break
        valid = torch.stack([s["valid_mask"] for s in samples]).to(device)
        output = model(images.to(device), valid_mask=valid)
        decoded = decode(output, 1e-5, {"box_nms_iou": None}, reference)
        for b, (p, sample) in enumerate(zip(decoded, samples)):
            centers, scores = p["centers"].to(device), p["scores"].to(device)
            q = centers.floor().long()
            raw_size = output["log_size"][b, :, q[:, 1], q[:, 0]].transpose(0, 1).float()
            ref = raw_size.new_tensor(reference)
            wh = ref * torch.minimum(raw_size.clamp_min(-20), (raw_size.new_tensor([512, 512]) / ref).log()).exp()
            raw = torch.cat((centers, wh, scores[:, None], torch.ones_like(scores[:, None])), 1)
            record = data_loader.dataset.records[sample["record_index"]]
            pred = postprocess(raw, record, sample["trans"])
            frames.append(match_frame(pred, record))
            for x, y, x2, y2, confidence in pred.tolist():
                predictions.append({"image_id": record["id"], "category_id": 1,
                                    "bbox": [x, y, x2 - x, y2 - y], "score": confidence})
    if path is not None:
        path.write_text(json.dumps({"frames": frames, "predictions": predictions}, separators=(",", ":")), encoding="utf-8")
    return frames


def validation_summary(frames):
    threshold = select_threshold(frames)
    pooled = metrics(frames, threshold)
    by_group = {group: metrics([f for f in frames if f["group"] == group], threshold)
                for group in sorted({f["group"] for f in frames})}
    macro = float(np.mean([x["AP50"] for x in by_group.values()]))
    return {"threshold": threshold, "pooled": pooled, "by_group": by_group,
            "group_macro_AP50": macro, "worst_group_AP50": min(x["AP50"] for x in by_group.values())}


@torch.inference_mode()
def geometry_probe(model, source, recipe, reference, device):
    """Source-val teacher-forced anchors, not deployment metrics or target tests."""
    data = Data(source, "val", recipe)
    grouped = defaultdict(list)
    for i, record in enumerate(data.records):
        grouped[record["group"]].append(i)
    ids = [group[j] for group in grouped.values() for j in np.linspace(0, len(group) - 1,
           min(recipe["probe_samples_per_group"], len(group)), dtype=int)]
    values = []
    model.eval()
    for index in ids:
        record = data.records[index]
        for scale in recipe["probe_scales"]:
            digest = hashlib.sha256(f"{source}/{record['id']}/{scale}".encode()).digest()
            rng = random.Random(int.from_bytes(digest[:8], "little"))
            plan = choose_plan(record, recipe["geometry"], rng, forced_scale=scale, flip_override=False)
            image, boxes, valid = render(record, plan)
            sample = {**data.base_sample(index), "image": image, "boxes": boxes, "valid_mask": valid, "ignore_mask": ~valid}
            target = targets([sample], model_config(), reference, device, "shared_regression")
            output = model(image[None].to(device), valid_mask=valid[None].to(device))
            centers, wh = decoded_geometry(output, target, reference)
            if not len(centers):
                continue
            true_center = target["anchors"][:, 1:] + target["offsets"]
            gt_wh = target["sizes"].exp() * wh.new_tensor(reference)
            pred = torch.cat((centers - wh / 2, centers + wh / 2), 1)
            gt = torch.cat((true_center - gt_wh / 2, true_center + gt_wh / 2), 1)
            values.append({"targets": len(wh), "log_size_error": float((wh.log() - gt_wh.log()).abs().mean()),
                           "center_error_input_px": float((centers - true_center).abs().mean()),
                           "mean_giou": float(giou_pairs(pred, gt).mean()), "fallback": plan["fallback"], "scale": scale})
    count = sum(x["targets"] for x in values)
    return {"scope": "fixed source-val geometry stress, GT anchors only; not a test score", "samples": len(values), "targets": count,
            **{k: sum(x[k] * x["targets"] for x in values) / max(count, 1)
               for k in ("log_size_error", "center_error_input_px", "mean_giou")},
            "fallback_views": sum(x["fallback"] for x in values), "requested_scales": recipe["probe_scales"]}
