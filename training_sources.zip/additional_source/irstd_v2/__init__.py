"""Versioned, switchable optimization experiments; v1 files remain unchanged."""
