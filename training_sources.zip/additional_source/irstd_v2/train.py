import os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import argparse
import copy
import hashlib
import json
import math
import random
import time
import numpy as np
import torch
from irstd_adapter import targets, source_audit, model_config
from irstd.engine.optim import make_optimizer
from irstd.losses.consistency import center_consistency
from .settings import ROOT, HOME, DOMAINS, SEEDS, recipe, fingerprints, split_hashes, write_json, now
from .model import Model
from .data import make_loader
from .losses import supervised, equivariance
from .evaluate import evaluate, validation_summary, geometry_probe
from evaluation import metrics


def rng_state():
    return {"python": random.getstate(), "numpy": np.random.get_state(), "torch": torch.get_rng_state(), "cuda": torch.cuda.get_rng_state_all()}


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"].cpu())
    torch.cuda.set_rng_state_all([x.cpu() for x in state["cuda"]])


def save_checkpoint(path, state):
    temp = path.with_suffix(".tmp")
    torch.save(state, temp)
    temp.replace(path)


def baseline(source="DAUB-R", seed=3407):
    cfg, device = recipe(), torch.device("cuda")
    path = ROOT / "runs" / "IRSTD" / source / f"seed_{seed}" / "best.pt"
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    cached = HOME / "baselines" / f"{source}_seed{seed}.json"
    identity = {"checkpoint_sha256": digest, "splits": split_hashes(),
                "probe_scales": cfg["probe_scales"], "probe_samples_per_group": cfg["probe_samples_per_group"],
                "probe_geometry_configuration": cfg["geometry"], "sources": fingerprints()}
    if cached.exists():
        old = json.loads(cached.read_text(encoding="utf-8"))
        if old["identity"] == identity:
            return old
    state = torch.load(path, map_location="cpu", weights_only=False)
    model = Model(cfg).to(device).eval()
    model.load_state_dict(state["model"])
    reference = state["config"]["size_reference_512"]
    frames = evaluate(model, make_loader(source, "val", cfg), device, reference)
    summary = validation_summary(frames)
    if abs(summary["pooled"]["AP50"] - state["source_val_AP50"]) > 1e-4:
        raise AssertionError("Baseline source-val AP no longer reproduces; inspect before training")
    result = {"identity": identity, "source": source, "seed": seed, "validation": summary,
              "geometry_probe": geometry_probe(model, source, cfg, reference, device), "updated_at": now()}
    write_json(cached, result)
    print(json.dumps({"baseline_source": source, "group_macro_AP50": summary["group_macro_AP50"],
                      "geometry_log_error": result["geometry_probe"]["log_size_error"]}), flush=True)
    return result


def train(source, seed, smoke=False, resume=False):
    cfg, core, device = recipe(), model_config(), torch.device("cuda")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    audit = source_audit(source)
    reference = audit["size_reference_512"]
    run = HOME / ("smoke" if smoke else "runs") / source / f"seed_{seed}"
    run.mkdir(parents=True, exist_ok=True)
    config = {"model": "IRSTD-v2", "source": source, "seed": seed, "recipe": cfg, "source_hashes": fingerprints(),
              "split_hashes": split_hashes(), "size_reference_512": reference, "smoke": smoke,
              "source_selection": cfg["selection"], "initialization": "random; no v1 training weights loaded"}
    if (run / "config.json").exists():
        old = json.loads((run / "config.json").read_text(encoding="utf-8"))
        if old != config:
            raise ValueError("Frozen run configuration/source changed")
        if not resume:
            raise ValueError("Run already exists; explicitly resume")
    write_json(run / "config.json", config)
    write_json(run / "source_audit.json", audit)
    write_json(run / "process.json", {"pid": os.getpid(), "started_at": now(), "source": source, "seed": seed})
    if (run / "training_complete.json").exists():
        return
    model = Model(cfg).to(device)
    optim_cfg = {**core["train"], "learning_rate": cfg["learning_rate"], "weight_decay": cfg["weight_decay"]}
    optimizer = make_optimizer(model, optim_cfg)
    ema = copy.deepcopy(model).eval()
    for p in ema.parameters():
        p.requires_grad_(False)
    parameter_names = set(dict(model.named_parameters()))
    start, updates, checks, best_key, previous_seconds = 0, 0, 0, None, 0.
    if resume and (run / "last.pt").exists():
        state = torch.load(run / "last.pt", map_location=device, weights_only=False)
        if state["config"] != config:
            raise ValueError("Checkpoint configuration mismatch")
        model.load_state_dict(state["model"])
        ema.load_state_dict(state["ema"])
        optimizer.load_state_dict(state["optimizer"])
        start, updates, checks, best_key, previous_seconds = [state[k] for k in ("next_epoch", "updates", "checks", "best_key", "elapsed_seconds")]
        restore_rng(state["rng"])
        del state
    training = make_loader(source, "train", cfg, training=True, seed=seed)
    validation = make_loader(source, "val", cfg)
    started = time.perf_counter()
    stopped = False
    epoch = start - 1
    for epoch in range(start, cfg["epochs"]):
        training.dataset.epoch = epoch
        model.train()
        losses_sum, frames_seen = {}, 0
        epoch_tick = time.perf_counter()
        lr = cfg["learning_rate"] * (.01 + .99 * (1 + math.cos(math.pi * epoch / (cfg["epochs"] - 1))) / 2)
        if epoch < 3:
            lr = cfg["learning_rate"] * (.1 + .9 * (epoch + 1) / 3)
        for group in optimizer.param_groups:
            group["lr"] = lr
        torch.cuda.reset_peak_memory_stats(device)
        paired_images, collisions = 0, 0
        for iteration, (images, samples) in enumerate(training):
            optimizer.zero_grad(set_to_none=True)
            normalizers = {"images": len(samples), "targets": sum(len(s["boxes"]) for s in samples),
                           "boxes": sum(len(s["boxes"]) for s in samples)}
            for i in range(0, len(samples), cfg["microbatch"]):
                group = samples[i:i + cfg["microbatch"]]
                target = targets(group, core, reference, device, "shared_regression")
                collisions += len(target["anchors"]) - int(target["positive"].sum())
                valid = torch.stack([s["valid_mask"] for s in group]).to(device)
                bg_active = cfg["background_swap"] and epoch >= cfg["consistency_start_epoch"]
                has_bg = bg_active and len(group) == 1 and "background_view" in group[0]
                has_geo = cfg["geometry_equivariance_weight"] > 0
                weight = .5 if has_geo else 1.
                weight *= .5 if has_bg else 1.
                output = model(images[i:i + len(group)].to(device), valid_mask=valid, return_features=has_bg)
                terms = supervised(output, target, core, reference, cfg, images.new_full((len(group),), weight).to(device), normalizers)
                loss = terms["total"]
                consistency = loss * 0
                eq_loss = loss * 0
                if has_bg:
                    second = model(group[0]["background_view"]["image"][None].to(device), valid_mask=valid, return_features=True)
                    second_terms = supervised(second, target, core, reference, cfg, loss.new_tensor([weight]), normalizers)
                    loss = loss + second_terms["total"]
                    paired = torch.ones(1, dtype=torch.bool, device=device)
                    consistency = center_consistency(output["final_features"], second["final_features"], target["anchors"], paired,
                                                     target_normalizer=normalizers["targets"])
                    ramp = min(max((epoch - cfg["consistency_start_epoch"]) / max(cfg["consistency_full_epoch"] - cfg["consistency_start_epoch"], 1), 0), 1)
                    loss = loss + cfg["consistency_weight"] * ramp * consistency
                    terms = {key: value + second_terms[key] for key, value in terms.items()}
                    paired_images += 1
                if has_geo:
                    geo_group = [s["geometry_view"] for s in group]
                    geo_target = targets(geo_group, core, reference, device, "shared_regression")
                    geo_images = torch.stack([s["image"] for s in geo_group]).to(device)
                    geo_valid = torch.stack([s["valid_mask"] for s in geo_group]).to(device)
                    geo_output = model(geo_images, valid_mask=geo_valid)
                    geo_terms = supervised(geo_output, geo_target, core, reference, cfg, loss.new_full((len(group),), .5), normalizers)
                    eq_loss = equivariance(output, geo_output, target, geo_target, group, geo_group, reference, normalizers["targets"])
                    loss = loss + geo_terms["total"] + cfg["geometry_equivariance_weight"] * eq_loss
                    terms = {key: value + geo_terms[key] for key, value in terms.items()}
                if not torch.isfinite(loss):
                    raise FloatingPointError(f"Nonfinite loss at epoch {epoch + 1}, batch {iteration}")
                loss.backward()
                for key, value in {**terms, "total": loss, "background_consistency": consistency, "geometry_equivariance": eq_loss}.items():
                    losses_sum[key] = losses_sum.get(key, 0.) + float(value.detach())
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["gradient_clip"], error_if_nonfinite=True)
            optimizer.step()
            updates += 1
            decay = .9999 * (1 - math.exp(-updates / 2000))
            with torch.no_grad():
                current = model.state_dict()
                for key, value in ema.state_dict().items():
                    value.mul_(decay).add_(current[key], alpha=1 - decay) if key in parameter_names else value.copy_(current[key])
            frames_seen += len(samples)
            if iteration % 100 == 0:
                progress = {"status": "training", "pid": os.getpid(), "epoch": epoch + 1, "batch": iteration,
                            "frames": frames_seen, "last_loss": float(loss.detach()), "epoch_seconds": time.perf_counter() - epoch_tick, "updated_at": now()}
                write_json(run / "progress.json", progress)
                print(json.dumps(progress), flush=True)
            if smoke and iteration >= 1:
                break
        torch.cuda.synchronize()
        stat = {"epoch": epoch + 1, "train_frames": frames_seen, "loss_sum_over_updates": losses_sum,
                "updates": updates, "learning_rate": lr, "training_seconds": time.perf_counter() - epoch_tick,
                "paired_images": paired_images, "same_cell_extra_labels": collisions,
                "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated(device)}
        if smoke or (epoch + 1) % cfg["validation_interval"] == 0 or epoch + 1 == cfg["epochs"]:
            frames = evaluate(ema, validation, device, reference, run / "last_source_val_predictions.json", 2 if smoke else None)
            summary = validation_summary(frames)
            key = (summary["group_macro_AP50"], summary["pooled"]["AP50"])
            stat["source_validation"] = summary
            if best_key is None or key > tuple(best_key):
                best_key, checks = key, 0
                probe = geometry_probe(ema, source, cfg, reference, device) if not smoke else None
                save_checkpoint(run / "best.pt", {"model": ema.state_dict(), "epoch": epoch + 1, "config": config,
                                                 "source_validation": summary, "geometry_probe": probe})
                write_json(run / "best_source_validation.json", {"epoch": epoch + 1, "validation": summary, "geometry_probe": probe})
                (run / "last_source_val_predictions.json").replace(run / "best_source_val_predictions.json")
            else:
                checks += 1
        stat["elapsed_seconds"] = previous_seconds + time.perf_counter() - started
        stat["height_output_weight_abs_max"] = float(model.heads.size[-1].weight[1].detach().abs().max())
        stat["offset_output_weight_abs_max"] = float(model.heads.offset[-1].weight.detach().abs().max())
        with (run / "history.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(stat, allow_nan=False) + "\n")
        save_checkpoint(run / "last.pt", {"model": model.state_dict(), "ema": ema.state_dict(), "optimizer": optimizer.state_dict(),
                                          "next_epoch": epoch + 1, "updates": updates, "checks": checks, "best_key": best_key,
                                          "elapsed_seconds": stat["elapsed_seconds"], "rng": rng_state(), "config": config})
        write_json(run / "status.json", {"status": "smoke_passed" if smoke else "training", "updated_at": now(), **stat})
        print(json.dumps({"epoch": epoch + 1, "training_seconds": stat["training_seconds"], "source_validation": stat.get("source_validation")}), flush=True)
        if smoke:
            return
        if epoch + 1 >= cfg["minimum_epochs"] and checks >= cfg["patience_checks"]:
            stopped = True
            break
    write_json(run / "training_complete.json", {"epochs_run": epoch + 1, "early_stopped": stopped, "updates": updates, "updated_at": now()})


def test(source, seed):
    cfg, device = recipe(), torch.device("cuda")
    run = HOME / "runs" / source / f"seed_{seed}"
    best = torch.load(run / "best.pt", map_location="cpu", weights_only=False)
    if best["config"]["source_hashes"] != fingerprints():
        raise ValueError("Code changed after training")
    model = Model(cfg).to(device).eval()
    model.load_state_dict(best["model"])
    reference = best["config"]["size_reference_512"]
    threshold = best["source_validation"]["threshold"]
    results = []
    for target in DOMAINS:
        frames = evaluate(model, make_loader(target, "test", cfg), device, reference, run / f"test_{target}_predictions.json")
        result = {"model": "IRSTD-v2", "source": source, "target": target, "seed": seed,
                  "best_epoch": best["epoch"], **metrics(frames, threshold, bootstrap=200)}
        by_group = {g: metrics([f for f in frames if f["group"] == g], threshold) for g in sorted({f["group"] for f in frames})}
        write_json(run / f"test_{target}_metrics.json", {"overall": result, "by_group": by_group})
        results.append(result)
        print(json.dumps(result), flush=True)
    write_json(run / "results.json", results)
    write_json(run / "status.json", {"status": "completed", "updated_at": now(), "best_epoch": best["epoch"], "test_cells": 4})


def main():
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices=["baseline", "train", "test"])
    p.add_argument("--source", choices=DOMAINS, default="DAUB-R")
    p.add_argument("--seed", type=int, choices=SEEDS, default=3407)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--smoke", action="store_true")
    args = p.parse_args()
    torch.set_num_threads(8)
    torch.backends.cudnn.benchmark = False
    {"baseline": lambda: baseline(args.source, args.seed), "train": lambda: train(args.source, args.seed, args.smoke, args.resume),
     "test": lambda: test(args.source, args.seed)}[args.mode]()


if __name__ == "__main__":
    main()
