"""Source-gated serial experiment; no target metric selects the recipe."""
import json
import os
import subprocess
import sys
import time
import traceback
from .settings import ROOT, HOME, DOMAINS, SEEDS, recipe, write_json, now, fingerprints
from .report import summarize, promotion


def status(**values):
    write_json(HOME / "queue_status.json", {"pid": os.getpid(), "updated_at": now(), **values})


def child(arguments, log, phase, source=None, seed=None):
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("a", encoding="utf-8") as stream:
        process = subprocess.Popen([sys.executable, "-u", "-m", "irstd_v2.train", *arguments], cwd=ROOT,
                                   stdout=stream, stderr=subprocess.STDOUT,
                                   env={**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1"},
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        while True:
            values = {"status": phase, "active_process_id": process.pid, "source": source, "seed": seed,
                      "completed_test_cells": len(list((HOME / "runs").glob("*/seed_*/results.json"))) * 4}
            if source:
                progress = HOME / "runs" / source / f"seed_{seed}" / "progress.json"
                if progress.exists():
                    try:
                        values["progress"] = json.loads(progress.read_text(encoding="utf-8"))
                    except (OSError, json.JSONDecodeError):
                        pass
            status(**values)
            try:
                code = process.wait(timeout=30)
                break
            except subprocess.TimeoutExpired:
                continue
    if code:
        raise RuntimeError(f"Child exited {code}; inspect {log}")


def main():
    import msvcrt
    HOME.mkdir(parents=True, exist_ok=True)
    lock = (HOME / "queue.lock").open("a+b")
    lock.seek(0)
    if not lock.read(1):
        lock.write(b"1")
        lock.flush()
    lock.seek(0)
    try:
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        raise SystemExit("An optimization queue already holds this experiment lock")
    cfg = recipe()
    write_json(HOME / "recipe.json", cfg)
    check_file = HOME / "checks" / "preflight.json"
    if not check_file.exists():
        raise RuntimeError("Run python -m irstd_v2.checks first")
    checks = json.loads(check_file.read_text(encoding="utf-8"))
    if not checks["passed"] or checks["recipe"] != cfg or checks["source_hashes"] != fingerprints():
        raise RuntimeError("Preflight stale or failed; rerun no-training acceptance checks")
    summarize()
    child(["baseline"], HOME / "baseline_console.log", "no_training_baseline_validation")
    pilot = HOME / "runs" / "DAUB-R" / "seed_3407"
    if not (pilot / "training_complete.json").exists():
        child(["train", "--source", "DAUB-R", "--seed", "3407", "--resume"], pilot / "console.log", "pilot_training", "DAUB-R", 3407)
    promoted = promotion()
    summarize()
    if not promoted["passed"]:
        status(status="held_source_validation_failed", promotion=promoted["gates"], completed_test_cells=0)
        return
    # The successful pilot is the first formal run; do not train it twice.
    for seed in SEEDS:
        for source in DOMAINS:
            run = HOME / "runs" / source / f"seed_{seed}"
            if (run / "results.json").exists():
                continue
            if not (run / "training_complete.json").exists():
                child(["train", "--source", source, "--seed", str(seed), "--resume"], run / "console.log", "matrix_training", source, seed)
            child(["test", "--source", source, "--seed", str(seed)], run / "test_console.log", "frozen_test_evaluation", source, seed)
            summarize()
    status(status="completed", completed_test_cells=48)
    summarize()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        status(status="failed", traceback=traceback.format_exc())
        raise
