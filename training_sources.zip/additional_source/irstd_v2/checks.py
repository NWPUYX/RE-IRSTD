"""No-training acceptance checks. A single gradient/optimizer check is not a run."""
import copy
import json
import math
import random
import tempfile
import time
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
import torch
from torch import nn
from irstd.models.detector import Detector
from irstd.models.blocks import REBlock
from irstd.models.relative_evidence import RelativeEvidenceEncoder
from irstd_adapter import model_config, targets
from .settings import HOME, DOMAINS, recipe, fingerprints, split_hashes, write_json, now
from .model import Model, MaskedGN, SoftEvidence
from .data import Data, choose_plan, render, native_gray, union_swap
from .losses import giou_pairs, supervised, equivariance


def preview(sample, path, image=None):
    value = sample["image"] if image is None else image
    pixels = (value[0].clamp(0, 1).numpy() * 255).round().astype(np.uint8)
    canvas = Image.fromarray(pixels).convert("RGB")
    draw = ImageDraw.Draw(canvas)
    for x1, y1, x2, y2 in sample["boxes"].tolist():
        draw.rectangle((x1, y1, x2, y2), outline="lime", width=1)
        cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
        draw.line((cx - 3, cy, cx + 3, cy), fill="red")
        draw.line((cx, cy - 3, cx, cy + 3), fill="red")
    canvas.save(path)


def run():
    torch.set_num_threads(2)
    torch.manual_seed(11)
    cfg, core = recipe(), model_config()
    out = HOME / "checks"
    out.mkdir(parents=True, exist_ok=True)
    results = []
    original = Detector(core)
    candidate = Model(cfg)
    candidate.load_state_dict(original.state_dict())
    x = torch.rand(1, 1, 32, 40)
    with torch.no_grad():
        a, b = original(x), candidate(x, valid_mask=torch.ones_like(x, dtype=torch.bool))
    assert all(torch.equal(a[key], b[key]) for key in a if a[key] is not None)
    assert sum(p.numel() for p in candidate.parameters()) == 808952
    assert len([m for m in candidate.modules() if isinstance(m, REBlock)]) == 14
    for m in candidate.modules():
        if isinstance(m, REBlock):
            assert all(q.sum((-2, -1)).abs().max() < 1e-6 for q in m.effective_kernels())
            assert m.gate is not None
    assert candidate.backbone.target_path is not None and candidate.heads.aux is not None
    results.append({"check": "v1_forward_bitwise_equal_and_core_mechanisms_preserved", "passed": True, "parameters": 808952})
    gn = nn.GroupNorm(8, 24)
    masked = MaskedGN(8, 24)
    masked.load_state_dict(gn.state_dict())
    t = torch.rand(2, 24, 8, 8)
    masked.mask = torch.ones(2, 1, 8, 8)
    assert torch.allclose(gn(t), masked(t), atol=2e-6)
    masked.mask[:, :, :, 4:] = 0
    v1 = masked(t)
    changed = t.clone()
    changed[:, :, :, 4:] = 10000
    assert torch.allclose(v1[:, :, :, :4], masked(changed)[:, :, :, :4], atol=1e-6)
    results.append({"check": "masked_GN_identity_and_invalid_region_exclusion", "passed": True})
    ev_cfg = copy.deepcopy(core["model"]["evidence"])
    ev_cfg["sigma_floor"] = 0.
    ev = SoftEvidence(ev_cfg)
    image = torch.rand(1, 1, 40, 48)
    a, b = ev(image), ev(1.2 * image + .1)
    assert all(torch.allclose(u, v, atol=4e-4, rtol=4e-4) for u, v in zip(a, b))
    with torch.no_grad():
        optional = Model(recipe({"soft_relative_evidence": True, "valid_region_evidence": True, "masked_group_norm": True}))
        mask = torch.zeros(1, 1, 32, 40, dtype=torch.bool)
        mask[:, :, :, 4:36] = True
        p = optional(torch.rand(1, 1, 32, 40), valid_mask=mask)
        assert all(torch.isfinite(v).all() for v in p.values() if v is not None)
    results.append({"check": "optional_P3_affine_property_and_masked_forward", "passed": True})
    with tempfile.TemporaryDirectory(dir=out) as folder:
        array = np.full((64, 80), 128, dtype=np.uint8)
        array[24:26, 20:24] = 240
        path = Path(folder) / "marker.png"
        Image.fromarray(array).save(path)
        record = {"path": str(path), "width": 80, "height": 64, "boxes": [[20, 24, 4, 2]]}
        plan = {"sx": 1.7, "sy": 1.7, "tx": 10.375, "ty": 22.625, "fallback": False}
        rendered, boxes, valid = render(record, plan)
        expected = torch.tensor([[44.375, 63.425, 51.175, 66.825]])
        assert torch.allclose(boxes, expected, atol=1e-4)
        reverse = {**plan, "sx": -plan["sx"], "tx": 512 - plan["tx"]}
        flipped, bflip, _ = render(record, reverse)
        assert torch.allclose(flipped, rendered.flip(-1), atol=2e-4)
        assert torch.allclose(bflip[:, [0, 2]], 512 - boxes[:, [2, 0]], atol=1e-4)
        assert rendered[0, 63:67, 44:52].max() > .8
        native_gray.cache_clear()
    results.append({"check": "continuous_pixel_center_geometry_matches_render_and_flip", "passed": True})
    geometry_stats = []
    first_sample = None
    for source in DOMAINS:
        data = Data(source, "train", cfg, training=True, seed=3407)
        heights, offsets, fallback = [], [], 0
        for index in np.linspace(0, len(data) - 1, 32, dtype=int):
            sample = data[int(index)]
            assert len(sample["boxes"]) == len(data.records[index]["boxes"])
            b = sample["boxes"]
            assert (b >= 0).all() and (b <= 512).all() and (b[:, 2:] > b[:, :2]).all()
            c = (b[:, :2] + b[:, 2:]) / 2
            heights.extend((b[:, 3] - b[:, 1]).tolist())
            offsets.extend((c - c.floor()).tolist())
            fallback += sample["geometry_plan"]["fallback"]
            if index == 0:
                preview(sample, out / f"{source}_geometry.png")
            if source == "DAUB-R" and first_sample is None:
                first_sample = sample
        assert np.std(heights) > 0 and np.std(offsets, axis=0).min() > 0
        geometry_stats.append({"source": source, "sampled_images": 32, "height_std": float(np.std(heights)),
                               "offset_std": np.std(offsets, axis=0).tolist(), "fallback_images": int(fallback),
                               "all_annotations_retained": True})
    results.append({"check": "real_data_target_preservation_and_non_degenerate_supervision", "passed": True, "domains": geometry_stats})
    donor = Data("DAUB-R", "train", cfg).base_sample(100)
    tick = time.perf_counter()
    swapped, alpha, protected = union_swap(first_sample, donor, cfg)
    assert torch.equal(swapped[protected], first_sample["image"][protected])
    assert ((alpha >= 0) & (alpha <= 1)).all() and (alpha > 0).any()
    assert torch.all(alpha[~first_sample["valid_mask"]] == 0)
    preview(first_sample, out / "DAUB-R_background_swap.png", swapped)
    results.append({"check": "F_safe_union_protection_no_donor_target_leak", "passed": True,
                    "pairing_seconds": time.perf_counter() - tick, "exchanged_fraction": float((alpha > 0).float().mean()),
                    "enabled_in_first_recipe": False})
    pred = torch.tensor([[0., 0., 2., 2.]], requires_grad=True)
    assert torch.allclose(giou_pairs(pred, pred.detach()), torch.ones(1))
    assert giou_pairs(pred, torch.tensor([[5., 5., 7., 7.]])).item() < 0
    (1 - giou_pairs(pred, torch.tensor([[.5, .5, 2.5, 2.5]]))).sum().backward()
    assert torch.isfinite(pred.grad).all() and pred.grad.abs().sum() > 0
    results.append({"check": "aligned_GIoU_values_and_gradients", "passed": True})
    another = Data("DAUB-R", "train", cfg, training=True, seed=77)[0]
    t1 = targets([first_sample], core, [16., 16.], "cpu", "shared_regression")
    t2 = targets([another], core, [16., 16.], "cpu", "shared_regression")
    def perfect(target):
        out = {"offsets": torch.zeros(1, 2, 512, 512), "log_size": torch.zeros(1, 2, 512, 512)}
        b, x, y = target["anchors"].unbind(1)
        out["offsets"][b, :, y, x] = target["offsets"]
        out["log_size"][b, :, y, x] = target["sizes"]
        return out
    f1, f2 = perfect(t1), perfect(t2)
    eq = equivariance(f1, f2, t1, t2, [first_sample], [another], [16., 16.], len(t1["anchors"]))
    assert float(eq) < 1e-8
    b, x, y = t2["anchors"].unbind(1)
    f2["log_size"][b, :, y, x] = t1["sizes"]
    assert equivariance(f1, f2, t1, t2, [first_sample], [another], [16., 16.], len(t1["anchors"])) > 1e-8
    results.append({"check": "geometric_equivariance_not_size_invariance", "passed": True})
    device = torch.device("cuda")
    model = Model(cfg).to(device)
    target = targets([first_sample], core, [16., 16.], device, "shared_regression")
    output = model(first_sample["image"][None].to(device), valid_mask=first_sample["valid_mask"][None].to(device))
    terms = supervised(output, target, core, [16., 16.], cfg)
    terms["total"].backward()
    height_grad = float(model.heads.size[-1].weight.grad[1].abs().sum())
    offset_grad = float(model.heads.offset[-1].weight.grad.abs().sum())
    assert height_grad > 0 and offset_grad > 0
    assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    optimizer = torch.optim.SGD(model.parameters(), lr=.001)
    optimizer.step()
    assert model.heads.size[-1].weight[1].abs().sum() > 0
    results.append({"check": "real_augmented_FP32_gradients_height_offset_nonzero", "passed": True,
                    "height_gradient_L1": height_grad, "offset_gradient_L1": offset_grad,
                    "scope": "one diagnostic update; not a training result"})
    write_json(out / "preflight.json", {"passed": True, "checks": results, "updated_at": now(),
                                        "recipe": cfg, "source_hashes": fingerprints(), "split_hashes": split_hashes()})
    print(json.dumps({"passed": True, "checks": len(results), "geometry": geometry_stats, "height_gradient": height_grad,
                      "offset_gradient": offset_grad}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    run()
