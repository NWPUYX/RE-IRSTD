from functools import lru_cache
import math
import random
import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F
from torch.utils.data import Dataset, DataLoader
from data_pipeline import worker_seed
from irstd_adapter import PublicInfraredData, transformed_boxes
from irstd.augmentation.background_swap import distance_from_protection


@lru_cache(maxsize=128)
def native_gray(path):
    with Image.open(path) as image:
        return torch.from_numpy(np.array(image.convert("L"), dtype=np.float32) / 255.)[None]


def original_boxes(record):
    b = torch.tensor(record["boxes"], dtype=torch.float32).reshape(-1, 4)
    b[:, 2:] += b[:, :2]
    return b


def choose_plan(record, cfg, rng, forced_scale=None, flip_override=None):
    """Continuous image-edge coordinates; never remove/crop an annotated target."""
    w, h = record["width"], record["height"]
    base = min(512 / w, 512 / h)
    boxes = original_boxes(record)
    attempts = cfg["maximum_attempts"]
    for attempt in range(attempts + 1):
        fallback = attempt == attempts
        jitter = forced_scale if forced_scale is not None else math.exp(rng.uniform(*np.log(cfg["scale_jitter"])))
        if fallback:
            jitter = 1.
        scale = base * jitter
        if len(boxes):
            wh = (boxes[:, 2:] - boxes[:, :2]) * scale
            if wh.min() < cfg["minimum_box_side"] and not fallback:
                continue
            lo = -boxes[:, :2].min(0).values.numpy() * scale
            hi = 512 - boxes[:, 2:].max(0).values.numpy() * scale
        else:
            lo, hi = np.array([-np.inf] * 2), np.array([np.inf] * 2)
        center = np.array([(512 - scale * w) / 2, (512 - scale * h) / 2])
        shift = 512 * cfg["shift_fraction"]
        low, high = np.maximum(lo, center - shift), np.minimum(hi, center + shift)
        if np.any(low > high):
            continue
        tx, ty = (rng.uniform(a, b) if b > a else a for a, b in zip(low, high))
        flip = rng.random() < cfg["horizontal_flip_probability"] if flip_override is None else flip_override
        return {"sx": -scale if flip else scale, "sy": scale,
                "tx": 512 - tx if flip else tx, "ty": ty, "fallback": fallback,
                "requested_jitter": float(jitter)}
    raise ValueError("No target-preserving geometry exists")


def render(record, plan):
    image = native_gray(record["path"])
    _, h, w = image.shape
    yy, xx = torch.meshgrid(torch.arange(512, dtype=torch.float32) + .5,
                            torch.arange(512, dtype=torch.float32) + .5, indexing="ij")
    xs, ys = (xx - plan["tx"]) / plan["sx"], (yy - plan["ty"]) / plan["sy"]
    grid = torch.stack((2 * xs / w - 1, 2 * ys / h - 1), dim=-1)[None]
    fill = 128 / 255
    transformed = (F.grid_sample((image - fill)[None], grid, mode="bicubic", padding_mode="zeros",
                                 align_corners=False)[0] + fill).clamp(0, 1)
    valid = ((xs >= 0) & (xs < w) & (ys >= 0) & (ys < h))[None]
    boxes = original_boxes(record)
    boxes[:, [0, 2]] = boxes[:, [0, 2]] * plan["sx"] + plan["tx"]
    boxes[:, [1, 3]] = boxes[:, [1, 3]] * plan["sy"] + plan["ty"]
    boxes = torch.cat((torch.minimum(boxes[:, :2], boxes[:, 2:]), torch.maximum(boxes[:, :2], boxes[:, 2:])), 1)
    if len(boxes) and ((boxes < -1e-3).any() or (boxes > 512 + 1e-3).any()):
        raise ValueError("Geometry would truncate a target; labels may not be dropped")
    boxes = boxes.clamp(0, 512)
    return transformed, boxes, valid


def union_swap(recipient, donor, cfg):
    if not recipient["complete"] or not donor["complete"] or donor.get("split") != "source_train":
        raise ValueError("F-safe requires complete source-train annotations")
    protected = (~(recipient["valid_mask"] & donor["valid_mask"]))[0].numpy().copy()
    for boxes in (recipient["boxes"], donor["boxes"]):
        for x1, y1, x2, y2 in boxes.tolist():
            m = cfg["protection_margin"]
            left, top, right, bottom = max(0, math.floor(x1 - m)), max(0, math.floor(y1 - m)), min(512, math.ceil(x2 + m)), min(512, math.ceil(y2 + m))
            protected[top:bottom, left:right] = True
    distance = distance_from_protection(protected)
    a = .5 * (1 - np.cos(np.pi * np.minimum(distance / cfg["transition_width"], 1.)))
    alpha = torch.from_numpy(a.astype(np.float32))[None]
    swapped = (1 - alpha) * recipient["image"] + alpha * donor["image"]
    return swapped, alpha, torch.from_numpy(protected)[None]


class Data(Dataset):
    def __init__(self, source, split, cfg, training=False, seed=0):
        self.base = PublicInfraredData(source, split, training=False)
        self.records = self.base.records
        self.cfg, self.training, self.seed, self.epoch = cfg, training, seed, 0
        self.split = "source_" + split if split in ("train", "val") else split

    def __len__(self):
        return len(self.records)

    def base_sample(self, index):
        sample = self.base[index]
        record = self.records[index]
        _, tr = transformed_boxes(record)
        sx, sy, dx, dy = tr
        nw, nh = round(record["width"] * sx), round(record["height"] * sy)
        valid = torch.zeros(1, 512, 512, dtype=torch.bool)
        valid[:, dy:dy + nh, dx:dx + nw] = True
        return {**sample, "valid_mask": valid, "ignore_mask": ~valid if self.cfg["ignore_synthetic_padding"] else torch.zeros_like(valid),
                "split": self.split, "geometry_plan": {"sx": sx, "sy": sy, "tx": dx, "ty": dy, "fallback": False}}

    def augmented(self, index, rng):
        record = self.records[index]
        plan = choose_plan(record, self.cfg["geometry"], rng)
        image, boxes, valid = render(record, plan)
        sample = {"image": image, "boxes": boxes, "points": torch.empty(0, 2), "complete": True,
                  "known_background_mask": torch.zeros_like(valid), "ignore_mask": ~valid if self.cfg["ignore_synthetic_padding"] else torch.zeros_like(valid),
                  "valid_mask": valid, "sample_id": str(record["id"]), "scene_id": record["group"],
                  "record_index": index, "split": self.split, "geometry_plan": plan}
        return sample

    def __getitem__(self, index):
        if not self.training:
            return self.base_sample(index)
        rng = random.Random(self.seed + self.epoch * 1_000_003 + index * 97)
        sample = self.augmented(index, rng) if self.cfg["geometry"]["enabled"] else self.base_sample(index)
        if not self.cfg["geometry"]["enabled"] and rng.random() < .5:
            sample = dict(sample)
            sample["image"] = sample["image"].flip(-1)
            sample["boxes"] = sample["boxes"][:, [2, 1, 0, 3]].clone()
            sample["boxes"][:, [0, 2]] = 512 - sample["boxes"][:, [0, 2]]
            sample["valid_mask"] = sample["valid_mask"].flip(-1)
        if self.cfg["geometry_equivariance_weight"]:
            sample["geometry_view"] = self.augmented(index, rng)
        if self.cfg["background_swap"] and self.epoch >= self.cfg["consistency_start_epoch"] and len(self) > 1 and rng.random() < self.cfg["paired_probability"]:
            j = rng.randrange(len(self) - 1)
            j += j >= index
            donor = self.base_sample(j)
            image, alpha, _ = union_swap(sample, donor, self.cfg)
            if (alpha > 0).any():
                sample["background_view"] = {**sample, "image": image}
                sample["donor_id"] = donor["sample_id"]
        return sample


def collate(samples):
    return torch.stack([s["image"] for s in samples]), samples


def make_loader(source, split, cfg, training=False, seed=0):
    data = Data(source, split, cfg, training, seed)
    # Fresh workers each epoch receive the updated epoch for reproducible plans.
    return DataLoader(data, batch_size=cfg["batch"], shuffle=training, num_workers=cfg["workers"],
                      collate_fn=collate, worker_init_fn=worker_seed, pin_memory=False,
                      persistent_workers=False, drop_last=False)
