"""Read a retained checkpoint and trace failed gradients; never update its weights."""
import os,json,traceback,random
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'cache/matplotlib'))
import torch
from model_adapter import build,training_loss
from data_pipeline import VideoData,collate
torch.set_num_threads(4)
out={'purpose':'gradient diagnosis only; no checkpoint or official score is changed','samples':[]}
checkpoint=torch.load(ROOT/'runs/Tridos/DAUB-R/seed_3407/last.pt',map_location='cpu',weights_only=False)
out['checkpoint_epoch']=checkpoint['epoch']+1
model,criterion=build('Tridos');model.load_state_dict(checkpoint['model']);model.cuda().train();criterion.cuda();del checkpoint
torch.cuda.empty_cache=lambda:None
original_angle=torch.angle;phase_inputs=[]
def traced_angle(value):
    absolute=value.detach().abs();positive=absolute[absolute>0]
    phase_inputs.append({'min_abs':float(absolute.min()),'min_positive_abs':float(positive.min()) if positive.numel() else None,'near_zero_nonzero_count':int(((absolute>0)&(absolute<1e-18)).sum()),'shape':list(value.shape)})
    return original_angle(value)
torch.angle=traced_angle
data=VideoData('DAUB-R','train','Tridos')
for index in [0,1045,2090,3135]:
    random.seed(3407);torch.manual_seed(3407);model.zero_grad(set_to_none=True);phase_inputs.clear()
    entry={'index':index,'path':data.records[index]['path']}
    try:
        images,targets,multi,ids,trans=collate([data[index]])
        with torch.autograd.detect_anomaly(check_nan=True):
            loss=training_loss('Tridos',model,criterion,images.cuda().float()/255,[t.cuda() for t in targets],multi)
            entry['loss']=float(loss.detach());loss.backward()
        bad=[name for name,p in model.named_parameters() if p.grad is not None and not torch.isfinite(p.grad).all()]
        entry['nonfinite_gradient_parameters']=bad
        entry['status']='finite' if not bad else 'nonfinite_gradient'
    except Exception:
        entry['status']='failed';entry['error']=traceback.format_exc()
    entry['phase_inputs']=list(phase_inputs);out['samples'].append(entry)
    (ROOT/'execution_checks/Tridos_gradient_diagnosis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in entry.items() if k!='phase_inputs'},ensure_ascii=False),flush=True)
    if entry['status']!='finite':break
