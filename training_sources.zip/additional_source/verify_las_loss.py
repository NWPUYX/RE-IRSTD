import sys,json
import numpy as np
import torch
from pathlib import Path
from las_loss_fix import BinaryMotionMaskLoss
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repositories/LASNet'))
from nets.LASNet import motion_mask_loss
boxes=np.array([[[[8.,8.,4.,4.,0.]]]],dtype=np.float32)
perfect=torch.full((1,1,32,32),-20.,device='cuda');perfect[:,:,8:12,8:12]=20.
original=float(motion_mask_loss()(perfect,boxes)); corrected=float(BinaryMotionMaskLoss()(perfect,boxes))
empty=torch.full((1,1,32,32),-20.,device='cuda'); no_boxes=np.zeros((1,1,1,5),dtype=np.float32)
empty_loss=float(BinaryMotionMaskLoss()(empty,no_boxes))
wrong=torch.full((1,1,32,32),20.,device='cuda'); wrong_loss=float(BinaryMotionMaskLoss()(wrong,boxes))
assert original<0 and abs(corrected)<1e-5 and 0<=empty_loss<1e-5 and 0<=wrong_loss<=1
gradient_input=torch.zeros((1,1,32,32),device='cuda',requires_grad=True)
BinaryMotionMaskLoss()(gradient_input,boxes).backward();assert torch.isfinite(gradient_input.grad).all()
out={'official_near_perfect_loss':original,'corrected_near_perfect_loss':corrected,'corrected_empty_loss':empty_loss,'corrected_wrong_loss':wrong_loss,'gradient_finite':True,'change':'heatmap target 255 to binary 1; architecture unchanged'}
(ROOT/'execution_checks/LASNet_loss_fix.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps(out))
