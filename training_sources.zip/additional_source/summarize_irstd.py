"""Describe measured gains only; never turn in-progress jobs into final results."""
import csv
import json
import statistics
from pathlib import Path
from summarize_results import DOMAINS, SEEDS, MODELS
ROOT = Path(__file__).resolve().parent


def summarize():
    records = {}
    for path in (ROOT / "runs").glob("*/*/seed_*/results.json"):
        for row in json.loads(path.read_text(encoding="utf-8")):
            records[(row["model"], row["source"], row["target"], row["seed"])] = row
    cells = []
    for source in DOMAINS:
        for target in DOMAINS:
            own = [records[("IRSTD", source, target, seed)] for seed in SEEDS if ("IRSTD", source, target, seed) in records]
            comparison = []
            for model in MODELS:
                if model == "IRSTD":
                    continue
                values = [records[(model, source, target, seed)] for seed in SEEDS if (model, source, target, seed) in records]
                if len(values) == 3:
                    comparison.append((statistics.mean(row["AP50"] for row in values), model, values))
            best = max(comparison, key=lambda item: item[0]) if comparison else None
            cell = {"source": source, "target": target, "cross_domain": source != target, "seeds": len(own),
                    "status": "complete" if len(own) == 3 else "partial" if own else "pending"}
            if own:
                for key in ("AP50", "F1", "FP_per_frame"):
                    cell[key] = statistics.mean(row[key] for row in own)
                    cell[key + "_std"] = statistics.stdev(row[key] for row in own) if len(own) == 3 else None
            if best:
                cell.update(best_complete_baseline=best[1], baseline_AP50=best[0])
                if len(own) == 3:
                    cell["AP50_gain_percentage_points"] = (cell["AP50"] - best[0]) * 100
            cells.append(cell)
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    lines = ["# IRSTD：同协议跨场景性能比较", "",
             "[KNOWN｜HIGH] 只使用完成全部训练和四域测试的正式results.json。短检查、阶段性checkpoint和未完成训练不构成最终结果。", "",
             "[INFERRED｜HIGH] 主比较是12个非对角跨域单元；同域4格单列。仅三种子齐全才给出标准差或相对最佳完整对比模型的差值。", "",
             "| 训练源 | 测试域 | 种子数 | IRSTD AP50% | 最佳完整对比模型 | 对比AP50% | 差值/百分点 |",
             "|---|---|---:|---:|---|---:|---:|"]
    for cell in cells:
        ap = "未完成"
        if cell["seeds"] == 3:
            ap = f"{cell['AP50']*100:.2f}±{cell['AP50_std']*100:.2f}"
        elif cell["seeds"]:
            ap = f"{cell['AP50']*100:.2f}（部分）"
        baseline = cell.get("best_complete_baseline", "未完成")
        base_ap = f"{cell['baseline_AP50']*100:.2f}" if "baseline_AP50" in cell else "—"
        delta = f"{cell['AP50_gain_percentage_points']:+.2f}" if "AP50_gain_percentage_points" in cell else "—"
        lines.append(f"| {cell['source']} | {cell['target']} | {cell['seeds']}/3 | {ap} | {baseline} | {base_ap} | {delta} |")
    macro = {}
    for model in MODELS:
        by_seed = []
        for seed in SEEDS:
            values = [records.get((model, source, target, seed)) for source in DOMAINS for target in DOMAINS if source != target]
            if all(row is not None for row in values):
                by_seed.append({key: statistics.mean(row[key] for row in values) for key in ("AP50", "F1", "FP_per_frame")})
        if len(by_seed) == 3:
            macro[model] = {key: {"mean": statistics.mean(row[key] for row in by_seed),
                                  "std": statistics.stdev(row[key] for row in by_seed)} for key in ("AP50", "F1", "FP_per_frame")}
    lines += ["", "[COMPUTED｜HIGH] 三种子、完整12个跨域单元的宏平均：", "",
              "| 模型 | 跨域AP50% | 跨域F1% | FP/帧 |", "|---|---:|---:|---:|"]
    for model, summary in macro.items():
        values = []
        for key, scale, digits in (("AP50", 100, 2), ("F1", 100, 2), ("FP_per_frame", 1, 4)):
            values.append(f"{summary[key]['mean']*scale:.{digits}f}±{summary[key]['std']*scale:.{digits}f}")
        lines.append("| " + model + " | " + " | ".join(values) + " |")
    if "IRSTD" not in macro:
        lines += ["", "[KNOWN｜HIGH] IRSTD完整三种子矩阵尚未完成；目前不能判断其整体跨域性能是否提升。"]
    else:
        baselines = {model: values for model, values in macro.items() if model != "IRSTD"}
        best_model = max(baselines, key=lambda name: baselines[name]["AP50"]["mean"])
        delta = (macro["IRSTD"]["AP50"]["mean"] - baselines[best_model]["AP50"]["mean"]) * 100
        lines += ["", f"[COMPUTED｜HIGH] 相对最佳完整对比模型{best_model}，IRSTD跨域宏平均AP50差值为{delta:+.2f}个百分点。",
                  "", "[INFERRED｜HIGH] 这是固定协议下的描述性比较；同时检查逐域结果、F1、误检和目录组区间，不能由均值差直接推出统计显著性。"]
    (out / "IRSTD性能比较.md").write_text("\n".join(lines), encoding="utf-8")
    (out / "IRSTD性能比较.json").write_text(json.dumps({"cells": cells, "cross_domain_macro": macro}, ensure_ascii=False, indent=2), encoding="utf-8")
    with (out / "IRSTD逐种子结果.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        fields = ["model", "source", "target", "seed", "AP50", "AP50_95", "F1", "FP_per_frame", "center_Pd_3px", "threshold", "best_epoch", "frames"]
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(row for row in records.values() if row["model"] == "IRSTD")
    return sum(row["model"] == "IRSTD" for row in records.values())


if __name__ == "__main__":
    print(summarize())
