"""Five-epoch source-only repair. Never launches target tests or another recipe."""
import os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import argparse
import copy
import json
import math
import platform
import random
import shutil
import sys
import time
import traceback
import numpy as np
import torch
from irstd_adapter import targets, source_audit, model_config
from irstd.engine.optim import make_optimizer
from evaluation import arrays
from irstd_v2.model import Model
from irstd_v2.data import make_loader
from irstd_v2.losses import supervised
from irstd_v2.evaluate import evaluate, validation_summary, geometry_probe
from irstd_v2.train import rng_state, restore_rng, save_checkpoint
from irstd_v2.settings import split_hashes
from .data import training_loader
from .settings import (HOME, PARENT, START_RUN, START_CHECKPOINT, SOURCE, SEED,
                       recipe, fingerprints, digest, write_json, now)


def ranking_summary(frames):
    result = {}
    for group in sorted({f["group"] for f in frames}):
        scores, tp, center, total = arrays([f for f in frames if f["group"] == group])
        recall = np.cumsum(tp[:,0]) / max(total, 1)
        precision = np.cumsum(tp[:,0]) / np.arange(1,len(tp)+1)
        envelope = np.maximum.accumulate(precision[::-1])[::-1]
        result[group] = {
            "precision_at_recall_50": float(envelope[recall >= .5].max()) if (recall >= .5).any() else 0.,
            "candidate_center_coverage_at_floor": float(center.sum()/max(total,1)),
            "box_vs_point_flag_disagreements": int((tp[:,0] != center).sum())}
    return result


def promotion(home, candidate):
    original = json.loads((PARENT / "promotion.json").read_text(encoding="utf-8"))["baseline"]
    b, v = original["validation"], candidate["source_validation"]
    bg, vg = original["geometry"], candidate["geometry_probe"]
    gates = {
        "source_group_AP50_retained": v["group_macro_AP50"] >= b["group_macro_AP50"] - .02,
        "source_pooled_AP50_retained": v["pooled"]["AP50"] >= b["pooled"]["AP50"] - .02,
        "source_geometry_error_improved": vg["log_size_error"] <= bg["log_size_error"] * .8}
    result = {"passed": all(gates.values()), "gates": gates, "baseline": original,
              "candidate": {k: candidate[k] for k in ("epoch", "source_validation", "geometry_probe", "ranking")},
              "scope": "Source validation only; no target test results or automatic matrix expansion",
              "updated_at": now()}
    write_json(home / "promotion.json", result)
    return result


def report(home, status):
    history_path = home / "history.jsonl"
    rows = [json.loads(s) for s in history_path.read_text(encoding="utf-8").splitlines()] if history_path.exists() else []
    best = torch.load(home / "best.pt", map_location="cpu", weights_only=False)
    promoted = promotion(home, best)
    v = best["source_validation"]
    lines = ["# IRSTD 原始视图混合短续调", "", f"[KNOWN｜HIGH] 更新时间：{now()}；状态：{status}。",
             "", "[KNOWN｜HIGH] 仅 DAUB-R/3407，起点为上一轮第5轮最佳EMA权重；最多5轮，固定学习率5e-5，FP32/batch4；每个完整批次2张原始视图、2张连续几何增强。",
             "", "[KNOWN｜HIGH] GIoU=0.1；相对证据、零和卷积、空间门控、全分辨率通路与检测头未变。P3/P4及双视图等变损失关闭。",
             "", "[KNOWN｜HIGH] 全部数字是源验证结果，不是跨域测试；起点记为续调第0轮，参与最佳权重比较。验收通过也不会自动启动新配方或完整矩阵。",
             "", "| 续调轮数 | 训练帧 | 原始/增强 | 组宏AP50 | pooled AP50 | data19 AP50 | data22 AP50 | pooled AP50:95 | data22 P@R50 | 尺寸压力误差 |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    initial = json.loads((home / "initial_source_validation.json").read_text(encoding="utf-8"))
    for row in [initial, *rows]:
        summary = row["source_validation"]
        groups = summary["by_group"]
        lines.append(f"| {row['epoch']} | {row.get('train_frames',0)} | {row.get('view_counts',{})} | "
                     f"{summary['group_macro_AP50']*100:.2f}% | {summary['pooled']['AP50']*100:.2f}% | "
                     f"{groups['data19']['AP50']*100:.2f}% | {groups['data22']['AP50']*100:.2f}% | "
                     f"{summary['pooled']['AP50_95']*100:.2f}% | {row['ranking']['data22']['precision_at_recall_50']*100:.2f}% | "
                     f"{row['geometry_probe']['log_size_error']:.4f} |")
    lines.extend(["", f"[COMPUTED｜HIGH] 当前最佳：续调第{best['epoch']}轮；分组宏平均AP50={v['group_macro_AP50']*100:.4f}%；pooled AP50:95={v['pooled']['AP50_95']*100:.4f}%。",
                  "", f"[COMPUTED｜HIGH] 原三项推广验收：{'通过' if promoted['passed'] else '未通过'}；{promoted['gates']}。",
                  "", "[KNOWN｜HIGH] 原门槛：组宏AP50≥77.3767%，pooled AP50≥76.8410%，固定压力探针log尺寸误差≤0.339524；AP50:95同步审查，本轮不添加事后门槛。",
                  "", "[KNOWN｜HIGH] 每轮原始权重/EMA、优化器及随机状态、源验证预测、几何探针、分组排序诊断均独立保存。best.pt 为EMA权重；last.pt用于断点恢复。",
                  "", "[KNOWN｜HIGH] 启动：D:\\Miniconda3\\envs\\IRSTD\\python.exe -u -m irstd_replay.run；恢复加 --resume；工作目录 D:\\Codex\\Scenario_adaptability。",
                  "", "[KNOWN｜HIGH] 微调日程与原随机初始化完整训练不同，不能把该修复结果作为同配方的完整训练对照。"])
    (home / "结果与进度.md").write_text("\n".join(lines), encoding="utf-8")
    return promoted


def train(smoke=False, resume=False):
    cfg, device, core = recipe(), torch.device("cuda"), model_config()
    home = HOME / "smoke" if smoke else HOME
    home.mkdir(parents=True, exist_ok=True)
    preflight = json.loads((HOME / "checks/preflight.json").read_text(encoding="utf-8"))
    if not preflight["passed"] or preflight["recipe"] != cfg or preflight["source_hashes"] != fingerprints():
        raise ValueError("Preflight failed or source/recipe changed")
    if preflight["split_hashes"] != split_hashes() or preflight["initial_checkpoint_sha256"] != digest(START_CHECKPOINT):
        raise ValueError("Source split or warmstart checkpoint changed")
    smoke_result = HOME / "smoke/training_complete.json"
    if not smoke and (not smoke_result.exists() or not json.loads(smoke_result.read_text(encoding="utf-8"))["smoke_passed"]):
        raise ValueError("Two-update smoke validation must pass before full repair")
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.backends.cudnn.benchmark = False
    start = torch.load(START_CHECKPOINT, map_location="cpu", weights_only=False)
    audit = source_audit(SOURCE)
    reference = audit["size_reference_512"]
    assert reference == start["config"]["size_reference_512"]
    config = {"source": SOURCE, "seed": SEED, "recipe": cfg, "smoke": smoke,
              "size_reference_512": reference, "source_hashes": fingerprints(), "split_hashes": split_hashes(),
              "initialization": {"checkpoint": str(START_CHECKPOINT), "sha256": digest(START_CHECKPOINT),
                                 "parent_epoch": 5, "weights": "EMA", "optimizer": "fresh", "ema": "initialized from same EMA weights"}}
    if (home / "config.json").exists():
        if json.loads((home / "config.json").read_text(encoding="utf-8")) != config or not resume:
            raise ValueError("Existing run requires identical configuration and explicit --resume")
    write_json(home / "config.json", config)
    write_json(home / "source_audit.json", audit)
    snapshot = home / "source_snapshot"
    snapshot.mkdir(exist_ok=True)
    for path in sorted((HOME.parents[2] / "irstd_replay").glob("*.py")):
        shutil.copyfile(path, snapshot / path.name)
    if (home / "training_complete.json").exists():
        return
    write_json(home / "environment.json", {"python": sys.version, "torch": torch.__version__, "cuda": torch.version.cuda,
               "gpu": torch.cuda.get_device_name(device), "platform": platform.platform(), "started_at": now()})
    model = Model(cfg).to(device)
    model.load_state_dict(start["model"], strict=True)
    optimizer = make_optimizer(model, {**core["train"], "learning_rate": cfg["learning_rate"], "weight_decay": cfg["weight_decay"]})
    assert not optimizer.state
    ema = copy.deepcopy(model).eval()
    for p in ema.parameters():
        p.requires_grad_(False)
    initial_weights = {k: v.clone() for k,v in start["model"].items()}
    training = training_loader(SOURCE, cfg, SEED)
    validation = make_loader(SOURCE, "val", cfg)
    parameters = set(dict(model.named_parameters()))
    updates, first_epoch, previous_seconds = 0, 0, 0.
    if not (home / "best.pt").exists():
        payload = json.loads((START_RUN / "best_source_val_predictions.json").read_text(encoding="utf-8"))
        initial = {"epoch": 0, "source_validation": start["source_validation"], "geometry_probe": start["geometry_probe"],
                   "ranking": ranking_summary(payload["frames"])}
        write_json(home / "initial_source_validation.json", initial)
        save_checkpoint(home / "best.pt", {**initial, "model": start["model"], "config": config})
        shutil.copyfile(START_RUN / "best_source_val_predictions.json", home / "best_source_val_predictions.json")
        del payload
    best = torch.load(home / "best.pt", map_location="cpu", weights_only=False)
    best_key = (best["source_validation"]["group_macro_AP50"], best["source_validation"]["pooled"]["AP50"])
    del best, start
    if resume and (home / "last.pt").exists():
        state = torch.load(home / "last.pt", map_location="cpu", weights_only=False)
        if state["config"] != config:
            raise ValueError("Resume checkpoint configuration mismatch")
        model.load_state_dict(state["model"])
        ema.load_state_dict(state["ema"])
        optimizer.load_state_dict(state["optimizer"])
        first_epoch, updates, previous_seconds = state["next_epoch"], state["updates"], state["elapsed_seconds"]
        restore_rng(state["rng"])
        del state
    write_json(home / "process.json", {"pid": os.getpid(), "started_at": now(), "resume": resume})
    started = time.perf_counter()
    for epoch in range(first_epoch, 1 if smoke else cfg["epochs"]):
        if config["source_hashes"] != fingerprints():
            raise ValueError("Frozen source changed during this repair")
        training.dataset.epoch = epoch
        model.train()
        tick, seen, counts, loss_sum, batches = time.perf_counter(), 0, {"native":0,"augmented":0}, {}, 0
        torch.cuda.reset_peak_memory_stats(device)
        for iteration, (images, samples) in enumerate(training):
            if len(samples) == 4:
                assert sum(s["view_type"] == "native" for s in samples) == 2
            optimizer.zero_grad(set_to_none=True)
            target = targets(samples, core, reference, device, "shared_regression")
            valid = torch.stack([s["valid_mask"] for s in samples]).to(device)
            output = model(images.to(device), valid_mask=valid)
            normalizers = {"images": len(samples), "targets": sum(len(s["boxes"]) for s in samples), "boxes": sum(len(s["boxes"]) for s in samples)}
            terms = supervised(output, target, core, reference, cfg, images.new_ones(len(samples)).to(device), normalizers)
            loss = terms["total"]
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Nonfinite loss at epoch {epoch+1}, batch {iteration}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["gradient_clip"], error_if_nonfinite=True)
            optimizer.step()
            updates += 1
            decay = .9999 * (1-math.exp(-updates/2000))
            with torch.no_grad():
                current = model.state_dict()
                for name, value in ema.state_dict().items():
                    value.mul_(decay).add_(current[name], alpha=1-decay) if name in parameters else value.copy_(current[name])
            for name, value in terms.items():
                loss_sum[name] = loss_sum.get(name,0.) + float(value.detach())
            for sample in samples:
                counts[sample["view_type"]] += 1
            seen += len(samples)
            batches += 1
            if iteration % 20 == 0:
                progress = {"status": "training", "pid": os.getpid(), "epoch": epoch+1, "maximum_epochs":5,
                            "batch": iteration+1, "total_batches":len(training), "frames":seen, "view_counts":counts,
                            "last_loss":float(loss.detach()), "learning_rate": optimizer.param_groups[0]["lr"],
                            "epoch_seconds":time.perf_counter()-tick, "updated_at":now()}
                write_json(home / "progress.json", progress)
                print(json.dumps(progress), flush=True)
            del output, terms, loss, target, valid
            if smoke and iteration == 1:
                break
        torch.cuda.synchronize()
        training_seconds = time.perf_counter()-tick
        assert all(g["lr"] == 5e-5 for g in optimizer.param_groups)
        if not smoke:
            assert seen == len(training.dataset) == 4181
        write_json(home / "progress.json", {"status":"source_validation", "pid":os.getpid(), "epoch":epoch+1,
                   "maximum_epochs":5, "frames":seen, "view_counts":counts, "updated_at":now()})
        pred_path = home / f"epoch_{epoch+1:02d}_source_val_predictions.json"
        frames = evaluate(ema, validation, device, reference, pred_path, 2 if smoke else None)
        summary = validation_summary(frames)
        probe = geometry_probe(ema, SOURCE, cfg, reference, device)
        stat = {"epoch":epoch+1, "train_frames":seen, "view_counts":counts, "updates":updates,
                "loss_mean_over_batches":{k:v/batches for k,v in loss_sum.items()}, "learning_rate":5e-5,
                "training_seconds":training_seconds, "validation_seconds":time.perf_counter()-tick-training_seconds,
                "elapsed_seconds":previous_seconds+time.perf_counter()-started, "source_validation":summary,
                "geometry_probe":probe, "ranking":ranking_summary(frames),
                "peak_cuda_allocated_bytes":torch.cuda.max_memory_allocated(device)}
        epoch_state = {"model":ema.state_dict(), "config":config, **stat}
        save_checkpoint(home / f"epoch_{epoch+1:02d}_ema.pt", epoch_state)
        key = (summary["group_macro_AP50"],summary["pooled"]["AP50"])
        if key > best_key:
            best_key = key
            save_checkpoint(home / "best.pt", epoch_state)
            shutil.copyfile(pred_path, home / "best_source_val_predictions.json")
        last_state = {"model":model.state_dict(), "ema":ema.state_dict(), "optimizer":optimizer.state_dict(),
                      "next_epoch":epoch+1, "updates":updates, "elapsed_seconds":stat["elapsed_seconds"],
                      "rng":rng_state(), "config":config}
        save_checkpoint(home / "last.pt", last_state)
        history_file = home / "history.jsonl"
        history = [json.loads(s) for s in history_file.read_text(encoding="utf-8").splitlines()] if history_file.exists() else []
        history = [s for s in history if s["epoch"] != epoch+1] + [stat]
        history.sort(key=lambda s:s["epoch"])
        temp = home / "history.jsonl.tmp"
        temp.write_text("".join(json.dumps(s,allow_nan=False)+"\n" for s in history),encoding="utf-8")
        temp.replace(history_file)
        if smoke:
            reloaded = torch.load(home / "last.pt", map_location="cpu", weights_only=False)
            changed = [k for k in parameters if not torch.equal(reloaded["model"][k],initial_weights[k])]
            assert reloaded["updates"] == 2 and len(reloaded["optimizer"]["state"]) > 0 and changed
            assert all(torch.equal(reloaded["ema"][k],v.cpu()) for k,v in ema.state_dict().items())
            restored_model = Model(cfg)
            restored_model.load_state_dict(reloaded["model"])
            restored_optimizer = make_optimizer(restored_model, {**core["train"], "learning_rate":5e-5, "weight_decay":cfg["weight_decay"]})
            restored_optimizer.load_state_dict(reloaded["optimizer"])
            assert len(restored_optimizer.state) == len(optimizer.state)
            assert all(g["lr"] == 5e-5 for g in restored_optimizer.param_groups)
            write_json(home / "training_complete.json", {"smoke_passed":True, "updates":updates,
                       "view_counts":counts, "parameters_updated":len(changed), "finite_gradients_and_loss":True,
                       "optimizer_and_ema_reload_passed":True, "updated_at":now()})
            write_json(home / "progress.json", {"status":"smoke_passed", "updated_at":now(), "updates":updates})
            return
        report(home, f"已完成{epoch+1}/5轮，仍在本次预算内")
        print(json.dumps({"epoch_completed":epoch+1,"group_macro_AP50":summary["group_macro_AP50"],
                          "data22_AP50":summary["by_group"]["data22"]["AP50"],"training_seconds":training_seconds}),flush=True)
    result = report(home, "五轮续调及源验证完成")
    status = "completed_source_gate_passed_review_pending" if result["passed"] else "completed_source_gate_failed"
    completed = {"status":status,"epochs_run":cfg["epochs"],"updates":updates,
                 "best_epoch":result["candidate"]["epoch"], "promotion_passed":result["passed"],
                 "elapsed_seconds":previous_seconds+time.perf_counter()-started,"target_test_cells":0,"updated_at":now()}
    write_json(home / "training_complete.json", completed)
    write_json(home / "progress.json", completed)
    print(json.dumps(completed),flush=True)


def main():
    import msvcrt
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke",action="store_true")
    parser.add_argument("--resume",action="store_true")
    args = parser.parse_args()
    HOME.mkdir(parents=True,exist_ok=True)
    with (HOME / "run.lock").open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1):
            lock.write(b"1")
            lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:
            raise SystemExit("Another replay repair process is active")
        torch.set_num_threads(8)
        write_json(HOME / "recipe.json",recipe())
        try:
            train(args.smoke,args.resume)
        except Exception:
            home = HOME / "smoke" if args.smoke else HOME
            home.mkdir(parents=True,exist_ok=True)
            write_json(home / "failure.json", {"pid":os.getpid(),"updated_at":now(),"traceback":traceback.format_exc()})
            write_json(home / "progress.json", {"status":"failed","updated_at":now(),"pid":os.getpid()})
            raise


if __name__ == "__main__":
    main()
