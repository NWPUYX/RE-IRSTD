"""Bounded native-view replay repair; original IRSTD/v2 sources stay frozen."""
