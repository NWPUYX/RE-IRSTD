from pathlib import Path
import hashlib
import json
from irstd_v2.settings import fingerprints as original_fingerprints, write_json, now

ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / "experiments/IRSTD_v2/geometry_giou_groupval_v1"
START_RUN = PARENT / "runs/DAUB-R/seed_3407"
START_CHECKPOINT = START_RUN / "best.pt"
HOME = ROOT / "experiments/IRSTD_v2/replay50_finetune5_v1"
SOURCE, SEED = "DAUB-R", 3407


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fingerprints():
    result = original_fingerprints()
    result.update({str(p.relative_to(ROOT.parent)): digest(p)
                   for p in sorted(Path(__file__).resolve().parent.glob("*.py"))})
    return result


def recipe():
    cfg = json.loads((PARENT / "recipe.json").read_text(encoding="utf-8"))
    cfg.update(name="replay50_finetune5_v1", initialization="v2_best_epoch5_EMA_warmstart",
               epochs=5, learning_rate=5e-5, validation_interval=1,
               learning_rate_schedule="constant_no_warmup", native_per_full_batch=2,
               augmented_per_full_batch=2, save_each_epoch=True)
    # This repair has a fixed budget, not the parent's patience/minimum schedule.
    cfg.pop("minimum_epochs")
    cfg.pop("patience_checks")
    if cfg["batch"] != 4 or cfg["microbatch"] != 4:
        raise ValueError("Approved replay recipe requires full FP32 batches of four")
    if cfg["giou_weight"] != .1 or any(cfg[k] for k in (
        "geometry_equivariance_weight", "background_swap", "soft_relative_evidence",
        "valid_region_evidence", "masked_group_norm")):
        raise ValueError("Only native-view replay is authorized for this repair")
    return cfg
