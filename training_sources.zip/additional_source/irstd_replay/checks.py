import json
import random
import torch
from irstd_adapter import targets, model_config
from irstd_v2.data import Data, render
from irstd_v2.model import Model
from irstd_v2.settings import fingerprints as original_fingerprints, split_hashes
from .data import ReplayData, BalancedViews
from .settings import HOME, START_CHECKPOINT, SOURCE, SEED, recipe, fingerprints, digest, write_json, now


def main():
    torch.set_num_threads(4)
    cfg = recipe()
    start = torch.load(START_CHECKPOINT, map_location="cpu", weights_only=False)
    assert start["epoch"] == 5 and not start["config"]["smoke"]
    assert start["config"]["source_hashes"] == original_fingerprints()
    assert start["config"]["split_hashes"] == split_hashes()
    data = ReplayData(SOURCE, "train", cfg, training=True, seed=SEED)
    validation = Data(SOURCE, "val", cfg)
    assert set(r["group"] for r in data.records).isdisjoint(r["group"] for r in validation.records)
    assert {r["path"] for r in data.records}.isdisjoint(r["path"] for r in validation.records)
    batch_results, native_exact, augmented_count, native_count = [], 0, 0, 0
    unique, augmented_heights, augmented_offsets = set(), [], []
    for epoch in range(5):
        data.epoch = epoch
        batches = list(BalancedViews(data))
        assert batches == list(BalancedViews(data))
        flat = [i for batch in batches for i, view in batch]
        assert len(flat) == len(set(flat)) == len(data)
        counts = {view: sum(v == view for batch in batches for i,v in batch) for view in ("native", "augmented")}
        assert all(sum(v == "native" for _,v in batch) == 2 for batch in batches if len(batch) == 4)
        batch_results.append({"epoch": epoch+1, "frames": len(flat), **counts})
        if epoch:
            continue
        for batch in batches[:8]:
            for key in batch:
                index, view = key
                sample = data[key]
                unique.add(index)
                assert len(sample["boxes"]) == len(data.records[index]["boxes"])
                assert (sample["boxes"] >= 0).all() and (sample["boxes"] <= 512).all()
                assert torch.equal(sample["ignore_mask"], ~sample["valid_mask"])
                if view == "native":
                    base = data.base_sample(index)
                    flip = random.Random(SEED + index * 97).random() < .5
                    image = base["image"].flip(-1) if flip else base["image"]
                    boxes = base["boxes"].clone()
                    if flip:
                        boxes = boxes[:, [2,1,0,3]]
                        boxes[:, [0,2]] = 512-boxes[:, [0,2]]
                    assert torch.equal(sample["image"], image) and torch.equal(sample["boxes"], boxes)
                    assert torch.equal(sample["valid_mask"], base["valid_mask"].flip(-1) if flip else base["valid_mask"])
                    native_exact += 1
                    native_count += 1
                else:
                    image, boxes, valid = render(data.records[index], sample["geometry_plan"])
                    assert torch.equal(image, sample["image"]) and torch.equal(boxes, sample["boxes"])
                    augmented_count += 1
                    target = targets([sample], model_config(), start["config"]["size_reference_512"], torch.device("cpu"), "shared_regression")
                    augmented_heights.extend((sample["boxes"][:,3]-sample["boxes"][:,1]).tolist())
                    augmented_offsets.extend(target["offsets"].tolist())
    assert torch.tensor(augmented_heights).std() > 1
    assert torch.tensor(augmented_offsets).std() > .05
    model = Model(cfg).eval()
    model.load_state_dict(start["model"], strict=True)
    assert sum(p.numel() for p in model.parameters()) == 808952
    other = Model(start["config"]["recipe"]).eval()
    other.load_state_dict(start["model"], strict=True)
    sample = validation[0]
    with torch.inference_mode():
        before = other(sample["image"][None], valid_mask=sample["valid_mask"][None])
        after = model(sample["image"][None], valid_mask=sample["valid_mask"][None])
    assert before.keys() == after.keys()
    assert all(torch.equal(before[k], after[k]) for k in before if torch.is_tensor(before[k]))
    result = {"passed": True, "updated_at": now(), "recipe": cfg, "source_hashes": fingerprints(),
              "split_hashes": split_hashes(), "initial_checkpoint_sha256": digest(START_CHECKPOINT),
              "batches": batch_results, "native_exact_samples": native_exact,
              "augmented_exact_samples": augmented_count, "target_count_preserved": True,
              "initial_forward_bitwise_equal": True, "parameters": 808952,
              "augmented_height_std": float(torch.tensor(augmented_heights).std()),
              "augmented_offset_std": float(torch.tensor(augmented_offsets).std()),
              "no_validation_images_in_training": True}
    write_json(HOME / "checks/preflight.json", result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
