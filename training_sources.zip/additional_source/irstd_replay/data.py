import math
import random
import torch
from torch.utils.data import DataLoader, Sampler
from irstd_v2.data import Data, collate
from data_pipeline import worker_seed


class ReplayData(Data):
    """Sampler provides (record index, view); labels are never dropped."""
    def __getitem__(self, key):
        index, view = key
        rng = random.Random(self.seed + self.epoch * 1_000_003 + index * 97)
        if view == "augmented":
            sample = self.augmented(index, rng)
        elif view == "native":
            sample = self.base_sample(index)
            if rng.random() < .5:
                sample = dict(sample)
                sample["image"] = sample["image"].flip(-1)
                sample["boxes"] = sample["boxes"][:, [2, 1, 0, 3]].clone()
                sample["boxes"][:, [0, 2]] = 512 - sample["boxes"][:, [0, 2]]
                for name in ("valid_mask", "ignore_mask", "known_background_mask"):
                    sample[name] = sample[name].flip(-1)
                plan = dict(sample["geometry_plan"])
                plan.update(sx=-plan["sx"], tx=512-plan["tx"])
                sample["geometry_plan"] = plan
        else:
            raise ValueError(view)
        sample["view_type"] = view
        return sample


class BalancedViews(Sampler):
    def __init__(self, dataset):
        self.dataset = dataset

    def __len__(self):
        return math.ceil(len(self.dataset) / 4)

    def __iter__(self):
        epoch, seed = self.dataset.epoch, self.dataset.seed
        generator = torch.Generator().manual_seed(seed + epoch * 1_000_003)
        indices = torch.randperm(len(self.dataset), generator=generator).tolist()
        for start in range(0, len(indices), 4):
            batch = indices[start:start+4]
            # Full batches are exactly 2+2; odd remainder alternates by epoch.
            native = len(batch)//2 + (len(batch)%2 if epoch%2 == 0 else 0)
            order = torch.randperm(len(batch), generator=generator).tolist()
            native_positions = set(order[:native])
            yield [(index, "native" if j in native_positions else "augmented")
                   for j, index in enumerate(batch)]


def training_loader(source, cfg, seed):
    data = ReplayData(source, "train", cfg, training=True, seed=seed)
    return DataLoader(data, batch_sampler=BalancedViews(data), num_workers=cfg["workers"],
                      collate_fn=collate, worker_init_fn=worker_seed,
                      pin_memory=False, persistent_workers=False)
