import copy
import random
import torch
from torch.utils.data import DataLoader, Sampler
from data_pipeline import worker_seed
from irstd_replay.data import ReplayData, BalancedViews
from irstd_v2.data import choose_plan, render, collate


def direction_plan(record, cfg, rng, direction):
    geometry = copy.deepcopy(cfg["geometry"])
    low, high = geometry["scale_jitter"]
    geometry["scale_jitter"] = [low, 1.] if direction == "shrink" else [1., high]
    # Retry the same record within the approved interval; never drop labels or
    # silently count an identity fallback as the requested direction.
    for block in range(8):
        plan = choose_plan(record, geometry, rng)
        scale = plan["requested_jitter"]
        if (direction == "shrink" and scale < 1) or (direction == "enlarge" and scale > 1):
            plan["direction_retry_blocks"] = block
            return plan
    raise ValueError(f"Cannot preserve all targets for requested direction {direction}")


class DirectionData(ReplayData):
    def __getitem__(self, key):
        index, view = key
        if view == "native":
            return super().__getitem__((index, view))
        if view not in ("shrink", "enlarge"):
            raise ValueError(view)
        rng = random.Random(self.seed + self.epoch * 1_000_003 + index * 97)
        plan = direction_plan(self.records[index], self.cfg, rng, view)
        image, boxes, valid = render(self.records[index], plan)
        return {"image":image,"boxes":boxes,"points":torch.empty(0,2),"complete":True,
            "known_background_mask":torch.zeros_like(valid),"ignore_mask":~valid,"valid_mask":valid,
            "sample_id":str(self.records[index]["id"]),"scene_id":self.records[index]["group"],
            "record_index":index,"split":self.split,"geometry_plan":plan,"view_type":view}


class DirectionBatches(Sampler):
    def __init__(self, dataset): self.dataset = dataset
    def __len__(self): return len(BalancedViews(self.dataset))
    def __iter__(self):
        for j, batch in enumerate(BalancedViews(self.dataset)):
            positions = [i for i,(_,view) in enumerate(batch) if view == "augmented"]
            if len(positions) == 2:
                rng = random.Random(self.dataset.seed + self.dataset.epoch*1_000_003 + j*12497 + 501)
                if rng.random() < .5: positions.reverse()
                assignments = dict(zip(positions,("shrink","enlarge")))
            elif len(positions) == 1:
                assignments = {positions[0]:"enlarge" if self.dataset.epoch%2 else "shrink"}
            else:
                assignments = {}
            yield [(index,assignments.get(i,view)) for i,(index,view) in enumerate(batch)]


def training_loader(source,cfg,seed):
    data = DirectionData(source,"train",cfg,training=True,seed=seed)
    return DataLoader(data,batch_sampler=DirectionBatches(data),num_workers=cfg["workers"],
        collate_fn=collate,worker_init_fn=worker_seed,pin_memory=False,persistent_workers=False)
