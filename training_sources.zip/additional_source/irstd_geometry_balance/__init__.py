"""Direction-balanced continuation of the frozen-feature geometry repair."""
