"""Two-epoch continuation; balance shrink/enlarge without changing the model."""
import os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import argparse
from collections import Counter, defaultdict
import copy
import hashlib
import json
import math
from pathlib import Path
import platform
import random
import shutil
import sys
import time
import traceback
import numpy as np
import torch
from irstd_adapter import model_config, targets
from irstd_geometry_repair.run import new_model, assert_frozen, loss_for, ap_key, baseline, geometry_ok
from irstd_replay.data import ReplayData, BalancedViews
from irstd_replay.run import ranking_summary
from irstd_v2.data import Data, choose_plan, render, make_loader
from irstd_v2.losses import decoded_geometry, giou_pairs
from irstd_v2.evaluate import evaluate, validation_summary
from irstd_v2.settings import split_hashes, write_json, now
from irstd_v2.train import rng_state, restore_rng, save_checkpoint
from .data import DirectionData, DirectionBatches, direction_plan, training_loader

ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT / "experiments/IRSTD_v2/v1_geometry_heads_lr1e4_3epoch_v1"
HOME=ROOT / "experiments/IRSTD_v2/v1_geometry_balanced_direction_2epoch_v1"
START=PARENT / "last.pt"
SOURCE,SEED="DAUB-R",3407
PREFIXES=("heads.offset.","heads.size.")


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_hashes():
    expected=json.loads((PARENT / "config.json").read_text(encoding="utf-8"))["source_hashes"]
    current={k:sha(ROOT.parent / k) for k in expected}
    assert current==expected,"Parent sources changed"
    current.update({str(p.relative_to(ROOT.parent)):sha(p) for p in Path(__file__).parent.glob("*.py")})
    return current


def recipe():
    cfg=json.loads((PARENT / "recipe.json").read_text(encoding="utf-8"))
    cfg.update(name=HOME.name,initialization="parent_epoch3_raw_EMA_optimizer_RNG_continuation",
        epochs=5,additional_epochs=2,parent_epochs=3,maximum_validation_checks=2,
        views_per_full_batch={"native":2,"shrink":1,"enlarge":1},
        selection="original_gates_and_enlarge_review_then_geometry_eligible_then_group_AP50_then_pooled",
        prior_geometry_selection_saved_separately=True)
    return cfg


def enlarge_limit():
    d=json.loads((PARENT / "scale_response.json").read_text(encoding="utf-8"))
    return d["models"]["v1_initial"]["per_scale"]["1.4"]["mean_log_size_error"]


@torch.inference_mode()
def probe(model,cfg,reference,device):
    data=Data(SOURCE,"val",cfg); grouped=defaultdict(list)
    for i,r in enumerate(data.records): grouped[r["group"]].append(i)
    ids=[group[j] for group in grouped.values() for j in np.linspace(0,len(group)-1,min(cfg["probe_samples_per_group"],len(group)),dtype=int)]
    values=[]; model.eval()
    for i in ids:
        record=data.records[i]
        for scale in cfg["probe_scales"]:
            digest=hashlib.sha256(f"{SOURCE}/{record['id']}/{scale}".encode()).digest()
            plan=choose_plan(record,cfg["geometry"],random.Random(int.from_bytes(digest[:8],"little")),forced_scale=scale,flip_override=False)
            image,boxes,valid=render(record,plan)
            sample={**data.base_sample(i),"image":image,"boxes":boxes,"valid_mask":valid,"ignore_mask":~valid}
            target=targets([sample],model_config(),reference,device,"shared_regression")
            output=model(image[None].to(device),valid_mask=valid[None].to(device))
            centers,wh=decoded_geometry(output,target,reference)
            truth_center=target["anchors"][:,1:]+target["offsets"]
            truth_wh=target["sizes"].exp()*wh.new_tensor(reference)
            pred=torch.cat((centers-wh/2,centers+wh/2),1)
            truth=torch.cat((truth_center-truth_wh/2,truth_center+truth_wh/2),1)
            values.append({"targets":len(wh),"scale":scale,"fallback":plan["fallback"],
                "log_size_error":float((wh.log()-truth_wh.log()).abs().mean()),
                "center_error_input_px":float((centers-truth_center).abs().mean()),"mean_giou":float(giou_pairs(pred,truth).mean())})
    def aggregate(rows):
        count=sum(x["targets"] for x in rows)
        return {k:sum(x[k]*x["targets"] for x in rows)/max(count,1) for k in ("log_size_error","center_error_input_px","mean_giou")}
    total={"scope":"fixed source-val GT anchors only; not a test score","samples":len(values),"targets":sum(x["targets"] for x in values),
        **aggregate(values),"fallback_views":sum(x["fallback"] for x in values),"requested_scales":cfg["probe_scales"]}
    return total,{str(s):aggregate([x for x in values if x["scale"]==s]) for s in cfg["probe_scales"]}


def gates(row):
    b=baseline(); v=row["source_validation"]
    original={"source_group_AP50_retained":v["group_macro_AP50"]>=b["validation"]["group_macro_AP50"]-.02,
        "source_pooled_AP50_retained":v["pooled"]["AP50"]>=b["validation"]["pooled"]["AP50"]-.02,
        "source_geometry_error_improved":geometry_ok(row["geometry_probe"])}
    return original,row["per_scale"]["1.4"]["log_size_error"]<=enlarge_limit()


def candidate_key(row):
    original,review=gates(row)
    return (all(original.values()) and review,geometry_ok(row["geometry_probe"]),*ap_key(row))


def previous_key(row): return (geometry_ok(row["geometry_probe"]),*ap_key(row))


def load_start(cfg,device,state):
    model,opt=new_model(cfg,device,state["model"])
    opt.load_state_dict(state["optimizer"])
    ema=copy.deepcopy(model).eval(); ema.load_state_dict(state["ema"])
    for p in ema.parameters(): p.requires_grad_(False)
    assert len(opt.state)==8 and all(g["lr"]==1e-4 for g in opt.param_groups)
    assert all(int(s["step"])==state["updates"] for s in opt.state.values())
    return model,opt,ema


def check(cfg,state,reference,device,identity):
    folder=HOME / "checks"; folder.mkdir(parents=True,exist_ok=True)
    data=DirectionData(SOURCE,"train",cfg,training=True,seed=SEED); plan_rows=[]
    for epoch in (3,4):
        data.epoch=epoch; counts=Counter(); ids=[]; retries=0; scales=[]
        for batch in DirectionBatches(data):
            if len(batch)==4: assert Counter(v for _,v in batch)=={"native":2,"shrink":1,"enlarge":1}
            for index,view in batch:
                counts[view]+=1; ids.append(index)
                if view=="native": continue
                plan=direction_plan(data.records[index],cfg,random.Random(SEED+epoch*1_000_003+index*97),view)
                retries+=plan["direction_retry_blocks"]
                assert not plan["fallback"]
                scales.append(plan["requested_jitter"])
        assert sorted(ids)==list(range(4181))
        plan_rows.append({"global_epoch":epoch+1,"counts":dict(counts),"all_4181_records_once":True,
            "identity_fallbacks":0,"extra_retry_blocks":retries,"mean_log_scale":float(np.log(scales).mean())})
    write_json(folder / "sampling_preflight.json",{"passed":True,"epochs":plan_rows})
    model,opt,ema=load_start(cfg,device,state)
    for name,value in model.state_dict().items(): assert torch.equal(value.cpu(),state["model"][name])
    for name,value in ema.state_dict().items(): assert torch.equal(value.cpu(),state["ema"][name])
    old_rows=[json.loads(x) for x in (PARENT / "history.jsonl").read_text(encoding="utf-8").splitlines()]
    total,split=probe(ema,cfg,reference,device)
    assert abs(total["log_size_error"]-old_rows[-1]["geometry_probe"]["log_size_error"])<1e-7
    loader=training_loader(SOURCE,cfg,SEED); loader.dataset.epoch=3
    images,samples=next(iter(loader)); assert Counter(s["view_type"] for s in samples)=={"native":2,"shrink":1,"enlarge":1}
    model.eval()
    with torch.no_grad(): before={k:v.clone() for k,v in model(images.to(device)).items() if v is not None}
    opt.zero_grad(set_to_none=True)
    loss,terms,_=loss_for(model,images,samples,reference,cfg,device); loss.backward()
    assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith(PREFIXES))
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad)
    torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10.,error_if_nonfinite=True); opt.step()
    assert all(int(s["step"])==state["updates"]+1 for s in opt.state.values())
    assert_frozen(model,state["model"])
    with torch.no_grad(): after=model(images.to(device))
    for key in ("center_logits","auxiliary_center_logits"): assert torch.equal(before[key],after[key])
    assert not torch.equal(before["log_size"],after["log_size"])
    save_checkpoint(folder / "smoke.pt",{"model":model.state_dict(),"optimizer":opt.state_dict()})
    saved=torch.load(folder / "smoke.pt",map_location="cpu",weights_only=False)
    restored,loaded=new_model(cfg,device,saved["model"]); loaded.load_state_dict(saved["optimizer"]); restored.eval()
    with torch.no_grad(): result=restored(images.to(device))
    assert all(torch.equal(result[k],v) for k,v in after.items() if v is not None)
    write_json(folder / "preflight.json",{"passed":True,"identity":identity,"trainable_parameters":10516,"total_parameters":808952,
        "parent_raw_EMA_optimizer_loaded_exactly":True,"optimizer_steps_before":state["updates"],"optimizer_steps_after_smoke":state["updates"]+1,
        "frozen_state_bitwise_equal":True,"center_and_aux_logits_bitwise_equal":True,"save_reload_bitwise_equal":True,
        "initial_geometry_reproduced":True,"initial_geometry_probe":total,"initial_per_scale":split,"updated_at":now()})
    print(json.dumps({"preflight_passed":True,"sampling":plan_rows}),flush=True)


def report():
    best=torch.load(HOME / "best.pt",map_location="cpu",weights_only=False)
    prior=torch.load(HOME / "best_previous_selection.pt",map_location="cpu",weights_only=False)
    original,review=gates(best)
    result={"original_gates_passed":all(original.values()),"passed":all(original.values()) and review,"gates":original,
        "enlarge_review_passed":review,"enlarge_error_limit":enlarge_limit(),"baseline":baseline(),
        "candidate":{k:best[k] for k in ("epoch","source_validation","geometry_probe","per_scale","ranking")},
        "selection":recipe()["selection"],"scope":"Source validation only; no target tests or automatic fallback","updated_at":now()}
    write_json(HOME / "promotion.json",result)
    rows=[json.loads(x) for x in (HOME / "history.jsonl").read_text(encoding="utf-8").splitlines()]
    lines=["# IRSTD 尺度方向均衡续调","",f"[KNOWN｜HIGH] 更新时间：{now()}；DAUB-R/3407，继承上轮第3轮原始参数、EMA、优化器和累计步数。",
        "","[KNOWN｜HIGH] 仅训练几何头10516参数；总参数808952；每批2原始+1缩小+1放大；学习率1e-4；最多追加2轮，每轮完整源验证。",
        "","| 累计轮数 | 组宏AP50 | pooled AP50 | pooled AP50:95 | data22 AP50 | 尺寸压力误差 | 缩小误差 | 放大误差 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in rows:
        v=r["source_validation"]
        lines.append(f"| {r['epoch']} | {v['group_macro_AP50']*100:.4f}% | {v['pooled']['AP50']*100:.4f}% | {v['pooled']['AP50_95']*100:.4f}% | {v['by_group']['data22']['AP50']*100:.4f}% | {r['geometry_probe']['log_size_error']:.6f} | {r['per_scale']['0.6']['log_size_error']:.6f} | {r['per_scale']['1.4']['log_size_error']:.6f} |")
    lines += ["",f"[COMPUTED｜HIGH] 本轮候选累计第{best['epoch']}轮；原三项验收{'通过' if result['original_gates_passed'] else '未通过'}；放大保护项{'通过' if review else '未通过'}。",
        "",f"[COMPUTED｜HIGH] 上轮几何资格选模规则在本轮候选中的最佳：累计第{prior['epoch']}轮；与新增放大审查的候选分别保存。",
        "","[KNOWN｜HIGH] 原三项门槛未变：组宏AP50≥77.3767%，pooled AP50≥76.8410%，压力尺寸误差≤0.339524。放大误差≤0.337624为本轮预先声明的额外推广审查，不回溯修改旧实验结论。",
        "","[KNOWN｜HIGH] best.pt按新增推广审查选择；best_previous_selection.pt保留上轮选模规则；best_source_ap.pt单独保留历史原始AP最佳。每轮原始/EMA、优化器、随机状态和完整预测均保存。",
        "","[KNOWN｜HIGH] 运行：D:\\Miniconda3\\envs\\IRSTD\\python.exe -u -m irstd_geometry_balance.run；工作目录D:\\Codex\\Scenario_adaptability；恢复加--resume。"]
    (HOME / "结果与进度.md").write_text("\n".join(lines),encoding="utf-8")
    return result


def run(check_only=False,resume=False):
    cfg,device=recipe(),torch.device("cuda")
    state=torch.load(START,map_location="cpu",weights_only=False)
    assert state["next_epoch"]==3 and state["updates"]==3138
    reference=state["config"]["size_reference_512"]
    assert split_hashes()==state["config"]["split_hashes"]
    identity={"source_hashes":source_hashes(),"split_hashes":split_hashes(),"parent_checkpoint_sha256":sha(START),
        "baseline_scale_record_sha256":sha(PARENT / "scale_response.json"),"recipe":cfg}
    if check_only: check(cfg,state,reference,device,identity); return
    check_result=json.loads((HOME / "checks/preflight.json").read_text(encoding="utf-8"))
    assert check_result["passed"] and check_result["identity"]==identity
    config={**identity,"source":SOURCE,"seed":SEED,"size_reference_512":reference,
        "initialization":{"checkpoint":str(START),"parent_global_epoch":3,"parent_updates":3138,"optimizer":"inherited","EMA":"inherited"}}
    if (HOME / "config.json").exists():
        if json.loads((HOME / "config.json").read_text(encoding="utf-8"))!=config or not resume: raise ValueError("Explicit identical --resume required")
    if (HOME / "training_complete.json").exists(): return
    write_json(HOME / "config.json",config); write_json(HOME / "recipe.json",cfg)
    folder=HOME / "source_snapshot"; folder.mkdir(exist_ok=True)
    for p in Path(__file__).parent.glob("*.py"): shutil.copyfile(p,folder / p.name)
    write_json(HOME / "environment.json",{"python":sys.version,"torch":torch.__version__,"cuda":torch.version.cuda,
        "gpu":torch.cuda.get_device_name(device),"platform":platform.platform(),"started_at":now()})
    model,opt,ema=load_start(cfg,device,state)
    initial={k:v.clone() for k,v in state["model"].items()}
    updates,first,prior_seconds=state["updates"],3,0.
    train=training_loader(SOURCE,cfg,SEED); val=make_loader(SOURCE,"val",cfg)
    if not (HOME / "best.pt").exists():
        parent_row=json.loads((PARENT / "history.jsonl").read_text(encoding="utf-8").splitlines()[-1])
        row={"epoch":3,"source_validation":parent_row["source_validation"],"geometry_probe":parent_row["geometry_probe"],
            "per_scale":check_result["initial_per_scale"],"ranking":parent_row["ranking"]}
        parent_ema=torch.load(PARENT / "epoch_03_ema.pt",map_location="cpu",weights_only=False)
        assert all(torch.equal(v,parent_ema["model"][k]) for k,v in state["ema"].items())
        for name in ("best.pt","best_previous_selection.pt"): save_checkpoint(HOME / name,{**row,"model":state["ema"],"config":config})
        shutil.copyfile(PARENT / "epoch_03_source_val_predictions.json",HOME / "best_source_val_predictions.json")
        shutil.copyfile(PARENT / "best_source_ap.pt",HOME / "best_source_ap.pt")
        (HOME / "history.jsonl").write_text(json.dumps(row)+"\n",encoding="utf-8")
        del parent_ema
    restore_rng(state["rng"]); del state
    if resume and (HOME / "last.pt").exists():
        state=torch.load(HOME / "last.pt",map_location="cpu",weights_only=False); assert state["config"]==config
        model.load_state_dict(state["model"]); ema.load_state_dict(state["ema"]); opt.load_state_dict(state["optimizer"])
        first,updates,prior_seconds=state["next_epoch"],state["updates"],state["elapsed_seconds"]
        restore_rng(state["rng"]); del state
    best=torch.load(HOME / "best.pt",map_location="cpu",weights_only=False)
    previous=torch.load(HOME / "best_previous_selection.pt",map_location="cpu",weights_only=False)
    plain=torch.load(HOME / "best_source_ap.pt",map_location="cpu",weights_only=False)
    best_key,prior_key,plain_key=candidate_key(best),previous_key(previous),ap_key(plain)
    del best,previous,plain
    write_json(HOME / "process.json",{"pid":os.getpid(),"started_at":now(),"resume":resume})
    current=report(); started=time.perf_counter(); at=first
    for epoch in range(first,5):
        if current["passed"]: break
        train.dataset.epoch=epoch; counts=Counter(); sums={}; batches=0; tick=time.perf_counter()
        for iteration,(images,samples) in enumerate(train):
            if len(samples)==4: assert Counter(s["view_type"] for s in samples)=={"native":2,"shrink":1,"enlarge":1}
            model.eval(); model.heads.offset.train(); model.heads.size.train()
            opt.zero_grad(set_to_none=True); loss,terms,output=loss_for(model,images,samples,reference,cfg,device); loss.backward()
            assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith(PREFIXES))
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10.,error_if_nonfinite=True)
            opt.step(); updates+=1
            decay=.9999*(1-math.exp(-updates/2000))
            with torch.no_grad():
                for name,p in ema.named_parameters():
                    if name.startswith(PREFIXES): p.mul_(decay).add_(model.get_parameter(name),alpha=1-decay)
            for sample in samples: counts[sample["view_type"]]+=1
            for k,v in terms.items(): sums[k]=sums.get(k,0.)+float(v.detach())
            batches+=1
            if iteration%40==0:
                progress={"status":"training","epoch":epoch+1,"additional_epoch":epoch-2,"batch":iteration+1,
                    "total_batches":len(train),"updates":updates,"views":dict(counts),"geometry_loss":float(loss.detach()),"updated_at":now()}
                write_json(HOME / "progress.json",progress); print(json.dumps(progress),flush=True)
            del loss,terms,output
        training_seconds=time.perf_counter()-tick
        assert sum(counts.values())==4181
        assert_frozen(model,initial); assert_frozen(ema,initial); assert source_hashes()==identity["source_hashes"]
        at=epoch+1; write_json(HOME / "progress.json",{"status":"source_validation","epoch":at,"updated_at":now()})
        tick=time.perf_counter(); path=HOME / f"epoch_{at:02d}_source_val_predictions.json"
        frames=evaluate(ema,val,device,reference,path); summary=validation_summary(frames); total,split=probe(ema,cfg,reference,device)
        row={"epoch":at,"updates":updates,"source_validation":summary,"geometry_probe":total,"per_scale":split,
            "ranking":ranking_summary(frames),"view_counts":dict(counts),"training_seconds":training_seconds,
            "validation_seconds":time.perf_counter()-tick,"loss_mean_over_batches":{k:v/batches for k,v in sums.items()},
            "elapsed_seconds":prior_seconds+time.perf_counter()-started,"frozen_state_bitwise_equal":True}
        checkpoint={**row,"model":ema.state_dict(),"config":config}
        save_checkpoint(HOME / f"epoch_{at:02d}_ema.pt",checkpoint)
        save_checkpoint(HOME / f"epoch_{at:02d}_raw.pt",{"model":model.state_dict(),"epoch":at,"config":config})
        if candidate_key(row)>best_key:
            best_key=candidate_key(row); save_checkpoint(HOME / "best.pt",checkpoint)
            shutil.copyfile(path,HOME / "best_source_val_predictions.json")
        if previous_key(row)>prior_key: prior_key=previous_key(row); save_checkpoint(HOME / "best_previous_selection.pt",checkpoint)
        if ap_key(row)>plain_key: plain_key=ap_key(row); save_checkpoint(HOME / "best_source_ap.pt",checkpoint)
        save_checkpoint(HOME / "last.pt",{"model":model.state_dict(),"ema":ema.state_dict(),"optimizer":opt.state_dict(),
            "next_epoch":at,"updates":updates,"rng":rng_state(),"config":config,"elapsed_seconds":row["elapsed_seconds"]})
        history=HOME / "history.jsonl"; rows=[json.loads(x) for x in history.read_text(encoding="utf-8").splitlines()]
        rows=sorted([r for r in rows if r["epoch"]!=at]+[row],key=lambda r:r["epoch"])
        tmp=history.with_suffix(".tmp"); tmp.write_text("".join(json.dumps(r)+"\n" for r in rows),encoding="utf-8"); tmp.replace(history)
        current=report()
        print(json.dumps({"validated_epoch":at,"geometry_error":total["log_size_error"],"enlarge_error":split["1.4"]["log_size_error"],
            "original_gates_passed":current["original_gates_passed"],"enlarge_review_passed":current["enlarge_review_passed"]}),flush=True)
    final=report()
    done={"status":"completed_promotable" if final["passed"] else "completed_held","additional_epochs_run":at-3,
        "global_epochs":at,"updates":updates,"best_epoch":final["candidate"]["epoch"],"original_gates_passed":final["original_gates_passed"],
        "promotion_passed":final["passed"],"enlarge_review_passed":final["enlarge_review_passed"],"frozen_state_bitwise_equal":True,
        "elapsed_seconds":prior_seconds+time.perf_counter()-started,"target_test_cells":0,"automatic_fallback":False,"updated_at":now()}
    write_json(HOME / "training_complete.json",done); write_json(HOME / "progress.json",done); print(json.dumps(done),flush=True)


def main():
    import msvcrt
    parser=argparse.ArgumentParser(); parser.add_argument("--check",action="store_true"); parser.add_argument("--resume",action="store_true")
    args=parser.parse_args(); HOME.mkdir(parents=True,exist_ok=True)
    with (HOME / "run.lock").open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1): lock.write(b"1"); lock.flush()
        lock.seek(0); msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1); torch.set_num_threads(8)
        try: run(args.check,args.resume)
        except Exception:
            write_json(HOME / "failure.json",{"traceback":traceback.format_exc(),"updated_at":now()})
            write_json(HOME / "progress.json",{"status":"failed","updated_at":now()}); raise


if __name__=="__main__": main()
