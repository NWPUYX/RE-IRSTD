"""Acceptance checks on synthetic labels and real training images, before runs."""
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from irstd.models.detector import Detector
from irstd.data.targets import build_targets
from irstd.losses.detection import detection_losses
from irstd_adapter import model_config, PublicInfraredData, transformed_boxes, source_audit, targets, evaluate, loader
from evaluation import postprocess, metrics
from data_pipeline import VideoData

ROOT = Path(__file__).resolve().parent


def check():
    torch.set_num_threads(4)
    torch.manual_seed(3407)
    cfg = model_config()
    report = {"source_audits": {}, "preprocessing": [], "label_policy": "shared_regression; all annotations retained"}
    for domain in ("DAUB-R", "IRDST-H", "IRSTD-UAV", "ITSDT-15K"):
        report["source_audits"][domain] = source_audit(domain)
        ours = PublicInfraredData(domain, "train")[0]
        comparator = VideoData(domain, "train", "AA-YOLO")[0]
        benchmark_targets = comparator[1]
        transformed_centers = (ours["boxes"][:, :2] + ours["boxes"][:, 2:]) / 2
        transformed_wh = ours["boxes"][:, 2:] - ours["boxes"][:, :2]
        assert torch.allclose(transformed_centers, benchmark_targets[:, :2], atol=1e-4)
        assert torch.allclose(transformed_wh, benchmark_targets[:, 2:4], atol=1e-4)
        assert ours["image"].shape == (1, 512, 512)
        report["preprocessing"].append({"domain": domain, "box_transform_matches_benchmark": True,
                                         "input_shape": list(ours["image"].shape), "intensity_range": [float(ours["image"].min()), float(ours["image"].max())]})
    sample = PublicInfraredData("ITSDT-15K", "train")[0]
    sample["boxes"] = torch.tensor([[10., 10., 14., 14.], [10., 10., 14.5, 14.]])
    strict_rejected = False
    try:
        build_targets([sample], cfg, [4., 4.])
    except ValueError:
        strict_rejected = True
    assert strict_rejected
    target = targets([sample], cfg, [4., 4.], "cpu", "shared_regression")
    assert target["counts"].tolist() == [2]
    assert len(target["anchors"]) == 2 and target["positive"].sum() == 1
    assert target["sizes"][0, 0] != target["sizes"][1, 0]
    ordinary = PublicInfraredData("DAUB-R", "train")[0]
    first = build_targets([ordinary], cfg, [16., 16.])
    second = targets([ordinary], cfg, [16., 16.], "cpu", "shared_regression")
    assert all(torch.equal(first[key], second[key]) for key in first)
    report["same_cell_labels_retained"] = 2
    report["no_collision_targets_bitwise_equal"] = True
    # Identity in original coordinates after common postprocess, including
    # non-square resize rounding and network-border crossing before NMS.
    record = {"width": 720, "height": 480, "boxes": [[20., 30., 10., 12.]]}
    transformed, trans = transformed_boxes(record)
    box = torch.tensor(transformed)
    raw = torch.cat(((box[:, :2] + box[:, 2:]) / 2, box[:, 2:] - box[:, :2], torch.tensor([[.8, 1.]])), dim=1)
    recovered = postprocess(raw, record, trans)
    assert np.allclose(recovered[0, :4], [20., 30., 30., 42.], atol=1e-4)
    report["common_inverse_transform_matches"] = True
    # Three-image last batch catches accidental global-index modulo mistakes.
    class Subset:
        def __init__(self, source):
            self.source, self.dataset = source, source.dataset
        def __iter__(self):
            images, samples = next(iter(self.source))
            yield images[:3], samples[:3]
    device = torch.device("cuda")
    model = Detector(cfg).to(device)
    images, samples = next(iter(loader("DAUB-R", "train", workers=0)))
    target = targets(samples, cfg, [16., 16.], device, "shared_regression")
    loss = detection_losses(model(images.to(device)), target, cfg["loss"])["total"]
    loss.backward()
    assert torch.isfinite(loss)
    assert all(torch.isfinite(parameter.grad).all() for parameter in model.parameters() if parameter.grad is not None)
    frames = evaluate(model, Subset(loader("DAUB-R", "val", workers=0)), device, [16., 16.], None)
    assert len(frames) == 3
    report["real_data_gradients_finite"] = True
    report["last_batch_of_three_decoded"] = True
    report["parameters"] = sum(parameter.numel() for parameter in model.parameters())
    report["passed"] = True
    path = ROOT / "execution_checks" / "IRSTD.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "source_audits"}, ensure_ascii=False))


if __name__ == "__main__":
    check()
