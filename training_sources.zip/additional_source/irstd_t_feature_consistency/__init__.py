"""Isolated source-paired alignment of the existing full-resolution T path."""
