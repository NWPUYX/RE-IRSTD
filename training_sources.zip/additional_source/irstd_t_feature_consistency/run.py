"""One epoch, T-path parameters only; all source gates remain explicit."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import argparse
from collections import Counter
import copy
import json
import math
from pathlib import Path
import random
import time
import traceback
import numpy as np
import torch
from irstd_t_size.model import TSizeModel
from irstd_stable_robust.data import training_loader
from irstd_stable_robust.loss import losses as supervised_losses
from irstd_robust_t.run import sha, mechanisms, gates
from irstd_robust_t.probe import extreme_probe
from irstd_geometry_balance.run import probe
from irstd_background_center.run import background_diagnostic
from irstd_noise_center.data import validation_loader
from irstd_adapter import targets, model_config
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate, validation_summary
from irstd_v2.settings import write_json, now, split_hashes
from irstd_v2.train import save_checkpoint, rng_state, restore_rng
from evaluation import metrics
from benchmark_center_metrics import center_metrics
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast

ROOT = Path(__file__).resolve().parents[1]
RESEARCH = ROOT/'experiments/IRSTD_research_20261107'
PARENT = RESEARCH/'robust_T_composed_v1'
HOME = RESEARCH/'T_feature_correspondence_v1'
PREFIX = 'backbone.target_path.'


def recipe(parent):
    return {**parent['config']['recipe'], 'name': HOME.name, 'epochs': 1,
        'initialization': 'source-AP-selected robust_T EMA; fresh AdamW; mechanism failures retained',
        'trainable_prefixes': [PREFIX], 'learning_rate': 5e-5,
        'augmentation_mix': 'one-third noise, one-third background+noise, one-third clean geometry',
        'geometry_regression_weight': 4., 'evidence_arithmetic': 'original',
        'native_T_local_weight': 1., 'native_T_global_weight': .05,
        'paired_T_local_weight': 1., 'T_channel_RMS_floor': .25,
        'normalization_gamma_bias_weight_decay': 0., 'ordinary_weight_decay': .0005,
        'selection': 'single fixed epoch; full existing source gates; no target-based selection'}


def construct(cfg, state, device):
    model = TSizeModel(cfg).to(device)
    model.load_state_dict(state, strict=True)
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(name.startswith(PREFIX))
    exempt = {id(p) for module in model.modules() if isinstance(module, torch.nn.GroupNorm)
              for p in module.parameters(recurse=False)}
    exempt.update(id(p) for n, p in model.named_parameters() if n.endswith(('.bias', '.gamma')))
    groups = {}
    for parameter in model.parameters():
        if parameter.requires_grad:
            groups.setdefault(0. if id(parameter) in exempt else .0005, []).append(parameter)
    optimizer = torch.optim.AdamW([{'params': p, 'weight_decay': wd} for wd, p in groups.items()],
                                 lr=cfg['learning_rate'], betas=tuple(model_config()['train']['betas']))
    teacher = copy.deepcopy(model).eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    assert sum(p.numel() for p in model.parameters()) == 808952
    return model, teacher, optimizer


def frozen(model, state):
    for name, value in model.state_dict().items():
        if not name.startswith(PREFIX):
            assert torch.equal(value.cpu(), state[name]), name


def relative_mse(student, fixed, floor):
    scale = fixed.detach().square().mean((-2, -1), keepdim=True).sqrt().clamp_min(floor)
    return ((student-fixed.detach())/scale).square().mean()


def losses(model, teacher, images, samples, reference, cfg, device):
    student_features, teacher_features = [], []
    handles = [model.backbone.target_path.register_forward_hook(lambda m, args, result: student_features.append(result)),
               teacher.backbone.target_path.register_forward_hook(lambda m, args, result: teacher_features.append(result))]
    try:
        loss, terms, out = supervised_losses(model, teacher, images, samples, reference, cfg, device)
    finally:
        for handle in handles:
            handle.remove()
    assert len(student_features) == len(teacher_features) == 1
    student, fixed = student_features[0], teacher_features[0]
    n = len(samples)//2
    assert len(fixed) == n and len(student) == 2*n
    t = targets(samples, model_config(), reference, device, 'shared_regression')
    native, paired = [], []
    for b in range(n):
        clean_ids = (t['anchors'][:, 0] == b).nonzero().flatten().tolist()
        aug_ids = (t['anchors'][:, 0] == b+n).nonzero().flatten().tolist()
        assert len(clean_ids) == len(aug_ids)
        photometric = samples[b+n]['view_type'] in ['noise', 'background_noise']
        for i, j in zip(clean_ids, aug_ids):
            _, x, y = t['anchors'][i].tolist()
            ys, xs = slice(max(y-3, 0), min(y+4, 512)), slice(max(x-3, 0), min(x+4, 512))
            target = fixed[b, :, ys, xs]
            native.append(relative_mse(student[b, :, ys, xs], target, cfg['T_channel_RMS_floor']))
            if photometric:
                assert torch.equal(t['anchors'][i, 1:], t['anchors'][j, 1:])
                paired.append(relative_mse(student[b+n, :, ys, xs], target, cfg['T_channel_RMS_floor']))
    zero = loss*0
    native_term = torch.stack(native).mean() if native else zero
    paired_term = torch.stack(paired).mean() if paired else zero
    global_term = relative_mse(student[:n, :, ::16, ::16], fixed[:, :, ::16, ::16], cfg['T_channel_RMS_floor'])
    loss = loss + cfg['native_T_local_weight']*native_term + cfg['paired_T_local_weight']*paired_term + cfg['native_T_global_weight']*global_term
    assert torch.isfinite(loss)
    terms.update(T_native_local=float(native_term.detach()), T_paired_local=float(paired_term.detach()),
                 T_native_global=float(global_term.detach()), actual_loss=float(loss.detach()))
    return loss, terms


def validate(model, cfg, reference, parent, binding):
    device = torch.device('cuda')
    manifest = HOME/'source_prediction_manifest.json'
    if manifest.exists():
        assert json.loads(manifest.read_text(encoding='utf-8')) == binding
    else:
        write_json(manifest, binding)
    path = HOME/'epoch_01_predictions.json'
    frames = json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,
        ReportingLoader(make_loader('DAUB-R', 'val', cfg), HOME/'progress.json', 'source_val'), device, reference, path)
    geometry, per_scale = probe(model, cfg, reference, device)
    row = {'epoch': 1, 'source_validation': validation_summary(frames), 'geometry_probe': geometry, 'per_scale': per_scale,
           'background': background_diagnostic(model, cfg, reference, device, HOME, 'epoch_01'), 'noise': {},
           'extreme_geometry': extreme_probe(model, cfg, reference, device)}
    for factor in [4, 16]:
        path = HOME/f'epoch_01_noise{factor}_predictions.json'
        frames = json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,
            validation_loader(cfg, factor), device, reference, path)
        row['noise'][str(factor)] = {'box': metrics(frames, row['source_validation']['threshold']),
                                   'center': center_metrics(frames, row['source_validation']['threshold'])}
    baseline = json.loads((RESEARCH/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    row['gates'] = gates(row, parent, baseline)
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    HOME.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    if (HOME/'training_complete.json').exists() and not args.check:
        return
    random.seed(3407); np.random.seed(3407); torch.manual_seed(3407); torch.cuda.manual_seed_all(3407)
    parent = torch.load(PARENT/'best.pt', map_location='cpu', weights_only=False)
    cfg = recipe(parent)
    diagnostic = RESEARCH/'paired_path_intervention_v1/result.json'
    evidence = json.loads(diagnostic.read_text(encoding='utf-8'))
    assert evidence['all_tensors_unchanged'] and evidence['status'] == 'completed'
    files = [*Path(__file__).parent.glob('*.py'), *(ROOT/'irstd_stable_robust').glob('*.py')]
    identity = {**parent['config'], 'recipe': cfg, 'parent_sha256': sha(PARENT/'best.pt'),
        'source_hashes': {**parent['config']['source_hashes'], **{str(p.relative_to(ROOT.parent)): sha(p) for p in files}},
        'diagnostic_hashes': {**parent['config']['diagnostic_hashes'], str(diagnostic.relative_to(ROOT.parent)): sha(diagnostic)},
        'role': 'source-only T-feature mechanism experiment; legacy evidence arithmetic retained for isolation'}
    assert split_hashes() == identity['split_hashes']
    for name, digest in {**identity['source_hashes'], **identity['diagnostic_hashes']}.items():
        assert sha(ROOT.parent/name) == digest, name
    fast.install()
    model, teacher, optimizer = construct(cfg, parent['model'], torch.device('cuda'))
    reference = identity['size_reference_512']
    if args.check:
        from irstd_background_center.data import collate_pairs
        data = training_loader(cfg); data.dataset.epoch = 1
        types = []
        for indices in [[0, 1], [2, 4], [6, 8]]:
            images, samples = collate_pairs([data.dataset[i] for i in indices])
            types.extend(s['view_type'] for s in samples[2:])
            model.eval(); optimizer.zero_grad(set_to_none=True)
            loss, terms = losses(model, teacher, images, samples, reference, cfg, torch.device('cuda'))
            loss.backward()
            assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad)
            assert all(p.grad is None for p in model.parameters() if not p.requires_grad)
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 10., error_if_nonfinite=True)
            optimizer.step(); frozen(model, parent['model']); mechanisms(model)
        assert all(int(v['step']) == 3 for v in optimizer.state.values())
        assert all(torch.equal(v.cpu(), parent['model'][k]) for k, v in teacher.state_dict().items())
        assert any(not torch.equal(v.cpu(), parent['model'][k]) for k, v in model.state_dict().items() if k.startswith(PREFIX))
        saved = copy.deepcopy(model.state_dict())
        save_checkpoint(HOME/'preflight_step.pt', {'model': saved, 'optimizer': optimizer.state_dict()})
        restored, _, _ = construct(cfg, torch.load(HOME/'preflight_step.pt', map_location='cpu', weights_only=False)['model'], torch.device('cuda'))
        with torch.no_grad():
            before, after = model(images.cuda()), restored(images.cuda())
        assert all(torch.equal(v, after[k]) for k, v in before.items())
        write_json(HOME/'preflight.json', {'passed': True, 'identity': identity, 'save_reload_exact': True,
            'trainable_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
            'optimizer_states': len(optimizer.state), 'optimizer_steps': 3, 'view_types_checked': types,
            'frozen_tensors_verified': True, 'teacher_unchanged': True, 'REBlock_constraints': mechanisms(model), 'updated_at': now()})
        return
    assert json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))['identity'] == identity
    if (HOME/'config.json').exists():
        assert args.resume and json.loads((HOME/'config.json').read_text(encoding='utf-8')) == identity
    write_json(HOME/'config.json', identity)
    write_json(HOME/'process.json', {'pid': os.getpid(), 'updated_at': now()})
    ema = copy.deepcopy(model).eval()
    for p in ema.parameters():
        p.requires_grad_(False)
    trained = HOME/'trained_last.pt'
    try:
        if args.resume and trained.exists():
            saved = torch.load(trained, map_location='cpu', weights_only=False)
            assert saved['config'] == identity
            model.load_state_dict(saved['model']); ema.load_state_dict(saved['ema'])
            optimizer.load_state_dict(copy.deepcopy(saved['optimizer'])); restore_rng(saved['rng'])
            updates = saved['updates']
        else:
            loader = training_loader(cfg); loader.dataset.epoch = 1; loader.generator.manual_seed(1003410)
            updates, count, types = 0, 0, Counter()
            start = time.perf_counter()
            for batch, (images, samples) in enumerate(loader):
                model.eval(); optimizer.zero_grad(set_to_none=True)
                loss, terms = losses(model, teacher, images, samples, reference, cfg, torch.device('cuda'))
                loss.backward()
                torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 10., error_if_nonfinite=True)
                optimizer.step(); updates += 1
                decay = .9999*(1-math.exp(-updates/2000))
                with torch.no_grad():
                    emap = dict(ema.named_parameters())
                    for name, parameter in model.named_parameters():
                        if parameter.requires_grad:
                            emap[name].mul_(decay).add_(parameter, alpha=1-decay)
                count += len(samples); types.update(s['view_type'] for s in samples)
                if batch % 100 == 0:
                    row = {'status': 'training', 'epoch': 1, 'batch': batch+1, 'total_batches': len(loader),
                           'updates': updates, 'loss_terms': terms, 'view_counts': dict(types), 'updated_at': now()}
                    write_json(HOME/'progress.json', row); print(json.dumps(row), flush=True)
            assert updates == 2091 and count == 8362 and types['native'] == 4181
            assert all(int(v['step']) == updates for v in optimizer.state.values())
            frozen(model, parent['model']); frozen(ema, parent['model']); mechanisms(ema)
            save_checkpoint(trained, {'model': model.state_dict(), 'ema': ema.state_dict(), 'optimizer': optimizer.state_dict(),
                'config': identity, 'updates': updates, 'rng': rng_state(), 'view_counts': dict(types), 'train_seconds': time.perf_counter()-start})
        row = validate(ema, cfg, reference, parent, {'trained_checkpoint_sha256': sha(trained)})
        row['updates'] = updates
        frozen(ema, parent['model']); mechanisms(ema)
        save_checkpoint(HOME/'best.pt', {**row, 'model': ema.state_dict(), 'config': identity})
        write_json(HOME/'epoch_01_row.json', row)
        for name, digest in {**identity['source_hashes'], **identity['diagnostic_hashes']}.items():
            assert sha(ROOT.parent/name) == digest, name
        done = {'status': 'completed', 'promotion_passed': all(row['gates'].values()), 'gates': row['gates'],
                'epochs_run': 1, 'updates': updates, 'target_test_cells': 0, 'updated_at': now()}
        write_json(HOME/'training_complete.json', done); write_json(HOME/'progress.json', done)
        print(json.dumps(done), flush=True)
    except Exception:
        write_json(HOME/'failure.json', {'traceback': traceback.format_exc(), 'updated_at': now()})
        raise


if __name__ == '__main__':
    main()
