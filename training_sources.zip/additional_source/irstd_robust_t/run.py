"""One source-only epoch: adapt existing T/fusion/heads, retain context and design."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import random
import time
import traceback
import numpy as np
import torch
from torch.nn import functional as F
from .data import training_loader
from .probe import extreme_probe
from irstd_t_size.model import TSizeModel
from irstd_adapter import model_config,targets
from irstd.data.targets import gather_centers
from irstd.losses.detection import detection_losses
from irstd.models.blocks import REBlock
from irstd_v2.losses import giou_pairs
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint,rng_state,restore_rng
from irstd_noise_center.run import native_gates
from irstd_noise_center.data import validation_loader
from irstd_background_center.run import background_diagnostic
from irstd_geometry_balance.run import probe,gates as geometry_gates
from evaluation import metrics
from benchmark_center_metrics import center_metrics
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast

ROOT=Path(__file__).resolve().parents[1]
RESEARCH=ROOT/'experiments/IRSTD_research_20261107'
PARENT=RESEARCH/'background_center_interpolation_refine_v1'
HOME=RESEARCH/'robust_T_composed_v1'
PREFIXES=('backbone.target_path.','backbone.final.','heads.')


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def recipe():
    return {'name':HOME.name,'initialization':'parent_BG_EMA_fresh_AdamW','epochs':1,'batch':4,'workers':2,
        'precision':'float32','learning_rates':{'T_fusion_center_aux':2e-5,'offset_size':1e-4},
        'weight_decay':.0005,'gradient_clip':10.,'native_weight':4.,'trainable_prefixes':list(PREFIXES),
        'source_noise_factors':[4,16],'augmentation_mix':'one-third noise, one-third background+noise, one-third geometry+noise',
        'geometry':{'enabled':True,'scale_jitter':[.25,2.],'shift_fraction':.125,'minimum_box_side':1.,
            'maximum_attempts':32,'horizontal_flip_probability':.5},
        'ignore_synthetic_padding':True,'soft_relative_evidence':False,'valid_region_evidence':False,
        'masked_group_norm':False,'size_feature_source':'T','protection_margin':14,'transition_width':8,
        'probe_samples_per_group':12,'probe_scales':[.6,1.4],'giou_weight':.1,
        'native_peak_weight':.5,'native_shape_weight':.1,'native_negative_weight':.05,
        'augmented_peak_weight':.05,'native_geometry_teacher_weight':.25,
        'postprocess':{'floor':1e-5,'pre_nms':1000,'nms_iou':.5,'max_detections':100}}


def construct(cfg,state,device):
    model=TSizeModel(cfg).to(device);model.load_state_dict(state,strict=True)
    for n,p in model.named_parameters():p.requires_grad_(n.startswith(PREFIXES))
    assert sum(p.numel() for p in model.parameters())==808952
    assert sum(p.numel() for p in model.parameters() if p.requires_grad)==23252
    groups={}
    for n,p in model.named_parameters():
        if not p.requires_grad:continue
        lr=1e-4 if n.startswith(('heads.offset.','heads.size.')) else 2e-5
        decay=0. if n.endswith('.bias') else .0005
        groups.setdefault((lr,decay),[]).append(p)
    opt=torch.optim.AdamW([{'params':v,'lr':lr,'weight_decay':wd} for (lr,wd),v in groups.items()],betas=tuple(model_config()['train']['betas']))
    teacher=copy.deepcopy(model).eval()
    for p in teacher.parameters():p.requires_grad_(False)
    return model,teacher,opt


def frozen(model,state):
    for n,v in model.state_dict().items():
        if not n.startswith(PREFIXES):assert torch.equal(v.cpu(),state[n]),n


def mechanisms(model):
    count=0
    for module in model.modules():
        if isinstance(module,REBlock):
            assert module.zero_sum and module.conditional and module.dilations==(1,2,3)
            assert all(float(k.sum((-2,-1)).abs().max())<1e-6 for k in module.effective_kernels())
            count+=1
    assert count and model.backbone.has_t
    assert all(p.grad is None for p in model.evidence.parameters())
    return count


def deployed_geometry(out,target,reference):
    anchor=target['anchors'];offset=gather_centers(out['offsets'],anchor).float().clamp(0,1-1e-6)
    center=anchor[:,1:].float()+offset;bounds=center.new_tensor([512,512])
    center=torch.minimum(center,torch.nextafter(bounds,torch.zeros_like(bounds)))
    value=gather_centers(out['log_size'],anchor).float();ref=value.new_tensor(reference)
    wh=ref*torch.minimum(value.clamp_min(-20),(value.new_tensor([512,512])/ref).log()).exp()
    return center,wh


def losses(model,teacher,images,samples,reference,cfg,device):
    n=len(samples)//2;assert all(s['view_type']=='native' for s in samples[:n])
    t=targets(samples,model_config(),reference,device,'shared_regression')
    valid=torch.stack([s['valid_mask'] for s in samples]).to(device)
    out=model(images.to(device),valid_mask=valid)
    with torch.no_grad():fixed=teacher(images[:n].to(device),valid_mask=valid[:n])
    weights=images.new_tensor([4.]*n+[1.]*n).to(device)
    count=sum(float(weights[i])*len(s['boxes']) for i,s in enumerate(samples))
    normalizers={'images':float(weights.sum()),'targets':count,'boxes':count}
    terms=detection_losses(out,t,model_config()['loss'],weights,normalizers)
    center,wh=deployed_geometry(out,t,reference);truth=t['anchors'][:,1:]+t['offsets']
    true_wh=t['sizes'].exp()*wh.new_tensor(reference)
    pred=torch.cat((center-wh/2,center+wh/2),1);gt=torch.cat((truth-true_wh/2,truth+true_wh/2),1)
    giou=((1-giou_pairs(pred,gt))*weights[t['anchors'][:,0]]).sum()/max(count,1.)
    peak=[];shape=[];augmented=[];negative=[];geometry=[]
    for b in range(n):
        assert samples[b]['sample_id']==samples[b+n]['sample_id']
        native_ids=(t['anchors'][:,0]==b).nonzero().flatten().tolist()
        aug_ids=(t['anchors'][:,0]==b+n).nonzero().flatten().tolist();assert len(native_ids)==len(aug_ids)
        for i,j in zip(native_ids,aug_ids):
            _,qx,qy=t['anchors'][i].tolist();_,ax,ay=t['anchors'][j].tolist()
            ys=slice(max(0,qy-3),min(512,qy+4));xs=slice(max(0,qx-3),min(512,qx+4))
            py=slice(max(0,ay-3),min(512,ay+4));px=slice(max(0,ax-3),min(512,ax+4))
            original=out['center_logits'][b,0,ys,xs];target=fixed['center_logits'][b,0,ys,xs]
            peak.append((original.max()-target.max()).square())
            shape.append(((original-original.max())-(target-target.max())).square().mean())
            augmented.append((out['center_logits'][b+n,0,py,px].max()-target.max()).square())
            point=int(target.argmax());height,width=target.shape
            peak_y=ys.start+point//width;peak_x=xs.start+point%width
            for field in ['offsets','log_size']:
                student=torch.stack((out[field][b,:,qy,qx],out[field][b,:,peak_y,peak_x]))
                baseline=torch.stack((fixed[field][b,:,qy,qx],fixed[field][b,:,peak_y,peak_x]))
                geometry.append(F.smooth_l1_loss(student,baseline))
        mask=t['negative'][b].flatten().bool()&(t['heatmap'][b].flatten()<.01)
        k=min(128,int(mask.sum()))
        if k:
            target=fixed['center_logits'][b].flatten();ids=target.masked_fill(~mask,-torch.inf).topk(k).indices
            negative.append((out['center_logits'][b].flatten()[ids]-target[ids]).square().mean())
    zero=terms['total']*0
    mean=lambda values:torch.stack(values).mean() if values else zero
    extra={'native_peak':mean(peak),'native_shape':mean(shape),'augmented_peak':mean(augmented),
        'native_negative':mean(negative),'native_geometry_teacher':mean(geometry)}
    loss=terms['total']+.1*giou+.5*extra['native_peak']+.1*extra['native_shape']+.05*extra['augmented_peak']+.05*extra['native_negative']+.25*extra['native_geometry_teacher']
    assert torch.isfinite(loss)
    return loss,{k:float(v.detach()) for k,v in {**terms,'giou':giou,**extra}.items()},out


def gates(row,parent,bg):
    result=native_gates(row,parent,bg)
    old,large=geometry_gates(row);result.update(old);result['enlarge_original']=large
    spec=json.loads((RESEARCH/'wide_scale_source_probe.json').read_text(encoding='utf-8'))
    base={str(r['scale']):r['log_size_MAE'] for r in spec['summary'] if r['model']=='Tsize_BG' and r['scale'] in [.25,2.]}
    current=row['extreme_geometry']
    result['extreme_scale_MAE_20percent']=sum(current[s]['log_size_MAE'] for s in base)<=.8*sum(base.values())
    result['each_extreme_no_worse']=all(current[s]['log_size_MAE']<=v+.02 for s,v in base.items())
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--resume',action='store_true');a=p.parse_args()
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    if (HOME/'training_complete.json').exists() and not a.check:return
    random.seed(3407);np.random.seed(3407);torch.manual_seed(3407);torch.cuda.manual_seed_all(3407)
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False);cfg=recipe()
    files=[*Path(__file__).parent.glob('*.py'),* (ROOT/'irstd_noise_center').glob('*.py'),
        RESEARCH/'classification_feature_probe.py',ROOT/'benchmark_center_metrics.py',ROOT/'benchmark_progress.py']
    identity={'recipe':cfg,'source':'DAUB-R','seed':3407,'parent_sha256':sha(PARENT/'best.pt'),
        'split_hashes':split_hashes(),'size_reference_512':parent['config']['size_reference_512'],
        'source_hashes':{**parent['config']['source_hashes'],**{str(f.relative_to(ROOT.parent)):sha(f) for f in files}},
        'diagnostic_hashes':{str(f.relative_to(ROOT.parent)):sha(f) for f in [RESEARCH/'wide_scale_source_probe.json',
            RESEARCH/'noise_validation_diagnostic/baseline.json',RESEARCH/'background_center_guarded_v1/background_baseline.json']}}
    for name,digest in {**identity['source_hashes'],**identity['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
    fast.install();device=torch.device('cuda');reference=identity['size_reference_512']
    model,teacher,opt=construct(cfg,parent['model'],device)
    if a.check:
        from irstd_background_center.data import collate_pairs
        data=training_loader(cfg);data.dataset.epoch=1;types=[]
        for indices in [[0,1],[2,4]]:
            images,samples=collate_pairs([data.dataset[i] for i in indices]);types.extend(s['view_type'] for s in samples[2:])
            model.eval();opt.zero_grad(set_to_none=True)
            loss,terms,_=losses(model,teacher,images,samples,reference,cfg,device);loss.backward()
            assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith(PREFIXES))
            assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad)
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10.,error_if_nonfinite=True);opt.step()
            frozen(model,parent['model']);mechanisms(model)
        assert all(int(v['step'])==2 for v in opt.state.values())
        assert any(not torch.equal(v.cpu(),parent['model'][n]) for n,v in model.state_dict().items() if n.startswith('backbone.target_path.'))
        save_checkpoint(HOME/'preflight_step.pt',{'model':model.state_dict(),'optimizer':opt.state_dict()})
        saved=torch.load(HOME/'preflight_step.pt',map_location='cpu',weights_only=False);restored,_,_=construct(cfg,saved['model'],device)
        with torch.no_grad():before=model(images.to(device));after=restored(images.to(device))
        assert all(torch.equal(v,after[n]) for n,v in before.items())
        assert all(torch.equal(v.cpu(),parent['model'][n]) for n,v in teacher.state_dict().items())
        write_json(HOME/'preflight.json',{'passed':True,'identity':identity,'trainable_parameters':23252,
            'frozen_context_verified':True,'save_reload_exact':True,'optimizer_steps':2,'view_types_checked':types,
            'REBlock_constraints_checked':mechanisms(model),'updated_at':now()});return
    assert json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))['identity']==identity
    if (HOME/'config.json').exists():assert a.resume and json.loads((HOME/'config.json').read_text(encoding='utf-8'))==identity
    write_json(HOME/'config.json',identity);write_json(HOME/'recipe.json',cfg);write_json(HOME/'process.json',{'pid':os.getpid(),'updated_at':now()})
    ema=copy.deepcopy(model).eval()
    for param in ema.parameters():param.requires_grad_(False)
    try:
        trained=HOME/'trained_last.pt';updates=0;started=time.perf_counter()
        if a.resume and trained.exists():
            s=torch.load(trained,map_location='cpu',weights_only=False);assert s['config']==identity
            model.load_state_dict(s['model']);ema.load_state_dict(s['ema']);opt.load_state_dict(copy.deepcopy(s['optimizer']));restore_rng(s['rng']);updates=s['updates']
        else:
            train=training_loader(cfg);train.dataset.epoch=1;train.generator.manual_seed(3407+1000003);seen=0;views=Counter()
            for j,(images,samples) in enumerate(train):
                model.eval();opt.zero_grad(set_to_none=True);loss,terms,_=losses(model,teacher,images,samples,reference,cfg,device)
                loss.backward();torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10.,error_if_nonfinite=True);opt.step();updates+=1
                decay=.9999*(1-math.exp(-updates/2000))
                with torch.no_grad():
                    emap=dict(ema.named_parameters())
                    for name,param in model.named_parameters():
                        if param.requires_grad:emap[name].mul_(decay).add_(param,alpha=1-decay)
                seen+=len(samples);views.update(s['view_type'] for s in samples)
                if j%100==0:
                    r={'status':'training','epoch':1,'batch':j+1,'total_batches':len(train),'updates':updates,'view_counts':dict(views),'loss_terms':terms,'updated_at':now()}
                    write_json(HOME/'progress.json',r);print(json.dumps(r),flush=True)
            assert seen==8362 and views['native']==4181 and updates==2091
            frozen(model,parent['model']);frozen(ema,parent['model']);mechanisms(model);mechanisms(ema)
            assert all(int(v['step'])==updates for v in opt.state.values())
            save_checkpoint(trained,{'model':model.state_dict(),'ema':ema.state_dict(),'optimizer':opt.state_dict(),'config':identity,
                'updates':updates,'rng':rng_state(),'view_counts':dict(views),'train_seconds':time.perf_counter()-started})
        binding={'trained_checkpoint_sha256':sha(trained),'source_threshold_selection':'clean source validation maxF1'}
        manifest=HOME/'source_prediction_manifest.json'
        if manifest.exists():assert json.loads(manifest.read_text(encoding='utf-8'))==binding
        else:write_json(manifest,binding)
        path=HOME/'epoch_01_predictions.json'
        if path.exists():frames=json.loads(path.read_text(encoding='utf-8'))['frames']
        else:frames=evaluate(ema,ReportingLoader(make_loader('DAUB-R','val',cfg),HOME/'progress.json','source_val'),device,reference,path)
        validation=validation_summary(frames)
        write_json(HOME/'progress.json',{'status':'source_validation','epoch':1,'phase':'controlled diagnostics','updated_at':now()})
        geom,per_scale=probe(ema,cfg,reference,device)
        bg=background_diagnostic(ema,cfg,reference,device,HOME,'epoch_01')
        noises={}
        for factor in [4,16]:
            path=HOME/f'epoch_01_noise{factor}_predictions.json'
            f=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(ema,validation_loader(cfg,factor),device,reference,path)
            noises[str(factor)]={'box':metrics(f,validation['threshold']),'center':center_metrics(f,validation['threshold'])}
        row={'epoch':1,'updates':updates,'source_validation':validation,'geometry_probe':geom,'per_scale':per_scale,
            'background':bg,'noise':noises,'extreme_geometry':extreme_probe(ema,cfg,reference,device)}
        original_bg=json.loads((RESEARCH/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
        row['gates']=gates(row,parent,original_bg)
        for name,digest in {**identity['source_hashes'],**identity['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
        save_checkpoint(HOME/'best.pt',{**row,'model':ema.state_dict(),'config':identity})
        (HOME/'history.jsonl').write_text(json.dumps(row)+'\n',encoding='utf-8')
        done={'status':'completed','promotion_passed':all(row['gates'].values()),'gates':row['gates'],
            'epochs_run':1,'updates':updates,'target_test_cells':0,'updated_at':now()}
        write_json(HOME/'training_complete.json',done);write_json(HOME/'progress.json',done);print(json.dumps(done),flush=True)
    except Exception:write_json(HOME/'failure.json',{'traceback':traceback.format_exc(),'updated_at':now()});raise


if __name__=='__main__':main()
