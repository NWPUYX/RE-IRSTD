"""Source-only paired compositional noise/background/geometry views."""
import random
from torch.utils.data import DataLoader
import torch
from irstd_background_center.data import Pairs,collate_pairs,union_swap
from irstd_geometry_balance.data import direction_plan
from irstd_v2.data import render
from data_pipeline import worker_seed
from irstd_noise_center.data import views


class RobustPairs(Pairs):
    def __getitem__(self,index):
        i=self.indices[index];native=self.base.base_sample(i)
        rng=random.Random(self.seed+self.epoch*1000003+i*97)
        flip=rng.random()<.5
        if flip:
            native=dict(native);native['image']=native['image'].flip(-1)
            native['boxes']=native['boxes'][:,[2,1,0,3]].clone();native['boxes'][:,[0,2]]=512-native['boxes'][:,[0,2]]
            for key in ['valid_mask','ignore_mask','known_background_mask']:native[key]=native[key].flip(-1)
            p=native['geometry_plan'];native['geometry_plan']={**p,'sx':-p['sx'],'tx':512-p['tx']}
        native={**native,'view_type':'native'}
        mode=(index+self.epoch)%3;kind='noise';augmented=dict(native)
        if mode==1:
            donor_index=rng.choice(self.eligible[self.records[i]['group']]);donor=self.donors.base_sample(donor_index)
            image,alpha,_=union_swap(native,donor,self.cfg);assert alpha.max()>0
            augmented.update(image=image,donor_id=donor['sample_id']);kind='background_noise'
        elif mode==2:
            direction='shrink' if (index//3+self.epoch)%2 else 'enlarge'
            plan=direction_plan(self.records[i],self.cfg,rng,direction)
            # Preserve the paired native orientation; the target order is kept.
            if (plan['sx']<0)!=flip:
                plan={**plan,'sx':-plan['sx'],'tx':512-plan['tx']}
            image,boxes,valid=render(self.records[i],plan)
            augmented.update(image=image,boxes=boxes,valid_mask=valid,ignore_mask=~valid,geometry_plan=plan)
            kind=direction+'_noise'
        images,_=views(augmented,index+(self.epoch+21)*1000003)
        # Different index bits cross both noise strengths with both directions.
        factor=4 if (index//6+self.epoch)%2==0 else 16
        augmented.update(image=images[1 if factor==4 else 2],view_type=kind,noise_factor=factor)
        assert len(augmented['boxes'])==len(native['boxes']) and torch.isfinite(augmented['image']).all()
        return native,augmented


def training_loader(cfg):
    return DataLoader(RobustPairs(cfg),batch_size=2,shuffle=True,num_workers=cfg['workers'],collate_fn=collate_pairs,
        worker_init_fn=worker_seed,persistent_workers=False,pin_memory=False,drop_last=False,
        generator=torch.Generator().manual_seed(3407))
