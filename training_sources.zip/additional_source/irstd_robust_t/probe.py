"""Reuse the predeclared all-scales-feasible source subset for the extreme guard."""
import json
from pathlib import Path
import random
import numpy as np
import torch
from irstd_v2.data import Data,choose_plan,render
from irstd_adapter import targets,model_config

HERE=Path(__file__).resolve().parents[1]/'experiments/IRSTD_research_20261107'


@torch.inference_mode()
def extreme_probe(model,cfg,reference,device):
    spec=json.loads((HERE/'wide_scale_source_probe.json').read_text(encoding='utf-8'))
    data=Data('DAUB-R','val',cfg);rows=[]
    original=torch.load(HERE/'background_center_interpolation_refine_v1/best.pt',map_location='cpu',weights_only=False)
    g=dict(original['config']['recipe']['geometry'],maximum_attempts=1)
    for i,identity in zip(spec['source_indices'],spec['source_record_ids']):
        record=data.records[i];assert record['id']==identity
        for scale in [.25,2.]:
            plan=choose_plan(record,g,random.Random(0),forced_scale=scale,flip_override=False);assert not plan['fallback']
            image,boxes,valid=render(record,plan)
            sample={**data.base_sample(i),'image':image,'boxes':boxes,'valid_mask':valid,'ignore_mask':~valid}
            t=targets([sample],model_config(),reference,device,'shared_regression')
            output=model(image[None].to(device),valid_mask=valid[None].to(device))
            for j,(b,qx,qy) in enumerate(t['anchors'].tolist()):
                value=output['log_size'][b,:,qy,qx].clamp(-10,10)
                wh=(value.exp()*value.new_tensor(reference)).clamp(1,512)
                truth=t['sizes'][j].exp()*value.new_tensor(reference)
                rows.append({'scale':scale,'log_size_MAE':float((wh.log()-truth.log()).abs().mean())})
    return {str(s):{'targets':sum(r['scale']==s for r in rows),
        'log_size_MAE':float(np.mean([r['log_size_MAE'] for r in rows if r['scale']==s]))} for s in [.25,2.]}
