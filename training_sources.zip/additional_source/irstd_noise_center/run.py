"""Size-qualified parent, center-only source background training with teacher anchors."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import random
import time
import traceback
import numpy as np
import torch
from .data import loader,swapped_loader,validation_loader
from irstd_t_size.model import TSizeModel
from irstd_adapter import targets,model_config
from irstd.losses.detection import center_loss
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,split_hashes,now
from irstd_v2.train import save_checkpoint,rng_state,restore_rng
from evaluation import metrics
from benchmark_center_metrics import center_metrics
import benchmark_fastdecode as fast

ROOT=Path(__file__).resolve().parents[1]
RESEARCH=ROOT/'experiments/IRSTD_research_20261107'
PARENT=RESEARCH/'background_center_interpolation_refine_v1'
HOME=RESEARCH/'noise_center_peak_guarded_v1'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def construct(c,state,device):
    model=TSizeModel(c).to(device);model.load_state_dict(state,strict=True)
    for name,p in model.named_parameters():p.requires_grad_(name.startswith('heads.center.'))
    assert sum(p.numel() for p in model.parameters() if p.requires_grad)==5233
    teacher=copy.deepcopy(model.heads.center).eval()
    for p in teacher.parameters():p.requires_grad_(False)
    opt=torch.optim.AdamW([{'params':[p for n,p in model.heads.center.named_parameters() if not n.endswith('.bias')],'weight_decay':.0005},
        {'params':[p for n,p in model.heads.center.named_parameters() if n.endswith('.bias')],'weight_decay':0.}],lr=1e-5,betas=tuple(model_config()['train']['betas']))
    return model,teacher,opt


def frozen(model,state):
    for name,value in model.state_dict().items():
        if not name.startswith('heads.center.'):assert torch.equal(value.cpu(),state[name]),name


def losses(model,teacher,images,samples,reference,device):
    count=len(samples)//2;assert len(samples)==count*2
    assert all(s['view_type']=='native' for s in samples[:count])
    t=targets(samples,model_config(),reference,device,'shared_regression')
    valid=torch.stack([s['valid_mask'] for s in samples]).to(device)
    out=model(images.to(device),valid_mask=valid,return_features=True)
    with torch.no_grad():fixed=teacher(out['final_features'][:count].detach())
    lc=model_config()['loss'];per_image=center_loss(out['center_logits'],t,lc['center_focal_alpha'],lc['center_focal_beta'])
    weights=per_image.new_tensor([4.]*count+[1.]*count);supervised=(per_image*weights).sum()/weights.sum()
    native=[];paired=[];shapes=[];negative_anchor=[]
    for b in range(count):
        assert samples[b]['sample_id']==samples[b+count]['sample_id']
        pos=t['positive'][b].flatten().bool();negative=t['negative'][b].flatten().bool()&(t['heatmap'][b].flatten()<.01)
        student=out['center_logits'][b].flatten();swap=out['center_logits'][b+count].flatten();target=fixed[b].flatten()
        if pos.any():
            coordinates=t['positive'][b,0].nonzero()
            for qy,qx in coordinates.tolist():
                ys=slice(max(0,qy-3),min(images.shape[-2],qy+4));xs=slice(max(0,qx-3),min(images.shape[-1],qx+4))
                original_patch=out['center_logits'][b,0,ys,xs];fixed_patch=fixed[b,0,ys,xs]
                augmented_patch=out['center_logits'][b+count,0,ys,xs]
                native.append((original_patch.max()-fixed_patch.max()).square())
                paired.append((augmented_patch.max()-fixed_patch.max()).square())
                shapes.append(((original_patch-original_patch.max())-(fixed_patch-fixed_patch.max())).square().mean())
        k=min(128,int(negative.sum()))
        if k:
            hard=target.masked_fill(~negative,-torch.inf).topk(k).indices
            negative_anchor.append((student[hard]-target[hard]).square().mean())
    zero=supervised*0
    anchor=torch.stack(native).mean() if native else zero;consistency=torch.stack(paired).mean() if paired else zero
    shape=torch.stack(shapes).mean() if shapes else zero;negative=torch.stack(negative_anchor).mean() if negative_anchor else zero
    loss=lc['center_weight']*supervised+.5*anchor+.1*shape+.05*negative+.05*consistency
    assert torch.isfinite(loss)
    return loss,{'center':float(supervised.detach()),'native_peak_mse':float(anchor.detach()),
        'native_local_shape_mse':float(shape.detach()),'native_background_mse':float(negative.detach()),'paired_peak_mse':float(consistency.detach())},out


@torch.inference_mode()
def background_diagnostic(model,cfg,reference,device,folder,name):
    values=[];model.eval()
    for images,samples in loader(cfg,'val'):
        n=len(samples)//2;t=targets(samples,model_config(),reference,device,'shared_regression')
        out=model(images.to(device))['center_logits']
        for b in range(n):
            positive=t['positive'][b].bool();values.extend((out[b][positive]-out[b+n][positive]).square().cpu().tolist())
    frames=evaluate(model,swapped_loader(cfg),device,reference,folder/f'{name}_swapped_predictions.json')
    # AP is threshold-independent. The native source threshold is retained for
    # the supplementary operating-point numbers, never selected on this set.
    from evaluation import metrics
    return {'GT_logit_pair_MSE':float(np.mean(values)),'targets':len(values),
        'swapped_metrics':metrics(frames,reference_threshold()),'scope':'fixed24-source-val-background diagnostic, not target test'}


def reference_threshold():
    return torch.load(RESEARCH/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)['source_validation']['threshold']


@torch.inference_mode()
def noise_diagnostic(model,cfg,reference,threshold,epoch):
    results={}
    for factor in [4,16]:
        frames=evaluate(model,validation_loader(cfg,factor),torch.device('cuda'),reference,HOME/f'epoch_{epoch:02d}_noise{factor}_predictions.json')
        results[str(factor)]={'box':metrics(frames,threshold),'center':center_metrics(frames,threshold)}
    return results


def native_gates(row,parent,baseline):
    v,p=row['source_validation'],parent['source_validation']
    # Parent already passed the geometry and AP95 guards. Permit at most an
    # additional0.5pp relative to that parent, while retaining original v1 limits.
    fine=[v['pooled']['AP50_95']-p['pooled']['AP50_95']+.005]
    fine.extend(v['by_group'][g]['AP50_95']-b['AP50_95']+.005 for g,b in p['by_group'].items())
    from irstd_geometry_repair.run import baseline as v1_base
    base=v1_base()['validation']
    original_fine=[v['pooled']['AP50_95']-base['pooled']['AP50_95']+.02]
    original_fine.extend(v['by_group'][g]['AP50_95']-b['AP50_95']+.02 for g,b in base['by_group'].items())
    result={'macro_AP50_original':v['group_macro_AP50']>=base['group_macro_AP50']-.02,
        'pooled_AP50_original':v['pooled']['AP50']>=base['pooled']['AP50']-.02,
        'native_F1_parent':v['pooled']['F1']>=p['pooled']['F1']-.02,
        'fine_AP95_parent_and_v1':min(fine+original_fine)>=0.,
        'background_logit_MSE_20percent':row['background']['GT_logit_pair_MSE']<=baseline['GT_logit_pair_MSE']*.8,
        'background_AP50_no_worse':row['background']['swapped_metrics']['AP50']>=baseline['swapped_metrics']['AP50']}
    noise_base=json.loads((RESEARCH/'noise_validation_diagnostic/baseline.json').read_text(encoding='utf-8'))['results']
    result.update(noise4_AP50_retained=row['noise']['4']['box']['AP50']>=noise_base['4']['box']['AP50']-.005,
        noise16_AP50_plus2pp=row['noise']['16']['box']['AP50']>=noise_base['16']['box']['AP50']+.02,
        noise16_F1_plus10pp=row['noise']['16']['box']['F1']>=noise_base['16']['box']['F1']+.10)
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--resume',action='store_true');a=p.parse_args()
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    if (HOME/'training_complete.json').exists() and not a.check:return
    random.seed(3407);np.random.seed(3407);torch.manual_seed(3407);torch.cuda.manual_seed_all(3407)
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False);cfg=copy.deepcopy(parent['config']['recipe'])
    cfg.update(name=HOME.name,epochs=1,geometry={**cfg['geometry'],'enabled':False},learning_rate=1e-5,
        trainable_prefixes=['heads.center.'],native_center_weight=4.,native_peak_teacher_weight=.5,
        native_shape_weight=.1,native_background_weight=.05,augmentation_peak_weight=.05)
    identity={'recipe':cfg,'parent_sha256':sha(PARENT/'best.pt'),'source':'DAUB-R','seed':3407,
        'split_hashes':split_hashes(),'source_hashes':{**parent['config']['source_hashes'],
            **{str(p.relative_to(ROOT.parent)):sha(p) for p in Path(__file__).parent.glob('*.py')},
            str((ROOT/'benchmark_fastdecode.py').relative_to(ROOT.parent)):sha(ROOT/'benchmark_fastdecode.py')}}
    for p in [RESEARCH/'classification_feature_probe.py',ROOT/'benchmark_center_metrics.py']:
        identity['source_hashes'][str(p.relative_to(ROOT.parent))]=sha(p)
    identity['noise_baseline_sha256']=sha(RESEARCH/'noise_validation_diagnostic/baseline.json')
    assert json.loads((RESEARCH/'noise_validation_diagnostic/baseline.json').read_text(encoding='utf-8'))['checkpoint_sha256']==identity['parent_sha256']
    for name,digest in identity['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
    check=json.loads((RESEARCH/'fastdecode_equivalence.json').read_text(encoding='utf-8'));assert check['source_sha256']==sha(ROOT/'benchmark_fastdecode.py');fast.install()
    reference=parent['config']['size_reference_512'];identity['size_reference_512']=reference
    device=torch.device('cuda');model,teacher,opt=construct(cfg,parent['model'],device)
    if a.check:
        data=loader(cfg);data.dataset.epoch=1
        from irstd_background_center.data import collate_pairs
        images,samples=collate_pairs([data.dataset[0],data.dataset[1]]);model.eval()
        assert any(s['view_type'].startswith('noise_') for s in samples)
        before={n:v.cpu().clone() for n,v in model.state_dict().items()}
        loss,terms,output=losses(model,teacher,images,samples,reference,device);loss.backward()
        assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith('heads.center.'))
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.heads.center.parameters())
        opt.step();frozen(model,parent['model'])
        with torch.no_grad():after=model(images.to(device),return_features=True)
        for name in ['offsets','log_size','auxiliary_center_logits','final_features']:assert torch.equal(output[name],after[name]),name
        assert any(not torch.equal(v.cpu(),before[n]) for n,v in model.state_dict().items() if n.startswith('heads.center.'))
        write_json(HOME/'preflight.json',{'passed':True,'identity':identity,'trainable_parameters':5233,'frozen_outputs_equal':True,'loss_terms':terms,'updated_at':now()});return
    assert json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))['identity']==identity
    if (HOME/'config.json').exists():assert a.resume and json.loads((HOME/'config.json').read_text(encoding='utf-8'))==identity
    write_json(HOME/'config.json',identity);write_json(HOME/'recipe.json',cfg);write_json(HOME/'process.json',{'pid':os.getpid(),'updated_at':now()})
    ema=copy.deepcopy(model).eval()
    for p in ema.parameters():p.requires_grad_(False)
    train=loader(cfg);val=make_loader('DAUB-R','val',cfg);updates=0;first=0;prior=0.;started=time.perf_counter()
    try:
        if not (HOME/'background_baseline.json').exists():
            import shutil
            shutil.copyfile(RESEARCH/'background_center_guarded_v1/background_baseline.json',HOME/'background_baseline.json')
        baseline=json.loads((HOME/'background_baseline.json').read_text(encoding='utf-8'))
        if a.resume and (HOME/'last.pt').exists():
            s=torch.load(HOME/'last.pt',map_location='cpu',weights_only=False);assert s['config']==identity
            model.load_state_dict(s['model']);ema.load_state_dict(s['ema']);opt.load_state_dict(s['optimizer']);restore_rng(s['rng'])
            first=s['next_epoch'];updates=s['updates'];prior=s['elapsed_seconds']
        best=None;best_key=None
        if a.resume and (HOME/'best.pt').exists():
            best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
            best_key=(all(best['gates'].values()),sum(best['gates'].values()),-best['background']['GT_logit_pair_MSE'],best['source_validation']['group_macro_AP50'])
        at=first
        for epoch in range(first,1):
            train.dataset.epoch=epoch+1;train.generator.manual_seed(3407+(epoch+1)*1000003);tick=time.perf_counter();seen=0
            for j,(images,samples) in enumerate(train):
                model.eval();model.heads.center.train();opt.zero_grad(set_to_none=True)
                loss,terms,_=losses(model,teacher,images,samples,reference,device);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.heads.center.parameters(),10.,error_if_nonfinite=True);opt.step();updates+=1;seen+=len(samples)
                decay=.9999*(1-math.exp(-updates/2000))
                with torch.no_grad():
                    for x,y in zip(ema.heads.center.parameters(),model.heads.center.parameters()):x.mul_(decay).add_(y,alpha=1-decay)
                if j%100==0:
                    r={'status':'training','epoch':epoch+1,'batch':j+1,'total_batches':len(train),'updates':updates,'views':seen,'loss_terms':terms,'updated_at':now()}
                    write_json(HOME/'progress.json',r);print(json.dumps(r),flush=True)
            assert seen==2*4181;frozen(model,parent['model']);frozen(ema,parent['model']);seconds=time.perf_counter()-tick
            write_json(HOME/'progress.json',{'status':'source_validation','epoch':epoch+1,'updated_at':now()})
            frames=evaluate(ema,val,device,reference,HOME/f'epoch_{epoch+1:02d}_predictions.json')
            row={'epoch':epoch+1,'updates':updates,'source_validation':validation_summary(frames),
                'background':background_diagnostic(ema,cfg,reference,device,HOME,f'epoch_{epoch+1:02d}'),
                'geometry_probe':parent['geometry_probe'],'per_scale':parent['per_scale'],'geometry_invariance':'all offset/size/backbone tensors frozen, exact outputs checked',
                'train_seconds':seconds,'elapsed_seconds':prior+time.perf_counter()-started}
            row['noise']=noise_diagnostic(ema,cfg,reference,row['source_validation']['threshold'],epoch+1)
            row['gates']=native_gates(row,parent,baseline);key=(all(row['gates'].values()),sum(row['gates'].values()),-row['background']['GT_logit_pair_MSE'],row['source_validation']['group_macro_AP50'])
            cp={**row,'model':ema.state_dict(),'config':identity};save_checkpoint(HOME/f'epoch_{epoch+1:02d}_ema.pt',cp)
            if best_key is None or key>best_key:best_key=key;best=cp;save_checkpoint(HOME/'best.pt',cp)
            save_checkpoint(HOME/'last.pt',{'model':model.state_dict(),'ema':ema.state_dict(),'optimizer':opt.state_dict(),'config':identity,
                'updates':updates,'next_epoch':epoch+1,'rng':rng_state(),'elapsed_seconds':row['elapsed_seconds']})
            for name,digest in identity['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
            with (HOME/'history.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
            print(json.dumps({'validated_epoch':epoch+1,'gates':row['gates'],'background':row['background']}),flush=True)
            at=epoch+1
            if all(row['gates'].values()):break
        done={'status':'completed','promotion_passed':all(best['gates'].values()),'best_epoch':best['epoch'],'gates':best['gates'],
            'epochs_run':at,'updates':updates,'target_test_cells':0,'updated_at':now()}
        write_json(HOME/'training_complete.json',done);write_json(HOME/'progress.json',done)
    except Exception:write_json(HOME/'failure.json',{'traceback':traceback.format_exc(),'updated_at':now()});raise


if __name__=='__main__':main()
