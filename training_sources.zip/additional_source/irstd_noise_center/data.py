from pathlib import Path
import sys
import torch
from torch.utils.data import Dataset,DataLoader
from irstd_background_center.data import Pairs,collate_pairs,loader as background_loader,swapped_loader
from irstd_v2.data import collate
from data_pipeline import worker_seed

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments/IRSTD_research_20261107'))
from classification_feature_probe import views


class NoisePairs(Pairs):
    def __getitem__(self,index):
        original,swapped=super().__getitem__(index)
        if (index+self.epoch)%2:
            images,_=views(original,index+(self.epoch+1)*1000003)
            slot=1 if (index//2+self.epoch)%2 else 2
            swapped={**original,'image':images[slot],'view_type':'noise_4' if slot==1 else 'noise_16'}
        return original,swapped


def training_loader(cfg):
    return DataLoader(NoisePairs(cfg),batch_size=2,shuffle=True,num_workers=cfg['workers'],collate_fn=collate_pairs,
        worker_init_fn=worker_seed,persistent_workers=False,pin_memory=False,
        generator=torch.Generator().manual_seed(3407),drop_last=False)


class NoiseValidation(Dataset):
    def __init__(self,cfg,factor):
        self.pairs=Pairs(cfg,'val');self.records=self.pairs.records;self.factor=factor
        assert factor in [4,16]
    def __len__(self):return len(self.pairs)
    def __getitem__(self,index):
        i=self.pairs.indices[index];sample=self.pairs.base.base_sample(i)
        images,_=views(sample,i+100000000) # Independent of all train-view seeds.
        return {**sample,'image':images[1 if self.factor==4 else 2],'view_type':f'noise_{self.factor}'}


def validation_loader(cfg,factor):
    return DataLoader(NoiseValidation(cfg,factor),batch_size=4,num_workers=cfg['workers'],collate_fn=collate,
        worker_init_fn=worker_seed,persistent_workers=False,pin_memory=False)


def loader(cfg,split='train'):
    return training_loader(cfg) if split=='train' else background_loader(cfg,split)
