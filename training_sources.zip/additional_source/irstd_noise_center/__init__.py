"""Source-only noise robustness study; original evidence and backbone retained."""
