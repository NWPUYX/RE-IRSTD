"""Freeze sequence-disjoint public splits. Never modify source datasets."""
import json, hashlib, collections, random, re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent; DATA=Path(r'D:\数据集'); OUT=ROOT/'splits'; OUT.mkdir(exist_ok=True)
CONFIG={
 'DAUB-R':('DAUB-R/DAUB',['train.json','val.json','test.json']),
 'IRDST-H':('IRDST-H/IRDST-H',['train.json','val.json','test.json']),
 'IRSTD-UAV':('IRSTD-UAV/datasets/IRSTD-UAV',['train_coco.json','val_coco.json']),
 'ITSDT-15K':('ITSDT-15K/ITSDT-15K',['instances_train2017.json','instances_test2017.json'])}
summary={}; allrecords=[]; corrections=[]
for name,(rel,files) in CONFIG.items():
    base=DATA/rel; subsets=[]; records={}
    for fn in files:
        j=json.loads((base/fn).read_text(encoding='utf-8')); anns=collections.defaultdict(list)
        for a in j['annotations']: anns[a['image_id']].append(a['bbox'])
        names=set()
        for im in j['images']:
            f=im['file_name'].replace('\\','/'); path=base/f
            if not path.exists(): path=base/'images'/f
            assert path.is_file(),path
            names.add(str(path)); boxes=[]
            for box in anns[im['id']]:
                x,y,w,h=map(float,box); x1=max(0.,x); y1=max(0.,y)
                x2=min(float(im['width']),x+w); y2=min(float(im['height']),y+h)
                assert x2>x1 and y2>y1,(name,f,box)
                b=[x1,y1,x2-x1,y2-y1]
                if b!=list(box): corrections.append({'dataset':name,'image':f,'old':box,'new':b})
                boxes.append(b)
            record={'path':str(path),'group':path.parent.name,'width':im['width'],'height':im['height'],'boxes':boxes}
            if str(path) in records: assert records[str(path)]==record
            records[str(path)]=record
        subsets.append(names)
    train,val,test=set(),set(),set()
    if name=='DAUB-R':
        # Original val/test share data11; relocate all data19 to val.
        test=subsets[2]
        val={p for p in subsets[0]|subsets[1] if records[p]['group'] in {'data19','data22','data6'}}
        train=subsets[0]-val
    elif name=='IRDST-H': train,val,test=subsets
    elif name=='IRSTD-UAV':
        groups=sorted({r['group'] for r in records.values()},key=lambda x:int(x))
        random.Random(3407).shuffle(groups)
        train={p for p,r in records.items() if r['group'] in groups[:11]}
        val={p for p,r in records.items() if r['group'] in groups[11:14]}
        test=set(records)-train-val
    else:
        permitted=set()
        for line in (base/'coco_train_ITSDT.txt').read_text().splitlines():
            if line.strip(): permitted.add(str(base/('/'.join(line.split()[0].replace('\\','/').split('/')[-3:]))))
        assert len(permitted)==10000 and permitted<=subsets[0]
        groups=sorted({records[p]['group'] for p in permitted},key=int)
        random.Random(3407).shuffle(groups); vg=set(groups[:8])
        val={p for p in permitted if records[p]['group'] in vg}; train=permitted-val; test=subsets[1]
    splits={'train':train,'val':val,'test':test}; seen=set(); gs=set(); summary[name]={}
    for split,paths in splits.items():
        rr=sorted((records[p] for p in paths),key=lambda r:(r['group'],int(re.findall(r'\d+',Path(r['path']).stem)[-1])))
        for i,r in enumerate(rr): r=dict(r); r['id']=i+1; rr[i]=r
        groups={r['group'] for r in rr}
        assert not seen&paths and not gs&groups,(name,split,'leakage')
        seen|=paths; gs|=groups
        blob=json.dumps(rr,ensure_ascii=False,separators=(',',':')).encode('utf8')
        (OUT/f'{name}_{split}.json').write_bytes(blob)
        summary[name][split]={'frames':len(rr),'boxes':sum(len(r['boxes']) for r in rr),'groups':sorted(groups),'sha256':hashlib.sha256(blob).hexdigest()}
        allrecords.extend((name,split,r['path']) for r in rr)
    print(name,summary[name],flush=True)
(OUT/'box_corrections.json').write_text(json.dumps(corrections,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
def fingerprint(item):
    name,split,path=item; return hashlib.sha256(Path(path).read_bytes()).hexdigest(),item
hashes=collections.defaultdict(list)
with ThreadPoolExecutor(max_workers=8) as pool:
    for h,item in pool.map(fingerprint,allrecords): hashes[h].append(item)
leaks=[{'sha256':h,'items':items} for h,items in hashes.items() if len({(x[0],x[1]) for x in items})>1]
(OUT/'exact_file_overlap.json').write_text(json.dumps(leaks,ensure_ascii=False,indent=2),encoding='utf8')
assert not leaks, f'{len(leaks)} duplicate image hashes across domains/splits; investigate before training'
print('PASS: no shared sequence within dataset and no exact file overlap across domains/splits; clipped boxes',len(corrections))
