"""Serial GPU queue: skip completed jobs, resume checkpoints, stop a failing model."""
import argparse, json, os, subprocess, sys, time, traceback
from pathlib import Path
from summarize_results import summarize, DOMAINS, SEEDS
ROOT=Path(__file__).resolve().parent
MODELS=['STMENet','AA-YOLO','Tridos','SSTNet','LASNet']
def write(value):
    file=ROOT/'queue_status.json'; temp=file.with_suffix('.tmp'); temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8'); temp.replace(file)
def main():
    p=argparse.ArgumentParser(); p.add_argument('--wait-for',type=int); p.add_argument('--models',nargs='+',default=MODELS)
    p.add_argument('--retry-model',action='append',choices=MODELS,default=[])
    a=p.parse_args()
    # Preserve known failed models across process restarts instead of silently
    # discarding diagnostics and retrying unstable training at every restart.
    previous=json.loads((ROOT/'queue_status.json').read_text(encoding='utf8')) if (ROOT/'queue_status.json').exists() else {}
    failures=previous.get('failed',[])
    if a.retry_model:
        retried=[failure for failure in failures if failure['model'] in a.retry_model]
        if retried:
            with (ROOT/'queue_retry_history.jsonl').open('a',encoding='utf8') as history:
                history.write(json.dumps({'retry_models':a.retry_model,'previous_failures':retried,'reason':'checkpoint validated; pinned-host memory disabled after allocator exception'},ensure_ascii=False)+'\n')
        failures=[failure for failure in failures if failure['model'] not in a.retry_model]
    write({'status':'waiting_for_existing_training' if a.wait_for else 'starting','pid':os.getpid(),'models':a.models,'seeds':SEEDS,'epochs_max':100,'failed':failures})
    if a.wait_for:
        import ctypes
        h=ctypes.windll.kernel32.OpenProcess(0x100000,False,a.wait_for)
        if h:
            while ctypes.windll.kernel32.WaitForSingleObject(h,1000)==258: pass
            ctypes.windll.kernel32.CloseHandle(h)
    jobs=[(m,d,s) for s in SEEDS for m in a.models for d in DOMAINS]
    for model,source,seed in jobs:
        run=ROOT/'runs'/model/source/f'seed_{seed}'
        if (run/'results.json').exists(): continue
        if any(x['model']==model for x in failures): continue
        run.mkdir(parents=True,exist_ok=True)
        write({'status':'running','pid':os.getpid(),'active':{'model':model,'source':source,'seed':seed},'failed':failures,'completed_result_cells':summarize(),'supported_training_jobs':len(jobs)})
        cmd=[sys.executable,str(ROOT/'train_public.py'),'--model',model,'--source',source,'--seed',str(seed),'--resume']
        with (run/'console.log').open('a',encoding='utf8') as log:
            result=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONIOENCODING':'utf-8','PYTHONUNBUFFERED':'1'})
        if result.returncode: failures.append({'model':model,'source':source,'seed':seed,'exit_code':result.returncode,'log':str(run/'console.log')})
        summarize()
    write({'status':'supported_jobs_finished' if not failures else 'finished_with_failures','pid':os.getpid(),'failed':failures,'completed_result_cells':summarize(),'supported_training_jobs':len(jobs),'blocked_models':['CHAL','TDCNet','S2MVP'],'Tiny_UAV_IR':'awaiting class semantics and capture-event metadata'})
if __name__=='__main__':
    try: main()
    except Exception:
        write({'status':'queue_failed','error':traceback.format_exc()}); raise
