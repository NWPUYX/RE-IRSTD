"""Source-only geometry repair preserving the v1 scoring pathway."""
