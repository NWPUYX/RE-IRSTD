"""Freeze v1 features/centers, repair offset/size heads, at most three epochs."""
import os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import platform
import random
import shutil
import sys
import time
import traceback
import numpy as np
import torch
from irstd_adapter import model_config, source_audit, targets
from irstd_replay.data import training_loader
from irstd_replay.run import ranking_summary
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate, validation_summary, geometry_probe
from irstd_v2.losses import supervised
from irstd_v2.model import Model
from irstd_v2.settings import write_json, now, split_hashes
from irstd_v2.train import rng_state, restore_rng, save_checkpoint

ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / "experiments/IRSTD_v2/replay50_finetune5_v1"
HOME = ROOT / "experiments/IRSTD_v2/v1_geometry_heads_lr1e4_3epoch_v1"
START = ROOT / "runs/IRSTD/DAUB-R/seed_3407/best.pt"
BASELINE = ROOT / "experiments/IRSTD_v2/geometry_giou_groupval_v1/promotion.json"
SOURCE, SEED = "DAUB-R", 3407
PREFIXES = ("heads.offset.", "heads.size.")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_hashes():
    expected = json.loads((PARENT / "config.json").read_text(encoding="utf-8"))["source_hashes"]
    current = {key: sha(ROOT.parent / key) for key in expected}
    if current != expected:
        raise ValueError("Frozen parent implementation changed")
    current.update({str(p.relative_to(ROOT.parent)): sha(p) for p in Path(__file__).parent.glob("*.py")})
    return current


def recipe():
    cfg = json.loads((PARENT / "recipe.json").read_text(encoding="utf-8"))
    cfg.update(name=HOME.name, initialization="v1_best_EMA", epochs=3, learning_rate=1e-4,
        validation_interval=1, trainable_prefixes=list(PREFIXES), maximum_validation_checks=3,
        selection="geometry_eligible_then_group_macro_AP50_then_pooled_AP50",
        original_AP_selection_saved_separately=True, automatic_matrix=False, automatic_fallback=False)
    return cfg


def baseline():
    return json.loads(BASELINE.read_text(encoding="utf-8"))["baseline"]


def geometry_ok(probe):
    return probe["log_size_error"] <= baseline()["geometry"]["log_size_error"] * .8


def ap_key(row):
    v = row["source_validation"]
    return (v["group_macro_AP50"], v["pooled"]["AP50"])


def candidate_key(row):
    return (geometry_ok(row["geometry_probe"]), *ap_key(row))


def freeze(model):
    for name,param in model.named_parameters():
        param.requires_grad_(name.startswith(PREFIXES))
    assert sum(p.numel() for p in model.parameters() if p.requires_grad) == 10516
    assert sum(p.numel() for p in model.parameters()) == 808952
    groups = [{"params":[p for n,p in model.named_parameters() if p.requires_grad and not n.endswith(".bias")],"weight_decay":.0005},
              {"params":[p for n,p in model.named_parameters() if p.requires_grad and n.endswith(".bias")],"weight_decay":0.}]
    return torch.optim.AdamW(groups,lr=1e-4,betas=tuple(model_config()["train"]["betas"]))


def assert_frozen(model, initial):
    for name,value in model.state_dict().items():
        if not name.startswith(PREFIXES):
            assert torch.equal(value.detach().cpu(),initial[name]), f"Frozen state changed: {name}"


def new_model(cfg,device,state):
    model = Model(cfg).to(device); model.load_state_dict(state,strict=True)
    return model,freeze(model)


def loss_for(model,images,samples,reference,cfg,device):
    target = targets(samples,model_config(),reference,device,"shared_regression")
    valid = torch.stack([s["valid_mask"] for s in samples]).to(device)
    output = model(images.to(device),valid_mask=valid)
    norm = {"images":len(samples),"targets":sum(len(s["boxes"]) for s in samples),"boxes":sum(len(s["boxes"]) for s in samples)}
    terms = supervised(output,target,model_config(),reference,cfg,normalizers=norm)
    lc = model_config()["loss"]
    loss = lc["offset_weight"]*terms["offset"]+lc["size_weight"]*terms["size"]+cfg["giou_weight"]*terms["giou"]
    if not torch.isfinite(loss): raise FloatingPointError("Nonfinite geometry loss")
    return loss,terms,output


def smoke(cfg,initial,reference,device,identity):
    folder = HOME / "checks"; folder.mkdir(parents=True,exist_ok=True)
    model,optimizer = new_model(cfg,device,initial)
    images,samples = next(iter(training_loader(SOURCE,cfg,SEED)))
    assert sorted(s["view_type"] for s in samples)==["augmented","augmented","native","native"]
    model.eval()
    with torch.no_grad(): before = {k:v.clone() for k,v in model(images.to(device)).items() if v is not None}
    before_probe = geometry_probe(model,SOURCE,cfg,reference,device)
    optimizer.zero_grad(set_to_none=True)
    loss,terms,_ = loss_for(model,images,samples,reference,cfg,device); loss.backward()
    assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith(PREFIXES))
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad)
    height_gradient = float(model.heads.size[-1].weight.grad[1].abs().max())
    offset_gradient = float(model.heads.offset[-1].weight.grad.abs().max())
    assert height_gradient>0 and offset_gradient>0
    torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10.,error_if_nonfinite=True)
    optimizer.step(); assert_frozen(model,initial)
    with torch.no_grad(): after = model(images.to(device))
    for key in ("center_logits","auxiliary_center_logits"): assert torch.equal(before[key],after[key])
    for key in ("offsets","log_size"): assert not torch.equal(before[key],after[key])
    after_probe = geometry_probe(model,SOURCE,cfg,reference,device)
    assert abs(before_probe["log_size_error"]-after_probe["log_size_error"])>1e-9
    save_checkpoint(folder / "smoke.pt",{"model":model.state_dict(),"optimizer":optimizer.state_dict()})
    saved = torch.load(folder / "smoke.pt",map_location="cpu",weights_only=False)
    restored,opt = new_model(cfg,device,saved["model"]); opt.load_state_dict(saved["optimizer"]); restored.eval()
    with torch.no_grad(): result = restored(images.to(device))
    assert all(torch.equal(result[k],v) for k,v in after.items() if v is not None)
    assert len(opt.state)==len(optimizer.state)==8
    write_json(folder / "preflight.json",{"passed":True,"identity":identity,"trainable_parameters":10516,"total_parameters":808952,
        "frozen_state_bitwise_equal":True,"center_and_aux_logits_bitwise_equal":True,"geometry_outputs_updated":True,
        "height_output_gradient_max":height_gradient,"offset_output_gradient_max":offset_gradient,
        "geometry_probe_before":before_probe,"geometry_probe_after":after_probe,"optimizer_only_geometry":True,
        "save_reload_bitwise_equal":True,"formal_optimizer_fresh":True,"updated_at":now()})
    print(json.dumps({"smoke_passed":True,"height_gradient":height_gradient,"offset_gradient":offset_gradient}),flush=True)


def promotion(row):
    b = baseline(); v = row["source_validation"]
    gates = {"source_group_AP50_retained":v["group_macro_AP50"]>=b["validation"]["group_macro_AP50"]-.02,
        "source_pooled_AP50_retained":v["pooled"]["AP50"]>=b["validation"]["pooled"]["AP50"]-.02,
        "source_geometry_error_improved":geometry_ok(row["geometry_probe"])}
    return {"passed":all(gates.values()),"gates":gates,"baseline":b,
        "candidate":{k:row[k] for k in ("epoch","source_validation","geometry_probe","ranking")},
        "selection":recipe()["selection"],"protocol_difference":"Geometry eligibility predeclared; original AP-best retained separately",
        "scope":"Source validation only; no target tests or automatic matrix", "updated_at":now()}


def report():
    best = torch.load(HOME / "best.pt",map_location="cpu",weights_only=False)
    original = torch.load(HOME / "best_source_ap.pt",map_location="cpu",weights_only=False)
    result = promotion(best); write_json(HOME / "promotion.json",result)
    rows = [json.loads(x) for x in (HOME / "history.jsonl").read_text(encoding="utf-8").splitlines()]
    lines = ["# IRSTD v1 几何分支受限修复","",f"[KNOWN｜HIGH] 更新时间：{now()}；仅 DAUB-R/3407 源验证。",
        "","[KNOWN｜HIGH] v1最佳EMA初始化；只训练尺寸、偏移头10516参数，总参数808952；FP32/batch4，学习率1e-4，原始/增强2+2；最多3轮，每轮完整源验证。",
        "","[KNOWN｜HIGH] 本轮预先声明几何误差合格后再按组宏AP50、pooled AP50选模，best.pt保存该候选；原先无几何约束的AP最佳另存best_source_ap.pt。此为选模规则差异，不冒充原协议完全同配方对照。",
        "","| 轮数 | 组宏AP50 | pooled AP50 | data19 AP50 | data22 AP50 | pooled AP50:95 | data22 P@R50 | 尺寸压力误差 | 几何合格 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---|"]
    for r in rows:
        v=r["source_validation"]
        lines.append(f"| {r['epoch']} | {v['group_macro_AP50']*100:.4f}% | {v['pooled']['AP50']*100:.4f}% | {v['by_group']['data19']['AP50']*100:.4f}% | {v['by_group']['data22']['AP50']*100:.4f}% | {v['pooled']['AP50_95']*100:.4f}% | {r['ranking']['data22']['precision_at_recall_50']*100:.4f}% | {r['geometry_probe']['log_size_error']:.6f} | {geometry_ok(r['geometry_probe'])} |")
    lines += ["",f"[COMPUTED｜HIGH] 几何约束下候选：第{best['epoch']}轮；三项验收{'通过' if result['passed'] else '未通过'}：{result['gates']}。",
        "",f"[COMPUTED｜HIGH] 原始AP规则最佳：第{original['epoch']}轮，组宏AP50={original['source_validation']['group_macro_AP50']*100:.4f}%，几何误差={original['geometry_probe']['log_size_error']:.6f}。",
        "","[KNOWN｜HIGH] 三项原门槛保持：组宏AP50≥77.3767%，pooled AP50≥76.8410%，尺寸压力误差≤0.339524；AP50:95同步审查。未启动目标测试或其他配方。",
        "","[KNOWN｜HIGH] 每轮保存原始权重、EMA、优化器、随机状态及完整源预测。运行入口：D:\\Miniconda3\\envs\\IRSTD\\python.exe -u -m irstd_geometry_repair.run；工作目录D:\\Codex\\Scenario_adaptability；恢复加--resume。"]
    (HOME / "结果与进度.md").write_text("\n".join(lines),encoding="utf-8")
    return result


def run(check=False,resume=False):
    cfg,device = recipe(),torch.device("cuda")
    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED)
    torch.backends.cudnn.benchmark=False
    parent = torch.load(START,map_location="cpu",weights_only=False)
    reference = source_audit(SOURCE)["size_reference_512"]
    assert reference==parent["config"]["size_reference_512"]
    expected_splits=json.loads((PARENT / "config.json").read_text(encoding="utf-8"))["split_hashes"]
    assert split_hashes()==expected_splits
    identity={"source_hashes":source_hashes(),"split_hashes":split_hashes(),"initial_checkpoint_sha256":sha(START),"recipe":cfg}
    if check: smoke(cfg,parent["model"],reference,device,identity); return
    preflight=json.loads((HOME / "checks/preflight.json").read_text(encoding="utf-8"))
    assert preflight["passed"] and preflight["identity"]==identity
    config={**identity,"source":SOURCE,"seed":SEED,"size_reference_512":reference,
        "initialization":{"checkpoint":str(START),"weights":"EMA","parent_epoch":parent.get("epoch"),"optimizer":"fresh"}}
    if (HOME / "config.json").exists():
        if json.loads((HOME / "config.json").read_text(encoding="utf-8"))!=config or not resume: raise ValueError("Explicit identical --resume required")
    if (HOME / "training_complete.json").exists(): return
    write_json(HOME / "config.json",config); write_json(HOME / "recipe.json",cfg)
    folder=HOME / "source_snapshot"; folder.mkdir(exist_ok=True)
    for p in Path(__file__).parent.glob("*.py"): shutil.copyfile(p,folder / p.name)
    write_json(HOME / "environment.json",{"python":sys.version,"torch":torch.__version__,"cuda":torch.version.cuda,
        "gpu":torch.cuda.get_device_name(device),"platform":platform.platform(),"started_at":now()})
    model,optimizer=new_model(cfg,device,parent["model"])
    initial={k:v.clone() for k,v in parent["model"].items()}
    ema=copy.deepcopy(model).eval()
    for p in ema.parameters(): p.requires_grad_(False)
    train=training_loader(SOURCE,cfg,SEED); val=make_loader(SOURCE,"val",cfg)
    updates,first_epoch,prior_seconds=0,0,0.; started=time.perf_counter()
    write_json(HOME / "process.json",{"pid":os.getpid(),"started_at":now(),"resume":resume})
    if not (HOME / "best.pt").exists():
        write_json(HOME / "progress.json",{"status":"initial_source_validation","epoch":0,"updated_at":now()})
        path=HOME / "epoch_00_source_val_predictions.json"
        frames=evaluate(ema,val,device,reference,path)
        summary=validation_summary(frames); probe=geometry_probe(ema,SOURCE,cfg,reference,device)
        assert abs(summary["group_macro_AP50"]-baseline()["validation"]["group_macro_AP50"])<1e-6
        assert abs(probe["log_size_error"]-baseline()["geometry"]["log_size_error"])<1e-7
        row={"epoch":0,"source_validation":summary,"geometry_probe":probe,"ranking":ranking_summary(frames)}
        for name in ("best.pt","best_source_ap.pt"): save_checkpoint(HOME / name,{**row,"model":parent["model"],"config":config})
        shutil.copyfile(path,HOME / "best_source_val_predictions.json")
        (HOME / "history.jsonl").write_text(json.dumps(row)+"\n",encoding="utf-8")
    best=torch.load(HOME / "best.pt",map_location="cpu",weights_only=False)
    plain=torch.load(HOME / "best_source_ap.pt",map_location="cpu",weights_only=False)
    best_key,plain_key=candidate_key(best),ap_key(plain)
    del best,plain,parent
    if resume and (HOME / "last.pt").exists():
        state=torch.load(HOME / "last.pt",map_location="cpu",weights_only=False)
        assert state["config"]==config
        model.load_state_dict(state["model"]); ema.load_state_dict(state["ema"]); optimizer.load_state_dict(state["optimizer"])
        updates,first_epoch,prior_seconds=state["updates"],state["next_epoch"],state["elapsed_seconds"]
        restore_rng(state["rng"]); del state
        started=time.perf_counter()
    current=report(); at=first_epoch
    for epoch in range(first_epoch,3):
        if current["passed"]: break
        train.dataset.epoch=epoch; counts={"native":0,"augmented":0}; sums={}; batches=0; tick=time.perf_counter()
        for iteration,(images,samples) in enumerate(train):
            if len(samples)==4: assert sum(s["view_type"]=="native" for s in samples)==2
            model.eval(); model.heads.offset.train(); model.heads.size.train()
            optimizer.zero_grad(set_to_none=True)
            loss,terms,output=loss_for(model,images,samples,reference,cfg,device); loss.backward()
            assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith(PREFIXES))
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10.,error_if_nonfinite=True)
            optimizer.step(); updates+=1
            decay=.9999*(1-math.exp(-updates/2000))
            with torch.no_grad():
                for name,p in ema.named_parameters():
                    if name.startswith(PREFIXES): p.mul_(decay).add_(model.get_parameter(name),alpha=1-decay)
            for name,value in terms.items(): sums[name]=sums.get(name,0.)+float(value.detach())
            for sample in samples: counts[sample["view_type"]]+=1
            batches+=1
            if iteration%40==0:
                progress={"status":"training","pid":os.getpid(),"epoch":epoch+1,"batch":iteration+1,"total_batches":len(train),
                    "updates":updates,"views":counts,"geometry_loss":float(loss.detach()),"updated_at":now()}
                write_json(HOME / "progress.json",progress); print(json.dumps(progress),flush=True)
            del loss,terms,output
        train_seconds=time.perf_counter()-tick
        assert sum(counts.values())==4181
        assert_frozen(model,initial); assert_frozen(ema,initial)
        assert source_hashes()==identity["source_hashes"]
        at=epoch+1; write_json(HOME / "progress.json",{"status":"source_validation","epoch":at,"updated_at":now()})
        tick=time.perf_counter(); path=HOME / f"epoch_{at:02d}_source_val_predictions.json"
        frames=evaluate(ema,val,device,reference,path); summary=validation_summary(frames)
        probe=geometry_probe(ema,SOURCE,cfg,reference,device)
        row={"epoch":at,"updates":updates,"source_validation":summary,"geometry_probe":probe,"ranking":ranking_summary(frames),
            "view_counts":counts,"training_seconds":train_seconds,"validation_seconds":time.perf_counter()-tick,
            "loss_mean_over_batches":{k:v/batches for k,v in sums.items()},"elapsed_seconds":prior_seconds+time.perf_counter()-started,
            "frozen_state_bitwise_equal":True}
        state={**row,"model":ema.state_dict(),"config":config}
        save_checkpoint(HOME / f"epoch_{at:02d}_ema.pt",state)
        save_checkpoint(HOME / f"epoch_{at:02d}_raw.pt",{"model":model.state_dict(),"epoch":at,"config":config})
        if candidate_key(row)>best_key:
            best_key=candidate_key(row); save_checkpoint(HOME / "best.pt",state)
            shutil.copyfile(path,HOME / "best_source_val_predictions.json")
        if ap_key(row)>plain_key:
            plain_key=ap_key(row); save_checkpoint(HOME / "best_source_ap.pt",state)
        save_checkpoint(HOME / "last.pt",{"model":model.state_dict(),"ema":ema.state_dict(),"optimizer":optimizer.state_dict(),
            "next_epoch":at,"updates":updates,"rng":rng_state(),"config":config,"elapsed_seconds":row["elapsed_seconds"]})
        history=HOME / "history.jsonl"; rows=[json.loads(x) for x in history.read_text(encoding="utf-8").splitlines()]
        rows=sorted([x for x in rows if x["epoch"]!=at]+[row],key=lambda x:x["epoch"])
        tmp=history.with_suffix(".tmp"); tmp.write_text("".join(json.dumps(x)+"\n" for x in rows),encoding="utf-8"); tmp.replace(history)
        current=report()
        print(json.dumps({"validated_epoch":at,"group_macro_AP50":summary["group_macro_AP50"],"geometry_error":probe["log_size_error"],"gates_passed":current["passed"]}),flush=True)
    final=report()
    completed={"status":"completed_source_gate_passed" if final["passed"] else "completed_source_gate_failed","epochs_run":at,
        "updates":updates,"best_epoch":final["candidate"]["epoch"],"promotion_passed":final["passed"],
        "frozen_state_bitwise_equal":True,"elapsed_seconds":prior_seconds+time.perf_counter()-started,"target_test_cells":0,
        "automatic_fallback":False,"updated_at":now()}
    write_json(HOME / "training_complete.json",completed); write_json(HOME / "progress.json",completed)
    print(json.dumps(completed),flush=True)


def main():
    import msvcrt
    parser=argparse.ArgumentParser(); parser.add_argument("--check",action="store_true"); parser.add_argument("--resume",action="store_true")
    args=parser.parse_args(); HOME.mkdir(parents=True,exist_ok=True)
    with (HOME / "run.lock").open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1): lock.write(b"1"); lock.flush()
        lock.seek(0); msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        torch.set_num_threads(8)
        try: run(args.check,args.resume)
        except Exception:
            write_json(HOME / "failure.json",{"traceback":traceback.format_exc(),"updated_at":now()})
            write_json(HOME / "progress.json",{"status":"failed","updated_at":now()}); raise


if __name__=="__main__": main()
