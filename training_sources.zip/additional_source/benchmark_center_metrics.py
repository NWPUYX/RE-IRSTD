"""Supplementary center metrics on unchanged frozen detector candidates."""
import numpy as np


def center_metrics(frames,threshold):
    scores=np.concatenate([np.asarray(f['scores']) for f in frames])
    tp=np.concatenate([np.asarray(f['center_tp'],dtype=bool) for f in frames])
    order=np.argsort(-scores,kind='stable');scores=scores[order];tp=tp[order]
    total=sum(f['gt'] for f in frames);hit=np.flatnonzero(tp);ap=0.
    if len(hit) and total:
        cumulative=np.arange(1,len(hit)+1);recall=cumulative/total;precision=cumulative/(hit+1)
        envelope=np.maximum.accumulate(precision[::-1])[::-1];index=np.searchsorted(recall,np.linspace(0,1,101),side='left')
        values=np.zeros(101);valid=index<len(envelope);values[valid]=envelope[index[valid]];ap=float(values.mean())
    selected=scores>=threshold;det=int(selected.sum());correct=int(tp[selected].sum())
    return {'center_AP3px':ap,'center_F1_at_source_box_threshold':2*correct/(det+total) if det+total else 0.,
        'center_Recall_at_source_box_threshold':correct/total if total else 0.,
        'center_FP_per_frame':(det-correct)/len(frames),'detections_at_threshold':det}
