"""Native-view precision repair after successful T-scale calibration."""
