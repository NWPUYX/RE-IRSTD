"""Two-epoch size-only continuation with native-view regression priority."""
import os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG",":4096:8")
import argparse
from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import shutil
import sys
import time
import traceback
import torch
from irstd_t_size.model import TSizeModel,initialize,optimizer
from irstd_adapter import model_config,targets
from irstd_geometry_balance.data import training_loader
from irstd_geometry_balance.run import probe,gates
from irstd_geometry_repair.run import ap_key,baseline
from irstd_replay.run import ranking_summary
from irstd_v2.data import make_loader
from irstd_v2.losses import supervised
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import split_hashes,write_json,now
from irstd_v2.train import save_checkpoint,rng_state,restore_rng

ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/"experiments/IRSTD_research_20261107/t_size_route_v1"
HOME=ROOT/"experiments/IRSTD_research_20261107/native_precision_w4_v1"
START=PARENT/"last.pt"
SOURCE,SEED="DAUB-R",3407


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def recipe():
    cfg=json.loads((PARENT/"recipe.json").read_text(encoding="utf-8"))
    cfg.update(name=HOME.name,epochs=4,additional_epochs=2,parent_epochs=2,native_regression_weight=4.,
        initialization="T route last raw/EMA/optimizer continuation",fine_AP95_max_drop=.02)
    return cfg


def fingerprints():
    expected=json.loads((PARENT/"config.json").read_text(encoding="utf-8"))["source_hashes"]
    current={k:sha(ROOT.parent/k) for k in expected}; assert current==expected
    current.update({str(p.relative_to(ROOT.parent)):sha(p) for p in Path(__file__).parent.glob("*.py")})
    return current


def frozen(model,state):
    for name,v in model.state_dict().items():
        if not name.startswith("heads.size."): assert torch.equal(v.cpu(),state[name]),name


def construct(cfg,state,device):
    m=TSizeModel(cfg).to(device); initialize(m,state["model"],reset_size=False)
    opt=optimizer(m,cfg); opt.load_state_dict(state["optimizer"])
    ema=copy.deepcopy(m).eval(); ema.load_state_dict(state["ema"])
    for p in ema.parameters(): p.requires_grad_(False)
    assert len(opt.state)==4 and all(int(v["step"])==state["updates"] for v in opt.state.values())
    return m,opt,ema


def loss_for(model,images,samples,reference,cfg,device):
    t=targets(samples,model_config(),reference,device,"shared_regression")
    valid=torch.stack([s["valid_mask"] for s in samples]).to(device)
    out=model(images.to(device),valid_mask=valid)
    w=images.new_tensor([cfg["native_regression_weight"] if s["view_type"]=="native" else 1. for s in samples]).to(device)
    normalizers={"images":float(w.sum()),"targets":sum(float(w[i])*len(s["boxes"]) for i,s in enumerate(samples)),
        "boxes":sum(float(w[i])*len(s["boxes"]) for i,s in enumerate(samples))}
    terms=supervised(out,t,model_config(),reference,cfg,weights=w,normalizers=normalizers)
    loss=model_config()["loss"]["size_weight"]*terms["size"]+cfg["giou_weight"]*terms["giou"]
    if not torch.isfinite(loss): raise FloatingPointError("Nonfinite precision loss")
    return loss,terms


def quality(row):
    base=baseline()["validation"]; v=row["source_validation"]
    margins=[v["pooled"]["AP50_95"]-base["pooled"]["AP50_95"]+.02]
    margins.extend(v["by_group"][g]["AP50_95"]-b["AP50_95"]+.02 for g,b in base["by_group"].items())
    original,large=gates(row)
    return all(original.values()) and large and min(margins)>=0.,all(original.values()),large,min(margins)


def key(row):
    full,original,large,margin=quality(row)
    return (full,original and large,margin,*ap_key(row))


def smoke(cfg,state,reference,device,identity):
    folder=HOME/"checks"; folder.mkdir(parents=True,exist_ok=True)
    model,opt,ema=construct(cfg,state,device)
    assert all(torch.equal(v.cpu(),state["ema"][k]) for k,v in ema.state_dict().items())
    loader=training_loader(SOURCE,cfg,SEED); loader.dataset.epoch=7
    images,samples=next(iter(loader)); model.eval()
    assert Counter(s["view_type"] for s in samples)=={"native":2,"shrink":1,"enlarge":1}
    with torch.no_grad(): before=model(images.to(device))
    opt.zero_grad(set_to_none=True); loss,terms=loss_for(model,images,samples,reference,cfg,device); loss.backward()
    assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith("heads.size."))
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.heads.size.parameters())
    torch.nn.utils.clip_grad_norm_(model.heads.size.parameters(),10.,error_if_nonfinite=True); opt.step(); frozen(model,state["model"])
    with torch.no_grad(): after=model(images.to(device))
    for field in ("center_logits","offsets","auxiliary_center_logits"): assert torch.equal(before[field],after[field])
    assert all(int(v["step"])==state["updates"]+1 for v in opt.state.values())
    save_checkpoint(folder/"smoke.pt",{"model":model.state_dict(),"optimizer":opt.state_dict(),"ema":ema.state_dict(),"updates":state["updates"]+1})
    saved=torch.load(folder/"smoke.pt",map_location="cpu",weights_only=False)
    restored,_,_=construct(cfg,saved,device); restored.eval()
    with torch.no_grad(): output=restored(images.to(device))
    assert all(torch.equal(output[k],v) for k,v in after.items())
    write_json(folder/"preflight.json",{"passed":True,"identity":identity,"frozen_states_and_outputs_equal":True,
        "optimizer_continuation_steps":state["updates"],"normalized_weighted_loss":True,"save_reload_equal":True,"updated_at":now()})
    print(json.dumps({"smoke_passed":True,"parent_updates":state["updates"]}),flush=True)


def report():
    best=torch.load(HOME/"best.pt",map_location="cpu",weights_only=False)
    full,original,large,margin=quality(best)
    result={"passed":full,"original_gates_passed":original,"enlarge_review_passed":large,"fine_AP95_review_passed":margin>=0,
        "worst_fine_AP95_margin":margin,"candidate":{k:best[k] for k in ("epoch","source_validation","geometry_probe","per_scale","ranking")},"updated_at":now()}
    write_json(HOME/"promotion.json",result)
    rows=[json.loads(s) for s in (HOME/"history.jsonl").read_text(encoding="utf-8").splitlines()]
    lines=["# 原始视图精度优先续调","",f"[KNOWN｜HIGH] 更新时间：{now()}；source-only，原始视图回归权重4，其余1，按加权目标数归一化；仅尺寸头5258参数。",
        "","| T阶段累计轮数 | 组宏AP50 | pooled AP50:95 | data19 AP50:95 | data22 AP50:95 | 压力尺寸误差 | 放大误差 |",
        "|---|---:|---:|---:|---:|---:|---:|"]
    for r in rows:
        v=r["source_validation"]
        lines.append(f"| {r['epoch']} | {v['group_macro_AP50']*100:.4f}% | {v['pooled']['AP50_95']*100:.4f}% | {v['by_group']['data19']['AP50_95']*100:.4f}% | {v['by_group']['data22']['AP50_95']*100:.4f}% | {r['geometry_probe']['log_size_error']:.6f} | {r['per_scale']['1.4']['log_size_error']:.6f} |")
    lines += ["",f"[COMPUTED｜HIGH] 当前候选第{best['epoch']}轮；原三项{original}，放大审查{large}，新增前瞻精细定位保护{margin>=0}。",
        "","[KNOWN｜HIGH] 新增精细定位保护：pooled及每个源验证组AP50:95均不低于v1超过2个百分点；此为本轮前瞻条件，不改写前轮已通过的原门槛。最多追加2轮，局部失败后自主诊断转向。"]
    (HOME/"结果与进度.md").write_text("\n".join(lines),encoding="utf-8")
    return result


def run(check=False,resume=False):
    cfg,device=recipe(),torch.device("cuda"); torch.backends.cudnn.benchmark=False
    state=torch.load(START,map_location="cpu",weights_only=False); assert state["next_epoch"]==2
    reference=state["config"]["size_reference_512"]; assert split_hashes()==state["config"]["split_hashes"]
    identity={"source_hashes":fingerprints(),"parent_checkpoint_sha256":sha(START),"split_hashes":split_hashes(),"recipe":cfg}
    if check: smoke(cfg,state,reference,device,identity); return
    checked=json.loads((HOME/"checks/preflight.json").read_text(encoding="utf-8")); assert checked["passed"] and checked["identity"]==identity
    config={**identity,"source":SOURCE,"seed":SEED,"size_reference_512":reference,"initial_checkpoint":str(START),"model_class":"irstd_t_size.model.TSizeModel"}
    if (HOME/"config.json").exists():
        if not resume or json.loads((HOME/"config.json").read_text(encoding="utf-8"))!=config: raise ValueError("Identical resume required")
    if (HOME/"training_complete.json").exists(): return
    write_json(HOME/"config.json",config); write_json(HOME/"recipe.json",cfg)
    folder=HOME/"source_snapshot"; folder.mkdir(exist_ok=True)
    for p in Path(__file__).parent.glob("*.py"): shutil.copyfile(p,folder/p.name)
    model,opt,ema=construct(cfg,state,device); initial=state["model"]
    updates,first,prior=state["updates"],2,0.
    train=training_loader(SOURCE,cfg,SEED); val=make_loader(SOURCE,"val",cfg)
    if not (HOME/"best.pt").exists():
        row=json.loads((PARENT/"history.jsonl").read_text(encoding="utf-8").splitlines()[-1])
        parent=torch.load(PARENT/"epoch_02_ema.pt",map_location="cpu",weights_only=False)
        assert all(torch.equal(v,parent["model"][k]) for k,v in state["ema"].items())
        save_checkpoint(HOME/"best.pt",{**row,"model":state["ema"],"config":config})
        shutil.copyfile(PARENT/"epoch_02_predictions.json",HOME/"best_source_val_predictions.json")
        (HOME/"history.jsonl").write_text(json.dumps(row)+"\n",encoding="utf-8")
        del parent
    restore_rng(state["rng"])
    if resume and (HOME/"last.pt").exists():
        saved=torch.load(HOME/"last.pt",map_location="cpu",weights_only=False); assert saved["config"]==config
        model.load_state_dict(saved["model"]); ema.load_state_dict(saved["ema"]); opt.load_state_dict(saved["optimizer"])
        updates,first,prior=saved["updates"],saved["next_epoch"],saved["elapsed_seconds"]; restore_rng(saved["rng"])
    best=torch.load(HOME/"best.pt",map_location="cpu",weights_only=False); best_key=key(best); del best
    started=time.perf_counter(); current=report(); at=first
    write_json(HOME/"process.json",{"pid":os.getpid(),"started_at":now()})
    for epoch in range(first,4):
        if current["passed"]: break
        train.dataset.epoch=5+epoch; counts=Counter(); sums={}; batches=0; tick=time.perf_counter()
        for j,(images,samples) in enumerate(train):
            model.eval(); model.heads.size.train(); opt.zero_grad(set_to_none=True)
            loss,terms=loss_for(model,images,samples,reference,cfg,device); loss.backward()
            assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith("heads.size."))
            torch.nn.utils.clip_grad_norm_(model.heads.size.parameters(),10.,error_if_nonfinite=True); opt.step(); updates+=1
            decay=.9999*(1-math.exp(-updates/2000))
            with torch.no_grad():
                for a,b in zip(ema.heads.size.parameters(),model.heads.size.parameters()): a.mul_(decay).add_(b,alpha=1-decay)
            for s in samples: counts[s["view_type"]]+=1
            for k,v in terms.items(): sums[k]=sums.get(k,0.)+float(v.detach())
            batches+=1
            if j%40==0:
                progress={"status":"training","epoch":epoch+1,"batch":j+1,"total_batches":len(train),"views":dict(counts),"updates":updates,"updated_at":now()}
                write_json(HOME/"progress.json",progress); print(json.dumps(progress),flush=True)
            del loss,terms
        train_seconds=time.perf_counter()-tick; assert sum(counts.values())==4181
        frozen(model,initial); frozen(ema,initial); assert fingerprints()==identity["source_hashes"]
        at=epoch+1; write_json(HOME/"progress.json",{"status":"source_validation","epoch":at,"updated_at":now()}); tick=time.perf_counter()
        path=HOME/f"epoch_{at:02d}_predictions.json"; frames=evaluate(ema,val,device,reference,path); total,split=probe(ema,cfg,reference,device)
        row={"epoch":at,"updates":updates,"source_validation":validation_summary(frames),"geometry_probe":total,"per_scale":split,
            "ranking":ranking_summary(frames),"view_counts":dict(counts),"training_seconds":train_seconds,"validation_seconds":time.perf_counter()-tick,
            "loss_mean_over_batches":{k:v/batches for k,v in sums.items()},"elapsed_seconds":prior+time.perf_counter()-started}
        checkpoint={**row,"model":ema.state_dict(),"config":config}; save_checkpoint(HOME/f"epoch_{at:02d}_ema.pt",checkpoint)
        save_checkpoint(HOME/f"epoch_{at:02d}_raw.pt",{"model":model.state_dict(),"config":config,"epoch":at})
        if key(row)>best_key: best_key=key(row); save_checkpoint(HOME/"best.pt",checkpoint); shutil.copyfile(path,HOME/"best_source_val_predictions.json")
        save_checkpoint(HOME/"last.pt",{"model":model.state_dict(),"ema":ema.state_dict(),"optimizer":opt.state_dict(),"next_epoch":at,"updates":updates,
            "rng":rng_state(),"elapsed_seconds":row["elapsed_seconds"],"config":config})
        history=HOME/"history.jsonl"; rows=[json.loads(s) for s in history.read_text(encoding="utf-8").splitlines()]
        rows=sorted([r for r in rows if r["epoch"]!=at]+[row],key=lambda r:r["epoch"])
        tmp=history.with_suffix(".tmp"); tmp.write_text("".join(json.dumps(r)+"\n" for r in rows),encoding="utf-8"); tmp.replace(history)
        current=report(); print(json.dumps({"validated_epoch":at,"quality_passed":current["passed"],"fine_margin":current["worst_fine_AP95_margin"]}),flush=True)
    final=report(); done={"status":"completed_passed" if final["passed"] else "completed_local_stage_held","additional_epochs_run":at-2,
        "epochs_run":at,"updates":updates,"best_epoch":final["candidate"]["epoch"],"promotion_passed":final["passed"],
        "original_gates_passed":final["original_gates_passed"],"enlarge_review_passed":final["enlarge_review_passed"],
        "fine_AP95_review_passed":final["fine_AP95_review_passed"],"elapsed_seconds":prior+time.perf_counter()-started,"target_test_cells":0,"updated_at":now()}
    write_json(HOME/"training_complete.json",done); write_json(HOME/"progress.json",done); print(json.dumps(done),flush=True)


def main():
    import msvcrt
    p=argparse.ArgumentParser(); p.add_argument("--check",action="store_true"); p.add_argument("--resume",action="store_true"); a=p.parse_args()
    HOME.mkdir(parents=True,exist_ok=True)
    with (HOME/"run.lock").open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1): lock.write(b"1"); lock.flush()
        lock.seek(0); msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1); torch.set_num_threads(8)
        try: run(a.check,a.resume)
        except Exception: write_json(HOME/"failure.json",{"traceback":traceback.format_exc(),"updated_at":now()}); raise


if __name__=="__main__": main()
