"""Exact AP50 cluster bootstrap using cumulative counts at TP ranks only."""
import numpy as np
from evaluation import arrays


def prepared(frames,names):
    lookup={g:i for i,g in enumerate(names)}
    _,tp,_,_=arrays(frames)
    raw_scores=np.concatenate([np.asarray(f['scores']) for f in frames])
    raw_groups=np.concatenate([np.full(len(f['scores']),lookup[f['group']],dtype=np.int32) for f in frames])
    pg=raw_groups[np.argsort(-raw_scores,kind='stable')]
    hit=np.flatnonzero(tp[:,0]);hit_group=pg[hit]
    pred_prefix=np.stack([np.cumsum(pg==i,dtype=np.int64)[hit] for i in range(len(names))],axis=1)
    tp_prefix=np.stack([np.cumsum(hit_group==i,dtype=np.int64) for i in range(len(names))],axis=1)
    gt=np.zeros(len(names),dtype=np.int64)
    for f in frames:gt[lookup[f['group']]]+=f['gt']
    return pred_prefix,tp_prefix,hit_group,gt


def weighted_ap(prep,counts):
    pred_prefix,tp_prefix,hit_group,gt=prep;total=int(gt@counts)
    if not total:return None
    selected=counts[hit_group]>0
    if not selected.any():return 0.
    hit=(tp_prefix@counts)[selected];den=(pred_prefix@counts)[selected]
    recall=hit/total;precision=hit/den
    envelope=np.maximum.accumulate(precision[::-1])[::-1]
    index=np.searchsorted(recall,np.linspace(0,1,101),side='left')
    values=np.zeros(101);valid=index<len(envelope);values[valid]=envelope[index[valid]]
    return float(values.mean())


def cluster_ci(frames,draws=200):
    names=sorted({f['group'] for f in frames})
    if len(names)<2:return None
    prep=prepared(frames,names);rng=np.random.default_rng(3407);values=[]
    for _ in range(draws):
        counts=np.bincount(rng.integers(0,len(names),len(names)),minlength=len(names))
        value=weighted_ap(prep,counts)
        if value is not None:values.append(value)
    return np.quantile(values,[.025,.975]).tolist()


def paired_ci(left,right,draws=200):
    assert len(left)==len(right)
    assert all((a['group'],a['gt'])==(b['group'],b['gt']) for a,b in zip(left,right))
    names=sorted({f['group'] for f in left})
    if len(names)<2:return None
    a,b=prepared(left,names),prepared(right,names);assert np.array_equal(a[3],b[3])
    rng=np.random.default_rng(3407);values=[]
    for _ in range(draws):
        counts=np.bincount(rng.integers(0,len(names),len(names)),minlength=len(names))
        first,second=weighted_ap(a,counts),weighted_ap(b,counts)
        if first is not None:values.append(first-second)
    return np.quantile(values,[.025,.975]).tolist()
