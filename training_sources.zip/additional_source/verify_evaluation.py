"""Cross-check AP against COCOeval and validate threshold selection."""
import contextlib, io, json
import numpy as np
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from evaluation import match_frame, metrics, select_threshold
records=[{'id':1,'group':'v1','width':100,'height':100,'boxes':[[20,20,8,8],[40,40,6,6]]},{'id':2,'group':'v2','width':100,'height':100,'boxes':[]},{'id':3,'group':'v3','width':100,'height':100,'boxes':[[10,10,8,8]]}]
predictions=[np.array([[20,20,28,28,.9],[20,20,28,28,.8],[40,40,46,46,.4]],dtype=np.float32),np.array([[5,5,9,9,.7]],dtype=np.float32),np.array([[11,10,19,18,.6]],dtype=np.float32)]
frames=[match_frame(p,r) for p,r in zip(predictions,records)]
gt={'images':[{'id':r['id'],'width':100,'height':100} for r in records],'categories':[{'id':1,'name':'target'}],'annotations':[],'info':{}}
dt=[]
for r,pred in zip(records,predictions):
    for box in r['boxes']: gt['annotations'].append({'id':len(gt['annotations'])+1,'image_id':r['id'],'category_id':1,'bbox':box,'area':box[2]*box[3],'iscrowd':0})
    for x,y,x2,y2,s in pred: dt.append({'image_id':r['id'],'category_id':1,'bbox':[float(x),float(y),float(x2-x),float(y2-y)],'score':float(s)})
with contextlib.redirect_stdout(io.StringIO()):
    coco=COCO(); coco.dataset=gt; coco.createIndex(); detect=coco.loadRes(dt)
    ev=COCOeval(coco,detect,'bbox'); ev.evaluate(); ev.accumulate(); ev.summarize()
ours=metrics(frames,.5)
assert abs(ours['AP50']-ev.stats[1])<1e-9,(ours,ev.stats)
assert abs(ours['AP50_95']-ev.stats[0])<1e-9,(ours,ev.stats)
assert ours['FP_per_frame']==2/3
thr=select_threshold(frames); candidates=[metrics(frames,float(s))['F1'] for pred in predictions for s in pred[:,4]]
assert abs(metrics(frames,thr)['F1']-max(candidates))<1e-9
empty=match_frame(np.zeros((0,5),dtype=np.float32),records[0]); assert metrics([empty],.5)['AP50']==0
print(json.dumps({'AP50_matches_COCOeval':True,'AP50_95_matches_COCOeval':True,'duplicate_predictions_count_as_FP':True,'empty_predictions_AP_zero':True,'source_threshold_maximizes_source_F1':True,'AP50':ours['AP50'],'AP50_95':ours['AP50_95']}))
