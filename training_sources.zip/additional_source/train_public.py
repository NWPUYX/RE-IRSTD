"""Scratch training; source-only selection; evaluate one checkpoint on all four domains."""
import os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'cache/matplotlib'))
os.environ.setdefault('TORCH_HOME',str(ROOT/'cache/torch'))
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse, copy, hashlib, json, math, random, time
import numpy as np
import torch
from torch.utils.data import DataLoader
from model_adapter import build, training_loss
from data_pipeline import VideoData, collate, worker_seed
from evaluation import evaluate, metrics, select_threshold
DOMAINS=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']

def write_json(path,value):
    temp=path.with_suffix('.tmp'); temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8'); temp.replace(path)

def loader(domain,split,model,batch,workers,train=False):
    dataset=VideoData(domain,split,model,train)
    # Avoid the pinned-host allocator failure seen on 2026-10-20. Pageable host
    # transfers preserve tensor values and the training/selection protocol.
    return DataLoader(dataset,batch_size=batch,shuffle=train,num_workers=workers,collate_fn=collate,pin_memory=False,persistent_workers=workers>0,worker_init_fn=worker_seed,drop_last=False)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--model',required=True); p.add_argument('--source',choices=DOMAINS,required=True)
    p.add_argument('--seed',type=int,default=3407); p.add_argument('--epochs',type=int,default=100); p.add_argument('--batch',type=int,default=4)
    p.add_argument('--workers',type=int,default=2); p.add_argument('--val-interval',type=int,default=5); p.add_argument('--patience',type=int,default=10)
    p.add_argument('--resume',action='store_true'); p.add_argument('--smoke',action='store_true',help='Real data 2 updates and 8-image inference; never a reported benchmark')
    a=p.parse_args(); torch.set_num_threads(8); random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed); torch.cuda.manual_seed_all(a.seed)
    torch.backends.cudnn.benchmark=False
    device=torch.device('cuda'); run=ROOT/('smoke_runs' if a.smoke else 'runs')/a.model/a.source/f'seed_{a.seed}'; run.mkdir(parents=True,exist_ok=True)
    split_hashes={s:hashlib.sha256((ROOT/'splits'/f'{a.source}_{s}.json').read_bytes()).hexdigest() for s in ('train','val','test')}
    config={**vars(a),'input_size':512,'pretrained':False,'frames':1 if a.model=='AA-YOLO' else 5,'window':'causal, gap reset, repeat first frame','augmentation':'same window horizontal flip, p=0.5; no mosaic or mixup','precision':'float32','NMS_IoU':.5,'confidence_floor':1e-5,'pre_NMS_topk':1000,'max_detections':100,'split_hashes':split_hashes,'protocol':'source-only checkpoint and threshold; sequence and exact-hash exclusion; research retraining, not paper-score reproduction'}
    if a.model=='LASNet': config['implementation_fix']='motion-mask target 255 -> 1 to match sigmoid [0,1]; otherwise same IoU loss and architecture'
    if (run/'config.json').exists():
        old=json.loads((run/'config.json').read_text(encoding='utf8'))
        assert old['split_hashes']==split_hashes,'Split changed after training started'
    write_json(run/'config.json',config)
    write_json(run/'process.json',{'pid':os.getpid(),'model':a.model,'source':a.source,'seed':a.seed})
    model,criterion=build(a.model); model.to(device)
    # The official YOLO losses call empty_cache for every image. It changes allocator
    # performance, not tensor values; keep cached CUDA allocations for this process.
    torch.cuda.empty_cache=lambda: None
    if hasattr(criterion,'to'): criterion.to(device)
    if a.model!='AA-YOLO':
        import importlib
        m=importlib.import_module({'STMENet':'model.nets.yolo_training','Tridos':'nets.yolo_training','SSTNet':'nets.yolo_training','LASNet':'nets.training','CHAL':'nets.yolo_training','TDCNet':'model.nets.yolo_training'}[a.model])
        if hasattr(m,'weights_init'): m.weights_init(model)
    kind='adam' if a.model in ('Tridos','TDCNet') else 'adamw' if a.model=='CHAL' else 'sgd'
    initial_lr=8e-5 if kind=='adamw' else max(3e-4,min(1e-3,a.batch/64*(.001 if a.model=='TDCNet' else .01))) if kind=='adam' else max(5e-4,a.batch/64*.01)
    norms=[]; weights=[]; biases=[]
    for module in model.modules():
        if hasattr(module,'bias') and isinstance(module.bias,torch.nn.Parameter): biases.append(module.bias)
        if hasattr(module,'weight') and isinstance(module.weight,torch.nn.Parameter):
            (norms if isinstance(module,(torch.nn.BatchNorm1d,torch.nn.BatchNorm2d,torch.nn.BatchNorm3d,torch.nn.LayerNorm,torch.nn.GroupNorm)) else weights).append(module.weight)
    known={id(x) for x in norms+weights+biases}; weights.extend(x for x in model.parameters() if id(x) not in known)
    groups=[{'params':norms,'weight_decay':0.},{'params':weights,'weight_decay':.05 if kind=='adamw' else .0005},{'params':biases,'weight_decay':0.}]
    if kind=='sgd': optimizer=torch.optim.SGD(groups,lr=initial_lr,momentum=.9,nesterov=True)
    elif kind=='adam': optimizer=torch.optim.Adam(groups,lr=initial_lr,betas=(.9,.999))
    else: optimizer=torch.optim.AdamW(groups,lr=initial_lr)
    ema=copy.deepcopy(model).eval()
    for parameter in ema.parameters(): parameter.requires_grad_(False)
    train=loader(a.source,'train',a.model,a.batch,a.workers,True); val=loader(a.source,'val',a.model,a.batch,a.workers)
    start_epoch=0; best=-1.; checks_since_best=0; updates=0; elapsed_previous=0.
    if a.resume and (run/'last.pt').exists():
        checkpoint=torch.load(run/'last.pt',map_location=device,weights_only=False)
        assert checkpoint['config']['split_hashes']==split_hashes
        model.load_state_dict(checkpoint['model']); ema.load_state_dict(checkpoint['ema']); optimizer.load_state_dict(checkpoint['optimizer'])
        start_epoch=checkpoint['epoch']+1; best=checkpoint['best']; checks_since_best=checkpoint['checks_since_best']; updates=checkpoint['updates']; elapsed_previous=checkpoint['elapsed_seconds']
        random.setstate(checkpoint['rng_python']); np.random.set_state(checkpoint['rng_numpy']); torch.set_rng_state(checkpoint['rng_torch'].cpu()); torch.cuda.set_rng_state_all([r.cpu() for r in checkpoint['rng_cuda']])
    total_start=time.perf_counter(); stopped=False
    epoch=start_epoch-1
    checkpoint=None
    for epoch in range(start_epoch,a.epochs):
        tick=time.perf_counter(); model.train(); losses=[]; count=0
        progress=epoch/max(1,a.epochs-1); lr=initial_lr*(.01+.99*(1+math.cos(math.pi*progress))/2)
        if epoch<3: lr=initial_lr*(.1+.9*(epoch+1)/3)
        for group in optimizer.param_groups: group['lr']=lr
        for iteration,(images,targets,multi,indices,trans) in enumerate(train):
            images=images.to(device,non_blocking=True).float()/255; targets=[t.to(device,non_blocking=True) for t in targets]
            optimizer.zero_grad(set_to_none=True); loss=training_loss(a.model,model,criterion,images,targets,multi)
            if not torch.isfinite(loss): raise RuntimeError(f'Nonfinite loss at epoch {epoch+1}, batch {iteration}')
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),10.,error_if_nonfinite=True); optimizer.step(); updates+=1
            decay=.9999*(1-math.exp(-updates/2000))
            with torch.no_grad():
                model_state=model.state_dict()
                for k,v in ema.state_dict().items():
                    mv=model_state[k].detach()
                    if v.is_floating_point(): v.mul_(decay).add_(mv,alpha=1-decay)
                    else: v.copy_(mv)
            losses.append(float(loss.detach())); count+=len(images)
            if iteration%100==0: print(json.dumps({'epoch':epoch+1,'batch':iteration,'loss':losses[-1],'frames':count,'seconds':round(time.perf_counter()-tick,1)}),flush=True)
            if a.smoke and iteration>=1: break
        torch.cuda.synchronize(); train_seconds=time.perf_counter()-tick
        stat={'epoch':epoch+1,'train_loss':float(np.mean(losses)),'train_seconds':train_seconds,'train_frames':count,'updates':updates,'lr':lr}
        validate=a.smoke or (epoch+1)%a.val_interval==0 or epoch==a.epochs-1
        if validate:
            if a.smoke:
                from torch.utils.data import Subset
                # evaluate uses full dataset records; retain dataset identity while stopping iterator.
                class Limited:
                    dataset=val.dataset
                    def __iter__(self):
                        for i,b in enumerate(val):
                            if i>=2: break
                            yield b
                frames=evaluate(a.model,ema,Limited(),device,run/'smoke_inference.json')
            else: frames=evaluate(a.model,ema,val,device,run/'source_val_predictions.json')
            score=metrics(frames,.25)['AP50']; stat['source_val_AP50']=score
            if score>best:
                best=score; checks_since_best=0
                temp=run/'best.tmp'; torch.save({'model':ema.state_dict(),'epoch':epoch,'source_val_AP50':best,'config':config},temp); temp.replace(run/'best.pt')
                write_json(run/'source_threshold.json',{'threshold':select_threshold(frames),'epoch':epoch+1,'selected_on':a.source+'_val'})
            else: checks_since_best+=1
        stat['elapsed_seconds']=elapsed_previous+time.perf_counter()-total_start
        with (run/'history.jsonl').open('a',encoding='utf8') as file: file.write(json.dumps(stat)+'\n')
        checkpoint={'model':model.state_dict(),'ema':ema.state_dict(),'optimizer':optimizer.state_dict(),'epoch':epoch,'best':best,'checks_since_best':checks_since_best,'updates':updates,'elapsed_seconds':stat['elapsed_seconds'],'config':config,'rng_python':random.getstate(),'rng_numpy':np.random.get_state(),'rng_torch':torch.get_rng_state(),'rng_cuda':torch.cuda.get_rng_state_all()}
        temp=run/'last.tmp'; torch.save(checkpoint,temp); temp.replace(run/'last.pt')
        write_json(run/'status.json',{'status':'smoke_passed' if a.smoke else 'training','pid':os.getpid(),**stat})
        print(json.dumps(stat),flush=True)
        if a.smoke: return
        if epoch+1>=30 and checks_since_best>=a.patience: stopped=True; break
    best_state=torch.load(run/'best.pt',map_location=device,weights_only=False); ema.load_state_dict(best_state['model'])
    # Training loaders are no longer needed. Release their persistent workers before
    # the full four-domain evaluation to keep memory bounded on the laptop.
    for data_loader in (train,val):
        if data_loader._iterator is not None:
            data_loader._iterator._shutdown_workers()
            data_loader._iterator=None
    del train,val,checkpoint,optimizer,model
    threshold=json.loads((run/'source_threshold.json').read_text())['threshold']; results=[]
    for target in DOMAINS:
        test=loader(target,'test',a.model,a.batch,a.workers)
        frames=evaluate(a.model,ema,test,device,run/f'test_{target}_predictions.json')
        result={'model':a.model,'source':a.source,'target':target,'seed':a.seed,'best_epoch':best_state['epoch']+1,**metrics(frames,threshold,bootstrap=200)}
        by_group={g:metrics([f for f in frames if f['group']==g],threshold) for g in sorted({f['group'] for f in frames})}
        write_json(run/f'test_{target}_metrics.json',{'overall':result,'by_group':by_group}); results.append(result)
        print(json.dumps(result),flush=True)
        del test
    write_json(run/'results.json',results)
    write_json(run/'status.json',{'status':'completed','best_epoch':best_state['epoch']+1,'epochs_run':epoch+1,'early_stopped':stopped,'updates':updates,'elapsed_seconds':elapsed_previous+time.perf_counter()-total_start})

if __name__=='__main__': main()
