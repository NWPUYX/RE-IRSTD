"""Equivalent relative-statistics formula with controlled arithmetic precision."""
import torch
from irstd.models.relative_evidence import RelativeEvidenceEncoder
from irstd_adapter import model_config
from irstd_t_size.model import TSizeModel


class StableEvidence(RelativeEvidenceEncoder):
    def __init__(self,cfg,mode):
        super().__init__(cfg);assert mode in ['raw_IEEE','centered_IEEE'];self.mode=mode

    def forward(self,image,diagnostics=False):
        # A constant per-image subtraction leaves the intended annular residual,
        # variance, mean gradient and scale ratios unchanged in exact arithmetic.
        # The existing sigma floor and clipping remain in the parent encoder.
        previous=torch.backends.cudnn.conv.fp32_precision
        try:
            torch.backends.cudnn.conv.fp32_precision='ieee'
            with torch.autocast(device_type=image.device.type,enabled=False):
                value=image.float()
                if self.mode=='centered_IEEE':value=value-value.mean((-2,-1),keepdim=True)
                return super().forward(value,diagnostics)
        finally:torch.backends.cudnn.conv.fp32_precision=previous


class StableModel(TSizeModel):
    def __init__(self,recipe):
        super().__init__(recipe)
        self.evidence=StableEvidence(model_config()['model']['evidence'],recipe['evidence_arithmetic'])
