"""Transparent loader wrapper for bounded evaluation progress updates."""
from irstd_v2.settings import write_json,now


class ReportingLoader:
    def __init__(self,wrapped,path,target):
        self.wrapped=wrapped;self.path=path;self.target=target;self.dataset=wrapped.dataset

    def __len__(self):return len(self.wrapped)

    def __iter__(self):
        frames=0
        for index,batch in enumerate(self.wrapped):
            if index%25==0:
                write_json(self.path,{'status':'evaluating','target':self.target,'batch':index+1,'total_batches':len(self),
                    'frames_completed':frames,'total_frames':len(self.dataset),'updated_at':now()})
            yield batch
            frames+=len(batch[0])
