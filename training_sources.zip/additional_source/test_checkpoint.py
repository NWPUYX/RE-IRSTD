"""Full-domain inference QA of a frozen intermediate SOURCE-selected checkpoint.
Results are explicitly interim and never enter the final benchmark table.
"""
import os, json, shutil, argparse, hashlib, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'cache/matplotlib'))
import torch
from model_adapter import build
from train_public import DOMAINS,loader,write_json
from evaluation import evaluate,metrics
def main():
    p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--source',required=True);p.add_argument('--seed',type=int,default=3407);a=p.parse_args()
    torch.set_num_threads(8)
    run=ROOT/'runs'/a.model/a.source/f'seed_{a.seed}'
    # Read threshold and checkpoint into an immutable copy before evaluating targets.
    checkpoint=torch.load(run/'best.pt',map_location='cpu',weights_only=False)
    threshold=json.loads((run/'source_threshold.json').read_text())
    assert threshold['epoch']==checkpoint['epoch']+1
    out=ROOT/'stage_evaluation'/f'{a.model}_{a.source}_seed{a.seed}_epoch{threshold["epoch"]}';out.mkdir(parents=True,exist_ok=True)
    torch.save(checkpoint,out/'source_selected_checkpoint.pt')
    write_json(out/'source_threshold.json',threshold)
    code_hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['model_adapter.py','data_pipeline.py','evaluation.py','train_public.py','test_checkpoint.py']}
    write_json(out/'protocol_snapshot.json',{'kind':'intermediate checkpoint pipeline validation; NOT final benchmark','epoch':threshold['epoch'],'source_val_AP50':checkpoint['source_val_AP50'],'threshold_selected_on':threshold['selected_on'],'code_sha256':code_hashes,'target_predictions_will_not_change_training_configuration':True})
    model,criterion=build(a.model);model.cuda();model.load_state_dict(checkpoint['model']);del checkpoint,criterion
    results=[];start=time.perf_counter()
    for domain in DOMAINS:
        gen=loader(domain,'test',a.model,4,0)
        frames=evaluate(a.model,model,gen,'cuda',out/f'{domain}_predictions.json')
        result={'model':a.model,'source':a.source,'target':domain,'seed':a.seed,'epoch':threshold['epoch'],'kind':'interim; training still running',**metrics(frames,threshold['threshold'],bootstrap=200)}
        write_json(out/f'{domain}_metrics.json',result);results.append(result)
        print(json.dumps(result,ensure_ascii=False),flush=True)
        del gen,frames
    write_json(out/'results.json',results)
    text=['# 阶段性完整测试：不是最终实验结果','',f'[COMPUTED｜HIGH] {a.model}，训练源 {a.source}，种子 {a.seed}，源验证选出的第 {threshold["epoch"]} 轮 checkpoint。正式训练仍在继续；这些目标结果不用于修改训练或选模策略。',
          '',f'[COMPUTED｜HIGH] 同一阈值 {threshold["threshold"]:.6f}，仅由源验证集确定。所有测试帧均已评测。','',
          '| 测试域 | 测试帧 | AP50% | AP50:95% | F1% | FP/frame |','|---|---:|---:|---:|---:|---:|']
    for r in results:text.append(f'| {r["target"]} | {r["frames"]} | {r["AP50"]*100:.2f} | {r["AP50_95"]*100:.2f} | {r["F1"]*100:.2f} | {r["FP_per_frame"]:.4f} |')
    text+=['','[INFERRED｜HIGH] 此表只验证完整跨域评测流程并展示中途实测；不能作为三种子最终比较、八模型排名或 Tiny 场景／设备泛化结论。']
    (out/'阶段性测试结果表.md').write_text('\n'.join(text),encoding='utf8')
    print('Full interim evaluation completed in seconds',time.perf_counter()-start)
if __name__=='__main__':main()
