import json, re, random
from pathlib import Path
from functools import lru_cache
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
ROOT=Path(__file__).resolve().parent
SIZE=512

@lru_cache(maxsize=512)
def load_frame(path):
    with Image.open(path) as image:
        image=image.convert('RGB'); w,h=image.size
        ratio=min(SIZE/w,SIZE/h); nw,nh=int(w*ratio),int(h*ratio)
        dx,dy=(SIZE-nw)//2,(SIZE-nh)//2
        canvas=Image.new('RGB',(SIZE,SIZE),(128,128,128))
        canvas.paste(image.resize((nw,nh),Image.Resampling.BICUBIC),(dx,dy))
        return np.array(canvas), (nw/w,nh/h,dx,dy)

class VideoData(Dataset):
    def __init__(self,domain,split,model,train=False):
        self.records=json.loads((ROOT/'splits'/f'{domain}_{split}.json').read_text(encoding='utf8'))
        self.model=model; self.train=train; self.windows=[]
        groups={}
        for i,r in enumerate(self.records): groups.setdefault(r['group'],[]).append(i)
        for i,r in enumerate(self.records):
            ids=groups[r['group']]; position=ids.index(i); start=position
            # Reset at the first available frame or a numerical gap.
            while start>max(0,position-4):
                a,b=(int(re.findall(r'\d+',Path(self.records[ids[k]]['path']).stem)[-1]) for k in (start-1,start))
                if b!=a+1: break
                start-=1
            self.windows.append([ids[max(start,position-4+k)] for k in range(5)])
            assert all(self.records[j]['group']==r['group'] for j in self.windows[-1])

    def __len__(self): return len(self.records)
    def __getitem__(self,index):
        indices=[index] if self.model=='AA-YOLO' else self.windows[index]
        frames=[]; annotations=[]; trans=None
        flip=self.train and random.random()<.5
        for j in indices:
            r=self.records[j]; array,trans=load_frame(r['path']); sx,sy,dx,dy=trans
            boxes=np.array(r['boxes'],dtype=np.float32).reshape(-1,4).copy()
            if len(boxes):
                boxes[:,0]=boxes[:,0]*sx+dx; boxes[:,1]=boxes[:,1]*sy+dy
                boxes[:,2]*=sx; boxes[:,3]*=sy
                if flip: boxes[:,0]=SIZE-boxes[:,0]-boxes[:,2]
            frames.append(array[:,::-1].copy() if flip else array)
            annotations.append(boxes)
        target=annotations[-1].copy()
        if len(target): target[:,:2]+=target[:,2:]/2
        target=np.concatenate((target,np.zeros((len(target),1),dtype=np.float32)),axis=1)
        if self.model=='AA-YOLO': x=np.transpose(frames[0],(2,0,1)).copy()
        else: x=np.transpose(np.stack(frames),(3,0,1,2)).copy()
        return torch.from_numpy(x), torch.from_numpy(target), annotations, index, trans

def collate(batch):
    images,targets,multi,ids,trans=zip(*batch)
    n=max((len(boxes) for sample in multi for boxes in sample),default=0)
    padded=np.zeros((len(batch),len(multi[0]),max(1,n),5),dtype=np.float32)
    for b,sample in enumerate(multi):
        for t,boxes in enumerate(sample): padded[b,t,:len(boxes),:4]=boxes
    return torch.stack(images), list(targets), padded, list(ids), list(trans)

def worker_seed(worker_id):
    seed=torch.initial_seed()%2**32; random.seed(seed); np.random.seed(seed)
