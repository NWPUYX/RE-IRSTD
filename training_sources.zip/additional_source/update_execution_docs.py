from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parent
statuses={
 'CHAL':'[COMPUTED｜HIGH] 已下载；官方快照缺少 nets/module/CBAM.py，导入失败；正式训练暂缓。',
 'TDCNet':'[COMPUTED｜HIGH] 已下载；随机初始化前向／反向通过；待确定无外部预训练条件下的背景配准方式，尚未正式训练。',
 'S2MVP':'[COMPUTED｜HIGH] 已下载；缺少 mmcv._ext；当前 DAUB 配置是 SoftTeacher＋Faster R-CNN，完整论文配置尚待核验；未正式训练。',
 'STMENet':'[COMPUTED｜HIGH] 已下载；真实数据训练／推理检查通过；随机初始化公开 4×4 正式训练队列已启动。',
 'Tridos':'[COMPUTED｜HIGH] 已下载；真实数据训练／推理检查通过；随机初始化公开 4×4 正式训练已入队。',
 'SSTNet':'[COMPUTED｜HIGH] 已下载；真实数据训练／推理检查通过，保留 motion_loss；随机初始化公开 4×4 正式训练已入队。',
 'LASNet（DMIST 基线）':'[COMPUTED｜HIGH] 已下载；真实数据训练／推理检查通过；辅助标签归一化255→1，保留结构与IoU损失；公开4×4正式训练已入队（明确标注修正）。',
 'AA-YOLO':'[COMPUTED｜HIGH] 已下载；官方 AA-yolov7-tiny＋AA/OTA 损失真实数据检查通过；scratch 公开 4×4 正式训练已入队。'}
path=ROOT/'comparators.md'; lines=[]
for line in path.read_text(encoding='utf8').splitlines():
    parts=line.split('|')
    if len(parts)>6 and parts[1].strip() in statuses:
        parts[-2]=' '+statuses[parts[1].strip()]+' '; line='|'.join(parts)
    lines.append(line)
path.write_text('\n'.join(lines)+'\n',encoding='utf8')
for path in [ROOT/'实验方案.md',ROOT.parent/'scene_generalization_audit/场景泛化实验方案.md']:
    text=path.read_text(encoding='utf8')
    text=re.sub(r'\[INFERRED · HIGH\] Tiny-UAV-IR 可作为额外外部目标列：[^\n]+', '[INFERRED · HIGH] 本轮公开实验仅执行上述4×4矩阵，不添加Tiny-UAV-IR外部测试列；Tiny的内部场景／探测器实验单独报告。',text)
    text=re.sub(r'\[INFERRED · HIGH\] 分割分支：[^\n]+','[INFERRED · HIGH] 本轮使用检测框任务，不执行MIST与NUDT-MIRSDT的2×2分割分支。',text)
    marker='## 运行前内容哈希复核补充（2026-10-01）'
    if marker not in text:
        text+='\n\n'+marker+'\n\n[COMPUTED · HIGH] 进一步发现1800组跨划分相同文件：DAUB-R data5/data12、data6/data11；IRDST-H 31/42、39/41；ITSDT-15K 18/19。原始目录ID互斥不足以保证数据独立。正式训练清单保守排除相关训练／验证整组，共4131帧，保留冻结测试集。修正后的划分、模型执行条件和当前状态以 [执行协议](../Scenario_adaptability/执行协议.md) 为准；原始文件与原始统计未改动。\n'
    assert '6×6' not in text
    path.write_text(text,encoding='utf8')
print('Updated model execution status and public-only 4x4 protocol')
