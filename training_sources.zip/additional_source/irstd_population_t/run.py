"""At most two T/fusion/head epochs after source-only locality calibration."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
from collections import Counter
import copy
import json
import math
from pathlib import Path
import random
import shutil
import time
import traceback
import numpy as np
import torch
from irstd_stable_robust.data import training_loader
from irstd_t_feature_consistency.run import losses as feature_losses
from .model import PopulationTModel
from irstd_robust_t.run import sha,mechanisms,gates as original_gates
from irstd_robust_t.probe import extreme_probe
from irstd_adapter import model_config
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint,rng_state,restore_rng
from irstd_geometry_balance.run import probe
from irstd_background_center.run import background_diagnostic
from irstd_noise_center.data import validation_loader
from benchmark_progress import ReportingLoader
from benchmark_center_metrics import center_metrics
from evaluation import metrics
import benchmark_fastdecode as fast

ROOT=Path(__file__).resolve().parents[1]
RESEARCH=ROOT/'experiments/IRSTD_research_20261107'
PARENT=RESEARCH/'robust_T_composed_v1'
HOME=RESEARCH/'population_T_correspondence_v1'
CALIBRATED=RESEARCH/'population_T_source_screen_v1/calibrated.pt'
PREFIXES=('backbone.target_path.','backbone.final.','heads.')


def losses(*args,**kwargs):
    loss,terms=feature_losses(*args,**kwargs)
    return loss,terms,None


def recipe(parent):
    return {**parent['config']['recipe'],'name':HOME.name,'epochs':2,
        'initialization':'source-calibrated T_only; zero-update screen failed noise F1; initialization only',
        'evidence_arithmetic':'original','teacher_model':'PopulationTModel_T_only_fixed_initialization',
        'population_norm_mode':'T_only','population_moments_frozen':True,
        'learning_rates':{'T_fusion_center_aux':2e-5,'offset_size':1e-4},
        'trainable_prefixes':list(PREFIXES),'geometry_regression_weight':4.,
        'native_T_local_weight':1.,'paired_T_local_weight':1.,'native_T_global_weight':.05,'T_channel_RMS_floor':.25,
        'normalization_gamma_bias_weight_decay':0.,'ordinary_weight_decay':.0005,
        'augmentation_mix':'one-third noise, one-third background+noise, one-third clean geometry',
        'selection':'all_source_gates_then_number_of_gates_then_source_AP50',
        'maximum_validation_checks':2}


def construct(cfg,state,device):
    model=PopulationTModel(cfg).to(device);model.load_state_dict(state,strict=True);model.set_mode(final=False)
    for n,p in model.named_parameters():p.requires_grad_(n.startswith(PREFIXES))
    assert sum(p.numel() for p in model.parameters())==808952
    assert sum(p.numel() for p in model.parameters() if p.requires_grad)==23252
    exempt={id(p) for module in model.modules() if isinstance(module,torch.nn.GroupNorm) for p in module.parameters(recurse=False)}
    exempt.update(id(p) for n,p in model.named_parameters() if n.endswith(('.bias','.gamma')))
    groups={}
    for n,p in model.named_parameters():
        if not p.requires_grad:continue
        lr=1e-4 if n.startswith(('heads.offset.','heads.size.')) else 2e-5
        wd=0. if id(p) in exempt else .0005;groups.setdefault((lr,wd),[]).append(p)
    opt=torch.optim.AdamW([{'params':v,'lr':lr,'weight_decay':wd} for (lr,wd),v in groups.items()],betas=tuple(model_config()['train']['betas']))
    assert all(g['weight_decay']==0. for g in opt.param_groups for p in g['params'] if id(p) in exempt)
    teacher=PopulationTModel(cfg).to(device);teacher.load_state_dict(state);teacher.set_mode(final=False);teacher.eval()
    for p in teacher.parameters():p.requires_grad_(False)
    return model,teacher,opt


def buffers_unchanged(model,state):
    for n,v in model.named_buffers():assert torch.equal(v.cpu(),state[n]),n


def frozen_context(model,state):
    for n,v in model.state_dict().items():
        if not n.startswith(PREFIXES):assert torch.equal(v.cpu(),state[n]),n
    buffers_unchanged(model,state)


@torch.inference_mode()
def locality_probe(model,cfg,device):
    from irstd_background_center.data import loader as background_pairs
    errors=[]
    for images,samples in background_pairs(cfg,'val'):
        saved=[];handle=model.backbone.target_path.register_forward_hook(lambda m,args,value:saved.append(value))
        try:model(images.to(device))
        finally:handle.remove()
        n=len(samples)//2
        for b in range(n):
            x,y=((samples[b]['boxes'][0,:2]+samples[b]['boxes'][0,2:])/2).floor().long().tolist()
            errors.append(float((saved[0][b,:,y,x]-saved[0][b+n,:,y,x]).square().mean()))
    assert len(errors)==24
    return float(np.mean(errors))


def gates(row,parent,baseline):
    result=original_gates(row,parent,baseline)
    result['T_population_locality']=row['T_pair_MSE']<=1e-10
    return result


def row_key(row):
    return (all(row['gates'].values()),sum(row['gates'].values()),row['source_validation']['pooled']['AP50'])


def validate(model,cfg,reference,device,epoch,parent,binding):
    manifest=HOME/f'epoch_{epoch:02d}_prediction_manifest.json'
    if manifest.exists():assert json.loads(manifest.read_text(encoding='utf-8'))==binding
    else:write_json(manifest,binding)
    path=HOME/f'epoch_{epoch:02d}_predictions.json'
    frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,
        ReportingLoader(make_loader('DAUB-R','val',cfg),HOME/'progress.json','source_val'),device,reference,path)
    write_json(HOME/'progress.json',{'status':'source_validation','epoch':epoch,'phase':'controlled diagnostics','updated_at':now()})
    geom,per_scale=probe(model,cfg,reference,device)
    row={'epoch':epoch,'source_validation':validation_summary(frames),'geometry_probe':geom,'per_scale':per_scale,
        'background':background_diagnostic(model,cfg,reference,device,HOME,f'epoch_{epoch:02d}'),'noise':{},
        'extreme_geometry':extreme_probe(model,cfg,reference,device)}
    for factor in [4,16]:
        path=HOME/f'epoch_{epoch:02d}_noise{factor}_predictions.json'
        frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,validation_loader(cfg,factor),device,reference,path)
        row['noise'][str(factor)]={'box':metrics(frames,row['source_validation']['threshold']),
            'center':center_metrics(frames,row['source_validation']['threshold'])}
    baseline=json.loads((RESEARCH/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    row['T_pair_MSE']=locality_probe(model,cfg,device)
    row['gates']=gates(row,parent,baseline);return row


def main():
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--resume',action='store_true');a=p.parse_args()
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    assert torch.backends.cudnn.conv.fp32_precision=='tf32'
    if (HOME/'training_complete.json').exists() and not a.check:return
    random.seed(3407);np.random.seed(3407);torch.manual_seed(3407);torch.cuda.manual_seed_all(3407)
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False);cfg=recipe(parent)
    initialization=torch.load(CALIBRATED,map_location='cpu',weights_only=False)
    initial=initialization['model']
    assert initialization['config']['checkpoint_sha256']==sha(PARENT/'best.pt')
    assert initialization['config']['model_module_sha256']==sha(Path(__file__).parent/'model.py')
    assert all(torch.equal(v,initial[n]) for n,v in parent['model'].items())
    proof=json.loads((PARENT/'independent_audit.json').read_text(encoding='utf-8'));assert proof['passed'] and proof['checkpoint_sha256']==sha(PARENT/'best.pt')
    files=[*Path(__file__).parent.glob('*.py'),*(ROOT/'irstd_stable_robust').glob('*.py'),
        *(ROOT/'irstd_t_feature_consistency').glob('*.py')]
    identity={**parent['config'],'recipe':cfg,'parent_sha256':sha(PARENT/'best.pt'),
        'source_hashes':{**parent['config']['source_hashes'],**{str(f.relative_to(ROOT.parent)):sha(f) for f in files}},
        'calibration_checkpoint_sha256':sha(CALIBRATED),
        'diagnostic_hashes':{**parent['config']['diagnostic_hashes'],
            **{str(p.relative_to(ROOT.parent)):sha(p) for p in [RESEARCH/'source_locality_audit_v1/result.json',RESEARCH/'population_T_source_screen_v1/result.json']}}}
    assert split_hashes()==identity['split_hashes']
    for n,digest in {**identity['source_hashes'],**identity['diagnostic_hashes']}.items():assert sha(ROOT.parent/n)==digest,n
    fast.install();device=torch.device('cuda');reference=identity['size_reference_512'];model,teacher,opt=construct(cfg,initial,device)
    if a.check:
        from irstd_background_center.data import collate_pairs
        data=training_loader(cfg);data.dataset.epoch=1;seen=[]
        for indices in [[0,1],[2,4],[6,8]]:
            images,samples=collate_pairs([data.dataset[i] for i in indices]);seen.extend(s['view_type'] for s in samples[2:])
            assert all('noise_factor' not in s for s in samples if s['view_type'] in ['shrink','enlarge'])
            opt.zero_grad(set_to_none=True);model.eval();loss,terms,_=losses(model,teacher,images,samples,reference,cfg,device);loss.backward()
            assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad)
            assert all(p.grad is None for p in model.parameters() if not p.requires_grad)
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10.,error_if_nonfinite=True);opt.step();frozen_context(model,initial);mechanisms(model)
        assert all(int(v['step'])==3 for v in opt.state.values()) and len(opt.state)==sum(p.requires_grad for p in model.parameters())
        assert any(not torch.equal(v.cpu(),initial[n]) for n,v in model.state_dict().items() if n.startswith('backbone.target_path.'))
        assert all(torch.equal(v.cpu(),initial[n]) for n,v in teacher.state_dict().items())
        assert locality_probe(model,cfg,device)<=1e-10
        assert torch.backends.cudnn.conv.fp32_precision=='tf32'
        save_checkpoint(HOME/'preflight_step.pt',{'model':model.state_dict(),'optimizer':opt.state_dict()})
        saved=torch.load(HOME/'preflight_step.pt',map_location='cpu',weights_only=False);restored,_,_=construct(cfg,saved['model'],device)
        with torch.no_grad():before=model(images.to(device));after=restored(images.to(device))
        assert all(torch.equal(v,after[n]) for n,v in before.items())
        write_json(HOME/'preflight.json',{'passed':True,'identity':identity,'trainable_parameters':23252,'optimizer_steps':3,
            'all_gradients_finite':True,'context_frozen':True,'buffers_unchanged':True,'population_teacher_unchanged':True,
            'normalization_gamma_bias_decay_zero':True,'clean_geometry_checked':True,'save_reload_exact':True,'view_types':seen,'updated_at':now()});return
    assert json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))['identity']==identity
    if (HOME/'config.json').exists():assert a.resume and json.loads((HOME/'config.json').read_text(encoding='utf-8'))==identity
    write_json(HOME/'config.json',identity);write_json(HOME/'recipe.json',cfg);write_json(HOME/'process.json',{'pid':os.getpid(),'updated_at':now()})
    ema=copy.deepcopy(model).eval()
    for p in ema.parameters():p.requires_grad_(False)
    updates=0;completed_training=0;best=None
    try:
        if a.resume and (HOME/'last.pt').exists():
            s=torch.load(HOME/'last.pt',map_location='cpu',weights_only=False);assert s['config']==identity
            model.load_state_dict(s['model']);ema.load_state_dict(s['ema']);opt.load_state_dict(copy.deepcopy(s['optimizer']));restore_rng(s['rng'])
            updates=s['updates'];completed_training=s['epoch']
        if (HOME/'best.pt').exists():best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
        rows=[]
        for epoch in [1,2]:
            rowpath=HOME/f'epoch_{epoch:02d}_row.json'
            if rowpath.exists():
                row=json.loads(rowpath.read_text(encoding='utf-8'));rows.append(row)
                if all(row['gates'].values()):break
                continue
            if completed_training<epoch:
                train=training_loader(cfg);train.dataset.epoch=epoch;train.generator.manual_seed(3407+epoch*1000003)
                views=Counter();tick=time.perf_counter()
                for j,(images,samples) in enumerate(train):
                    model.eval();opt.zero_grad(set_to_none=True);loss,terms,_=losses(model,teacher,images,samples,reference,cfg,device)
                    loss.backward();torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10.,error_if_nonfinite=True);opt.step();updates+=1
                    decay=.9999*(1-math.exp(-updates/2000))
                    with torch.no_grad():
                        for x,y in zip(ema.parameters(),model.parameters()):
                            if y.requires_grad:x.mul_(decay).add_(y,alpha=1-decay)
                    views.update(s['view_type'] for s in samples)
                    if j%100==0:
                        r={'status':'training','epoch':epoch,'batch':j+1,'total_batches':len(train),'updates':updates,'view_counts':dict(views),'loss_terms':terms,'updated_at':now()}
                        write_json(HOME/'progress.json',r);print(json.dumps(r),flush=True)
                assert sum(views.values())==8362 and views['native']==4181 and updates==epoch*2091
                frozen_context(model,initial);frozen_context(ema,initial);mechanisms(model);mechanisms(ema)
                assert all(int(v['step'])==updates for v in opt.state.values())
                state={'model':model.state_dict(),'ema':ema.state_dict(),'optimizer':opt.state_dict(),'config':identity,
                    'updates':updates,'epoch':epoch,'rng':rng_state(),'view_counts':dict(views),'train_seconds':time.perf_counter()-tick}
                save_checkpoint(HOME/f'epoch_{epoch:02d}_training.pt',state);shutil.copyfile(HOME/f'epoch_{epoch:02d}_training.pt',HOME/'last.pt');completed_training=epoch
            assert completed_training==epoch
            row=validate(ema,cfg,reference,device,epoch,parent,{'trained_checkpoint_sha256':sha(HOME/f'epoch_{epoch:02d}_training.pt')})
            row['updates']=updates
            cp={**row,'model':ema.state_dict(),'config':identity};save_checkpoint(HOME/f'epoch_{epoch:02d}_ema.pt',cp)
            if best is None or row_key(row)>row_key(best):
                save_checkpoint(HOME/'best.pt',cp);shutil.copyfile(HOME/f'epoch_{epoch:02d}_predictions.json',HOME/'best_source_val_predictions.json')
                best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
            write_json(rowpath,row);rows.append(row)
            (HOME/'history.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows),encoding='utf-8')
            for n,digest in {**identity['source_hashes'],**identity['diagnostic_hashes']}.items():assert sha(ROOT.parent/n)==digest,n
            print(json.dumps({'validated_epoch':epoch,'gates':row['gates']}),flush=True)
            if all(row['gates'].values()):break
        done={'status':'completed','promotion_passed':all(best['gates'].values()),'best_epoch':best['epoch'],
            'gates':best['gates'],'epochs_run':completed_training,'updates':updates,'target_test_cells':0,'updated_at':now()}
        write_json(HOME/'training_complete.json',done);write_json(HOME/'progress.json',done);print(json.dumps(done),flush=True)
    except Exception:write_json(HOME/'failure.json',{'traceback':traceback.format_exc(),'updated_at':now()});raise


if __name__=='__main__':main()
