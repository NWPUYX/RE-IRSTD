"""Source-calibrated local normalization for the existing T path."""
