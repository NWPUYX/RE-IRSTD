import argparse,json,time,traceback
import torch
from model_adapter import build,training_loss,ROOT
from data_pipeline import VideoData,collate
p=argparse.ArgumentParser();p.add_argument('model');a=p.parse_args()
torch.set_num_threads(8);torch.manual_seed(3407);model,criterion=build(a.model);model.cuda().train()
if hasattr(criterion,'cuda'):criterion.cuda()
torch.cuda.empty_cache=lambda:None
d=VideoData('ITSDT-15K','train',a.model);x,y,m,ids,tr=collate([d[i] for i in [0,40,80,120]])
x=x.cuda().float()/255;y=[t.cuda() for t in y];opt=torch.optim.SGD(model.parameters(),lr=1e-4)
out={'model':a.model,'kind':'precision and runtime check; not benchmark accuracy','batch':4}
try:
    for precision in ['float32','bfloat16']:
        seconds=[];losses=[]
        for i in range(4):
            torch.cuda.synchronize();tick=time.perf_counter();opt.zero_grad(set_to_none=True)
            loss=training_loss(a.model,model,criterion,x,y,m,amp=precision=='bfloat16');assert torch.isfinite(loss)
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),10.,error_if_nonfinite=True);opt.step();torch.cuda.synchronize()
            seconds.append(time.perf_counter()-tick);losses.append(float(loss.detach()))
        out[precision]={'median_step_seconds':sorted(seconds[1:])[1],'losses':losses}
    out['status']='passed'
except Exception:out['status']='failed';out['error']=traceback.format_exc()
(ROOT/'execution_checks'/f'{a.model}_precision.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps(out,indent=2))
