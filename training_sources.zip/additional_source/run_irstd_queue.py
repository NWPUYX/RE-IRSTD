"""Durable serial queue for 12 IRSTD trainings and 48 frozen-domain results."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone, timedelta
from summarize_results import summarize, DOMAINS, SEEDS
from summarize_irstd import summarize as summarize_irstd

ROOT = Path(__file__).resolve().parent


def write(value):
    value["updated_at"] = datetime.now(timezone(timedelta(hours=8))).isoformat(timespec="seconds")
    path = ROOT / "irstd_queue_status.json"
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def main():
    import msvcrt
    lock = (ROOT / "irstd_queue.lock").open("a+b")
    lock.seek(0)
    if not lock.read(1):
        lock.write(b"1")
        lock.flush()
    lock.seek(0)
    try:
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        raise SystemExit("An IRSTD queue already holds the exclusive lock")
    # Keep lock alive until this queue exits; stale PIDs cannot create duplicates.
    started = time.time()
    jobs = [(source, seed) for seed in SEEDS for source in DOMAINS]
    for source, seed in jobs:
        run = ROOT / "runs" / "IRSTD" / source / f"seed_{seed}"
        if (run / "results.json").exists():
            continue
        run.mkdir(parents=True, exist_ok=True)
        summarize()
        complete = summarize_irstd()
        write({"status": "running", "pid": os.getpid(), "active": {"model": "IRSTD", "source": source, "seed": seed},
               "completed_irstd_result_cells": complete, "total_irstd_result_cells": 48, "training_jobs": 12,
               "collision_policy": "shared_regression (user confirmed)", "started_unix": started})
        command = [sys.executable, str(ROOT / "train_irstd.py"), "--source", source, "--seed", str(seed),
                   "--resume", "--center-collision-policy", "shared_regression"]
        with (run / "console.log").open("a", encoding="utf-8") as stream:
            process = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                       env={**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1"},
                                       creationflags=subprocess.CREATE_NO_WINDOW)
            status = json.loads((ROOT / "irstd_queue_status.json").read_text(encoding="utf-8"))
            write({**status, "active_process_id": process.pid})
            code = process.wait()
        if code:
            write({"status": "failed", "pid": os.getpid(), "active": {"source": source, "seed": seed},
                   "exit_code": code, "log": str(run / "console.log"), "completed_irstd_result_cells": summarize_irstd()})
            return
        summarize()
        summarize_irstd()
    write({"status": "completed", "pid": os.getpid(), "completed_irstd_result_cells": summarize_irstd(),
           "training_jobs": 12, "elapsed_seconds": time.time() - started})
    summarize()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        write({"status": "failed", "error": traceback.format_exc()})
        raise
