"""Autonomous local experiment: three-epoch T-size readout pilot."""
import os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG",":4096:8")
import argparse
from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import shutil
import sys
import time
import traceback
import torch
from irstd_adapter import model_config
from irstd_v2.model import Model
from irstd_geometry_balance.data import training_loader
from irstd_geometry_balance.run import probe, gates, candidate_key, previous_key
from irstd_geometry_repair.run import loss_for, ap_key
from irstd_replay.run import ranking_summary
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate, validation_summary
from irstd_v2.settings import split_hashes, write_json, now
from irstd_v2.train import save_checkpoint, rng_state, restore_rng
from .model import TSizeModel, initialize, optimizer

ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT / "experiments/IRSTD_v2/v1_geometry_balanced_direction_2epoch_v1"
START=PARENT / "epoch_05_ema.pt"
HOME=ROOT / "experiments/IRSTD_research_20261107/t_size_route_v1"
SOURCE,SEED="DAUB-R",3407


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def recipe():
    cfg=json.loads((PARENT / "recipe.json").read_text(encoding="utf-8"))
    cfg.update(name="t_size_route_v1",epochs=3,additional_epochs=3,parent_epochs=0,
        initialization="parent_epoch5_EMA; size output reset to source reference; optimizer fresh",
        trainable_prefixes=["heads.size."],size_feature_source="T",maximum_validation_checks=3)
    return cfg


def fingerprints():
    expected=json.loads((PARENT / "config.json").read_text(encoding="utf-8"))["source_hashes"]
    current={k:sha(ROOT.parent/k) for k in expected}; assert current==expected
    current.update({str(p.relative_to(ROOT.parent)):sha(p) for p in Path(__file__).parent.glob("*.py")})
    return current


def frozen_equal(model,initial):
    for name,value in model.state_dict().items():
        if not name.startswith("heads.size."): assert torch.equal(value.detach().cpu(),initial[name]),name


def construct(cfg,state,device,reset=True):
    model=TSizeModel(cfg).to(device); initialize(model,state,reset)
    return model,optimizer(model,cfg)


def smoke(cfg,state,reference,device,identity):
    folder=HOME/"checks"; folder.mkdir(parents=True,exist_ok=True)
    model,opt=construct(cfg,state,device); initial={k:v.cpu().clone() for k,v in model.state_dict().items()}
    ordinary=Model(cfg).to(device).eval(); ordinary.load_state_dict(state)
    loader=training_loader(SOURCE,cfg,SEED); loader.dataset.epoch=5
    images,samples=next(iter(loader)); model.eval()
    with torch.no_grad(): old=ordinary(images.to(device)); before=model(images.to(device))
    for key in ("center_logits","offsets","auxiliary_center_logits"): assert torch.equal(old[key],before[key])
    assert torch.count_nonzero(before["log_size"])==0
    opt.zero_grad(set_to_none=True)
    _,terms,_=loss_for(model,images,samples,reference,cfg,device)
    loss=model_config()["loss"]["size_weight"]*terms["size"]+cfg["giou_weight"]*terms["giou"]
    loss.backward()
    assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith("heads.size."))
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.heads.size.parameters())
    torch.nn.utils.clip_grad_norm_(model.heads.size.parameters(),10.,error_if_nonfinite=True); opt.step()
    frozen_equal(model,initial)
    with torch.no_grad(): after=model(images.to(device))
    for key in ("center_logits","offsets","auxiliary_center_logits"): assert torch.equal(before[key],after[key])
    assert not torch.equal(before["log_size"],after["log_size"])
    save_checkpoint(folder/"smoke.pt",{"model":model.state_dict(),"optimizer":opt.state_dict()})
    saved=torch.load(folder/"smoke.pt",map_location="cpu",weights_only=False)
    restored,loaded=construct(cfg,saved["model"],device,reset=False); loaded.load_state_dict(saved["optimizer"])
    restored.eval()
    with torch.no_grad(): again=restored(images.to(device))
    assert all(torch.equal(again[k],v) for k,v in after.items())
    write_json(folder/"preflight.json",{"passed":True,"identity":identity,"trainable_parameters":5258,"total_parameters":808952,
        "center_offset_aux_bitwise_equal_to_parent":True,"zero_log_size_initialization":True,"only_size_gradients":True,
        "frozen_state_bitwise_equal":True,"save_reload_bitwise_equal":True,"updated_at":now()})
    print(json.dumps({"smoke_passed":True,"trainable_parameters":5258}),flush=True)


def report():
    best=torch.load(HOME/"best.pt",map_location="cpu",weights_only=False)
    original,review=gates(best)
    result={"original_gates_passed":all(original.values()),"passed":all(original.values()) and review,
        "gates":original,"enlarge_review_passed":review,"candidate":{k:best[k] for k in ("epoch","source_validation","geometry_probe","per_scale","ranking")},
        "scope":"source validation; target tests not used","updated_at":now()}
    write_json(HOME/"promotion.json",result)
    rows=[json.loads(s) for s in (HOME/"history.jsonl").read_text(encoding="utf-8").splitlines()]
    lines=["# T特征尺寸头路由实验","",f"[KNOWN｜HIGH] 更新时间：{now()}；仅DAUB-R/3407源验证。",
        "","[KNOWN｜HIGH] 父第5轮EMA初始化；尺寸末层清零以源训练中位尺寸起步；仅训练尺寸头5258参数，其他分支冻结，总参数808952；FP32/batch4，2原始+1缩小+1放大，学习率1e-4。",
        "","| 本轮轮数 | 组宏AP50 | pooled AP50 | pooled AP50:95 | data22 AP50:95 | 尺寸误差 | 缩小误差 | 放大误差 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for row in rows:
        v=row["source_validation"]
        lines.append(f"| {row['epoch']} | {v['group_macro_AP50']*100:.4f}% | {v['pooled']['AP50']*100:.4f}% | {v['pooled']['AP50_95']*100:.4f}% | {v['by_group']['data22']['AP50_95']*100:.4f}% | {row['geometry_probe']['log_size_error']:.6f} | {row['per_scale']['0.6']['log_size_error']:.6f} | {row['per_scale']['1.4']['log_size_error']:.6f} |")
    lines += ["",f"[COMPUTED｜HIGH] 最佳候选第{best['epoch']}轮，原三项{'通过' if result['original_gates_passed'] else '未通过'}，放大保护{'通过' if review else '未通过'}。",
        "","[KNOWN｜HIGH] 尺寸输入路由发生改变；原中心/偏移输出保持，创新核心结构与参数量不变。本轮为候选诊断，不是跨域成绩。"]
    (HOME/"结果与进度.md").write_text("\n".join(lines),encoding="utf-8")
    return result


def run(check=False,resume=False):
    torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED); torch.backends.cudnn.benchmark=False
    cfg,device=recipe(),torch.device("cuda")
    parent=torch.load(START,map_location="cpu",weights_only=False); reference=parent["config"]["size_reference_512"]
    assert split_hashes()==parent["config"]["split_hashes"]
    identity={"source_hashes":fingerprints(),"split_hashes":split_hashes(),"checkpoint_sha256":sha(START),"recipe":cfg}
    if check: smoke(cfg,parent["model"],reference,device,identity); return
    preflight=json.loads((HOME/"checks/preflight.json").read_text(encoding="utf-8")); assert preflight["passed"] and preflight["identity"]==identity
    config={**identity,"source":SOURCE,"seed":SEED,"size_reference_512":reference,"initial_checkpoint":str(START)}
    if (HOME/"config.json").exists():
        if not resume or json.loads((HOME/"config.json").read_text(encoding="utf-8"))!=config: raise ValueError("Identical --resume required")
    if (HOME/"training_complete.json").exists(): return
    write_json(HOME/"config.json",config); write_json(HOME/"recipe.json",cfg)
    snapshot=HOME/"source_snapshot"; snapshot.mkdir(exist_ok=True)
    for p in Path(__file__).parent.glob("*.py"): shutil.copyfile(p,snapshot/p.name)
    model,opt=construct(cfg,parent["model"],device)
    initial={k:v.cpu().clone() for k,v in model.state_dict().items()}
    ema=copy.deepcopy(model).eval()
    for p in ema.parameters(): p.requires_grad_(False)
    train=training_loader(SOURCE,cfg,SEED); val=make_loader(SOURCE,"val",cfg)
    started=time.perf_counter(); first,updates,prior_seconds=0,0,0.
    if not (HOME/"best.pt").exists():
        write_json(HOME/"progress.json",{"status":"initial_source_validation","epoch":0,"updated_at":now()})
        path=HOME/"epoch_00_predictions.json"; frames=evaluate(ema,val,device,reference,path)
        total,split=probe(ema,cfg,reference,device)
        row={"epoch":0,"source_validation":validation_summary(frames),"geometry_probe":total,"per_scale":split,"ranking":ranking_summary(frames)}
        save_checkpoint(HOME/"best.pt",{**row,"model":ema.state_dict(),"config":config})
        save_checkpoint(HOME/"best_previous_selection.pt",{**row,"model":ema.state_dict(),"config":config})
        shutil.copyfile(path,HOME/"best_source_val_predictions.json")
        (HOME/"history.jsonl").write_text(json.dumps(row)+"\n",encoding="utf-8")
    if resume and (HOME/"last.pt").exists():
        state=torch.load(HOME/"last.pt",map_location="cpu",weights_only=False); assert state["config"]==config
        model.load_state_dict(state["model"]); ema.load_state_dict(state["ema"]); opt.load_state_dict(state["optimizer"])
        first,updates,prior_seconds=state["next_epoch"],state["updates"],state["elapsed_seconds"]
        restore_rng(state["rng"]); started=time.perf_counter()
    best=torch.load(HOME/"best.pt",map_location="cpu",weights_only=False); best_key=candidate_key(best)
    prior=torch.load(HOME/"best_previous_selection.pt",map_location="cpu",weights_only=False); old_key=previous_key(prior)
    del parent,best,prior
    current=report(); at=first
    write_json(HOME/"process.json",{"pid":os.getpid(),"started_at":now()})
    for epoch in range(first,3):
        if current["passed"]: break
        train.dataset.epoch=5+epoch; counts=Counter(); sums={}; tick=time.perf_counter(); batches=0
        for iteration,(images,samples) in enumerate(train):
            if len(samples)==4: assert Counter(s["view_type"] for s in samples)=={"native":2,"shrink":1,"enlarge":1}
            model.eval(); model.heads.size.train(); opt.zero_grad(set_to_none=True)
            _,terms,output=loss_for(model,images,samples,reference,cfg,device)
            loss=model_config()["loss"]["size_weight"]*terms["size"]+cfg["giou_weight"]*terms["giou"]
            if not torch.isfinite(loss): raise FloatingPointError("Nonfinite size loss")
            loss.backward()
            assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith("heads.size."))
            torch.nn.utils.clip_grad_norm_(model.heads.size.parameters(),10.,error_if_nonfinite=True); opt.step(); updates+=1
            decay=.9999*(1-math.exp(-updates/2000))
            with torch.no_grad():
                for a,b in zip(ema.heads.size.parameters(),model.heads.size.parameters()): a.mul_(decay).add_(b,alpha=1-decay)
            for s in samples: counts[s["view_type"]]+=1
            for k,v in terms.items(): sums[k]=sums.get(k,0.)+float(v.detach())
            batches+=1
            if iteration%40==0:
                progress={"status":"training","epoch":epoch+1,"batch":iteration+1,"total_batches":len(train),"updates":updates,"views":dict(counts),"updated_at":now()}
                write_json(HOME/"progress.json",progress); print(json.dumps(progress),flush=True)
            del loss,terms,output
        train_seconds=time.perf_counter()-tick
        assert sum(counts.values())==4181
        frozen_equal(model,initial); frozen_equal(ema,initial); assert fingerprints()==identity["source_hashes"]
        at=epoch+1; write_json(HOME/"progress.json",{"status":"source_validation","epoch":at,"updated_at":now()}); tick=time.perf_counter()
        path=HOME/f"epoch_{at:02d}_predictions.json"; frames=evaluate(ema,val,device,reference,path)
        total,split=probe(ema,cfg,reference,device)
        row={"epoch":at,"updates":updates,"source_validation":validation_summary(frames),"geometry_probe":total,"per_scale":split,
            "ranking":ranking_summary(frames),"view_counts":dict(counts),"training_seconds":train_seconds,"validation_seconds":time.perf_counter()-tick,
            "loss_mean_over_batches":{k:v/batches for k,v in sums.items()},"elapsed_seconds":prior_seconds+time.perf_counter()-started,"frozen_state_bitwise_equal":True}
        checkpoint={**row,"model":ema.state_dict(),"config":config}; save_checkpoint(HOME/f"epoch_{at:02d}_ema.pt",checkpoint)
        save_checkpoint(HOME/f"epoch_{at:02d}_raw.pt",{"model":model.state_dict(),"config":config,"epoch":at})
        if candidate_key(row)>best_key:
            best_key=candidate_key(row); save_checkpoint(HOME/"best.pt",checkpoint); shutil.copyfile(path,HOME/"best_source_val_predictions.json")
        if previous_key(row)>old_key: old_key=previous_key(row); save_checkpoint(HOME/"best_previous_selection.pt",checkpoint)
        save_checkpoint(HOME/"last.pt",{"model":model.state_dict(),"ema":ema.state_dict(),"optimizer":opt.state_dict(),"next_epoch":at,
            "updates":updates,"rng":rng_state(),"elapsed_seconds":row["elapsed_seconds"],"config":config})
        history=HOME/"history.jsonl"; rows=[json.loads(s) for s in history.read_text(encoding="utf-8").splitlines()]
        rows=sorted([r for r in rows if r["epoch"]!=at]+[row],key=lambda r:r["epoch"])
        tmp=history.with_suffix(".tmp"); tmp.write_text("".join(json.dumps(r)+"\n" for r in rows),encoding="utf-8"); tmp.replace(history)
        current=report(); print(json.dumps({"validated_epoch":at,"geometry_error":total["log_size_error"],"enlarge_error":split["1.4"]["log_size_error"],"passed":current["passed"]}),flush=True)
    final=report(); done={"status":"completed_passed" if final["passed"] else "completed_local_stage_held","epochs_run":at,"updates":updates,
        "best_epoch":final["candidate"]["epoch"],"original_gates_passed":final["original_gates_passed"],"promotion_passed":final["passed"],
        "enlarge_review_passed":final["enlarge_review_passed"],"elapsed_seconds":prior_seconds+time.perf_counter()-started,"target_test_cells":0,"updated_at":now()}
    write_json(HOME/"training_complete.json",done); write_json(HOME/"progress.json",done); print(json.dumps(done),flush=True)


def main():
    import msvcrt
    parser=argparse.ArgumentParser(); parser.add_argument("--check",action="store_true"); parser.add_argument("--resume",action="store_true")
    args=parser.parse_args(); HOME.mkdir(parents=True,exist_ok=True)
    with (HOME/"run.lock").open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1): lock.write(b"1"); lock.flush()
        lock.seek(0); msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1); torch.set_num_threads(8)
        try: run(args.check,args.resume)
        except Exception:
            write_json(HOME/"failure.json",{"traceback":traceback.format_exc(),"updated_at":now()}); raise


if __name__=="__main__": main()
