"""Size regression on the existing full-resolution target pathway."""
