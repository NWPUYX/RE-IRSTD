import torch
from torch.nn import functional as F
from irstd_v2.model import Model


class TSizeModel(Model):
    def __init__(self,recipe):
        if any(recipe.get(k,False) for k in ("valid_region_evidence","masked_group_norm","soft_relative_evidence")):
            raise ValueError("This isolated route experiment keeps the original evidence/GN")
        super().__init__(recipe)

    def forward(self,image,valid_mask=None,return_features=False,diagnostics=False):
        if image.ndim!=4 or image.shape[1]!=1 or min(image.shape[-2:])<32:
            raise ValueError("Expected grayscale [B,1,H,W], H/W>=32")
        h,w=image.shape[-2:]
        z,c=self.evidence(image,diagnostics)
        padding=(0,(-w)%8,0,(-h)%8)
        final,target=self.backbone(F.pad(z,padding,mode="replicate"),F.pad(c,padding,mode="replicate"),diagnostics)
        output={"center_logits":self.heads.center(final),"offsets":self.heads.offset(final),
                "log_size":self.heads.size(target),"auxiliary_center_logits":self.heads.aux(target)}
        output={k:v[...,:h,:w] for k,v in output.items()}
        if return_features: output["final_features"]=final[...,:h,:w]
        return output


def initialize(model,state,reset_size=True):
    model.load_state_dict(state,strict=True)
    if reset_size:
        torch.nn.init.zeros_(model.heads.size[-1].weight)
        torch.nn.init.zeros_(model.heads.size[-1].bias)
    for name,p in model.named_parameters(): p.requires_grad_(name.startswith("heads.size."))
    assert sum(p.numel() for p in model.parameters() if p.requires_grad)==5258
    assert sum(p.numel() for p in model.parameters())==808952


def optimizer(model,cfg):
    groups=[{"params":[p for n,p in model.named_parameters() if p.requires_grad and not n.endswith(".bias")],"weight_decay":.0005},
            {"params":[p for n,p in model.named_parameters() if p.requires_grad and n.endswith(".bias")],"weight_decay":0.}]
    from irstd_adapter import model_config
    return torch.optim.AdamW(groups,lr=cfg["learning_rate"],betas=tuple(model_config()["train"]["betas"]))
