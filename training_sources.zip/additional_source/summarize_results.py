import csv, json, math, statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MODELS=['CHAL','TDCNet','S2MVP','STMENet','Tridos','SSTNet','LASNet','AA-YOLO','IRSTD']
DOMAINS=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']; SEEDS=[3407,2026,17]
def summarize():
    records={}
    for path in (ROOT/'runs').glob('*/*/seed_*/results.json'):
        for r in json.loads(path.read_text(encoding='utf8')):
            key=(r['model'],r['source'],r['target'],r['seed']); assert key not in records; records[key]=r
    out=ROOT/'results'; out.mkdir(exist_ok=True)
    fields=['model','source','target','seed','status','AP50','AP50_95','Precision','Recall','F1','FP_per_frame','center_Pd_3px','threshold','best_epoch','frames','ground_truth']
    with (out/'测试结果_逐种子.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); writer.writeheader()
        for model in MODELS:
            for source in DOMAINS:
                for target in DOMAINS:
                    for seed in SEEDS:
                        r=records.get((model,source,target,seed))
                        writer.writerow({'model':model,'source':source,'target':target,'seed':seed,'status':'completed' if r else 'not_completed',**(r or {})})
    total_jobs=len(MODELS)*len(DOMAINS)*len(SEEDS)
    lines=['# 公开数据集 4×4 实测结果','',f'[COMPUTED｜HIGH] 已完成 {len(records)} / {total_jobs*len(DOMAINS)} 个“模型×训练源×测试域×随机种子”结果单元（{total_jobs} 次训练，每次测试四域）。','',
           '[INFERRED｜HIGH] 每格为 AP50% / F1% / FP每帧；三种子齐全才报告均值±样本标准差。未完成单元不填数字。F1 和 FP 使用源验证集选出的同一阈值。','',
           '[COMPUTED｜HIGH] 短运行检查和随机初始化推理不计入本表。所有结果来源于 runs 中的 results.json、checkpoint 与冻结测试集。','']
    lines.extend(['[COMPUTED｜HIGH] LASNet 使用辅助标签归一化修正（255→1），结构不变；修正证据和全部重训设置见执行协议。它不是原始代码逐字复现。',''])
    lines.extend(['[KNOWN｜HIGH] IRSTD 使用RE-IRSTD-v1的D结构（单帧灰度、无背景交换），按同一公开协议重训；ITSDT-15K同格标签共同回归是经用户确认的显式适配。具体差异见IRSTD执行协议.md。',''])
    for model in MODELS:
        lines.extend([f'## {model}','','| 训练源 \\ 测试域 | '+' | '.join(DOMAINS)+' |','|---|'+'---|'*4])
        for source in DOMAINS:
            cells=[]
            for target in DOMAINS:
                values=[records[(model,source,target,s)] for s in SEEDS if (model,source,target,s) in records]
                if not values: cells.append('未完成'); continue
                if len(values)==3:
                    parts=[]
                    for field,scale,digits in [('AP50',100,2),('F1',100,2),('FP_per_frame',1,4)]:
                        v=[r[field]*scale for r in values]; parts.append(f'{statistics.mean(v):.{digits}f}±{statistics.stdev(v):.{digits}f}')
                    cells.append(' / '.join(parts))
                else:
                    cells.append(' / '.join(f'{statistics.mean([r[f] for r in values])*s:.{d}f}' for f,s,d in [('AP50',100,2),('F1',100,2),('FP_per_frame',1,4)])+f'（部分，n={len(values)}）')
            lines.append('| '+source+' | '+' | '.join(cells)+' |')
        lines.append('')
    (out/'测试结果表.md').write_text('\n'.join(lines),encoding='utf8')
    return len(records)
if __name__=='__main__': print('Completed result cells:',summarize())
