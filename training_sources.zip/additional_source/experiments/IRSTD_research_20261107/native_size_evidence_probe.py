"""Check arithmetic on actual native512 source batches, not only small crops."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from evidence_numeric_probe import reference
from irstd_adapter import model_config
from irstd.models.relative_evidence import RelativeEvidenceEncoder
from irstd_v2.data import Data
from irstd_v2.settings import write_json,now


@torch.inference_mode()
def main():
    torch.set_num_threads(3);torch.backends.cudnn.benchmark=False
    state=torch.load(HERE/'background_center_interpolation_refine_v1/best.pt',map_location='cpu',weights_only=False)
    data=Data('DAUB-R','train',state['config']['recipe']);groups={}
    for i,r in enumerate(data.records):groups.setdefault(r['group'],[]).append(i)
    ids=[v[len(v)//2] for k,v in list(sorted(groups.items()))[:4]]
    samples=[data.base_sample(i) for i in ids];images=torch.stack([s['image'] for s in samples]).cuda()
    encoder=RelativeEvidenceEncoder(model_config()['model']['evidence']).cuda().eval();rows=[]
    references=[reference(image[None],encoder) for image in images]
    for mode,tf32,center in [('raw_default',True,False),('raw_IEEE',False,False),('centered_default',True,True),('centered_IEEE',False,True)]:
        torch.backends.cudnn.allow_tf32=tf32
        x=images-images.mean((-2,-1),keepdim=True) if center else images
        z,c=encoder(x);z=z.cpu().double().numpy();c=c.cpu().double().numpy()
        for b,i in enumerate(ids):
            rz,rc=references[b];delta=np.abs(z[b]-rz);cd=np.abs(c[b]-rc)
            boxes=samples[b]['boxes'];points=((boxes[:,:2]+boxes[:,2:])/2).floor().long().numpy()
            gt_delta=[float(delta[:3,qy,qx].mean()) for qx,qy in points]
            rows.append({'mode':mode,'record_index':i,'record_id':data.records[i]['id'],'Z_MAE':float(delta.mean()),
                'Z_p99':float(np.quantile(delta,.99)),'C_MAE':float(cd.mean()),'GT_Z_MAE':float(np.mean(gt_delta))})
    summary={mode:{key:float(np.mean([r[key] for r in rows if r['mode']==mode])) for key in ['Z_MAE','Z_p99','C_MAE','GT_Z_MAE']}
        for mode in ['raw_default','raw_IEEE','centered_default','centered_IEEE']}
    report={'scope':'four actual source_train images, native512 batch4, evidence numerical accuracy only',
        'reference':'same float64 unit-sum annular reference as crop probe','summary':summary,'rows':rows,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'updated_at':now()}
    write_json(HERE/'native_size_evidence_probe.json',report);print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
