"""Source-only locality audit: identical foreground versus global normalization."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from native_unit_prior_evaluation import build, sha
from irstd_background_center.data import Pairs, collate_pairs
from irstd_v2.settings import write_json, now


@torch.inference_mode()
def main():
    folder = HERE/'source_locality_audit_v1'
    folder.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    model, state, recipe, checkpoint = build('irstd_robust')
    dataset = Pairs(recipe, 'val')
    loader = DataLoader(dataset, batch_size=2, num_workers=2, collate_fn=collate_pairs)
    errors = {}
    for images, samples in loader:
        n = len(samples)//2
        assert all(a['sample_id'] == b['sample_id'] for a, b in zip(samples[:n], samples[n:]))
        coordinates = [((s['boxes'][0, :2]+s['boxes'][0, 2:])/2).floor().long().tolist() for s in samples]
        patches, moments = {}, {}

        def extract(value, radius=3):
            result = []
            for b, (x, y) in enumerate(coordinates):
                result.append(value[b, :, max(0, y-radius):min(512, y+radius+1),
                                    max(0, x-radius):min(512, x+radius+1)].detach().cpu().double().numpy())
            return result

        def norm_hook(name):
            def capture(module, args, result):
                patches[name+'/input'] = extract(args[0])
                patches[name+'/output'] = extract(result)
                grouped = args[0].float().reshape(len(args[0]), module.num_groups, -1)
                moments[name] = (grouped.mean(2).cpu().numpy(), grouped.var(2, unbiased=False).cpu().numpy())
            return capture

        handles = []
        for name, module in model.named_modules():
            if isinstance(module, torch.nn.GroupNorm) and (name == 'backbone.stem.1' or name.startswith('backbone.target_path.')):
                handles.append(module.register_forward_hook(norm_hook(name)))
        handles.append(model.evidence.register_forward_hook(lambda m, args, result: patches.update(
            {'evidence_Z': extract(result[0]), 'evidence_C': extract(result[1])})))
        handles.append(model.backbone.target_path.register_forward_hook(lambda m, args, result:
            patches.update({'T_at_GT': extract(result, radius=0)})))
        patches['raw_foreground_radius20'] = extract(images, radius=20)
        try:
            model(images.cuda(), valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
        finally:
            for handle in handles:
                handle.remove()
        for name, values in patches.items():
            row = errors.setdefault(name, [])
            for a, b in zip(values[:n], values[n:]):
                assert a.shape == b.shape
                row.append({'MSE': float(np.mean((a-b)**2)), 'max_abs': float(np.max(np.abs(a-b)))})
        for name, (mean, variance) in moments.items():
            for label, values in [('global_group_mean', mean), ('global_group_variance', variance)]:
                row = errors.setdefault(name+'/'+label, [])
                row.extend({'MSE': float(np.mean((a-b)**2)), 'max_abs': float(np.max(np.abs(a-b)))}
                           for a, b in zip(values[:n], values[n:]))
    assert all(len(values) == 24 for values in errors.values())
    summary = {name: {'mean_MSE': float(np.mean([r['MSE'] for r in values])),
                      'maximum_abs_difference': max(r['max_abs'] for r in values)} for name, values in errors.items()}
    assert summary['raw_foreground_radius20']['maximum_abs_difference'] == 0
    assert all(torch.equal(v.cpu(), state['model'][k]) for k, v in model.state_dict().items())
    report = {'status': 'completed', 'source_frames': 24, 'checkpoint_sha256': sha(checkpoint),
              'script_sha256': sha(__file__), 'all_tensors_unchanged': True, 'optimization_updates': 0,
              'summary': summary, 'per_source_target': errors, 'updated_at': now(),
              'scope': 'same source foreground, different source backgrounds; internal mechanism diagnostic, not sole explanation or SOTA proof'}
    write_json(folder/'result.json', report)
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
