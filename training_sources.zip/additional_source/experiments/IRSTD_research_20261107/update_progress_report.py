"""Publish only observed completed cells and explicit active-stage status."""
import json
from pathlib import Path
import sys

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_v2.settings import now


def read(path):return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None


def main():
    domains=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K'];rows=[]
    for source in ['DAUB-R','IRDST-H']:
        original=ROOT/'runs/IRSTD'/source/'seed_3407'
        old=[read(original/f'test_{t}_metrics.json')['overall'] for t in domains if t!=source]
        rows.append((f'IRSTD v1 / {source} / 3407',read(original/f'test_{source}_metrics.json')['overall']['AP50'],
            sum(x['AP50'] for x in old)/3,sum(x['F1'] for x in old)/3,'原始冻结结果'))
    aa=ROOT/'runs/AA-YOLO/DAUB-R/seed_3407'
    aa_cross=[read(aa/f'test_{t}_metrics.json')['overall'] for t in domains if t!='DAUB-R']
    rows.append(('AA-YOLO原解码 / DAUB-R / 3407',read(aa/'test_DAUB-R_metrics.json')['overall']['AP50'],
        sum(x['AP50'] for x in aa_cross)/3,sum(x['F1'] for x in aa_cross)/3,'单帧主对照；原始冻结结果'))
    for label,stage in [('T尺寸+原始精度保护','native_precision_w4_v1'),('MPR-Net匹配因果','mpr_causal_DAUB_3407'),
        ('背景保护中心训练','background_center_guarded_v1'),('背景中心插值','background_center_interpolation_refine_v1'),
        ('有效区域零训练','P3_zero_training_source_v1'),('有效区域填充保护','P3_padding_review_v1'),
        ('尺寸解码对齐','IRDST_decode_consistent_size_v2'),('噪声峰值保护中心训练','noise_center_peak_guarded_v1'),
        ('T通路联合稳健化','robust_T_composed_v1'),('源AP冻结诊断对照','robust_T_sourceAP_control_v1'),
        ('正确统计分离增强','stable_robust_separated_v1'),('YOLO26n-P2单帧','yolo26n_p2_DAUB_3407'),
        ('原IRSTD+原图单位先验','native_unit_irstd_v1_native_constant_v1'),
        ('联合IRSTD+原图单位先验','native_unit_irstd_robust_native_constant_v1'),
        ('MPR-Net+原图单位先验','native_unit_mpr_native_constant_v1'),
        ('YOLO26+原图单位先验','native_unit_yolo26_native_constant_v1'),
        ('联合IRSTD+输入单位先验','native_unit_irstd_robust_input_constant_v1'),
        ('正确统计IRSTD+原图单位先验','native_unit_irstd_stable_native_constant_v1'),
        ('联合IRSTD+原图单位残差','native_unit_irstd_robust_native_residual_v1'),
        ('AA-YOLO+原图单位先验','native_unit_aa_yolo_native_constant_v1'),
        ('MPR-Net+原图单位残差','native_unit_mpr_native_residual_v1'),
        ('YOLO26+原图单位残差','native_unit_yolo26_native_residual_v1'),
        ('AA-YOLO+原图单位残差','native_unit_aa_yolo_native_residual_v1')]:
        folder=HOME/stage/'frozen_four_domain_test';summary=read(folder/'summary.json')
        if summary:
            source=summary['source'];native=read(folder/f'{source}_metrics.json')['overall']['AP50'];cross=summary['cross_domain_macro']
            rows.append((f'{label} / {source} / 3407',native,cross['AP50'],cross['F1'],'完成4个测试单元'))
    population=HOME/'population_T_sourceAP_control_v1/source_qualified_tests'
    for rule in ['original','native_residual']:
        summary=read(population/rule/'summary.json')
        if summary:
            native=read(population/rule/'DAUB-R_metrics.json')['overall']['AP50'];cross=summary['cross_domain_macro']
            rows.append((f'固定统计T源AP诊断/{rule} / DAUB-R / 3407',native,cross['AP50'],cross['F1'],'诊断完成；扩展源门槛未全通过'))
    scene_control=HOME/'scene_scale_sourceAP_control_v1/source_qualified_tests'
    for rule in ['original','native_residual']:
        summary=read(scene_control/rule/'summary.json')
        if summary:
            native=read(scene_control/rule/'DAUB-R_metrics.json')['overall']['AP50'];cross=summary['cross_domain_macro']
            rows.append((f'完整场景源AP诊断/{rule} / DAUB-R / 3407',native,cross['AP50'],cross['F1'],'保留峰锚点；诊断完成；扩展源门槛未全通过'))
    for stage,label in [('local_readout_qualified_v1','混合T读出'),('locked_peak_readout_v1','固定峰T重评分'),('peak_calibrated_v1','峰定位与正例校准联合训练'),('consistent_teacher_v1','数值一致教师与几何校准')]:
        folder=HOME/stage/'source_qualified_tests';summary=read(folder/'summary.json')
        if summary:
            cross=summary['cross_domain_macro'];native=read(folder/'DAUB-R_metrics.json')['overall']['AP50']
            rows.append((f'{label} / DAUB-R / 3407',native,cross['AP50'],cross['F1'],'源18项与独立审查通过后的四域开发测试'))
    review=read(HOME/'paper_metric_review_consistent_teacher_v1/summary.json')
    if review:
        cross=review['cross_domain_macro'];native=read(HOME/'paper_metric_review_consistent_teacher_v1/DAUB-R_metrics.json')['overall']['AP50']
        rows.append(('数值一致教师主指标复核 / DAUB-R / 3407',native,cross['AP50'],cross['F1'],'四域完成；源15/18历史状态保留；另立主指标复核'))
    lines=['# IRSTD自主优化进度','',f'[KNOWN｜HIGH] 更新时间：{now()}。本表按同源、同种子、同三目标域汇总；不与四源三种子的总宏均值混比。原始测试表及历史实验不覆盖。','',
        '| 模型/训练源/种子 | 本域测试AP50 | 三个跨域宏AP50 | 三个跨域宏F1 | 状态 |','|---|---:|---:|---:|---|']
    for label,native,ap,f1,status in rows:lines.append(f'| {label} | {native*100:.4f}% | {ap*100:.4f}% | {f1*100:.4f}% | {status} |')
    if review:
        cross=review['cross_domain_macro']
        lines+=['',f"[COMPUTED｜HIGH] 最新固定512原尺寸主指标测试完成：跨域宏AP50/F1为{cross['AP50']*100:.4f}%/{cross['F1']*100:.4f}%，均高于当前AA-YOLO与YOLO26单帧主对照。整体和分组缓存重算审查、成对场景组区间另见IRSTD论文主指标测试结果_20261110.md。它不是原18项晋级，也不是四训练源三种子的完整SOTA确认。"]
    lines+=['','[KNOWN｜HIGH] MPR-Net是公开源码匹配因果适配：检测器从头训练，冻结CLIP文本预训练原型；原作者未来帧改为两个过去邻帧，EMM参数跨域冻结。其外部信息及多帧输入与IRSTD单帧不同；不能称为原论文分数的精确复现，也不能单凭这一模型覆盖所有当前SOTA。','',
        '| 正在推进或刚完成的局部阶段 | 实际记录 |','|---|---|']
    for stage in ['IRDST_fused_size_w4_v1','IRDST_decode_consistent_size_v1','IRDST_decode_consistent_size_v2',
        'background_center_guarded_v1','background_center_interpolation_refine_v1','P3_zero_training_source_v1',
        'P3_padding_review_v1','noise_center_peak_guarded_v1','robust_T_composed_v1',
        'robust_T_sourceAP_control_v1','stable_evidence_source_calibrated_v1','stable_robust_separated_v1','yolo26n_p2_DAUB_3407',
        'native_unit_irstd_v1_native_constant_v1','native_unit_irstd_robust_native_constant_v1','native_unit_mpr_native_constant_v1',
        'native_unit_yolo26_native_constant_v1','native_unit_irstd_robust_input_constant_v1',
        'native_unit_irstd_stable_native_constant_v1','native_unit_irstd_robust_native_residual_v1','global_logit_cohort_v1',
        'T_feature_correspondence_v1','native_unit_aa_yolo_native_constant_v1',
        'population_T_source_screen_v1','population_T_correspondence_v1',
        'native_unit_mpr_native_residual_v1','native_unit_yolo26_native_residual_v1','native_unit_aa_yolo_native_residual_v1',
        'scene_scale_joint_v1','integral_joint_v1','local_readout_qualified_v1','locked_peak_readout_v1','peak_calibrated_v1','consistent_teacher_v1']:
        folder=HOME/stage;progress=read(folder/'training_complete.json') or read(folder/'source_complete.json') or read(folder/'progress.json')
        if progress:
            status=progress.get('status','')
            if status=='training':description=f"训练第{progress.get('epoch')}轮，批次{progress.get('batch')}/{progress.get('total_batches')}"
            elif status=='source_validation':description=f"源验证，{progress.get('variant','')}第{progress.get('epoch','')}轮"
            elif status=='evaluating':description=f"源验证 {progress.get('frames_completed','?')}/{progress.get('total_frames','?')}帧"
            elif 'completed' in status:description='源阶段完成；'+('源门槛通过' if progress.get('promotion_passed') else '源门槛未通过')
            else:description=status
            if stage=='robust_T_sourceAP_control_v1':description='按源AP冻结诊断对照；机制未全部通过'
            if stage.startswith('native_unit_'):description='源统计尺寸先验诊断；零训练'
            if stage=='global_logit_cohort_v1' and status=='completed':description='源24帧四视图校准预审完成；两个标准化候选未通过，保留原分数，无目标测试'
            if stage=='population_T_source_screen_v1' and status=='completed':description='源训练统计校准完成；T配对误差为0，但强噪声F1未过预筛；仅作新训练初始化'
            if progress.get('completed') is True:description=f"训练完成{progress.get('epochs')}轮，按既定规则早停"
            if (folder/'integrity_failure.json').exists():description='完整性未通过；候选测试撤回，受影响轮次已在v2重放'
            test=folder/'frozen_four_domain_test';p=read(test/'progress.json');count=len(list(test.glob('*_metrics.json'))) if test.exists() else 0
            if p and p.get('status')=='evaluating' and not (test/'test_aborted.json').exists():
                description+=f"；已完成{count}/4测试单元，当前{p.get('target')} {p.get('frames_completed','?')}/{p.get('total_frames','?')}帧"
            elif p and p.get('status')=='completed':description+='；4/4测试单元完成'
            lines.append(f'| {stage} | {description} |')
    p=read(population/'progress.json')
    if p:
        count=sum(len(list((population/rule).glob('*_metrics.json'))) for rule in ['original','native_residual'])
        lines.append(f"| population_T_sourceAP_control_v1 | 独立诊断角色，源失败保留；已完成{count}/8测试单元；当前{p.get('target',p.get('status'))} {p.get('frames_completed','')}/{p.get('total_frames','')} |")
    scene=read(HOME/'scene_scale_joint_v1/training_complete.json') or read(HOME/'scene_scale_joint_v1/progress.json')
    if scene:
        lines+=['', '[COMPUTED｜HIGH] 完整场景小目标联合适配已通过五类视图、2/3/4阶全部标签及新增目标梯度预审；最多四轮、8364次正式更新，训练全部808952原有参数，T源统计冻结、上下文低学习率适配。全部18项源条件通过后独立审查并测试；新增供体曝光与额外训练预算单列，不能视为与旧配方完全相同预算。']
        lines+=['','| 完整场景阶段源轮次 | AP50 | AP50:95 | F1 | 源检查 | 未通过 |','|---|---:|---:|---:|---:|---|']
        names={'fine_AP95_parent_and_v1':'精细定位','noise4_AP50_retained':'中噪声AP','noise16_AP50_plus2pp':'强噪声AP','extreme_scale_MAE_20percent':'极端缩放平均误差','mosaic_known_size_F1_plus5pp':'拼接F1'}
        for path in sorted((HOME/'scene_scale_joint_v1').glob('epoch_*_row.json')):
            row=read(path);v=row['source_validation']['pooled'];failed=[names.get(k,k) for k,ok in row['gates'].items() if not ok]
            lines.append(f"| {row['epoch']} | {v['AP50']*100:.4f}% | {v['AP50_95']*100:.4f}% | {v['F1']*100:.4f}% | {sum(row['gates'].values())}/{len(row['gates'])} | {'、'.join(failed) or '无'} |")
    composition=read(HOME/'source_model_composition_v1/summary.json')
    if composition:
        lines+=['',f"[COMPUTED｜HIGH] 源域8种模块组合零训练检查完成，完整源缓存核对及独立审查通过；最佳{composition['best_assignment']}，{sum(composition['gates'].values())}/18源条件通过，未形成正式晋级。6个混合候选均未过强噪声AP预筛，未为它们重复完整源推理，未做目标测试。"]
    bridge=read(HOME/'scene_scale_sourceAP_control_v1/anchor_bridge_v2/result.json')
    if bridge:
        lines+=['',f"[COMPUTED｜HIGH] 保留峰锚点的解码修订完成完整源桥接：通过={bridge['passed']}。1801帧源验证有{bridge['details']['source_val']['changed_anchor_candidates']}个候选的旧恢复索引发生变化，但完整源验证、两档噪声和背景指标均与旧记录逐值一致。旧原始代码和旧指标未覆盖。当前完整场景诊断测试使用新解码，源阈值未改变。"]
    lines+=['','| 源像素密度v2补充协议（与固定512分列） | 四域完成数 | 跨域宏AP50/F1 | 实际状态 |','|---|---:|---|---|']
    for model in ['irstd_scene','irstd_population','aa_yolo','yolo26','irstd_robust']:
        folder=HOME/f'native_pixel_{model}_v2';summary=read(folder/'summary.json');p=read(folder/'progress.json');count=len(list(folder.glob('*_metrics.json')))
        if summary:
            cross=summary['cross_domain_macro'];score=f"{cross['AP50']*100:.4f}% / {cross['F1']*100:.4f}%";status='全部完成；不等于固定512晋级'
        else:
            score='尚未形成完整宏指标';status='已排队'
            if p and p.get('status')=='evaluating':
                status=f"{p['target']} {p.get('frames_completed',0)}/{p.get('total_frames',0)}帧"
                if (HOME/'primary_work_priority.json').exists():status+='；等待源训练/验证释放GPU'
        lines.append(f'| {model} | {count}/4 | {score} | {status} |')
    if (HOME/'native_pixel_v1_abort.json').exists():lines+=['','[COMPUTED｜HIGH] 像素密度v1在首个跨域单元完成前因峰索引问题中止，不计入完成结果。v2已修订解码并预先固定五个模型；scene的源桥接与DAQ缓存经过相同输入/采样证明复用，旧两个IRSTD父模型的旧DAQ缓存不复用。新增输入像素及等待/共享负载墙钟时间单列，不能当作同512预算或独占部署速度。']
    lines+=['','[KNOWN｜HIGH] 用户已明确主验收为单帧、同监督与同外部信息条件；MPR-Net作为多帧附加对照，不作为主验收必须超过的模型。','',
        '[COMPUTED｜HIGH] 已完成的DAUB-R候选尚未达到论文验收：完整场景E4固定512原尺寸解码的跨域宏AP50为1.3756%、F1为1.2730%；AA-YOLO原规则对应0.7278%与2.4440%。AP50提高，F1仍低于该单帧对照。部分尺寸再校准设置提高框AP，但固定统计T的跨域F1仍低于AA-YOLO相同残差设置。旧R残差设置的局部宏AP/F1虽超过这里两个单帧对照，仍不是完整四源三种子或全部最新SOTA证据。已有源验证过线不等于跨场景达标。','',
        '[COMPUTED｜HIGH] 噪声中心头一轮训练2091次更新，独立审计通过但源验收失败：原图AP50:95为61.8950%，强噪声AP50为81.7439%、F1为22.2222%，未达到预先设定的改善门槛。未启动该候选的目标测试。后续已改为原有T通路、融合层及四头联合训练，总模型参数808952不变。','',
        '[COMPUTED｜HIGH] T联合训练源AP50为80.8853%、AP50:95为64.3597%，强噪声F1为34.4828%；极端尺度等新增条件未通过，未被标为最终验收成功。源AP冻结诊断对照完成四域：本域AP50为55.9149%、F1为48.1817%，跨域宏AP50为0.0433%、F1为0.0574%，仍未达标。','',
        '[COMPUTED｜HIGH] 正确统计分离增强的两轮适配完成4182次更新，215个优化器状态、固定buffer及指标重算审计通过；最佳第1轮强噪声F1为63.1579%，清洁源F1/精细定位未通过保护，未进入正式候选测试。其另立原图尺寸先验诊断对照已完成四域，结果单列，不能撤销原源条件失败。','',
        '[COMPUTED｜HIGH] 后续进行无需训练的源尺寸先验诊断（原坐标逆变换未发现单位错误）：源4181帧均256×256，4178个原图框8×8，预处理后变为16×16；比较原图单位与输入单位先验，并给MPR-Net及YOLO26相同控制。不修改目标真值或主评价规则。置信度平移校准在源端选中alpha0，因此未采用。','',
        '[COMPUTED｜HIGH] 全热图置信度标准化在固定24帧源验证的清洁/背景替换/两档噪声上未通过预定条件；背景F1下降、强噪声F1没有改善，拒绝该方向且未继续目标测试。','',
        '[COMPUTED｜HIGH] 源配对双通路干预中，强噪声下恢复清洁T特征使AP50/F1由83.8152%/34.4828%变为85.4669%/50.0000%；这属于内部干预，不能当作部署成绩。T特征对应一轮实验已完成2091更新及独立审计：源AP50/AP95/F1为80.1718%/63.8087%/76.0775%，强噪声F1为50.0000%；精细定位、背景AP、强噪声AP与极端尺度未全部通过，未做目标测试。','',
        '[COMPUTED｜HIGH] 源背景替换中前景像素、Z/C和stem局部输入逐值不变，stem GN输出MSE为1.1253066；T_only源统计校准使T配对误差为0，并改善源子集排序，但强噪声F1未过预筛。后续作为明确失败的初始化启动最多两轮T/final/head适配，23252学习参数、上下文及64个统计标量冻结，保留全部既有源门槛和T局部性审计。','',
        '[KNOWN｜HIGH] 后续继续按源数据诊断、明确变更、源验证验收、冻结后测试迭代。保留相对证据、条件零和算子和全分辨率T；所有阶段保持已提出/已编码/已运行/已验证的区别。',
        '','[KNOWN｜HIGH] 尺寸残差属于源先验再校准，不能称为已确认的坐标错误修复；正确学习输入尺寸后再次乘缩放比可能重复校正，原解码与诊断规则持续分列。',
        '[KNOWN｜HIGH] 当前既有目标测试已用于历史诊断，最终论文需要额外未参与开发的确认场景、完整三种子和机制消融；不能把重复开发测试包装为独立确认。']
    integral=read(HOME/'integral_joint_v1/training_complete.json') or read(HOME/'integral_joint_v1/progress.json')
    if integral:
        lines+=['','[KNOWN｜HIGH] 积分证据与噪声输出联合适配：保持三个核心机制和808952参数，局部统计改为FP64积分、下游FP32；固定场景E2干净输出教师及旧population-E1噪声输出教师，只使用源训练。最多两轮4182更新，原18门槛不变；失败不启动本阶段正式目标测试。数值修正、训练配方及历史结构偏离分别披露。',
            '','| 积分联合阶段源轮次 | AP50 | AP50:95 | F1 | 源检查 | 未通过 |','|---|---:|---:|---:|---:|---|']
        for path in sorted((HOME/'integral_joint_v1').glob('epoch_*_row.json')):
            row=read(path);v=row['source_validation']['pooled'];failed=[k for k,ok in row['gates'].items() if not ok]
            lines.append(f"| {row['epoch']} | {v['AP50']*100:.4f}% | {v['AP50_95']*100:.4f}% | {v['F1']*100:.4f}% | {sum(row['gates'].values())}/18 | {'、'.join(failed) or '无'} |")
    readout=read(HOME/'local_readout_qualified_v1/source_row.json')
    locked=read(HOME/'locked_peak_readout_v1/rows.json')
    if readout or locked:
        lines+=['','[COMPUTED｜HIGH] 以下读出实验无新增训练、参数或统计更新；完整源阈值分别选择，保留父阶段失败。混合热图读出会改变峰位置；固定峰重评分仅改变原主峰候选分数，框几何保持。',
            '','| 完整源读出验证 | AP50 | AP50:95 | F1 | noise16 AP50 | 源条件 | 未通过 |','|---|---:|---:|---:|---:|---:|---|']
        cases=([('场景E2混合a0.25',readout)] if readout else [])+[(f'积分E1固定峰a{a}',row) for a,row in (locked or {}).items()]
        for label,row in cases:
            v=row['source_validation']['pooled'];failed=[k for k,ok in row['gates'].items() if not ok]
            lines.append(f"| {label} | {v['AP50']*100:.4f}% | {v['AP50_95']*100:.4f}% | {v['F1']*100:.4f}% | {row['noise']['16']['box']['AP50']*100:.4f}% | {sum(row['gates'].values())}/18 | {'、'.join(failed) or '无'} |")
    if read(HOME/'native_pixel_results_audit_v2/result.json'):
        lines+=['','[COMPUTED｜HIGH] 源像素密度5模型20单元全部完成，缓存总体/分组指标、样本数与真值数、输入尺寸及宏均值独立重算通过；场景版本跨域宏AP50/F1为2.0565%/1.2546%，不能并入固定512结果或据此宣称论文达标。']
    calibration=read(HOME/'peak_calibrated_v1/preflight.json')
    if calibration:
        lines+=['','[COMPUTED｜HIGH] 峰定位与正例校准联合训练预检通过：全部808952参数有限梯度，两项新增损失有梯度、增强校准覆盖全部供体目标、教师及64个统计buffer不变、保存重载精确、原峰几何与部署/训练分数一致。',
            '[KNOWN｜HIGH] 本轮保留FP64积分和三项核心机制，固定a0.25候选重评分；新增原生7×7空间KL0.5与全部增强GT正例softplus校准0.1。最多六轮12546次更新，原18项门槛不变；通过后独立审查再做四域测试。',
            '','| 峰定位与正例校准轮次 | AP50 | AP50:95 | F1 | noise16 AP | 源条件 | 未通过 |','|---|---:|---:|---:|---:|---:|---|']
        for path in sorted((HOME/'peak_calibrated_v1').glob('epoch_*_row.json')):
            row=read(path);v=row['source_validation']['pooled'];failed=[k for k,ok in row['gates'].items() if not ok]
            lines.append(f"| {row['epoch']} | {v['AP50']*100:.4f}% | {v['AP50_95']*100:.4f}% | {v['F1']*100:.4f}% | {row['noise']['16']['box']['AP50']*100:.4f}% | {sum(row['gates'].values())}/18 | {'、'.join(failed) or '无'} |")
    if (HOME/'数值一致教师与几何校准后续方案.md').exists():
        parent=read(HOME/'peak_calibrated_v1/independent_audit.json')
        description='已编写并排队；先等待六轮父阶段结束及独立审查；尚未实际预检或训练'
        if parent and parent['promotion_passed']:description='父阶段源验收通过，后续方案跳过；父阶段继续四域测试'
        elif read(HOME/'consistent_teacher_v1/progress.json'):description='后续已开始，实际状态见阶段表'
        lines+=['',f'[KNOWN｜HIGH] 条件后续：{description}。仅当父阶段审查通过但源失败时，执行数值一致积分噪声教师、仅几何视图额外正例校准；最多两轮，原门槛不变。']
    destination=ROOT/'results/IRSTD自主优化进度.md';destination.write_text('\n'.join(lines),encoding='utf-8')
    print(str(destination),flush=True)
    from write_current_round_report import main as write_current_round
    write_current_round()


if __name__=='__main__':main()
