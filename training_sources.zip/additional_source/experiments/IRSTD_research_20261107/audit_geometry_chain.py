"""CPU integrity and source-selection audit for the IRDST geometry chain."""
import hashlib
import json
from pathlib import Path
import sys
import torch

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path[:0]=[str(ROOT),str(HOME)]
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import split_hashes,write_json,now
from fused_geometry_source import gates


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    for stage in ['IRDST_fused_size_w4_v1','IRDST_decode_consistent_size_v1','IRDST_decode_consistent_size_v2']:
        folder=HOME/stage
        if not (folder/'training_complete.json').exists():continue
        done=json.loads((folder/'training_complete.json').read_text(encoding='utf-8'))
        cfg=json.loads((folder/'config.json').read_text(encoding='utf-8'));assert cfg['split_hashes']==split_hashes()
        for name,digest in cfg['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
        parent=torch.load(cfg['initial_checkpoint'],map_location='cpu',weights_only=False);assert sha(cfg['initial_checkpoint'])==cfg['parent_sha256']
        last=torch.load(folder/'last.pt',map_location='cpu',weights_only=False);best=torch.load(folder/'best.pt',map_location='cpu',weights_only=False)
        for state in [last['model'],last['ema'],best['model']]:
            for name,value in state.items():
                if not name.startswith('heads.size.'):assert torch.equal(value,parent['model'][name]),name
        assert len(last['optimizer']['state'])==4
        optimizer_steps=[int(v['step']) for v in last['optimizer']['state'].values()]
        steps_ok=all(step==last['updates'] for step in optimizer_steps)
        path=folder/f"epoch_{best['epoch']:02d}_predictions.json"
        if not path.exists():path=HOME/'IRDST_fused_size_w4_v1'/path.name
        frames=json.loads(path.read_text(encoding='utf-8'))['frames'];assert validation_summary(frames)==best['validation']
        base=json.loads((folder/'baseline.json').read_text(encoding='utf-8'));assert gates(best,base)==done['gates']
        assert done['promotion_passed']==all(done['gates'].values())
        report={'passed':steps_ok,'stage':stage,'updates':last['updates'],'selected_epoch':best['epoch'],
            'optimizer_steps':optimizer_steps,'optimizer_counter_exact':steps_ok,
            'source_metrics_and_gates_recomputed':True,'non_size_states_equal_parent':True,
            'optimizer_tensor_count':4,'checkpoint_sha256':sha(folder/'best.pt'),'split_and_source_hashes_match':True,
            'center_probe_note':'historical probe raw-offset error; decoded clamp error separately measured in offset_decode_audit.json','updated_at':now()}
        write_json(folder/'independent_audit.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
