"""Temporarily suspend our baseline process; always resume after bounded wait."""
import json
from pathlib import Path
import sys
import time

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT/'vendor_sota'))
import psutil


def main():
    home=HOME/'mpr_causal_DAUB_3407'
    pid=json.loads((home/'process.json').read_text(encoding='utf-8'))['pid']
    process=psutil.Process(pid)
    assert '-m' in process.cmdline() and 'mpr_matched.run' in process.cmdline(),process.cmdline()
    created=process.create_time();started=time.monotonic()
    flag=home/'resource_pause.json'
    def record(paused,reason):
        flag.write_text(json.dumps({'pid':pid,'process_create_time':created,'paused':paused,'reason':reason,'time':time.time()},indent=2),encoding='utf-8')
    paused=False
    try:
        process.suspend();paused=True;record(True,'Prioritize frozen IRSTD tests and source-only geometry; preserve in-memory optimizer/RNG')
        print(json.dumps({'baseline_suspended':pid}),flush=True)
        while time.monotonic()-started<5400:
            tests=(HOME/'native_precision_w4_v1/frozen_four_domain_test/summary.json').exists()
            source=(HOME/'IRDST_fused_size_w4_v1/training_complete.json').exists()
            if tests and source:break
            if not process.is_running():return
            time.sleep(5)
    finally:
        if paused and process.is_running() and process.create_time()==created:
            process.resume();record(False,'Resumed after IRSTD priority stages or maximum90min safety bound')
            print(json.dumps({'baseline_resumed':pid}),flush=True)


if __name__=='__main__':main()
