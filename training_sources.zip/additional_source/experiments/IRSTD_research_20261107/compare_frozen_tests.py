"""Compare completed frozen cells; never alter checkpoints or thresholds."""
import json
import argparse
from pathlib import Path
import sys
import numpy as np

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from benchmark_cluster_bootstrap import paired_ci
from irstd_v2.settings import write_json,now


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',default='native_precision_w4_v1');args=parser.parse_args()
    stage=HOME/args.stage;folder=stage/'frozen_four_domain_test'
    manifest=json.loads((folder/'freeze_manifest.json').read_text(encoding='utf-8'))
    source=manifest['source'];seed=manifest['seed'];rows=[]
    for target in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=folder/f'{target}_metrics.json'
        if not path.exists():continue
        candidate=json.loads(path.read_text(encoding='utf-8'))['overall']
        olddir=ROOT/'runs/IRSTD'/source/f'seed_{seed}'
        old=json.loads((olddir/f'test_{target}_metrics.json').read_text(encoding='utf-8'))['overall']
        cf=json.loads((folder/f'{target}_predictions.json').read_text(encoding='utf-8'))['frames']
        of=json.loads((olddir/f'test_{target}_predictions.json').read_text(encoding='utf-8'))['frames']
        row={'target':target,'candidate':candidate,'v1':old,
            'delta':{k:candidate[k]-old[k] for k in ('AP50','AP50_95','F1','center_Pd_3px','FP_per_frame')},
            'paired_group_bootstrap_AP50_delta_CI95':paired_ci(cf,of)}
        comparator=ROOT/'runs/STMENet'/source/f'seed_{seed}'/f'test_{target}_metrics.json'
        if comparator.exists():row['STMENet_same_source_seed']=json.loads(comparator.read_text(encoding='utf-8'))['overall']
        rows.append(row)
    summary={'source':source,'seed':seed,'completed_cells':len(rows),'results':rows,'updated_at':now(),
        'scope':'single-source single-seed development comparison, not full-matrix or SOTA proof'}
    cross=[r for r in rows if r['target']!=source]
    if len(cross)==3:
        summary['cross_domain_macro']={name:{k:float(np.mean([r[name][k] for r in cross])) for k in ('AP50','AP50_95','F1','center_Pd_3px','FP_per_frame')} for name in ('candidate','v1')}
    write_json(stage/'frozen_test_comparison.json',summary)
    lines=['# 冻结测试对比','',f'[KNOWN｜HIGH] 单源{source}、种子{seed}；以下均为已完成单元。源验证阈值分别冻结；全矩阵、稳定性和当前强基线尚需完成。','',
        '| 目标域 | v1 AP50 | 候选AP50 | v1 F1 | 候选F1 | v1 AP50:95 | 候选AP50:95 | AP50差值95%区间(pp) |',
        '|---|---:|---:|---:|---:|---:|---:|---|']
    for r in rows:
        a,b=r['v1'],r['candidate'];ci=r['paired_group_bootstrap_AP50_delta_CI95'];ci_text='无足够组' if ci is None else f'[{ci[0]*100:.4f},{ci[1]*100:.4f}]'
        lines.append(f"| {r['target']} | {a['AP50']*100:.4f}% | {b['AP50']*100:.4f}% | {a['F1']*100:.4f}% | {b['F1']*100:.4f}% | {a['AP50_95']*100:.4f}% | {b['AP50_95']*100:.4f}% | {ci_text} |")
    if 'cross_domain_macro' in summary:
        v=summary['cross_domain_macro'];lines+=['',f"[COMPUTED｜HIGH] 三个非对角目标域宏AP50：v1 {v['v1']['AP50']*100:.4f}%，候选{v['candidate']['AP50']*100:.4f}%；宏F1：v1 {v['v1']['F1']*100:.4f}%，候选{v['candidate']['F1']*100:.4f}%。"]
    lines+=['','[KNOWN｜HIGH] 区间由200次成对场景组bootstrap计算，固定随机种子3407；它不替代多训练种子变异分析。测试反馈未用于重设本次模型或阈值；既有测试已参与历史诊断，后续论文需独立确认数据。']
    (stage/'冻结测试对比.md').write_text('\n'.join(lines),encoding='utf-8');print(json.dumps({'completed_cells':len(rows),'cross_domain_macro':summary.get('cross_domain_macro')}),flush=True)


if __name__=='__main__':main()
