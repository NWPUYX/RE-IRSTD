"""Freeze only audited, source-qualified robust-T or arithmetic candidates."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_t_size.model import TSizeModel
from irstd_stable_evidence.model import StableModel
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate
from irstd_v2.settings import write_json,now
from evaluation import metrics
from benchmark_cluster_bootstrap import cluster_ci
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['robust_T_composed_v1','stable_evidence_source_calibrated_v1','robust_T_sourceAP_control_v1'],required=True);a=p.parse_args()
    stable=a.stage.startswith('stable_');audit_script=HERE/('audit_stable_evidence.py' if stable else 'audit_robust_T.py')
    control=a.stage=='robust_T_sourceAP_control_v1'
    if control:audit_script=HERE/'freeze_sourceAP_control.py'
    subprocess.run([sys.executable,str(audit_script)],check=True,cwd=ROOT)
    home=HERE/a.stage;folder=home/'frozen_four_domain_test'
    audit=json.loads((home/'independent_audit.json').read_text(encoding='utf-8'))
    assert audit['passed'] and (audit.get('eligible_for_diagnostic_test',False) if control else audit['promotion_passed'])
    folder.mkdir(exist_ok=True);state=torch.load(home/'best.pt',map_location='cpu',weights_only=False);cfg=state['config']
    threshold=state['source_validation']['threshold'];source=cfg['source'];targets=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']
    manifest={'source':source,'seed':cfg['seed'],'checkpoint_sha256':sha(home/'best.pt'),'threshold':threshold,
        'epoch':state['epoch'],'split_hashes':cfg['split_hashes'],'script_sha256':sha(__file__),
        'audit_script_sha256':sha(audit_script),'decoder_helper_sha256':sha(ROOT/'benchmark_fastdecode.py'),
        'bootstrap_helper_sha256':sha(ROOT/'benchmark_cluster_bootstrap.py'),
        'progress_helper_sha256':sha(ROOT/'benchmark_progress.py'),'test_order':targets,
        'evidence_arithmetic':cfg['recipe'].get('evidence_arithmetic','original'),
        'role':cfg.get('role','source-qualified candidate')}
    assert manifest['checkpoint_sha256']==audit['checkpoint_sha256']
    check=json.loads((HERE/'fastdecode_equivalence.json').read_text(encoding='utf-8'));assert check['passed'] and check['source_sha256']==manifest['decoder_helper_sha256']
    assert json.loads((HERE/'bootstrap_equivalence.json').read_text(encoding='utf-8'))['passed']
    if (folder/'freeze_manifest.json').exists():assert json.loads((folder/'freeze_manifest.json').read_text(encoding='utf-8'))==manifest
    else:write_json(folder/'freeze_manifest.json',manifest)
    fast.install();torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;device=torch.device('cuda')
    model=(StableModel if stable else TSizeModel)(cfg['recipe']).to(device);model.load_state_dict(state['model']);model.eval()
    for param in model.parameters():param.requires_grad_(False)
    rows=[]
    for target in targets:
        path=folder/f'{target}_metrics.json'
        if path.exists():result=json.loads(path.read_text(encoding='utf-8'))
        else:
            tick=time.perf_counter();data=ReportingLoader(make_loader(target,'test',cfg['recipe']),folder/'progress.json',target)
            frames=evaluate(model,data,device,cfg['size_reference_512'],folder/f'{target}_predictions.json')
            overall=metrics(frames,threshold);ci=cluster_ci(frames)
            if ci is not None:overall['AP50_cluster_CI95']=ci
            result={'source':source,'target':target,'seed':cfg['seed'],'checkpoint_sha256':manifest['checkpoint_sha256'],
                'overall':overall,'by_group':{g:metrics([f for f in frames if f['group']==g],threshold) for g in sorted({f['group'] for f in frames})},
                'elapsed_seconds':time.perf_counter()-tick,'updated_at':now()}
            assert sha(home/'best.pt')==manifest['checkpoint_sha256'];write_json(path,result)
        rows.append(result);print(json.dumps({'target':target,**result['overall']}),flush=True)
    cross=[r['overall'] for r in rows if r['target']!=source]
    summary={'status':'completed','source':source,'seed':cfg['seed'],'completed_cells':len(rows),
        'cross_domain_macro':{k:sum(r[k] for r in cross)/3 for k in ['AP50','AP50_95','F1','center_Pd_3px']},'updated_at':now()}
    write_json(folder/'summary.json',summary);write_json(folder/'progress.json',summary)


if __name__=='__main__':main()
