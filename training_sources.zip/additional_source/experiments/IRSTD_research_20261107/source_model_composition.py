"""Eight source-only old/new module combinations; zero optimization updates."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import copy
import itertools
import json
from pathlib import Path
import shutil
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_scene_scale.run import HOME as NEW,PARENT,INITIAL,sha,gates,row_key,locality_probe
from irstd_scene_scale.probe import evaluate_mosaics
from irstd_population_t.model import PopulationTModel
from irstd_robust_t.run import mechanisms
from irstd_robust_t.probe import extreme_probe
from irstd_geometry_balance.run import probe
from irstd_background_center.run import background_diagnostic
from irstd_noise_center.data import validation_loader
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint
from evaluation import metrics
from benchmark_center_metrics import center_metrics
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast

HOME=HERE/'source_model_composition_v1'
OLD=INITIAL


def group(name):
    if name.startswith(('backbone.stem.','backbone.target_path.')):return 0
    if name.startswith(('heads.offset.','heads.size.')):return 2
    return 1


def network(recipe,state):
    model=PopulationTModel(recipe).cuda().eval();model.load_state_dict(state,strict=True);model.set_mode(final=False)
    for p in model.parameters():p.requires_grad_(False)
    return model


def mixed_state(old,new,bits,parameter_names):
    assert old.keys()==new.keys()
    result={}
    for name,value in old.items():
        if name in parameter_names:result[name]=(new if bits[group(name)] else old)[name].clone()
        else:
            assert torch.equal(value,new[name]),name
            result[name]=value.clone()
    return result


def cached_row(state,old=False):
    keys=['epoch','source_validation','geometry_probe','per_scale','background','noise','extreme_geometry','T_pair_MSE']
    row={key:copy.deepcopy(state[key]) for key in keys}
    if old:
        source=json.loads((HERE/'source_mosaic_probe_v1/result.json').read_text(encoding='utf-8'))['results']['population']['results']
        row['mosaics']={k:{mode:value[mode] for mode in ['learned','known_source_size']} for k,value in source.items()}
    else:row['mosaics']=copy.deepcopy(state['mosaics'])
    return row


def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    done=json.loads((NEW/'training_complete.json').read_text(encoding='utf-8'))
    audit=json.loads((NEW/'independent_audit.json').read_text(encoding='utf-8'))
    assert audit['passed'] and audit['checkpoint_sha256']==sha(NEW/'best.pt')
    if done['promotion_passed']:
        write_json(HOME/'skipped.json',{'reason':'original stage passed; no composition needed'});return
    old=torch.load(OLD,map_location='cpu',weights_only=False)
    new=torch.load(NEW/'best.pt',map_location='cpu',weights_only=False)
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False)
    bg=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    noise_limit=json.loads((HERE/'noise_validation_diagnostic/baseline.json').read_text(encoding='utf-8'))['results']['16']['box']['AP50']+.02
    recipe={**new['config']['recipe'],'name':HOME.name,'selection':'8 fixed module assignments, no optimization; same18sourcegates'}
    model=network(recipe,old['model']);parameter_names=set(dict(model.named_parameters()))
    assert sum(p.numel() for p in model.parameters())==808952
    assignments={name:group(name) for name in parameter_names}
    del model
    config={**new['config'],'recipe':recipe,'old_endpoint_sha256':sha(OLD),'new_endpoint_sha256':sha(NEW/'best.pt'),
        'parameter_group_assignment':assignments,'optimization_updates':0,
        'source_hashes':{**new['config']['source_hashes'],str(Path(__file__).relative_to(ROOT.parent)):sha(__file__),
            str((HERE/'源域模块组合零训练方案.md').relative_to(ROOT.parent)):sha(HERE/'源域模块组合零训练方案.md')},
        'diagnostic_hashes':{**new['config']['diagnostic_hashes'],str((NEW/'independent_audit.json').relative_to(ROOT.parent)):sha(NEW/'independent_audit.json')}}
    if (HOME/'config.json').exists():assert json.loads((HOME/'config.json').read_text(encoding='utf-8'))==config
    else:write_json(HOME/'config.json',config)
    reference=config['size_reference_512'];rows=[];prescreen=[]
    for number,bits in enumerate(itertools.product([0,1],repeat=3),start=1):
        label=''.join(map(str,bits));folder=HOME/label;folder.mkdir(exist_ok=True)
        state=mixed_state(old['model'],new['model'],bits,parameter_names)
        model=network(recipe,state);mechanisms(model)
        write_json(HOME/'progress.json',{'status':'source_composition','assignment':label,'candidate':number,'total_candidates':8,'updated_at':now()})
        row_path=folder/'row.json'
        if row_path.exists():row=json.loads(row_path.read_text(encoding='utf-8'))
        elif label in ['000','111']:
            row=cached_row(old if label=='000' else new,old=label=='000')
            source=OLD.parent/'epoch_01_predictions.json' if label=='000' else NEW/'best_source_val_predictions.json'
            shutil.copyfile(source,folder/'source_val_predictions.json')
            row['source_cache_equivalence']={'all_model_tensors_equal':True,'source_sha256':sha(source),'input_recipe_equal':True}
        else:
            path=folder/'noise16_prescreen_predictions.json'
            frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,validation_loader(recipe,16),'cuda',reference,path)
            value=metrics(frames,old['source_validation']['threshold'])
            passed=value['AP50']>=noise_limit
            item={'assignment':label,'strong_noise_AP50':value['AP50'],'passed':passed,'threshold_not_used_for_AP':True}
            prescreen.append(item);write_json(folder/'prescreen.json',item)
            if not passed:
                del model;torch.cuda.empty_cache();continue
            path=folder/'source_val_predictions.json'
            frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,
                ReportingLoader(make_loader('DAUB-R','val',recipe),folder/'progress.json','source_val'),'cuda',reference,path)
            geometry,per_scale=probe(model,recipe,reference,'cuda')
            row={'source_validation':validation_summary(frames),'geometry_probe':geometry,'per_scale':per_scale,
                'background':background_diagnostic(model,recipe,reference,'cuda',folder,'source'),'noise':{},
                'extreme_geometry':extreme_probe(model,recipe,reference,'cuda'),'T_pair_MSE':locality_probe(model,recipe,'cuda')}
            for factor in [4,16]:
                path=folder/f'noise{factor}_predictions.json'
                frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,validation_loader(recipe,factor),'cuda',reference,path)
                row['noise'][str(factor)]={'box':metrics(frames,row['source_validation']['threshold']),
                    'center':center_metrics(frames,row['source_validation']['threshold'])}
            row['mosaics']=evaluate_mosaics(model,recipe,reference,'cuda',row['source_validation']['threshold'])
        row['assignment']=label;row['candidate_index']=number
        if 'epoch' in row:row['endpoint_training_epoch']=row.pop('epoch')
        row['gates']=gates(row,parent,bg);write_json(row_path,row);rows.append(row)
        assert all(torch.equal(v.cpu(),state[k]) for k,v in model.state_dict().items())
        del model;torch.cuda.empty_cache()
    assert len(rows)>=2
    best=max(rows,key=row_key);bits=tuple(map(int,best['assignment']))
    state=mixed_state(old['model'],new['model'],bits,parameter_names)
    checkpoint={**best,'model':state,'config':{**config,'selected_assignment':best['assignment']}}
    save_checkpoint(HOME/'best.pt',checkpoint)
    shutil.copyfile(HOME/best['assignment']/'source_val_predictions.json',HOME/'best_source_val_predictions.json')
    summary={'status':'completed','promotion_passed':all(best['gates'].values()),'best_assignment':best['assignment'],
        'gates':best['gates'],'optimization_updates':0,'completed_full_source_candidates':len(rows),'prescreen':prescreen,
        'all_assignments_attempted':8,'updated_at':now()}
    write_json(HOME/'summary.json',summary);write_json(HOME/'progress.json',summary)
    print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
