"""Reuse original baselines only on partitions with an exactly unit factor."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from native_unit_prior_evaluation import sha, source_statistics
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json, now


def copy_same(source, target):
    if target.exists():
        assert sha(source) == sha(target)
    else:
        shutil.copyfile(source, target)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', choices=['mpr', 'yolo26'], required=True)
    args = parser.parse_args()
    name = {'mpr': 'mpr_causal_DAUB_3407', 'yolo26': 'yolo26n_p2_DAUB_3407'}[args.model]
    source = HERE/name
    state = torch.load(source/'best.pt', map_location='cpu', weights_only=False)
    epoch = state['epoch']
    predictions = source/f'source_val_epoch_{epoch:03d}.json'
    frames = json.loads(predictions.read_text(encoding='utf-8'))['frames']
    source_validation = validation_summary(frames)
    assert source_validation['pooled'] == state['validation']
    original_test = source/'frozen_four_domain_test'
    manifest = json.loads((original_test/'freeze_manifest.json').read_text(encoding='utf-8'))
    assert manifest['checkpoint_sha256'] == sha(source/'best.pt')
    stats = source_statistics()
    proof = {}
    for split in ['val', 'test']:
        path = ROOT/f'splits/DAUB-R_{split}.json'
        records = json.loads(path.read_text(encoding='utf-8'))
        for record in records:
            ratio = min(512/record['width'], 512/record['height'])
            scale = np.array([int(record['width']*ratio)/record['width'], int(record['height']*ratio)/record['height']])
            np.testing.assert_array_equal(scale/np.array(stats['resize_median']), np.ones(2))
        proof[split] = {'frames': len(records), 'split_sha256': sha(path), 'all_factors_exactly_one': True}
    home = HERE/f'native_unit_{args.model}_native_residual_v1'
    home.mkdir(exist_ok=True)
    test = home/'frozen_four_domain_test'
    test.mkdir(exist_ok=True)
    copy_same(predictions, home/'source_val_predictions.json')
    copy_same(original_test/'DAUB-R_predictions.json', test/'DAUB-R_predictions.json')
    path = test/'DAUB-R_metrics.json'
    if not path.exists():
        metric = json.loads((original_test/'DAUB-R_metrics.json').read_text(encoding='utf-8'))
        write_json(path, {**metric, 'elapsed_seconds': 0., 'cache_reuse': {
            'from': str(original_test), 'reason': 'same checkpoint and residual unit factor exactly1',
            'input_predictions_sha256': sha(original_test/'DAUB-R_predictions.json')}, 'updated_at': now()})
    write_json(home/'source_cache_equivalence.json', {'passed': True, 'source_checkpoint_sha256': sha(source/'best.pt'),
        'source_validation_reproduced_from_original_cache': True, 'selected_epoch': epoch, 'partitions': proof,
        'no_target_labels_used_for_equivalence': True, 'updated_at': now()})
    print(json.dumps({'model': args.model, 'passed': True, 'reused_source_frames': len(frames), 'reused_native_test_frames': proof['test']['frames']}), flush=True)


if __name__ == '__main__':
    main()
