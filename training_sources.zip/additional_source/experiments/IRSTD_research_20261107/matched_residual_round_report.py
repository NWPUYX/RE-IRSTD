"""Matched learned-size residual comparison; publish observed cells only."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from benchmark_cluster_bootstrap import paired_ci
from irstd_v2.settings import write_json, now

DOMAINS = ['DAUB-R', 'IRDST-H', 'IRSTD-UAV', 'ITSDT-15K']
STAGES = {
    'robust_T/residual': HERE/'native_unit_irstd_robust_native_residual_v1/frozen_four_domain_test',
    'population_T/residual': HERE/'population_T_sourceAP_control_v1/source_qualified_tests/native_residual',
    'population_T/original': HERE/'population_T_sourceAP_control_v1/source_qualified_tests/original',
    'MPR/residual': HERE/'native_unit_mpr_native_residual_v1/frozen_four_domain_test',
    'YOLO26/residual': HERE/'native_unit_yolo26_native_residual_v1/frozen_four_domain_test',
    'AA-YOLO/residual': HERE/'native_unit_aa_yolo_native_residual_v1/frozen_four_domain_test',
}


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def paired_f1(a, ta, b, tb):
    assert len(a) == len(b)
    groups = sorted({r['group'] for r in a})
    if len(groups) < 2:
        return None
    assert all((x['group'], x['gt']) == (y['group'], y['gt']) for x, y in zip(a, b))
    tables = []
    for frames, threshold in [(a, ta), (b, tb)]:
        data = np.zeros((len(groups), 3))
        index = {g: i for i, g in enumerate(groups)}
        for frame in frames:
            keep = np.asarray(frame['scores']) >= threshold
            tp = np.asarray(frame['tp'], dtype=bool).reshape(-1, 10)[:, 0]
            data[index[frame['group']]] += [tp[keep].sum(), keep.sum(), frame['gt']]
        tables.append(data)
    rng = np.random.default_rng(3407)
    values = []
    for _ in range(200):
        weights = np.bincount(rng.integers(0, len(groups), len(groups)), minlength=len(groups))
        f1 = []
        for data in tables:
            hit, predicted, gt = weights@data
            f1.append(2*hit/(predicted+gt) if predicted+gt else 0.)
        values.append(f1[0]-f1[1])
    return np.quantile(values, [.025, .975]).tolist()


def main():
    cache = HERE/'matched_residual_round_report'
    cache.mkdir(exist_ok=True)
    rows = []
    complete = {}
    for name, folder in STAGES.items():
        cells = []
        for domain in DOMAINS:
            path = folder/f'{domain}_metrics.json'
            if path.exists():
                result = read(path)['overall']
                rows.append({'model': name, 'domain': domain, 'metrics': result, 'metrics_sha256': sha(path)})
                cells.append((domain, result))
        if len(cells) == 4:
            cross = [v for d, v in cells if d != 'DAUB-R']
            complete[name] = {k: float(np.mean([r[k] for r in cross])) for k in ['AP50', 'AP50_95', 'F1', 'center_Pd_3px']}
    pairs = []
    for right in ['robust_T/residual', 'MPR/residual', 'YOLO26/residual', 'AA-YOLO/residual']:
        for domain in DOMAINS:
            folders = [STAGES['population_T/residual'], STAGES[right]]
            paths = [f/f'{domain}_predictions.json' for f in folders]
            if not all(p.exists() and p.with_name(f'{domain}_metrics.json').exists() for p in paths):
                continue
            digest = [sha(p) for p in paths]
            destination = cache/f"population_minus_{right.replace('/', '_')}_{domain}.json"
            if destination.exists() and read(destination)['predictions_sha256'] == digest:
                pair = read(destination)
            else:
                a, b = [read(p)['frames'] for p in paths]
                ta, tb = [read(f/f'{domain}_metrics.json')['overall']['threshold'] for f in folders]
                pair = {'left': 'population_T/residual', 'right': right, 'domain': domain,
                        'predictions_sha256': digest, 'AP50_delta_CI95': paired_ci(a, b),
                        'fixed_source_threshold_F1_delta_CI95': paired_f1(a, ta, b, tb), 'draws': 200, 'seed': 3407}
                write_json(destination, pair)
            pairs.append(pair)
    source = read(HERE/'population_T_correspondence_v1/epoch_01_row.json')
    lines = ['# 固定统计T：本轮完整验证与尺寸残差公平对照', '',
             f'[COMPUTED｜HIGH] 更新时间：{now()}。仅列实际完成的单元；全部为DAUB-R源、3407种子。', '',
             '[COMPUTED｜HIGH] 最多两轮已完成4182次更新，最佳第1轮源AP50/AP50:95/F1为81.7616%/64.8335%/77.7126%。独立审查通过；扩展源检查13/16通过，精细定位父模型保护及两项极端尺度检查失败。普通候选未进入目标测试；下表权重以预先单列的源AP冻结诊断角色测试，失败不撤回。', '',
             '| 模型/尺寸规则 | 已完成单元 | 跨域宏AP50 | 跨域宏AP50:95 | 跨域宏F1 | 跨域宏中心Pd |',
             '|---|---:|---:|---:|---:|---:|']
    for name in STAGES:
        count = sum(r['model'] == name for r in rows)
        if name in complete:
            m = complete[name]
            lines.append(f"| {name} | {count}/4 | {m['AP50']*100:.4f}% | {m['AP50_95']*100:.4f}% | {m['F1']*100:.4f}% | {m['center_Pd_3px']*100:.4f}% |")
        else:
            lines.append(f'| {name} | {count}/4 | 待完成 | 待完成 | 待完成 | 待完成 |')
    lines += ['', '[KNOWN｜HIGH] residual保留学习尺寸头，只按当前图像已知缩放与源训练缩放中位数的比值转换尺寸；未使用目标框估计先验。原尺寸规则与residual均预先固定并全部报告，不按目标结果择优拼接。MPR同时使用多帧及冻结CLIP文本先验，输入信息不同。', '',
              '| 模型 | 目标域 | AP50 | F1 | 召回 | FP/帧 |', '|---|---|---:|---:|---:|---:|']
    for row in rows:
        m = row['metrics']
        lines.append(f"| {row['model']} | {row['domain']} | {m['AP50']*100:.4f}% | {m['F1']*100:.4f}% | {m['Recall']*100:.4f}% | {m['FP_per_frame']:.4f} |")
    lines += ['', '[COMPUTED｜HIGH] 下列200次成对场景组bootstrap区间均为百分点；固定各模型源阈值，不在目标域选阈值，不能替代多训练种子。', '',
              '| 固定统计T残差 减 对照 | 域 | AP50差值95%区间 | F1差值95%区间 |', '|---|---|---|---|']
    for pair in pairs:
        values = []
        for key in ['AP50_delta_CI95', 'fixed_source_threshold_F1_delta_CI95']:
            ci = pair[key]
            values.append(f'[{ci[0]*100:.4f}, {ci[1]*100:.4f}]' if ci is not None else '组数不足')
        lines.append(f"| {pair['right']} | {pair['domain']} | {values[0]} | {values[1]} |")
    lines += ['', '[COMPUTED｜HIGH] 当前源域检查未全部通过，且尚无四源三种子与独立确认场景证据；本轮不能宣称达到当前SOTA或论文验收完成。', '',
              '[KNOWN｜HIGH] 保留三项核心机制；本轮显式偏离为T分支在共享stem卷积后、原GN前分出，并使用冻结的源统计。全部历史阶段额外训练预算、原TF32证据运算及T尺寸头偏离仍需披露。']
    (HERE/'固定统计T本轮验证结果.md').write_text('\n'.join(lines), encoding='utf-8')
    write_json(cache/'summary.json', {'updated_at': now(), 'rows': rows, 'complete_cross_domain': complete,
                                     'source_gates': source['gates'], 'paired': pairs})
    print(json.dumps({'complete_cells': len(rows), 'complete_models': complete, 'paired_rows': len(pairs)}), flush=True)


if __name__ == '__main__':
    main()
