"""Standalone scientific figure from completed source-only JSON results."""
import os
from pathlib import Path
import json
import numpy as np
HERE=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(HERE.parents[1]/'cache/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    original=json.loads((HERE/'source_pixel_density_probe_v1/result.json').read_text(encoding='utf-8'))['results']
    reports=[original['robust'],original['population']]
    for name in ['aa_yolo','yolo26']:
        reports.append(json.loads((HERE/f'source_pixel_density_{name}_v1/result.json').read_text(encoding='utf-8'))['results'][name])
    names=['IRSTD robust T','IRSTD population T','AA-YOLO','YOLO26n-P2']
    fig,axes=plt.subplots(2,2,figsize=(11,7),layout='constrained')
    panels=[('learned','AP50','AP50, learned size'),('known_source_size','AP50','AP50, known source size (diagnostic)'),
            ('learned','F1','F1, learned size'),('learned','Recall','Recall, learned size')]
    x=np.arange(4)
    for ax,(rule,metric,title) in zip(axes.flat,panels):
        for offset,side,color in [(-.19,'512','#4c78a8'),(.19,'1024','#f28e2b')]:
            values=[r['results'][side][rule][metric]*100 for r in reports]
            bars=ax.bar(x+offset,values,width=.36,label=f'{side} input',color=color)
            ax.bar_label(bars,fmt='%.1f',padding=3,fontsize=8)
        ax.set_title(title,fontsize=11);ax.set_ylim(0,92);ax.set_ylabel('%')
        ax.set_xticks(x,names,rotation=12,fontsize=8);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
        ax.spines[['top','right']].set_visible(False)
    axes[0,0].legend(frameon=False,fontsize=9)
    fig.suptitle('Source-only pixel-density control: same 16 scenes / 64 targets\nFrozen full-source thresholds; no weight updates; 1024 uses 4x input pixels',fontsize=12)
    fig.savefig(HERE/'源像素密度对照.png',dpi=200)
    fig.savefig(HERE/'源像素密度对照.svg')
    plt.close(fig)
    print(HERE/'源像素密度对照.png')


if __name__=='__main__':main()
