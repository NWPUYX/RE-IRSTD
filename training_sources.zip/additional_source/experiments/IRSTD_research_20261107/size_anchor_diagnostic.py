"""Native source-val diagnostic of GT-anchor versus detected-peak sizing."""
from collections import defaultdict
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.nn import functional as F

HOME=Path(__file__).resolve().parent; ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_t_size.model import TSizeModel, initialize
from irstd_v2.data import Data
from irstd_adapter import targets, model_config
from irstd_v2.settings import write_json, now


@torch.inference_mode()
def main():
    torch.set_num_threads(4); torch.backends.cudnn.benchmark=False
    path=HOME/"t_size_route_v1/best.pt"
    state=torch.load(path,map_location="cpu",weights_only=False)
    cfg=state["config"]["recipe"]; reference=state["config"]["size_reference_512"]
    model=TSizeModel(cfg).cuda().eval(); initialize(model,state["model"],reset_size=False)
    data=Data("DAUB-R","val",cfg); grouped=defaultdict(list)
    for i,r in enumerate(data.records): grouped[r["group"]].append(i)
    result={}
    for group,ids in grouped.items():
        errors=defaultdict(list)
        for j in np.linspace(0,len(ids)-1,32,dtype=int):
            sample=data[ids[j]]
            target=targets([sample],model_config(),reference,torch.device("cuda"),"shared_regression")
            out=model(sample["image"][None].cuda(),valid_mask=sample["valid_mask"][None].cuda())
            score=out["center_logits"][0,0].sigmoid()
            maxima=score==F.max_pool2d(score[None,None],3,1,1)[0,0]
            for k,(_,x,y) in enumerate(target["anchors"].cpu().tolist()):
                truth=target["sizes"][k]
                gt_error=(out["log_size"][0,:,y,x]-truth).abs().mean()
                left,right=max(0,x-6),min(512,x+7); top,bottom=max(0,y-6),min(512,y+7)
                local=score[top:bottom,left:right].masked_fill(~maxima[top:bottom,left:right],-1)
                flat=int(local.argmax()); py=top+flat//(right-left); px=left+flat%(right-left)
                peak_error=(out["log_size"][0,:,py,px]-truth).abs().mean()
                errors["GT_anchor_log_MAE"].append(float(gt_error))
                errors["local_detected_peak_log_MAE"].append(float(peak_error))
                errors["anchor_distance_input_px"].append(float(np.hypot(px-x,py-y)))
                errors["same_cell"].append(int(px==x and py==y))
        result[group]={key:{"mean":float(np.mean(values)),"q50":float(np.quantile(values,.5)),"q90":float(np.quantile(values,.9))} for key,values in errors.items()}
    output={"scope":"32 native source-val frames/group; highest local maximum before NMS, not deployable correction",
        "results":result,"updated_at":now()}
    write_json(HOME/"size_anchor_diagnostic.json",output); print(json.dumps(output,indent=2))


if __name__=="__main__": main()
