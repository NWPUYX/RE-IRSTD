"""Audit every source geometry plan before the bounded robust-T training."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import random
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_robust_t.run import recipe
from irstd_robust_t.data import RobustPairs
from irstd_geometry_balance.data import direction_plan
from irstd_v2.data import original_boxes
from irstd_v2.settings import write_json,now


def main():
    torch.set_num_threads(3);cfg=recipe();data=RobustPairs(cfg);epoch=1
    counts=Counter();cross=Counter();scales=[]
    for index,i in enumerate(data.indices):
        r=data.records[i];rng=random.Random(3407+epoch*1000003+i*97);flip=rng.random()<.5
        mode=(index+epoch)%3;factor=4 if (index//6+epoch)%2==0 else 16
        counts[(mode,factor)]+=1
        assert all(data.donors.records[j]['group']!=r['group'] for j in data.eligible[r['group']])
        if mode!=2:continue
        direction='shrink' if (index//3+epoch)%2 else 'enlarge'
        plan=direction_plan(r,cfg,rng,direction)
        if (plan['sx']<0)!=flip:plan={**plan,'sx':-plan['sx'],'tx':512-plan['tx']}
        assert not plan['fallback']
        assert (plan['requested_jitter']<1)==(direction=='shrink')
        boxes=original_boxes(r);boxes[:,[0,2]]=boxes[:,[0,2]]*plan['sx']+plan['tx'];boxes[:,[1,3]]=boxes[:,[1,3]]*plan['sy']+plan['ty']
        assert (boxes>=-1e-3).all() and (boxes<=512+1e-3).all()
        cross[(direction,factor)]+=1;scales.append(plan['requested_jitter'])
    assert len(data)==4181 and len(cross)==4 and min(cross.values())>0
    result={'passed':True,'source_records':len(data),'geometry_views':len(scales),
        'mode_noise_counts':{str(k):v for k,v in counts.items()},'direction_noise_cross':{str(k):v for k,v in cross.items()},
        'geometry_min_max':[min(scales),max(scales)],'all_geometry_labels_preserved':True,
        'data_sha256':hashlib.sha256((ROOT/'irstd_robust_t/data.py').read_bytes()).hexdigest(),'updated_at':now()}
    write_json(HERE/'robust_T_composed_v1/augmentation_plan_audit.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
