"""Source diagnostics with original-peak geometry throughout."""
import json
import numpy as np
import torch
from torch.utils.data import DataLoader
from anchor_preserving_decode import decode_raw
from evaluation import postprocess, match_frame, metrics
from irstd_adapter import targets, model_config
from irstd_background_center.data import loader, swapped_loader
from irstd_background_center.run import reference_threshold
from irstd_v2.data import collate
from source_mosaic_probe import Probe


@torch.inference_mode()
def evaluate(model, data_loader, device, reference, path=None):
    model.eval(); frames=[]; predictions=[]
    for images,samples in data_loader:
        valid=torch.stack([s['valid_mask'] for s in samples]).to(device)
        output=model(images.to(device),valid_mask=valid)
        proposals=decode_raw(output,reference)
        for proposal,sample in zip(proposals,samples):
            record=data_loader.dataset.records[sample['record_index']]
            pred=postprocess(proposal['raw'],record,sample['trans'])
            frames.append(match_frame(pred,record))
            for x,y,x2,y2,score in pred.tolist():
                predictions.append({'image_id':record['id'],'category_id':1,
                    'bbox':[x,y,x2-x,y2-y],'score':score})
    if path is not None:
        path.write_text(json.dumps({'frames':frames,'predictions':predictions},separators=(',',':')),encoding='utf-8')
    return frames


@torch.inference_mode()
def background_diagnostic(model,cfg,reference,device,folder,name):
    values=[];model.eval()
    for images,samples in loader(cfg,'val'):
        n=len(samples)//2;t=targets(samples,model_config(),reference,device,'shared_regression')
        out=model(images.to(device))['center_logits']
        for b in range(n):
            positive=t['positive'][b].bool()
            values.extend((out[b][positive]-out[b+n][positive]).square().cpu().tolist())
    frames=evaluate(model,swapped_loader(cfg),device,reference,folder/f'{name}_swapped_predictions.json')
    return {'GT_logit_pair_MSE':float(np.mean(values)),'targets':len(values),
        'swapped_metrics':metrics(frames,reference_threshold()),
        'scope':'fixed24-source-val-background diagnostic, not target test'}


@torch.inference_mode()
def evaluate_mosaics(model,cfg,reference,device,threshold):
    rows={};model.eval()
    for images,samples in DataLoader(Probe(cfg),batch_size=4,num_workers=cfg['workers'],collate_fn=collate):
        proposals=decode_raw(model(images.to(device)),reference)
        for proposal,sample in zip(proposals,samples):
            k=sample['k'];row=rows.setdefault(str(k),{'learned':[],'known_source_size':[]})
            for rule in row:
                raw=proposal['raw'].clone()
                if rule=='known_source_size':raw[:,2:4]=raw.new_tensor(reference)/k
                row[rule].append(match_frame(postprocess(raw,sample['record'],(1.,1.,0,0)),sample['record']))
    return {k:{rule:metrics(frames,threshold) for rule,frames in row.items()} for k,row in rows.items()}
