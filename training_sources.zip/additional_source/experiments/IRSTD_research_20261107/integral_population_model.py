"""Population-T model with numerically controlled annular evidence."""
from integral_evidence_prototype import IntegralEvidence
from irstd_population_t.model import PopulationTModel
from irstd_adapter import model_config


class IntegralPopulationModel(PopulationTModel):
    def __init__(self,recipe):
        super().__init__(recipe)
        self.evidence=IntegralEvidence(model_config()['model']['evidence'])
        assert sum(p.numel() for p in self.parameters())==808952
