"""Sequential source-train moment calibration, then fixed source-only screen."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
from collections import defaultdict
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from irstd_population_t.model import PopulationTModel
from native_unit_prior_evaluation import build, sha
from irstd_v2.data import Data, collate
from irstd_v2.evaluate import evaluate, validation_summary
from irstd_v2.settings import write_json, now, split_hashes
from irstd_background_center.data import loader as paired_loader, swapped_loader
from irstd_noise_center.data import validation_loader
from stable_evidence_source_cohort import NativeCohort
from evaluation import metrics
import benchmark_fastdecode as fast


@torch.inference_mode()
def main():
    home = HERE/'population_T_source_screen_v1'
    home.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    fast.install()
    parent_model, parent, recipe, checkpoint = build('irstd_robust')
    model = PopulationTModel(recipe).cuda().eval()
    missing, unexpected = model.load_state_dict(parent['model'], strict=False)
    assert not unexpected and len(missing) == 8 and all('population_' in k for k in missing)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    train = Data('DAUB-R', 'train', recipe)
    groups = defaultdict(list)
    for i, record in enumerate(train.records):
        groups[record['group']].append(i)
    indices = [ids[j] for ids in groups.values() for j in np.linspace(0, len(ids)-1, min(12, len(ids)), dtype=int)]
    identity = {'checkpoint_sha256': sha(checkpoint), 'script_sha256': sha(__file__),
        'model_module_sha256': sha(ROOT/'irstd_population_t/model.py'), 'split_hashes': split_hashes(),
        'source_calibration_indices': [int(i) for i in indices], 'source_calibration_record_ids': [train.records[i]['id'] for i in indices],
        'calibration_frames': len(indices), 'calibration_groups': sorted(groups), 'optimization_updates': 0,
        'source_population_only': True, 'role': 'locality calibration screen, not target test or SOTA confirmation'}
    if (home/'config.json').exists():
        assert json.loads((home/'config.json').read_text(encoding='utf-8')) == identity
    else:
        write_json(home/'config.json', identity)
    calibration = DataLoader(Subset(train, indices), batch_size=4, num_workers=2, collate_fn=collate)
    images, samples = next(iter(calibration))
    valid = torch.stack([s['valid_mask'] for s in samples]).cuda()
    before, replay = parent_model(images.cuda(), valid_mask=valid), model(images.cuda(), valid_mask=valid)
    assert all(torch.equal(value, replay[key]) for key, value in before.items()), 'live-GN replay failed'
    del parent_model, before, replay
    path = home/'calibrated.pt'
    if path.exists():
        calibrated = torch.load(path, map_location='cpu', weights_only=False)
        assert calibrated['config'] == identity
        model.load_state_dict(calibrated['model'], strict=True)
    else:
        for name, module in model.population_modules():
            total, squared, count = torch.zeros(module.num_groups, dtype=torch.float64), torch.zeros(module.num_groups, dtype=torch.float64), 0

            def capture(m, args):
                nonlocal total, squared, count
                x = args[0].float().reshape(len(args[0]), module.num_groups, -1)
                total += x.mean(2).sum(0).cpu().double()
                squared += x.square().mean(2).sum(0).cpu().double()
                count += len(x)

            handle = module.register_forward_pre_hook(capture)
            try:
                for images, samples in calibration:
                    model(images.cuda(), valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
            finally:
                handle.remove()
            assert count == len(indices)
            mean = total/count
            variance = (squared/count-mean.square()).clamp_min(0)
            module.population_mean.copy_(mean.float().cuda())
            module.population_variance.copy_(variance.float().cuda())
            module.use_population = True
            write_json(home/'progress.json', {'status': 'source_train_calibration', 'module': name, 'frames': count, 'updated_at': now()})
        torch.save({'model': model.state_dict(), 'config': identity}, path)
    assert sum(p.numel() for p in model.parameters()) == 808952
    assert all(torch.equal(v.cpu(), parent['model'][k]) for k, v in model.state_dict().items() if k in parent['model'])
    baseline = {}
    files = {'native': HERE/'stable_robust_source_cohort_v1/original_native_predictions.json',
             'background': HERE/'robust_T_composed_v1/epoch_01_swapped_predictions.json',
             'noise4': HERE/'robust_T_composed_v1/epoch_01_noise4_predictions.json',
             'noise16': HERE/'robust_T_composed_v1/epoch_01_noise16_predictions.json'}
    base_frames = {k: json.loads(p.read_text(encoding='utf-8'))['frames'] for k, p in files.items()}
    base_source = validation_summary(base_frames['native'])
    baseline = {k: metrics(frames, base_source['threshold']) for k, frames in base_frames.items()}
    results = {}
    for mode in ['T_only', 'T_final']:
        model.set_mode(final=mode == 'T_final')
        result = {}
        for view in ['native', 'background', 'noise4', 'noise16']:
            destination = home/f'{mode}_{view}_predictions.json'
            if destination.exists():
                frames = json.loads(destination.read_text(encoding='utf-8'))['frames']
            else:
                data = DataLoader(NativeCohort(recipe), batch_size=4, num_workers=2, collate_fn=collate) if view == 'native' else swapped_loader(recipe) if view == 'background' else validation_loader(recipe, int(view.removeprefix('noise')))
                frames = evaluate(model, data, torch.device('cuda'), parent['config']['size_reference_512'], destination)
            if view == 'native':
                threshold = validation_summary(frames)['threshold']
            result[view] = metrics(frames, threshold)
        errors = []
        for images, samples in paired_loader(recipe, 'val'):
            saved = []
            handle = model.backbone.target_path.register_forward_hook(lambda m, args, value: saved.append(value))
            try:
                model(images.cuda())
            finally:
                handle.remove()
            n = len(samples)//2
            for b in range(n):
                x, y = ((samples[b]['boxes'][0, :2]+samples[b]['boxes'][0, 2:])/2).floor().long().tolist()
                errors.append(float((saved[0][b, :, y, x]-saved[0][b+n, :, y, x]).square().mean()))
        result['T_pair_MSE'] = float(np.mean(errors))
        native = all(result['native'][k] >= baseline['native'][k]-.02 for k in ['AP50', 'AP50_95', 'F1'])
        background = result['background']['AP50'] >= baseline['background']['AP50']-.005 and result['background']['F1'] >= baseline['background']['F1']-.02
        noise4 = result['noise4']['AP50'] >= baseline['noise4']['AP50']-.005 and result['noise4']['F1'] >= baseline['noise4']['F1']
        noise16 = result['noise16']['AP50'] >= baseline['noise16']['AP50']-.005 and result['noise16']['F1'] >= baseline['noise16']['F1']+.10
        result['screen_gates'] = {'native_retained': native, 'background_retained': background,
                                 'noise4_retained': noise4, 'noise16_improved': noise16, 'T_locality': result['T_pair_MSE'] <= 1e-10}
        result['qualified'] = all(result['screen_gates'].values())
        results[mode] = result
        print(json.dumps({'mode': mode, **result}), flush=True)
    eligible = [(k, v) for k, v in results.items() if v['qualified']]
    selected = max(eligible, key=lambda p: (p[1]['native']['AP50'], np.mean([p[1][v]['F1'] for v in ['background', 'noise4', 'noise16']])))[0] if eligible else None
    assert all(torch.equal(v.cpu(), parent['model'][k]) for k, v in model.state_dict().items() if k in parent['model'])
    report = {'status': 'completed', 'baseline': baseline, 'results': results, 'selected': selected,
        'all_original_tensors_unchanged': True, 'original_live_replay_exact': True, 'parameters': 808952,
        'added_population_scalars': sum(m.population_mean.numel()+m.population_variance.numel() for _, m in model.population_modules()),
        'optimization_updates': 0, 'target_test_cells': 0, 'updated_at': now()}
    write_json(home/'result.json', report)
    write_json(home/'progress.json', {'status': 'completed', 'selected': selected, 'updated_at': now()})


if __name__ == '__main__':
    main()
