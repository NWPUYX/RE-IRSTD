"""Test effective zero-sum kernels through actual CUDA grouped convolutions."""
import json
from pathlib import Path
import sys
import torch
from torch.nn import functional as F

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_population_t.model import PopulationTModel
from irstd.models.blocks import REBlock
from irstd_v2.settings import write_json,now
from native_unit_prior_evaluation import sha


@torch.inference_mode()
def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    checkpoint=HERE/'scene_scale_sourceAP_control_v1/best.pt';state=torch.load(checkpoint,map_location='cpu',weights_only=False)
    model=PopulationTModel(state['config']['recipe']).cuda().eval();model.load_state_dict(state['model']);model.set_mode(final=False)
    results={}
    for name,module in model.named_modules():
        if not isinstance(module,REBlock):continue
        row={'algebraic_DC_max':max(float(k.sum((-2,-1)).abs().max()) for k in module.effective_kernels()),'CUDA_constant_response_max':{}}
        for side in [64,128,256,512]:
            feature=torch.ones(1,module.channels,side,side,device='cuda');values=[]
            for kernel,dilation in zip(module.effective_kernels(),module.dilations):
                response=F.conv2d(F.pad(feature,(dilation,)*4,mode='reflect'),kernel,dilation=dilation,groups=module.channels)
                assert torch.isfinite(response).all();values.append(float(response.abs().max()))
            row['CUDA_constant_response_max'][str(side)]=max(values)
        results[name]=row
    assert len(results)==14
    maximum=max(v for row in results.values() for v in row['CUDA_constant_response_max'].values())
    assert all(torch.equal(v.cpu(),state['model'][name]) for name,v in model.state_dict().items())
    result={'passed':maximum<=1e-6,'maximum_actual_CUDA_DC':maximum,'results':results,'checkpoint_sha256':sha(checkpoint),
        'cudnn_conv_fp32_precision':torch.backends.cudnn.conv.fp32_precision,'optimization_updates':0,
        'script_sha256':sha(__file__),'updated_at':now()}
    write_json(HERE/'effective_kernel_dc_cuda_audit.json',result)
    print(json.dumps({'passed':result['passed'],'maximum_actual_CUDA_DC':maximum,'blocks':len(results)}),flush=True)


if __name__=='__main__':main()
