"""Audit and freeze the two source-selected follow-up candidate families."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_t_size.model import TSizeModel
from p3_source_only import P3Route
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,split_hashes,now
from evaluation import metrics
from benchmark_cluster_bootstrap import cluster_ci
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',required=True,choices=['P3_zero_training_source_v1','P3_padding_review_v1','background_center_guarded_v1','background_center_interpolation_v1']);a=parser.parse_args()
    home=HERE/a.stage;folder=home/'frozen_four_domain_test';folder.mkdir(exist_ok=True)
    p3=a.stage.startswith('P3_')
    done=json.loads((home/('source_complete.json' if p3 else 'training_complete.json')).read_text(encoding='utf-8'));assert done['promotion_passed']
    state=torch.load(home/'best.pt',map_location='cpu',weights_only=False);cfg=state['config'];recipe=cfg['recipe']
    assert split_hashes()==cfg['split_hashes']
    for name,digest in cfg['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
    parent_path=HERE/'native_precision_w4_v1/best.pt';parent=torch.load(parent_path,map_location='cpu',weights_only=False)
    assert sha(parent_path)==cfg['parent_sha256']
    for name,value in state['model'].items():
        if p3 or not name.startswith('heads.center.'):assert torch.equal(value,parent['model'][name]),name
    zero_optimization=p3 or cfg.get('zero_extra_training',False)
    if not zero_optimization:
        last=torch.load(home/'last.pt',map_location='cpu',weights_only=False)
        assert len(last['optimizer']['state'])==4 and all(int(v['step'])==last['updates'] for v in last['optimizer']['state'].values())
    predictions=home/'best_source_val_predictions.json'
    if not predictions.exists():predictions=home/f"epoch_{state['epoch']:02d}_predictions.json"
    cached=json.loads(predictions.read_text(encoding='utf-8'))['frames'];assert validation_summary(cached)==state['source_validation']
    check=json.loads((HERE/'fastdecode_equivalence.json').read_text(encoding='utf-8'));assert check['passed'] and check['source_sha256']==sha(ROOT/'benchmark_fastdecode.py')
    assert json.loads((HERE/'bootstrap_equivalence.json').read_text(encoding='utf-8'))['passed']
    threshold=state['source_validation']['threshold'];source=cfg['source']
    targets=['IRSTD-UAV','IRDST-H','ITSDT-15K','DAUB-R'] if p3 else ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']
    manifest={'checkpoint_sha256':sha(home/'best.pt'),'source':source,'seed':cfg['seed'],'epoch':state['epoch'],'threshold':threshold,
        'split_hashes':split_hashes(),'script_sha256':sha(__file__),'decoder_helper_sha256':check['source_sha256'],
        'bootstrap_helper_sha256':sha(ROOT/'benchmark_cluster_bootstrap.py'),
        'progress_helper_sha256':sha(ROOT/'benchmark_progress.py'),
        'source_metrics_recalculated_exactly':True,'frozen_tensor_verification':True,'zero_extra_optimization':zero_optimization,
        'test_order':targets}
    write_json(home/'independent_audit.json',{'passed':True,**manifest,'updated_at':now()})
    if (folder/'freeze_manifest.json').exists():assert json.loads((folder/'freeze_manifest.json').read_text(encoding='utf-8'))==manifest
    else:write_json(folder/'freeze_manifest.json',manifest)
    fast.install();torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;device=torch.device('cuda')
    model=(P3Route if p3 else TSizeModel)(recipe).to(device);model.load_state_dict(state['model']);model.eval()
    for p in model.parameters():p.requires_grad_(False)
    rows=[]
    for target in targets:
        path=folder/f'{target}_metrics.json'
        if path.exists():result=json.loads(path.read_text(encoding='utf-8'))
        else:
            tick=time.perf_counter();write_json(folder/'progress.json',{'status':'evaluating','target':target,'updated_at':now()})
            data=ReportingLoader(make_loader(target,'test',recipe),folder/'progress.json',target)
            frames=evaluate(model,data,device,cfg['size_reference_512'],folder/f'{target}_predictions.json')
            overall=metrics(frames,threshold);ci=cluster_ci(frames)
            if ci is not None:overall['AP50_cluster_CI95']=ci
            result={'source':source,'target':target,'seed':cfg['seed'],'checkpoint_sha256':manifest['checkpoint_sha256'],
                'overall':overall,'by_group':{g:metrics([f for f in frames if f['group']==g],threshold) for g in sorted({f['group'] for f in frames})},
                'elapsed_seconds':time.perf_counter()-tick,'updated_at':now()}
            assert sha(home/'best.pt')==manifest['checkpoint_sha256'];write_json(path,result)
        rows.append(result);print(json.dumps({'target':target,**result['overall']}),flush=True)
    cross=[r['overall'] for r in rows if r['target']!=source]
    summary={'status':'completed','source':source,'seed':cfg['seed'],'completed_cells':len(rows),
        'cross_domain_macro':{k:sum(r[k] for r in cross)/3 for k in ['AP50','AP50_95','F1','center_Pd_3px']},'updated_at':now()}
    write_json(folder/'summary.json',summary);write_json(folder/'progress.json',summary)


if __name__=='__main__':main()
