"""One source inference per input, five predeclared logits readouts."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import json
from pathlib import Path
import sys
import torch
from torch.utils.data import DataLoader

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from local_readout_model import blend,IntegralReadoutModel,PopulationReadoutModel
from source_noise_geometry_probe import Clean
from anchor_preserving_decode import decode_raw
from irstd_scene_scale.run import locality_probe
from irstd_v2.data import collate
from irstd_noise_center.data import validation_loader
from irstd_background_center.data import swapped_loader
from irstd_v2.settings import write_json,now,split_hashes
from native_unit_prior_evaluation import sha
from evaluation import postprocess,match_frame,metrics
import benchmark_fastdecode as fast

HOME=HERE/'local_readout_screen_v1'
ENDPOINTS={'scene_E2':HERE/'scene_scale_joint_v1/epoch_02_ema.pt','integral_E1':HERE/'integral_joint_v1/epoch_01_ema.pt'}
WEIGHTS=[0.,.25,.5,.75,1.]


@torch.inference_mode()
def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    config={'script_sha256':sha(__file__),'helper_sha256':sha(HERE/'local_readout_model.py'),
        'decoder_sha256':sha(HERE/'anchor_preserving_decode.py'),'plan_sha256':sha(HERE/'T局部读出零训练筛查方案.md'),
        'checkpoint_sha256':{k:sha(p) for k,p in ENDPOINTS.items()},'weights':WEIGHTS,'split_hashes':split_hashes(),
        'optimization_updates':0,'target_frames':0}
    path=HOME/'config.json'
    if path.exists():assert json.loads(path.read_text(encoding='utf-8'))==config
    else:write_json(path,config)
    if (HOME/'result.json').exists():return
    noise=json.loads((HERE/'noise_validation_diagnostic/baseline.json').read_text(encoding='utf-8'))['results']
    bg=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    results={}
    for name,path in ENDPOINTS.items():
        state=torch.load(path,map_location='cpu',weights_only=False);cfg={**state['config']['recipe'],'local_readout_weight':0.}
        cls=IntegralReadoutModel if name.startswith('integral') else PopulationReadoutModel
        model=cls(cfg).cuda().eval();model.load_state_dict(state['model'],strict=True);model.set_mode(final=False)
        assert sum(p.numel() for p in model.parameters())==808952
        for p in model.parameters():p.requires_grad_(False)
        threshold=state['source_validation']['threshold'];reference=state['config']['size_reference_512']
        cohorts={str(a):{} for a in WEIGHTS}
        for view in ['clean','noise4','noise16','swapped']:
            loader=DataLoader(Clean(cfg),batch_size=4,num_workers=2,collate_fn=collate) if view=='clean' else (
                swapped_loader(cfg) if view=='swapped' else validation_loader(cfg,int(view.removeprefix('noise'))))
            frames={str(a):[] for a in WEIGHTS}
            for images,samples in loader:
                out=model(images.cuda(),valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
                assert blend(out,0.) is out
                for a in WEIGHTS:
                    modified=blend(out,a)
                    assert modified['log_size'] is out['log_size'] and modified['offsets'] is out['offsets']
                    for proposal,sample in zip(decode_raw(modified,reference),samples):
                        record=loader.dataset.records[sample['record_index']]
                        frames[str(a)].append(match_frame(postprocess(proposal['raw'],record,sample['trans']),record))
            for a in WEIGHTS:
                key=str(a);cohorts[key][view]=metrics(frames[key],threshold)
                write_json(HOME/f'{name}_a{key}_{view}_frames.json',{'frames':frames[key]})
            print(json.dumps({'endpoint':name,'view':view,'AP50':{a:cohorts[a][view]['AP50'] for a in cohorts}}),flush=True)
        for factor in [4,16]:assert cohorts['0.0'][f'noise{factor}']['AP50']==state['noise'][str(factor)]['box']['AP50']
        locality=locality_probe(model,cfg,'cuda')
        for a,row in cohorts.items():
            row['T_pair_MSE']=locality
            row['prescreen']={'clean_AP_retained':row['clean']['AP50']>=cohorts['0.0']['clean']['AP50']-.02,
                'noise4_AP_retained':row['noise4']['AP50']>=noise['4']['box']['AP50']-.005,
                'noise16_AP_plus2pp':row['noise16']['AP50']>=noise['16']['box']['AP50']+.02,
                'background_AP_retained':row['swapped']['AP50']>=bg['swapped_metrics']['AP50'],'T_locality':locality<=1e-10}
            row['prescreen_passed']=all(row['prescreen'].values());results[f'{name}/{a}']=row
        assert all(torch.equal(v.cpu(),state['model'][n]) for n,v in model.state_dict().items())
        assert sha(path)==config['checkpoint_sha256'][name]
        write_json(HOME/'partial.json',{'results':results,'updated_at':now()})
        del model;torch.cuda.empty_cache()
    eligible=[(key,row) for key,row in results.items() if row['prescreen_passed']]
    winner=max(eligible,key=lambda item:(item[1]['clean']['AP50'],item[1]['noise16']['AP50'],-float(item[0].split('/')[-1])))[0] if eligible else None
    result={'status':'completed','results':results,'selected_for_full_source_validation':winner,
        'all_tensors_unchanged':True,'optimization_updates':0,'target_frames':0,'updated_at':now()}
    write_json(HOME/'result.json',result);print(json.dumps({'selected':winner,'passed':[key for key,row in eligible]}),flush=True)


if __name__=='__main__':main()
