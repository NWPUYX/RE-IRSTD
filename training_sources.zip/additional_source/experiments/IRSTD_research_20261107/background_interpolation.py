"""If needed, reduce head drift using source-selected weights without new training."""
import copy
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_background_center.run import background_diagnostic,native_gates
from irstd_t_size.model import TSizeModel
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast

PARENT=HERE/'background_center_guarded_v1'
HOME=HERE/'background_center_interpolation_v1'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    global HOME
    parser=argparse.ArgumentParser();parser.add_argument('--refine',action='store_true');args=parser.parse_args()
    alphas=[.25,.5,.75]
    if args.refine:
        coarse=json.loads((HOME/'training_complete.json').read_text(encoding='utf-8'))
        assert not coarse['promotion_passed']
        HOME=HERE/'background_center_interpolation_refine_v1';alphas=[.28125,.3125,.375]
    done=json.loads((PARENT/'training_complete.json').read_text(encoding='utf-8'))
    HOME.mkdir(exist_ok=True)
    if done['promotion_passed']:
        write_json(HOME/'skipped.json',{'reason':'Original two-epoch stage passed; no interpolation needed','updated_at':now()});return
    assert not (HOME/'training_complete.json').exists()
    write_json(HOME/'plan.json',{'source_only':True,'training_updates':0,'alphas':alphas,
        'selection':'first smallest update passing unchanged background and native gates',
        'reason':'refine the coarse0.25-to0.5 bracket using source constraints only' if args.refine else 'coarse source-only grid',
        'updated_at':now()})
    torch.set_num_threads(3);torch.backends.cudnn.benchmark=False;fast.install();device=torch.device('cuda')
    native=torch.load(HERE/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)
    trained=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False)
    assert trained['config']['split_hashes']==split_hashes()
    for name,digest in trained['config']['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
    for name,value in trained['model'].items():
        if not name.startswith('heads.center.'):assert torch.equal(value,native['model'][name]),name
    baseline=json.loads((PARENT/'background_baseline.json').read_text(encoding='utf-8'))
    reference=trained['config']['size_reference_512'];rows=[];selected=None
    # Minimal native-head departure first. Cheap background screening precedes
    # any full source validation; no target predictions are used.
    for alpha in alphas:
        cfg=copy.deepcopy(trained['config']['recipe']);cfg['name']=HOME.name
        state={name:torch.lerp(native['model'][name],value,alpha) if name.startswith('heads.center.') else value
            for name,value in trained['model'].items()}
        model=TSizeModel(cfg).to(device).eval();model.load_state_dict(state)
        for p in model.parameters():p.requires_grad_(False)
        label=f'alpha_{alpha}';write_json(HOME/'progress.json',{'status':'background_source_screen','alpha':alpha,'updated_at':now()})
        bg=background_diagnostic(model,cfg,reference,device,HOME,label)
        screen=bg['GT_logit_pair_MSE']<=baseline['GT_logit_pair_MSE']*.8 and bg['swapped_metrics']['AP50']>=baseline['swapped_metrics']['AP50']
        row={'alpha':alpha,'background':bg,'background_screen_passed':screen,'zero_extra_training':True}
        if screen:
            pred_path=HOME/f'{label}_source_predictions.json'
            frames=evaluate(model,ReportingLoader(make_loader('DAUB-R','val',cfg),HOME/'progress.json','source_val'),device,reference,pred_path)
            row.update(epoch=trained['epoch'],source_validation=validation_summary(frames),geometry_probe=native['geometry_probe'],per_scale=native['per_scale'])
            row['gates']=native_gates(row,native,baseline)
            if all(row['gates'].values()):
                identity=copy.deepcopy(trained['config']);identity.update(recipe=cfg,zero_extra_training=True,head_interpolation_alpha=alpha,
                    interpolated_checkpoint_sha256=sha(PARENT/'best.pt'))
                identity['source_hashes'][str(Path(__file__).relative_to(ROOT.parent))]=sha(__file__)
                identity['source_hashes'][str((ROOT/'benchmark_progress.py').relative_to(ROOT.parent))]=sha(ROOT/'benchmark_progress.py')
                save_checkpoint(HOME/'best.pt',{**row,'model':model.state_dict(),'config':identity});write_json(HOME/'config.json',identity)
                shutil.copyfile(pred_path,HOME/'best_source_val_predictions.json');selected=alpha
        write_json(HOME/f'{label}_result.json',row);rows.append(row);print(json.dumps(row),flush=True)
        del model
        if selected is not None:break
    final={'status':'completed_without_extra_training','promotion_passed':selected is not None,'selected_alpha':selected,
        'training_updates':0,'target_test_cells':0,'results':rows,'updated_at':now()}
    write_json(HOME/'training_complete.json',final);write_json(HOME/'progress.json',final)


if __name__=='__main__':main()
