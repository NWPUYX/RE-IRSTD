"""Finish the already-running bounded source experiment, then gated evaluation."""
import json
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];HOME=HERE/'locked_peak_readout_v1'


def run(script,log,*args):
    with (HERE/log).open('a',encoding='utf-8') as stream:
        subprocess.run([sys.executable,str(HERE/script),*args],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)


def main():
    deadline=time.monotonic()+1200
    while not (HOME/'source_complete.json').exists():
        log=HERE/'locked_readout_source.log'
        if log.exists() and 'Traceback (most recent call last)' in log.read_text(encoding='utf-8'):
            raise RuntimeError('source stage failed; inspect locked_readout_source.log')
        if time.monotonic()>deadline:raise TimeoutError('source stage did not finish in20 minutes')
        time.sleep(5)
    done=json.loads((HOME/'source_complete.json').read_text(encoding='utf-8'))
    if done.get('reason')=='no_prescreen_candidate':
        print(json.dumps({'status':'source_prescreen_failed','target_tests_started':False}),flush=True);return
    run('locked_readout_source.py','locked_readout_audit.log','--audit')
    audit=json.loads((HOME/'independent_audit.json').read_text(encoding='utf-8'));assert audit['passed']
    if audit['promotion_passed']:run('evaluate_locked_readout.py','locked_readout_frozen_test.log')
    print(json.dumps({'status':'completed','promotion_passed':audit['promotion_passed'],
        'target_tests_started':audit['promotion_passed']}),flush=True)
    subprocess.run([sys.executable,str(HERE/'update_progress_report.py')],cwd=ROOT,check=False)


if __name__=='__main__':main()
