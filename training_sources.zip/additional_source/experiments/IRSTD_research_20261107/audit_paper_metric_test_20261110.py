"""Audit frozen primary metrics and paired scene uncertainty; zero new training."""
import json
from pathlib import Path
import sys
import numpy as np
import torch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from consistent_teacher_training import identity,sha
from evaluation import metrics
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import split_hashes,write_json,now
from benchmark_cluster_bootstrap import prepared,weighted_ap

HOME=HERE/'paper_metric_review_consistent_teacher_v1'
DOMAINS=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']
KEYS=['AP50','AP50_95','Precision','Recall','F1','FP_per_frame','center_Pd_3px']
BASELINES={
    'AA-YOLO':(ROOT/'runs/AA-YOLO/DAUB-R/seed_3407','test_','单帧主对照'),
    'YOLO26n-P2':(HERE/'yolo26n_p2_DAUB_3407/frozen_four_domain_test','','单帧主对照'),
    'SSTNet':(ROOT/'runs/SSTNet/DAUB-R/seed_3407','test_','五帧额外对照'),
    'STMENet':(ROOT/'runs/STMENet/DAUB-R/seed_3407','test_','五帧额外对照'),
    'LASNet':(ROOT/'runs/LASNet/DAUB-R/seed_3407','test_','五帧额外对照'),
    'MPR-Net':(HERE/'mpr_causal_DAUB_3407/frozen_four_domain_test','','多帧及CLIP额外对照')}


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def avg(rows):return {k:sum(r[k] for r in rows)/len(rows) for k in KEYS}
def fmt(m):return ' | '.join(f"{m[k]:.5f}" if k=='FP_per_frame' else f"{m[k]*100:.4f}%" for k in KEYS)


def f1_table(frames,threshold,names):
    index={g:i for i,g in enumerate(names)};table=np.zeros((len(names),3),dtype=np.int64)
    for frame in frames:
        keep=np.asarray(frame['scores'])>=threshold
        tp=np.asarray(frame['tp'],dtype=bool).reshape(-1,10)[:,0]
        table[index[frame['group']]] += [tp[keep].sum(),keep.sum(),frame['gt']]
    return table


def paired_macro(left,right,threshold_left,threshold_right,draws=1000):
    rng=np.random.default_rng(3407);statistics=[];point=[]
    for domain in DOMAINS[1:]:
        a,b=left[domain],right[domain]
        assert len(a)==len(b) and all((x['group'],x['gt'])==(y['group'],y['gt']) for x,y in zip(a,b))
        names=sorted({f['group'] for f in a})
        assert len(names)>1
        statistics.append((prepared(a,names),prepared(b,names),f1_table(a,threshold_left,names),
            f1_table(b,threshold_right,names),len(names)))
        ma,mb=metrics(a,threshold_left),metrics(b,threshold_right)
        point.append((ma['AP50']-mb['AP50'],ma['F1']-mb['F1']))
    values=[]
    for _ in range(draws):
        delta=[]
        for a,b,fa,fb,n in statistics:
            counts=np.bincount(rng.integers(0,n,n),minlength=n)
            def f1(table):
                hit,predicted,gt=counts@table
                return 2*hit/(predicted+gt) if predicted+gt else 0.
            delta.append((weighted_ap(a,counts)-weighted_ap(b,counts),f1(fa)-f1(fb)))
        values.append(np.mean(delta,axis=0))
    ci=np.quantile(values,[.025,.975],axis=0)
    return {'draws':draws,'seed':3407,'unit':'scene groups resampled within each fixed domain; equal-domain macro',
        'AP50_delta':float(np.mean(point,axis=0)[0]),'F1_delta':float(np.mean(point,axis=0)[1]),
        'AP50_delta_CI95':ci[:,0].tolist(),'F1_delta_CI95':ci[:,1].tolist(),
        'scope':'conditional on these trained checkpoints and development test set; excludes training-seed/search uncertainty'}


def main():
    torch.set_num_threads(2)
    output=HOME/'independent_test_audit.json'
    checkpoint=HERE/'consistent_teacher_v1/best.pt';manifest=read(HOME/'freeze_manifest.json')
    summary=read(HOME/'summary.json');source_proof=read(HERE/'consistent_teacher_v1/independent_audit.json')
    bound,_=identity();state=torch.load(checkpoint,map_location='cpu',weights_only=False)
    assert source_proof['passed'] and source_proof['checkpoint_sha256']==sha(checkpoint)==manifest['checkpoint_sha256']
    assert state['config']==bound and manifest['split_hashes']==split_hashes()
    assert manifest['audit_sha256']==sha(HERE/'consistent_teacher_v1/independent_audit.json')
    assert manifest['source_predictions_sha256']==sha(HERE/'consistent_teacher_v1/best_source_val_predictions.json')
    assert manifest['script_sha256']==sha(HERE/'evaluate_paper_metric_review_v1.py')
    assert manifest['plan_sha256']==sha(HERE/'论文主指标审查测试冻结方案_20261110.md')
    assert manifest['source_gates']==state['gates']
    frames=read(HERE/'consistent_teacher_v1/best_source_val_predictions.json')['frames']
    assert validation_summary(frames)==state['source_validation'] and len(frames)==1801
    threshold=state['source_validation']['threshold'];assert manifest['threshold']==threshold==summary['threshold']
    latest={};rows=[];cells=[]
    for domain in DOMAINS:
        path=HOME/f'{domain}_predictions.json';latest[domain]=read(path)['frames']
        saved=read(HOME/f'{domain}_metrics.json');actual=metrics(latest[domain],threshold)
        assert all(v==saved['overall'][k] for k,v in actual.items())
        records=read(ROOT/f'splits/{domain}_test.json')
        assert actual['frames']==len(records) and actual['ground_truth']==sum(len(r['boxes']) for r in records)
        for group,value in saved['by_group'].items():
            assert metrics([f for f in latest[domain] if f['group']==group],threshold)==value
        rows.append({'model':'IRSTD最新候选','role':'单帧','domain':domain,'metrics':actual})
        cells.append({'domain':domain,'predictions_sha256':sha(path),'metrics_sha256':sha(HOME/f'{domain}_metrics.json')})
    macro=avg([r['metrics'] for r in rows if r['domain']!='DAUB-R'])
    for key,value in summary['cross_domain_macro'].items():np.testing.assert_allclose(value,macro[key],rtol=0,atol=1e-15)
    assert summary['all_tensors_unchanged'] and summary['completed_cells']==4
    macros={'IRSTD最新候选':{'role':'单帧','metrics':macro}};pairs={}
    for name,(folder,prefix,role) in BASELINES.items():
        baseline_frames={};baseline_metrics=[];thresholds=[];paths=[]
        for domain in DOMAINS:
            path=folder/f'{prefix}{domain}_predictions.json';values=read(folder/f'{prefix}{domain}_metrics.json')['overall']
            rows.append({'model':name,'role':role,'domain':domain,'metrics':values})
            if domain!='DAUB-R':
                baseline_metrics.append(values);thresholds.append(values['threshold'])
                if name in ['AA-YOLO','YOLO26n-P2']:
                    baseline_frames[domain]=read(path)['frames'];paths.append(sha(path))
                    actual=metrics(baseline_frames[domain],values['threshold'])
                    assert all(v==values[k] for k,v in actual.items())
        assert len(set(thresholds))==1
        macros[name]={'role':role,'metrics':avg(baseline_metrics)}
        if baseline_frames:
            pairs[name]={**paired_macro(latest,baseline_frames,threshold,thresholds[0]),'baseline_predictions_sha256':paths}
        print(json.dumps({'compared':name,'macro':macros[name],'paired':pairs.get(name)}),flush=True)
    result={'passed':True,'checkpoint_sha256':sha(checkpoint),'all_four_domain_metrics_recomputed':True,
        'fixed_threshold':threshold,'test_cells':cells,'cross_domain_macros':macros,'paired_macro_comparisons':pairs,
        'domain_rows':rows,'optimization_updates':0,'inference_reruns':0,'source_gates_retained':state['gates'],
        'script_sha256':sha(__file__),'updated_at':now()}
    write_json(output,result)
    lines=['# 论文主指标四域测试：验证效果与同条件比较','',f'[COMPUTED｜HIGH] {now()}：四域测试完成，预测缓存总体/分组指标、帧数与GT数、源阈值、检查点/代码/划分指纹及汇总独立审查通过。没有新增训练或推理重跑。',
        '', '[KNOWN｜HIGH] 所有当前行均为DAUB-R训练、seed3407、固定512、原学习尺寸规则。IRSTD使用正确FP64积分证据，固定主峰/框与a0.25 T重评分；阈值0.5791078209877014在完整源验证确定，目标域不再选阈值。',
        '', '| 模型 | 输入信息角色 | 跨域AP50 | 跨域AP50:95 | P | R | F1 | FP/帧 | 中心Pd3px |',
        '|---|---|---:|---:|---:|---:|---:|---:|---:|']
    for name,item in macros.items():lines.append(f"| {name} | {item['role']} | {fmt(item['metrics'])} |")
    lines+=['', '[COMPUTED｜HIGH] 新候选在当前两个单帧主对照上同时取得更高的跨域宏AP50、AP50:95和F1。宏FP/帧没有优于AA-YOLO，且不是每个目标域都领先。多帧模型仅作附加对照。',
        '', '| 模型 | 测试域 | AP50 | AP50:95 | P | R | F1 | FP/帧 | 中心Pd3px |',
        '|---|---|---:|---:|---:|---:|---:|---:|---:|']
    for row in rows:lines.append(f"| {row['model']} | {row['domain']} | {fmt(row['metrics'])} |")
    lines+=['', '[COMPUTED｜HIGH] 以下区间为1000次域内场景组配对重采样、三个域等权宏差值，单位为百分点。阈值固定；没有重新训练，不能代替多随机种子的稳定性证据。',
        '', '| IRSTD减对照 | AP50差值 | AP50差值95%区间 | F1差值 | F1差值95%区间 |','|---|---:|---|---:|---|']
    for name,item in pairs.items():
        ci=lambda key:f"[{item[key][0]*100:.4f}, {item[key][1]*100:.4f}]"
        lines.append(f"| {name} | {item['AP50_delta']*100:.4f} | {ci('AP50_delta_CI95')} | {item['F1_delta']*100:.4f} | {ci('F1_delta_CI95')} |")
    lines+=['', '[KNOWN｜HIGH] 这是15/18源内部条件下另立的主指标复核；三项内部失败保留，不据此否认已观察到的跨域提升，也不将其改成原18项晋级成功。',
        '[INFERRED｜HIGH] 可以开始基于真实结果的论文初稿，并冻结本候选作为稳定性与消融的起点。优先补充随机种子、三个机制的同配方消融、其他训练源与匹配训练预算。现有单源单种子、已参与开发的测试结果，支持“本协议已完成对照上的领先”，尚不足以写成全面SOTA或独立最终确认。']
    destination=ROOT/'results/IRSTD论文主指标测试结果_20261110.md'
    destination.write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps({'passed':True,'report':str(destination),'latest_macro':macro,'paired':pairs}),flush=True)


if __name__=='__main__':main()
