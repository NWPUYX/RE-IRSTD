"""Report completed matched unit-prior cells without selecting test thresholds."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from benchmark_cluster_bootstrap import paired_ci
from irstd_v2.settings import now, write_json

STAGES = {
    'v1_native': 'native_unit_irstd_v1_native_constant_v1',
    'robust_native': 'native_unit_irstd_robust_native_constant_v1',
    'robust_input': 'native_unit_irstd_robust_input_constant_v1',
    'robust_residual': 'native_unit_irstd_robust_native_residual_v1',
    'stable_native': 'native_unit_irstd_stable_native_constant_v1',
    'mpr_native': 'native_unit_mpr_native_constant_v1',
    'yolo_native': 'native_unit_yolo26_native_constant_v1',
    'aa_yolo_native': 'native_unit_aa_yolo_native_constant_v1',
}
DOMAINS = ['DAUB-R', 'IRDST-H', 'IRSTD-UAV', 'ITSDT-15K']


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def diagnostic(frames, threshold):
    total = sum(f['gt'] for f in frames)
    counts = dict(box_any=0, box_at_threshold=0, center_any=0,
                  center_at_threshold=0, top1_box=0)
    positive_scores = []
    for frame in frames:
        score = np.asarray(frame['scores'])
        box = np.asarray(frame['tp'], dtype=bool).reshape(-1, 10)[:, 0]
        center = np.asarray(frame['center_tp'], dtype=bool)
        assert len(score) == len(box) == len(center)
        keep = score >= threshold
        counts['box_any'] += int(box.sum())
        counts['box_at_threshold'] += int(box[keep].sum())
        counts['center_any'] += int(center.sum())
        counts['center_at_threshold'] += int(center[keep].sum())
        counts['top1_box'] += int(box[0]) if len(box) else 0
        positive_scores.extend(score[box].tolist())
    return {'ground_truth': total, 'matched_counts': counts,
            'recall': {k: v / total if total else None for k, v in counts.items()},
            'matched_box_score_quantiles_10_50_90': np.quantile(positive_scores, [.1, .5, .9]).tolist() if positive_scores else [],
            'interpretation': 'unchanged proposal cap/floor and greedy matching; no oracle threshold search'}


def main():
    output = HERE / 'native_unit_diagnostic_report'
    output.mkdir(exist_ok=True)
    rows, paired = [], []
    for key, stage in STAGES.items():
        folder = HERE / stage / 'frozen_four_domain_test'
        for target in DOMAINS:
            path = folder / f'{target}_metrics.json'
            if not path.exists():
                continue
            prediction = folder / f'{target}_predictions.json'
            metric = read(path)['overall']
            cache = output / f'{key}_{target}_diagnostic.json'
            digest = sha(prediction)
            if cache.exists() and read(cache)['prediction_sha256'] == digest:
                diag = read(cache)['diagnostic']
            else:
                diag = diagnostic(read(prediction)['frames'], metric['threshold'])
                assert abs(diag['recall']['box_at_threshold'] - metric['Recall']) < 1e-12
                assert abs(diag['recall']['center_at_threshold'] - metric['center_Pd_3px']) < 1e-12
                write_json(cache, {'prediction_sha256': digest, 'diagnostic': diag})
            rows.append({'model': key, 'target': target, 'overall': metric, 'diagnostic': diag})
    for left, right in [('robust_native', 'v1_native'), ('robust_native', 'robust_input'),
                        ('robust_residual', 'robust_native'),
                        ('robust_native', 'mpr_native'), ('robust_native', 'yolo_native'),
                        ('robust_native', 'aa_yolo_native'),
                        ('stable_native', 'robust_native')]:
        for target in DOMAINS:
            paths = [HERE / STAGES[k] / 'frozen_four_domain_test' / f'{target}_predictions.json' for k in [left, right]]
            if not all(p.exists() and p.with_name(f'{target}_metrics.json').exists() for p in paths):
                continue
            digests = [sha(p) for p in paths]
            cache = output / f'{left}_minus_{right}_{target}_paired.json'
            if cache.exists() and read(cache)['prediction_sha256'] == digests:
                pair = read(cache)
            else:
                a, b = [read(p)['frames'] for p in paths]
                pair = {'left': left, 'right': right, 'target': target, 'prediction_sha256': digests,
                        'paired_cluster_AP50_delta_CI95': paired_ci(a, b), 'draws': 200, 'seed': 3407}
                write_json(cache, pair)
            paired.append(pair)
    summary = {'updated_at': now(), 'rows': rows, 'paired_comparisons': paired,
               'scope': 'DAUB-R source, seed3407 development diagnostics; source-frozen thresholds, not independent SOTA confirmation'}
    write_json(output / 'summary.json', summary)
    lines = ['# 原图单位先验：公平对照与剩余误差', '',
             '[KNOWN｜HIGH] 仅汇总已完成单元。全部训练源为DAUB-R，种子3407；阈值由各自完整源验证冻结。native为原图8×8先验，input为输入16×16先验。所有先验来自源训练。', '',
             '| 模型 | 目标域 | AP50 | AP50:95 | F1 | 框召回@源阈值 | 框召回@候选下限 | 中心召回@候选下限 |',
             '|---|---|---:|---:|---:|---:|---:|---:|']
    for row in rows:
        m, d = row['overall'], row['diagnostic']['recall']
        lines.append(f"| {row['model']} | {row['target']} | {m['AP50']*100:.4f}% | {m['AP50_95']*100:.4f}% | {m['F1']*100:.4f}% | {m['Recall']*100:.4f}% | {d['box_any']*100:.4f}% | {d['center_any']*100:.4f}% |")
    lines += ['', '[COMPUTED｜HIGH] 以下为同一目标域场景组的200次成对bootstrap AP50差值区间（百分点）；不替代训练随机种子分析。', '',
              '| 左侧减右侧 | 目标域 | AP50差值95%区间(pp) |', '|---|---|---|']
    for pair in paired:
        ci = pair['paired_cluster_AP50_delta_CI95']
        text = f'[{ci[0]*100:.4f}, {ci[1]*100:.4f}]' if ci is not None else '组数不足'
        lines.append(f"| {pair['left']} − {pair['right']} | {pair['target']} | {text} |")
    lines += ['', '[KNOWN｜HIGH] 候选下限为原协议1e-5，仍受统一前1000/后100候选和NMS约束。框与中心的贪心匹配分别计算，不能将两者差值直接解释成互斥错误类别。未使用目标标签寻找更优阈值。', '',
              '[KNOWN｜HIGH] constant版本旁路尺寸头，属于显式诊断偏离；改善不能直接归于三项核心创新。MPR-Net同时使用多帧和预训练文本信息，YOLO26为本协议从头重训而非作者默认配方。所有结果尚不足以证明达到当前SOTA。']
    (HERE / '原图单位先验公平对照结果.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({'completed_rows': len(rows), 'paired_rows': len(paired)}), flush=True)


if __name__ == '__main__':
    main()
