"""Explicit diagnostic control selected by source AP; not a mechanism promotion."""
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now
from irstd_v2.train import save_checkpoint
from irstd_geometry_repair.run import baseline
from irstd_robust_t.run import sha


def main():
    parent_home=HERE/'robust_T_composed_v1';home=HERE/'robust_T_sourceAP_control_v1';home.mkdir(exist_ok=True)
    parent=torch.load(parent_home/'best.pt',map_location='cpu',weights_only=False)
    audit=json.loads((parent_home/'independent_audit.json').read_text(encoding='utf-8'))
    assert audit['passed'] and audit['checkpoint_sha256']==sha(parent_home/'best.pt')
    keys=['macro_AP50_original','pooled_AP50_original','native_F1_parent','fine_AP95_parent_and_v1',
        'source_geometry_error_improved','enlarge_original']
    primary={k:parent['gates'][k] for k in keys};assert all(primary.values())
    table={'v1':baseline()['validation']['pooled']['AP50']}
    hashes={}
    for stage in ['native_precision_w4_v1','background_center_interpolation_refine_v1','robust_T_composed_v1']:
        path=HERE/stage/'best.pt';s=torch.load(path,map_location='cpu',weights_only=False)
        table[stage]=s['source_validation']['pooled']['AP50'];hashes[stage]=sha(path)
    assert table['robust_T_composed_v1']==max(table.values())
    frames=json.loads((parent_home/'epoch_01_predictions.json').read_text(encoding='utf-8'))['frames']
    assert validation_summary(frames)==parent['source_validation']
    cfg={**parent['config'],'parent_sha256':sha(parent_home/'best.pt'),'control_name':home.name,
        'additional_optimization_updates':0,'role':'source-AP-selected frozen diagnostic control, not mechanism-qualified promotion',
        'selection_table_AP50':table,'selection_checkpoint_hashes':hashes,
        'source_hashes':{**parent['config']['source_hashes'],str(Path(__file__).relative_to(ROOT.parent)):sha(__file__)},
        'parent_audit_sha256':sha(parent_home/'independent_audit.json')}
    control={**parent,'config':cfg,'gates':primary,'mechanism_gates':parent['gates'],'mechanism_promotion_passed':False}
    if (home/'best.pt').exists():
        saved=torch.load(home/'best.pt',map_location='cpu',weights_only=False)
        assert saved['config']==cfg and saved['source_validation']==parent['source_validation']
        assert all(torch.equal(v,parent['model'][n]) for n,v in saved['model'].items())
    else:save_checkpoint(home/'best.pt',control);write_json(home/'config.json',cfg)
    write_json(home/'source_complete.json',{'status':'completed','promotion_passed':False,'primary_source_quality_passed':True,
        'mechanism_promotion_passed':False,'eligible_for_diagnostic_test':True,'optimization_updates':0,
        'primary_gates':primary,'failed_mechanism_gates':[k for k,v in parent['gates'].items() if not v],
        'selection_table_AP50':table,'updated_at':now()})
    result={'passed':True,'promotion_passed':False,'eligible_for_diagnostic_test':True,
        'role':cfg['role'],'checkpoint_sha256':sha(home/'best.pt'),'all_tensors_equal_parent':True,
        'source_metrics_recalculated':True,'primary_gates':primary,'updated_at':now()}
    write_json(home/'independent_audit.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
