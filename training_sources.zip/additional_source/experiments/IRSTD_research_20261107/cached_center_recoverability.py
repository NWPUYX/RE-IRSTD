"""Incremental head-only source probe on already cached feature patches."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.nn import functional as F

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_t_size.model import TSizeModel
from classification_feature_probe import ap
from irstd_v2.settings import write_json,now


def logits(head,x):
    first,last=head[0],head[2]
    return F.linear(F.silu(F.linear(x,first.weight.flatten(1),first.bias)),last.weight.flatten(1),last.bias).flatten()


def summary(scores,y,fit,factors,threshold):
    result={}
    for split,mask in [('fit',fit),('incremental_holdout',~fit)]:
        result[split]={}
        for factor in [0,4,16]:
            selected=mask&(factors==factor);labels=y[selected];values=scores[selected]
            positive=labels>0
            result[split][str(factor)]={'proxy_AP':ap(values,labels),'positive_points':int(positive.sum()),
                'positive_score_mean':float(torch.sigmoid(torch.tensor(values[positive])).mean()),
                'positive_fraction_at_parent_threshold':float((values[positive]>=np.log(threshold/(1-threshold))).mean()),
                'false_positive_points_at_parent_threshold':int(((~positive)&(values>=np.log(threshold/(1-threshold)))).sum())}
    return result


def main():
    torch.set_num_threads(4);torch.manual_seed(3407)
    folder=HERE/'classification_noise_probe';features=np.load(folder/'features.npz')
    x=torch.tensor(features['fused'],dtype=torch.float32);y=torch.tensor(features['y'],dtype=torch.float32)
    fit=torch.tensor(features['fit'],dtype=torch.bool)
    meta=json.loads((folder/'metadata.json').read_text(encoding='utf-8'));factors=np.array([r['factor'] for r in meta])
    parent=HERE/'background_center_interpolation_refine_v1/best.pt';state=torch.load(parent,map_location='cpu',weights_only=False)
    model=TSizeModel(state['config']['recipe']);model.load_state_dict(state['model']);head=copy.deepcopy(model.heads.center)
    with torch.no_grad():initial=logits(head,x)
    cached=torch.tensor(features['main_scores'],dtype=torch.float32)
    with torch.no_grad():conv=head(x[:32].reshape(-1,24,3,3))[:,0,1,1]
    torch.testing.assert_close(initial[:32],conv,rtol=1e-4,atol=1e-4)
    # This is a numerical proxy on CPU, not a bitwise replacement for GPU
    # benchmark inference. Record the observed convolution-rounding difference.
    numeric={'max_logit_difference_from_cached_GPU':float((initial-cached).abs().max()),
        'max_probability_difference_from_cached_GPU':float((initial.sigmoid()-cached.sigmoid()).abs().max())}
    assert numeric['max_probability_difference_from_cached_GPU']<.0003
    teacher=initial.detach();threshold=state['source_validation']['threshold']
    results={'parent':summary(initial.numpy(),y.numpy(),fit.numpy(),factors,threshold)}
    failed=torch.load(HERE/'noise_center_peak_guarded_v1/best.pt',map_location='cpu',weights_only=False)
    model.load_state_dict(failed['model'])
    with torch.no_grad():scores=logits(model.heads.center,x)
    results['full_image_one_epoch']=summary(scores.numpy(),y.numpy(),fit.numpy(),factors,threshold)
    native=torch.tensor(factors==0);w=torch.where(native,4.,1.)
    joint=torch.cat((x,torch.tensor(features['T'],dtype=torch.float32)),dim=1)
    for mode,lr in [('fused24',1e-4),('fused24',1e-3),('fused64',1e-4),('joint24',1e-4)]:
        inputs=joint if mode=='joint24' else x
        if mode=='fused24':student=copy.deepcopy(head)
        else:
            width=64 if mode=='fused64' else 24;channels=48 if mode=='joint24' else 24
            torch.manual_seed(3407)
            student=torch.nn.Sequential(torch.nn.Conv2d(channels,width,3,padding=1),torch.nn.SiLU(),torch.nn.Conv2d(width,1,1))
            with torch.no_grad():
                if mode=='joint24':student[0].weight.zero_()
                student[0].weight[:24,:24].copy_(head[0].weight);student[0].bias[:24].copy_(head[0].bias)
                student[2].weight.zero_();student[2].weight[:,:24].copy_(head[2].weight);student[2].bias.copy_(head[2].bias)
            with torch.no_grad():torch.testing.assert_close(logits(student,inputs),initial,rtol=1e-4,atol=1e-4)
        opt=torch.optim.AdamW(student.parameters(),lr=lr,weight_decay=.0005)
        history=[]
        for step in range(200):
            opt.zero_grad(set_to_none=True);score=logits(student,inputs);p=score.sigmoid()
            focal=-(y*(1-p).square()*F.logsigmoid(score)+(1-y)*p.square()*F.logsigmoid(-score))
            loss=(focal[fit]*w[fit]).sum()/((y[fit]*w[fit]).sum())+.1*(score[fit&native]-teacher[fit&native]).square().mean()
            loss.backward();torch.nn.utils.clip_grad_norm_(student.parameters(),10.,error_if_nonfinite=True);opt.step()
            if step in [0,49,99,199]:history.append({'step':step+1,'loss':float(loss.detach())})
        with torch.no_grad():scores=logits(student,inputs)
        results[f'cached_{mode}_focal_lr{lr}']={'fixed_steps':200,'loss_history':history,
            **summary(scores.numpy(),y.numpy(),fit.numpy(),factors,threshold)}
    report={'scope':'sampled GT-anchor/hard-background binary proxy; no image-level detector AP or deployable checkpoint',
        'split_caveat':'incremental head fitting excludes held-out groups; original pretrained detector already saw those source-training groups',
        'checkpoint_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),
        'features_sha256':hashlib.sha256((folder/'features.npz').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'CPU_head_numerics':numeric,
        'results':results,'updated_at':now()}
    write_json(HERE/'cached_center_recoverability.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
