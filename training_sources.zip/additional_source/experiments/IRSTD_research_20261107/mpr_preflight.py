"""CPU-only official MPR-Net import, forward and text-context gradient audit."""
import hashlib
import json
from pathlib import Path
import sys
import time
import torch

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path[:0]=[str(ROOT/"vendor_sota"),str(ROOT/"repositories/CLIP"),str(ROOT/"repositories/MPR-Net"),str(ROOT)]
from irstd_v2.settings import write_json, now
import clip


def main():
    torch.set_num_threads(2); torch.manual_seed(3407)
    weights=ROOT/"external_weights/CLIP/ViT-B-32.pt"
    assert weights.exists()
    expected="40d365715913c9da98579312b702a82c18be219cc2a73407c4526f58eba950af"
    assert hashlib.sha256(weights.read_bytes()).hexdigest()==expected
    old_load=clip.load
    def local_cpu_load(name,*args,**kwargs):
        kwargs.update(device="cpu",download_root=str(weights.parent))
        return old_load(name,*args,**kwargs)
    clip.load=local_cpu_load
    from nets.MPR_DAUB import MPR
    model=MPR(num_classes=1,num_frame=5).cpu()
    prior_ids={id(p) for p in model.parameters()}
    encoder=model.target_encoder
    tick=time.perf_counter()
    text=encoder.encode_target_classes(model.target_classes)
    (text*torch.randn_like(text)).sum().backward()
    grad=encoder.learnable_ctx.grad
    context_max=0. if grad is None else float(grad.abs().max())
    clip_trainable=sum(p.numel() for p in encoder.clip_model.parameters() if p.requires_grad)
    clip_outside_prior=sum(p.numel() for p in encoder.clip_model.parameters() if id(p) not in prior_ids)
    clip_grad=sum(p.numel() for p in encoder.clip_model.parameters() if p.grad is not None)
    for p in model.parameters(): p.grad=None
    # README states a frozen CLIP teacher. This is a CPU forward check only;
    # preserve the observed discrepancy instead of editing official code.
    for p in encoder.clip_model.parameters(): p.requires_grad_(False)
    model.eval()
    with torch.no_grad():
        images=torch.randn(1,3,5,256,256)
        output=model(images,motion_diffs=torch.zeros_like(images))
    assert all(torch.isfinite(v).all() for v in output)
    report={"scope":"official public-code CPU audit; not training or benchmark score",
        "CLIP_weight_sha256":expected,"total_parameters_after_lazy_load":sum(p.numel() for p in model.parameters()),
        "detector_parameters_before_lazy_load":sum(p.numel() for p in model.parameters() if id(p) in prior_ids),
        "CLIP_parameters_requiring_grad_in_official_default":clip_trainable,
        "CLIP_parameters_missing_from_pre_forward_optimizer_list":clip_outside_prior,
        "CLIP_parameters_with_gradient_in_text_audit":clip_grad,
        "learnable_context_gradient_abs_max":context_max,
        "context_EOT_positions":clip.tokenize(model.target_classes).argmax(-1).tolist(),
        "learnable_context_start_position":61,"output_shapes":[list(v.shape) for v in output],
        "forward_finite":True,"elapsed_seconds":time.perf_counter()-tick,"updated_at":now()}
    write_json(HOME/"mpr_preflight.json",report)
    print(json.dumps(report,indent=2),flush=True)


if __name__=="__main__": main()
