"""Frozen source transforms: confidence/localization versus size regression."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import argparse
import hashlib
import json
from pathlib import Path
import random
import sys
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from native_unit_prior_evaluation import build, source_statistics, apply_prior
from irstd_v2.data import Data, choose_plan, render, collate
from irstd_v2.settings import write_json, now, split_hashes
from classification_feature_probe import views
from irstd.inference.decoder import decode
from evaluation import postprocess, match_frame, metrics
import benchmark_fastdecode as fast


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Controlled(Dataset):
    def __init__(self, recipe):
        self.base = Data('DAUB-R', 'val', recipe)
        self.records = self.base.records
        self.spec = json.loads((HERE/'wide_scale_source_probe.json').read_text(encoding='utf-8'))
        self.rows = [(i, identity, scale, noise) for i, identity in zip(self.spec['source_indices'], self.spec['source_record_ids'])
                     for scale in ['native', .25, .5, 1., 2.] for noise in [0, 4]]
        self.geometry = dict(recipe['geometry'], maximum_attempts=1)

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        i, identity, scale, noise = self.rows[index]
        assert self.records[i]['id'] == identity
        sample = self.base.base_sample(i)
        if scale != 'native':
            plan = choose_plan(self.records[i], self.geometry, random.Random(0), forced_scale=scale, flip_override=False)
            assert not plan['fallback'] and plan['sx'] > 0 and plan['sy'] > 0
            image, boxes, valid = render(self.records[i], plan)
            sample = {**sample, 'image': image, 'boxes': boxes, 'valid_mask': valid, 'ignore_mask': ~valid,
                      'trans': (plan['sx'], plan['sy'], plan['tx'], plan['ty'])}
        if noise:
            images, _ = views(sample, 211000000+index)
            sample = {**sample, 'image': images[1]}
        return {**sample, 'controlled_scale': str(scale), 'controlled_noise': noise, 'controlled_index': index}


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', choices=['irstd_robust', 'irstd_stable'], required=True)
    args = parser.parse_args()
    folder = HERE/f'wide_source_detection_{args.model}_v1'
    folder.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    fast.install()
    model, state, recipe, checkpoint = build(args.model)
    stats = source_statistics()
    threshold = state['source_validation']['threshold']
    identity = {'model': args.model, 'checkpoint_sha256': sha(checkpoint), 'script_sha256': sha(__file__),
                'source_subset_sha256': sha(HERE/'wide_scale_source_probe.json'), 'split_hashes': split_hashes(),
                'threshold': threshold, 'source_statistics': stats, 'optimization_updates': 0,
                'scope': 'source16 known-transform diagnosis, not target tests or new threshold selection'}
    if (folder/'config.json').exists():
        assert json.loads((folder/'config.json').read_text(encoding='utf-8')) == identity
    else:
        write_json(folder/'config.json', identity)
    if (folder/'result.json').exists():
        return
    dataset = Controlled(recipe)
    loader = DataLoader(dataset, batch_size=4, num_workers=2, collate_fn=collate, persistent_workers=False)
    collected = {}
    for batch, (images, samples) in enumerate(loader):
        out = model(images.cuda(), valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
        decoded = decode(out, 1e-5, {'box_nms_iou': None}, stats['input_median'])
        for b, (proposal, sample) in enumerate(zip(decoded, samples)):
            key = f"{sample['controlled_scale']}/noise{sample['controlled_noise']}"
            row = collected.setdefault(key, {'learned_size': [], 'known_source_size': [], 'GT_scores': []})
            center, score = proposal['centers'].cuda(), proposal['scores'].cuda()
            q = center.floor().long()
            value = out['log_size'][b, :, q[:, 1], q[:, 0]].T.float()
            ref = value.new_tensor(stats['input_median'])
            wh = ref*torch.minimum(value.clamp_min(-20), (value.new_tensor([512, 512])/ref).log()).exp()
            raw = torch.cat((center, wh, score[:, None], torch.ones_like(score[:, None])), 1)
            record = dataset.records[sample['record_index']]
            for mode in ['learned_size', 'known_source_size']:
                candidate = raw if mode == 'learned_size' else apply_prior(raw, sample['trans'], stats, 'native_constant')
                row[mode].append(match_frame(postprocess(candidate, record, sample['trans']), record))
            for box in sample['boxes']:
                x, y = ((box[:2]+box[2:])/2).floor().long().tolist()
                logits = out['center_logits'][b, 0]
                patch = logits[max(y-3, 0):min(y+4, 512), max(x-3, 0):min(x+4, 512)]
                row['GT_scores'].append({'record_id': record['id'], 'anchor_score': float(logits[y, x].sigmoid()),
                                         'local_peak_score': float(patch.max().sigmoid())})
        write_json(folder/'progress.json', {'status': 'evaluating_source', 'batch': batch+1, 'total_batches': len(loader), 'updated_at': now()})
    report = {}
    for key, row in collected.items():
        assert len(row['learned_size']) == len(row['known_source_size']) == 16
        report[key] = {mode: metrics(row[mode], threshold) for mode in ['learned_size', 'known_source_size']}
        report[key]['GT_scores'] = row['GT_scores']
        report[key]['mean_local_peak_score'] = float(np.mean([r['local_peak_score'] for r in row['GT_scores']]))
        report[key]['local_peaks_above_source_threshold'] = sum(r['local_peak_score'] >= threshold for r in row['GT_scores'])
    assert all(torch.equal(v.cpu(), state['model'][k]) for k, v in model.state_dict().items())
    assert sha(checkpoint) == identity['checkpoint_sha256']
    write_json(folder/'result.json', {'status': 'completed', 'results': report, 'all_tensors_unchanged': True,
                                     'optimization_updates': 0, 'scope': identity['scope'], 'updated_at': now()})
    write_json(folder/'progress.json', {'status': 'completed', 'updated_at': now()})
    print(json.dumps({k: {'AP50_known_size': v['known_source_size']['AP50'], 'F1_known_size': v['known_source_size']['F1'],
                         'mean_peak': v['mean_local_peak_score'], 'peaks_above_threshold': v['local_peaks_above_source_threshold']} for k, v in report.items()}), flush=True)


if __name__ == '__main__':
    main()
