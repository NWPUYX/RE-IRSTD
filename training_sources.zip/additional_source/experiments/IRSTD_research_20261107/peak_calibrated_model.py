"""Same parameters; calibrated score map plus explicitly retained main peak map."""
from integral_population_model import IntegralPopulationModel
from locked_peak_decode import base_candidates


class PeakCalibratedModel(IntegralPopulationModel):
    def forward(self,*args,**kwargs):
        out=super().forward(*args,**kwargs)
        main=out['center_logits']
        return {**out,'main_peak_logits':main,'center_logits':.75*main+.25*out['auxiliary_center_logits']}


def decode_calibrated(outputs,reference):
    original={**outputs,'center_logits':outputs['main_peak_logits']}
    score_map=outputs['center_logits'].float().sigmoid();result=[]
    for b,item in enumerate(base_candidates(original,reference)):
        x,y=item['anchors'].unbind(1)
        scores=score_map[b,0,y,x];keep=scores>=1e-5
        raw=item['raw'][keep].clone();raw[:,4]=scores[keep]
        result.append({'raw':raw,'anchors':item['anchors'][keep]})
    return result
