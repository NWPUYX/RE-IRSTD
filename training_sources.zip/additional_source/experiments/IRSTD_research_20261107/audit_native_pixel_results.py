"""CPU replay of all20 completed cells; never rerun or select on target inference."""
import json
from pathlib import Path
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from evaluation import metrics
from irstd_v2.settings import write_json,now,split_hashes
from irstd_robust_t.run import sha

MODELS=['irstd_scene','irstd_population','aa_yolo','yolo26','irstd_robust']
DOMAINS=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']
SIZES={'DAUB-R':[512,512],'IRDST-H':[1440,960],'IRSTD-UAV':[1280,1024],'ITSDT-15K':[1280,960]}


def read(path):return json.loads(path.read_text(encoding='utf-8'))


def main():
    folder=HERE/'native_pixel_results_audit_v2';folder.mkdir(exist_ok=True)
    cells=[];macros={}
    for model in MODELS:
        home=HERE/f'native_pixel_{model}_v2';config=read(home/'config.json');summary=read(home/'summary.json')
        assert config['split_hashes']==split_hashes() and summary['completed_cells']==4 and summary['all_tensors_unchanged']
        assert config['script_sha256']==sha(HERE/'native_pixel_evaluation_v2.py')
        preflight=read(home/'source_preflight.json')
        assert preflight['passed'] and preflight['config_sha256']==sha(home/'config.json')
        assert preflight['source_pixel_checks']==16
        thresholds=[];cross=[]
        for domain in DOMAINS:
            path=home/f'{domain}_predictions.json';frames=read(path)['frames']
            saved=read(home/f'{domain}_metrics.json');threshold=saved['overall']['threshold'];thresholds.append(threshold)
            actual=metrics(frames,threshold)
            assert all(value==saved['overall'][key] for key,value in actual.items()),(model,domain)
            records=read(ROOT/f'splits/{domain}_test.json')
            assert actual['frames']==len(records) and actual['ground_truth']==sum(len(r['boxes']) for r in records)
            if 'input_sizes' in saved:assert saved['input_sizes']==[SIZES[domain]]
            else:
                assert domain=='DAUB-R' and config['DAQ_test_reused']
                assert config['native_resize']==[2.,2.]
                assert all(r['width']==r['height']==256 for r in records)
            assert all(r['group'] in saved['by_group'] for r in records)
            for group,value in saved['by_group'].items():
                replay=metrics([f for f in frames if f['group']==group],threshold)
                assert replay==value,(model,domain,group)
            cells.append({'model':model,'domain':domain,'metrics':actual,'input_size':SIZES[domain],
                'predictions_sha256':sha(path),'metrics_sha256':sha(home/f'{domain}_metrics.json')})
            if domain!='DAUB-R':cross.append(actual)
            del frames,records
        assert len(set(thresholds))==1
        macro={key:float(np.mean([r[key] for r in cross])) for key in ['AP50','AP50_95','F1','center_Pd_3px']}
        for key,value in macro.items():
            np.testing.assert_allclose(value,summary['cross_domain_macro'][key],rtol=0,atol=1e-15)
        macros[model]=macro
        print(json.dumps({'audited':model,'macro':macro}),flush=True)
    result={'passed':True,'cells':cells,'cross_domain_macros':macros,'source':'DAUB-R','seed':3407,
        'inference_reruns':0,'optimization_updates':0,'script_sha256':sha(__file__),'updated_at':now()}
    write_json(folder/'result.json',result)
    lines=['# 源像素密度五模型对照：完整验证结果','',f'[COMPUTED｜HIGH] {now()}：5模型×4域全部20单元完成，预测缓存的总体/分组指标、样本数、真值数、输入尺寸与宏均值独立重算通过。无新增训练或目标推理。',
        '', '| 模型 | 跨域宏AP50 | 跨域宏AP50:95 | 跨域宏F1 | 跨域宏中心Pd |','|---|---:|---:|---:|---:|']
    for name,row in macros.items():
        lines.append(f"| {name} | {row['AP50']*100:.4f}% | {row['AP50_95']*100:.4f}% | {row['F1']*100:.4f}% | {row['center_Pd_3px']*100:.4f}% |")
    lines+=['','[KNOWN｜HIGH] 全部为DAUB-R训练、3407种子、单帧；每个模型使用自己的完整源验证冻结阈值，学习尺寸采用原输入像素语义，不加入尺寸先验。IRDST-H输入1440×960、UAV输入1280×1024、ITSDT输入1280×960，对应固定512的5.2734、5、4.6875倍输入像素；本表不能并入固定512或称同512计算预算。',
        '', '| 模型 | 测试域 | AP50 | F1 | 召回 | FP/帧 |','|---|---|---:|---:|---:|---:|']
    for cell in cells:
        m=cell['metrics'];lines.append(f"| {cell['model']} | {cell['domain']} | {m['AP50']*100:.4f}% | {m['F1']*100:.4f}% | {m['Recall']*100:.4f}% | {m['FP_per_frame']:.5f} |")
    lines+=['','[COMPUTED｜HIGH] 该补充协议下场景版本超过这里两个单帧对照，但绝对F1仍低；场景版本的固定512宏AP50/F1为1.3756%/1.2730%，较大输入为2.0565%/1.2546%，没有同时改善两项。源像素密度16个合成场景上的收益不能直接外推为实际跨场景整体收益。',
        '', '[KNOWN｜HIGH] 场景权重来自另立源AP诊断角色，其扩展源门槛失败仍保留；本表并未撤销。较旧IRSTD父模型的历史512使用旧峰索引适配，而本次使用修订版本，不能将其全部差值归因于输入分辨率。AA与YOLO各自原解码不受该索引问题影响。',
        '', '[KNOWN｜HIGH] 单源单种子诊断、未完全匹配的累计续调预算及已经参与开发的目标场景，不构成完整SOTA或可直接发表的证据。后续仍以固定512主比较和单帧同监督/外部信息为验收；需完整训练源与种子、机制和预算对照及独立确认。']
    (HERE/'源像素密度五模型完整验证结果.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps({'passed':True,'completed_cells':len(cells)}),flush=True)


if __name__=='__main__':main()
