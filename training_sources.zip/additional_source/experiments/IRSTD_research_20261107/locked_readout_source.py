"""One numeric checkpoint; shared source inference for locked-anchor rescoring."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
import json
from pathlib import Path
import sys
import torch
from torch.utils.data import DataLoader

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from integral_population_model import IntegralPopulationModel
from locked_peak_decode import base_candidates,rescore
from anchor_preserving_decode import decode_raw
from source_noise_geometry_probe import Clean
from source_mosaic_probe import Probe
from irstd_scene_scale.run import gates,locality_probe
from irstd_v2.data import make_loader,collate
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint
from irstd_noise_center.data import validation_loader
from irstd_background_center.data import swapped_loader,loader as background_pairs
from irstd_background_center.run import reference_threshold
from irstd_adapter import targets,model_config
from irstd_geometry_balance.run import probe
from irstd_robust_t.probe import extreme_probe
from irstd_robust_t.run import sha,mechanisms
from benchmark_progress import ReportingLoader
from benchmark_center_metrics import center_metrics
from evaluation import postprocess,match_frame,metrics
from audit_conditional_function import functional_responses
from audit_integral_joint import numerical_check
import benchmark_fastdecode as fast

HOME=HERE/'locked_peak_readout_v1';INITIAL=HERE/'integral_joint_v1/epoch_01_ema.pt'
PARENT=HERE/'robust_T_composed_v1/best.pt';WEIGHTS=[0.,.25,.5,.75,1.]


def identity():
    original=torch.load(INITIAL,map_location='cpu',weights_only=False)
    proof=json.loads((INITIAL.parent/'independent_audit.json').read_text(encoding='utf-8'))
    audited=torch.load(INITIAL.parent/'best.pt',map_location='cpu',weights_only=False)
    assert proof['passed'] and proof['checkpoint_sha256']==sha(INITIAL.parent/'best.pt')
    assert all(torch.equal(v,audited['model'][n]) for n,v in original['model'].items())
    files=[Path(__file__),HERE/'locked_peak_decode.py',HERE/'固定峰T重评分零训练方案.md']
    cfg={**original['config'],'recipe':{**original['config']['recipe'],'decoder':'locked_peak_T_logit_rescoring'},
        'source_hashes':{**original['config']['source_hashes'],**{str(p.relative_to(ROOT.parent)):sha(p) for p in files}},
        'locked_parent_checkpoint_sha256':sha(INITIAL),'locked_weights':WEIGHTS,'optimization_updates_this_stage':0}
    assert cfg['split_hashes']==split_hashes()
    for name,digest in {**cfg['source_hashes'],**cfg['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
    return cfg,original


def build(config,state):
    model=IntegralPopulationModel(config['recipe']).cuda().eval();model.load_state_dict(state,strict=True);model.set_mode(final=False)
    for p in model.parameters():p.requires_grad_(False)
    return model


@torch.inference_mode()
def infer(model,loader,reference,weights,verify=False):
    payload={str(a):{'frames':[],'predictions':[]} for a in weights}
    for batch,(images,samples) in enumerate(loader):
        out=model(images.cuda(),valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
        candidates=base_candidates(out,reference)
        if verify and batch==0:
            actual=rescore(out,candidates,0.);expected=decode_raw(out,reference)
            assert all(torch.equal(a['raw'],b['raw']) and torch.equal(a['anchors'],b['anchors']) for a,b in zip(actual,expected))
        for weight in weights:
            for proposal,sample in zip(rescore(out,candidates,weight),samples):
                record=loader.dataset.records[sample['record_index']]
                prediction=postprocess(proposal['raw'],record,sample['trans'])
                payload[str(weight)]['frames'].append(match_frame(prediction,record))
                payload[str(weight)]['predictions'].extend({'image_id':record['id'],'category_id':1,
                    'bbox':[x,y,x2-x,y2-y],'score':score} for x,y,x2,y2,score in prediction.tolist())
    return payload


@torch.inference_mode()
def mosaics(model,cfg,reference,weights,thresholds):
    frames={str(a):{} for a in weights}
    for images,samples in DataLoader(Probe(cfg),batch_size=4,num_workers=2,collate_fn=collate):
        out=model(images.cuda());candidates=base_candidates(out,reference)
        for weight in weights:
            for proposal,sample in zip(rescore(out,candidates,weight),samples):
                k=sample['k'];row=frames[str(weight)].setdefault(str(k),{'learned':[],'known_source_size':[]})
                for rule in row:
                    raw=proposal['raw'].clone()
                    if rule=='known_source_size':raw[:,2:4]=raw.new_tensor(reference)/k
                    row[rule].append(match_frame(postprocess(raw,sample['record'],(1.,1.,0,0)),sample['record']))
    return {a:{k:{rule:metrics(values,thresholds[a]) for rule,values in row.items()} for k,row in case.items()} for a,case in frames.items()}


@torch.inference_mode()
def background_mse(model,cfg,reference,weights):
    values={str(a):[] for a in weights}
    for images,samples in background_pairs(cfg,'val'):
        out=model(images.cuda());n=len(samples)//2
        t=targets(samples,model_config(),reference,'cuda','shared_regression')
        for weight in weights:
            logit=(1-weight)*out['center_logits']+weight*out['auxiliary_center_logits']
            for b in range(n):
                positive=t['positive'][b].bool()
                values[str(weight)].extend((logit[b][positive]-logit[b+n][positive]).square().cpu().tolist())
    return {a:sum(v)/len(v) for a,v in values.items()}


def main():
    HOME.mkdir(exist_ok=True);bound,original=identity();cfg=bound['recipe'];reference=bound['size_reference_512']
    path=HOME/'config.json'
    if path.exists():assert json.loads(path.read_text(encoding='utf-8'))==bound
    else:write_json(path,bound)
    if (HOME/'source_complete.json').exists():return
    model=build(bound,original['model']);results={str(a):{} for a in WEIGHTS}
    for view in ['clean','noise4','noise16','swapped']:
        paths={str(a):HOME/f'a{a}_{view}.json' for a in WEIGHTS}
        if not all(p.exists() for p in paths.values()):
            loader=DataLoader(Clean(cfg),batch_size=4,num_workers=2,collate_fn=collate) if view=='clean' else (
                swapped_loader(cfg) if view=='swapped' else validation_loader(cfg,int(view.removeprefix('noise'))))
            outputs=infer(model,loader,reference,WEIGHTS,verify=True)
            for a,payload in outputs.items():write_json(paths[a],payload)
        for a,path in paths.items():results[a][view]=metrics(json.loads(path.read_text(encoding='utf-8'))['frames'],original['source_validation']['threshold'])
        print(json.dumps({'view':view,'AP50':{a:row[view]['AP50'] for a,row in results.items()}}),flush=True)
    for factor in [4,16]:assert results['0.0'][f'noise{factor}']['AP50']==original['noise'][str(factor)]['box']['AP50']
    noise=json.loads((HERE/'noise_validation_diagnostic/baseline.json').read_text(encoding='utf-8'))['results']
    baseline=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    locality=locality_probe(model,cfg,'cuda')
    for a,row in results.items():
        row['prescreen']={'clean_AP_retained':row['clean']['AP50']>=results['0.0']['clean']['AP50']-.02,
            'noise4_AP_retained':row['noise4']['AP50']>=noise['4']['box']['AP50']-.005,
            'noise16_AP_plus2pp':row['noise16']['AP50']>=noise['16']['box']['AP50']+.02,
            'background_AP_retained':row['swapped']['AP50']>=baseline['swapped_metrics']['AP50'],'T_locality':locality<=1e-10}
    eligible=[float(a) for a,row in results.items() if all(row['prescreen'].values())]
    write_json(HOME/'prescreen.json',{'results':results,'eligible':eligible,'T_pair_MSE':locality,'updated_at':now()})
    print(json.dumps({'eligible':eligible}),flush=True)
    if not eligible:
        write_json(HOME/'source_complete.json',{'status':'completed','promotion_passed':False,'reason':'no_prescreen_candidate',
            'optimization_updates':0,'target_frames':0,'updated_at':now()});return
    paths={str(a):HOME/f'a{a}_source_val.json' for a in eligible}
    if not all(path.exists() for path in paths.values()):
        loader=ReportingLoader(make_loader('DAUB-R','val',cfg),HOME/'progress.json','source_val')
        outputs=infer(model,loader,reference,eligible,verify=True)
        for a,payload in outputs.items():write_json(paths[a],payload)
    summaries={a:validation_summary(json.loads(path.read_text(encoding='utf-8'))['frames']) for a,path in paths.items()}
    geometry,per_scale=probe(model,cfg,reference,'cuda');extreme=extreme_probe(model,cfg,reference,'cuda')
    pair_mse=background_mse(model,cfg,reference,eligible)
    mosaic_rows=mosaics(model,cfg,reference,eligible,{a:v['threshold'] for a,v in summaries.items()})
    parent=torch.load(PARENT,map_location='cpu',weights_only=False);rows={}
    for a,summary in summaries.items():
        row={'source_validation':summary,'geometry_probe':geometry,'per_scale':per_scale,'extreme_geometry':extreme,
            'T_pair_MSE':locality,'mosaics':mosaic_rows[a],
            'background':{'GT_logit_pair_MSE':pair_mse[a],'targets':24,
                'swapped_metrics':metrics(json.loads((HOME/f'a{a}_swapped.json').read_text(encoding='utf-8'))['frames'],reference_threshold())},'noise':{}}
        for factor in [4,16]:
            f=json.loads((HOME/f'a{a}_noise{factor}.json').read_text(encoding='utf-8'))['frames']
            row['noise'][str(factor)]={'box':metrics(f,summary['threshold']),'center':center_metrics(f,summary['threshold'])}
        row['gates']=gates(row,parent,baseline);assert len(row['gates'])==18;rows[a]=row
    winner=max(rows,key=lambda a:(all(rows[a]['gates'].values()),sum(rows[a]['gates'].values()),rows[a]['source_validation']['pooled']['AP50'],rows[a]['noise']['16']['box']['AP50'],-float(a)))
    assert all(torch.equal(v.cpu(),original['model'][name]) for name,v in model.state_dict().items())
    checkpoint={**rows[winner],'config':{**bound,'locked_selected_weight':float(winner)},'model':original['model'],
        'optimization_updates':0,'role':'zero-training locked-anchor source readout development'}
    save_checkpoint(HOME/'best.pt',checkpoint);write_json(HOME/'rows.json',rows)
    done={'status':'completed','promotion_passed':all(rows[winner]['gates'].values()),'selected_weight':float(winner),
        'gates':rows[winner]['gates'],'optimization_updates':0,'target_frames':0,'updated_at':now()}
    write_json(HOME/'source_complete.json',done);write_json(HOME/'progress.json',done)
    print(json.dumps({'complete':done,'source':rows[winner]['source_validation']['pooled']}),flush=True)


def audit():
    bound,original=identity();done=json.loads((HOME/'source_complete.json').read_text(encoding='utf-8'))
    if done.get('reason')=='no_prescreen_candidate':return
    state=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False);a=str(float(done['selected_weight']))
    assert state['config']=={**bound,'locked_selected_weight':float(a)} and state['optimization_updates']==0
    assert all(torch.equal(v,original['model'][name]) for name,v in state['model'].items())
    model=build(bound,state['model']);assert sum(p.numel() for p in model.parameters())==808952
    images,_=next(iter(make_loader('DAUB-R','val',bound['recipe'])))
    with torch.inference_mode():
        out=model(images.cuda());candidates=base_candidates(out,bound['size_reference_512'])
        zero=rescore(out,candidates,0.);reference=decode_raw(out,bound['size_reference_512'])
        assert all(torch.equal(x['raw'],y['raw']) and torch.equal(x['anchors'],y['anchors']) for x,y in zip(zero,reference))
        for old,new in zip(candidates,rescore(out,candidates,float(a))):
            lookup={tuple(q):i for i,q in enumerate(old['anchors'].tolist())}
            ids=[lookup[tuple(q)] for q in new['anchors'].tolist()]
            assert torch.equal(new['raw'][:,:4],old['raw'][ids,:4])
    frames=json.loads((HOME/f'a{a}_source_val.json').read_text(encoding='utf-8'))['frames']
    assert len(frames)==1801 and validation_summary(frames)==state['source_validation']
    for factor in [4,16]:
        f=json.loads((HOME/f'a{a}_noise{factor}.json').read_text(encoding='utf-8'))['frames']
        assert metrics(f,state['source_validation']['threshold'])==state['noise'][str(factor)]['box']
        assert center_metrics(f,state['source_validation']['threshold'])==state['noise'][str(factor)]['center']
    cfg=bound['recipe'];ref=bound['size_reference_512'];geometry,per_scale=probe(model,cfg,ref,'cuda')
    assert geometry==state['geometry_probe'] and per_scale==state['per_scale']
    assert extreme_probe(model,cfg,ref,'cuda')==state['extreme_geometry']
    assert locality_probe(model,cfg,'cuda')==state['T_pair_MSE']<=1e-10
    assert mosaics(model,cfg,ref,[float(a)],{a:state['source_validation']['threshold']})[a]==state['mosaics']
    assert background_mse(model,cfg,ref,[float(a)])[a]==state['background']['GT_logit_pair_MSE']
    functional=functional_responses(model);numeric=numerical_check(model);blocks=mechanisms(model)
    baseline=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    computed=gates(state,torch.load(PARENT,map_location='cpu',weights_only=False),baseline)
    assert computed==state['gates']==done['gates'] and all(computed.values())==done['promotion_passed']
    rows=json.loads((HOME/'rows.json').read_text(encoding='utf-8'))
    winner=max(rows,key=lambda k:(all(rows[k]['gates'].values()),sum(rows[k]['gates'].values()),rows[k]['source_validation']['pooled']['AP50'],rows[k]['noise']['16']['box']['AP50'],-float(k)))
    assert winner==a and all(torch.equal(v.cpu(),original['model'][name]) for name,v in model.state_dict().items())
    result={'passed':True,'promotion_passed':all(computed.values()),'checkpoint_sha256':sha(HOME/'best.pt'),
        'all_parameters_and_buffers_unchanged':True,'zero_readout_exact':True,'selected_proposal_geometry_exact':True,
        'source_metrics_recalculated':True,'geometry_remeasured':True,'numerical_checks':numeric,'REBlocks':blocks,
        'functional_C_output_responses':functional,'gates':computed,'optimization_updates':0,'updated_at':now()}
    write_json(HOME/'independent_audit.json',result);print(json.dumps({'passed':True,'promotion_passed':result['promotion_passed']}),flush=True)


if __name__=='__main__':
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    parser=argparse.ArgumentParser();parser.add_argument('--audit',action='store_true');args=parser.parse_args()
    audit() if args.audit else main()
