"""Audit selected epoch independently of the last optimization epoch."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_population_t.run import HOME,PARENT,CALIBRATED,construct,buffers_unchanged,frozen_context,locality_probe,sha,row_key,gates
from irstd_robust_t.run import mechanisms
from irstd_robust_t.probe import extreme_probe
from irstd_geometry_balance.run import probe
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from evaluation import metrics
from benchmark_center_metrics import center_metrics
from irstd.models.blocks import REBlock


def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    done=json.loads((HOME/'training_complete.json').read_text(encoding='utf-8'))
    best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
    last=torch.load(HOME/'last.pt',map_location='cpu',weights_only=False)
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False);cfg=best['config']
    initial=torch.load(CALIBRATED,map_location='cpu',weights_only=False)['model']
    assert cfg['calibration_checkpoint_sha256']==sha(CALIBRATED)
    assert cfg==last['config'] and split_hashes()==cfg['split_hashes']
    assert sha(PARENT/'best.pt')==cfg['parent_sha256']
    for name,digest in {**cfg['source_hashes'],**cfg['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
    assert last['updates']==done['updates']==last['epoch']*2091 and last['epoch']==done['epochs_run']
    epoch=best['epoch'];assert epoch==done['best_epoch'] and best['updates']==epoch*2091
    selected=torch.load(HOME/f'epoch_{epoch:02d}_training.pt',map_location='cpu',weights_only=False)
    assert selected['config']==cfg and selected['updates']==best['updates']
    assert all(torch.equal(v,selected['ema'][n]) for n,v in best['model'].items())
    manifest=json.loads((HOME/f'epoch_{epoch:02d}_prediction_manifest.json').read_text(encoding='utf-8'))
    assert manifest['trained_checkpoint_sha256']==sha(HOME/f'epoch_{epoch:02d}_training.pt')
    model,teacher,opt=construct(cfg['recipe'],best['model'],torch.device('cuda'))
    parameter_count=sum(p.requires_grad for p in model.parameters())
    assert sum(p.numel() for p in model.parameters())==808952
    assert sum(p.numel() for p in model.parameters() if p.requires_grad)==23252 and parameter_count==41
    for checkpoint in [selected,last]:
        assert len(checkpoint['optimizer']['state'])==parameter_count
        assert all(int(s['step'])==checkpoint['updates'] for s in checkpoint['optimizer']['state'].values())
        assert sum(checkpoint['view_counts'].values())==8362 and checkpoint['view_counts']['native']==4181
        assert 'shrink_noise' not in checkpoint['view_counts'] and 'enlarge_noise' not in checkpoint['view_counts']
        frozen_context(model,initial)
        for actual in [checkpoint['model'],checkpoint['ema']]:
            for n,v in actual.items():
                if not n.startswith(('backbone.target_path.','backbone.final.','heads.')) or n in dict(model.named_buffers()):assert torch.equal(v,initial[n]),n
        for actual,expected in zip(checkpoint['optimizer']['param_groups'],opt.param_groups):
            assert actual['lr']==expected['lr'] and actual['weight_decay']==expected['weight_decay'] and len(actual['params'])==len(expected['params'])
    assert all(torch.isfinite(v).all() for v in best['model'].values())
    assert any(not torch.equal(v,initial[n]) for n,v in best['model'].items() if n.startswith('backbone.target_path.'))
    model.eval();blocks=mechanisms(model)
    conditional={}
    with torch.inference_mode():
        for name,module in model.named_modules():
            if isinstance(module,REBlock):
                x=torch.zeros(1,module.channels,16,16,device='cuda')
                c=torch.linspace(-1,1,4*16*16,device='cuda').reshape(1,4,16,16)
                alpha=module.mixing_weights(x,c)
                assert torch.isfinite(alpha).all() and (alpha>=0).all()
                torch.testing.assert_close(alpha.sum(1),torch.ones_like(alpha[:,0]),rtol=0,atol=1e-6)
                conditional[name]=float((alpha-module.mixing_weights(x,torch.zeros_like(c))).abs().mean())
                if name.startswith('backbone.target_path.'):assert conditional[name]>1e-8
    frames=json.loads((HOME/'best_source_val_predictions.json').read_text(encoding='utf-8'))['frames']
    assert len(frames)==1801 and validation_summary(frames)==best['source_validation']
    threshold=best['source_validation']['threshold']
    for factor in [4,16]:
        f=json.loads((HOME/f'epoch_{epoch:02d}_noise{factor}_predictions.json').read_text(encoding='utf-8'))['frames']
        assert len(f)==24 and metrics(f,threshold)==best['noise'][str(factor)]['box']
        assert center_metrics(f,threshold)==best['noise'][str(factor)]['center']
    original_threshold=torch.load(HERE/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)['source_validation']['threshold']
    f=json.loads((HOME/f'epoch_{epoch:02d}_swapped_predictions.json').read_text(encoding='utf-8'))['frames']
    assert metrics(f,original_threshold)==best['background']['swapped_metrics']
    geometry,per_scale=probe(model,cfg['recipe'],cfg['size_reference_512'],torch.device('cuda'))
    assert geometry==best['geometry_probe'] and per_scale==best['per_scale']
    assert extreme_probe(model,cfg['recipe'],cfg['size_reference_512'],torch.device('cuda'))==best['extreme_geometry']
    assert locality_probe(model,cfg['recipe'],torch.device('cuda'))==best['T_pair_MSE']<=1e-10
    for name,module in model.population_modules():assert module.use_population==(name!='backbone.final.1')
    assert torch.backends.cudnn.conv.fp32_precision=='tf32'
    baseline=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    computed=gates(best,parent,baseline)
    assert computed==best['gates']==done['gates'] and all(computed.values())==done['promotion_passed']
    rows=[json.loads((HOME/f'epoch_{e:02d}_row.json').read_text(encoding='utf-8')) for e in range(1,last['epoch']+1)]
    winner=max(rows,key=row_key);assert winner['epoch']==epoch
    result={'passed':True,'promotion_passed':done['promotion_passed'],'checkpoint_sha256':sha(HOME/'best.pt'),
        'selected_epoch':epoch,'selected_updates':best['updates'],'total_updates':last['updates'],
        'optimizer_state_count':parameter_count,'parameters':808952,'trainable_parameters':23252,
        'context_and_fixed_population_buffers_unchanged':True,'T_pair_MSE':best['T_pair_MSE'],
        'conditional_response_to_changed_C':conditional,
        'normalization_gamma_bias_decay_zero':True,'REBlock_constraints_checked':blocks,
        'source_metrics_recalculated':True,'geometry_remeasured':True,'gates':computed,'updated_at':now()}
    write_json(HOME/'independent_audit.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
