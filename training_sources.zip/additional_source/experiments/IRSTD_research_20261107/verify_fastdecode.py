"""Exact synthetic and real-output comparisons before using decoder speedup."""
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
import torch
from torch.nn import functional as F

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
import irstd_adapter
from irstd.inference import decoder
import benchmark_fastdecode as fast
from irstd_t_size.model import TSizeModel
from irstd_v2.data import make_loader
from irstd_v2.settings import write_json,now


@torch.inference_mode()
def main():
    torch.set_num_threads(2);fast.cv2.setNumThreads(1);rng=np.random.default_rng(3407)
    old_seconds=0.;new_seconds=0.;count=0
    def check(score):
        nonlocal old_seconds,new_seconds,count
        tensor=torch.from_numpy(score)[None,None]
        mask=((tensor==F.max_pool2d(tensor,3,1,1))&(tensor>=1e-5))[0,0].numpy()
        tick=time.perf_counter();a=fast.ORIGINAL(score,mask);old_seconds+=time.perf_counter()-tick
        tick=time.perf_counter();b=fast.representatives(score,mask);new_seconds+=time.perf_counter()-tick
        assert a==b;count+=1
    for shape in [(32,33),(64,64),(512,512)]:
        for mode in range(12):
            x=rng.random(shape).astype(np.float32)
            if mode%4==0:x=np.round(x*3)/3
            if mode%4==1:x[:]=mode/20
            if mode%4==2:x[5:20,4:27]=.99
            check(x)
    state=torch.load(HOME/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)
    cfg=state['config']['recipe'];model=TSizeModel(cfg).cuda().eval();model.load_state_dict(state['model'])
    real=0
    for images,samples in make_loader('DAUB-R','val',cfg):
        output=model(images.cuda())
        for score in output['center_logits'].sigmoid()[:,0].cpu().numpy():check(score)
        fast.uninstall();before=decoder.decode(output,1e-5,{'box_nms_iou':None},state['config']['size_reference_512'])
        fast.install();after=decoder.decode(output,1e-5,{'box_nms_iou':None},state['config']['size_reference_512'])
        for a,b in zip(before,after):
            for key in a:assert (a[key] is None and b[key] is None) or torch.equal(a[key],b[key]),key
        real+=len(images)
        if real>=16:break
    fast.uninstall()
    result={'passed':True,'synthetic_and_real_score_maps':count,'real_full_decode_frames':real,
        'all_positions_order_and_decoded_tensors_exactly_equal':True,'old_plateau_seconds':old_seconds,
        'new_plateau_seconds':new_seconds,'plateau_only_speed_ratio':old_seconds/max(new_seconds,1e-12),
        'scope':'decoder helper only; no model parameters, thresholds, NMS or protocol change',
        'source_sha256':hashlib.sha256((ROOT/'benchmark_fastdecode.py').read_bytes()).hexdigest(),'updated_at':now()}
    write_json(HOME/'fastdecode_equivalence.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
