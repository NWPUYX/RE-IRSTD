"""Run the bounded source-derived fallback only if the six-epoch parent fails."""
import json
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
PARENT=HERE/'peak_calibrated_v1';HOME=HERE/'consistent_teacher_v1'


def read(path):
    if not path.exists():return None
    try:return json.loads(path.read_text(encoding='utf-8'))
    except json.JSONDecodeError:return None


def run(script,log,*args):
    with (HERE/log).open('a',encoding='utf-8') as stream:
        subprocess.run([sys.executable,str(HERE/script),*args],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)


def main():
    deadline=time.monotonic()+6*3600
    while True:
        done=read(PARENT/'training_complete.json');audit=read(PARENT/'independent_audit.json')
        if done and audit:break
        if (PARENT/'failure.json').exists():raise RuntimeError('parent source stage failed; fallback not started')
        for name in ['peak_calibrated_pipeline.log','peak_calibrated_audit.log']:
            path=HERE/name
            if path.exists() and 'Traceback (most recent call last)' in path.read_text(encoding='utf-8'):
                raise RuntimeError('parent audit/pipeline failed; inspect its retained log')
        if time.monotonic()>deadline:raise TimeoutError('parent did not finish within bounded wait')
        time.sleep(5)
    assert audit['passed']
    if audit['promotion_passed']:
        print(json.dumps({'status':'skipped_parent_source_qualified','parent_tests_continue':True,
            'SOTA_goal_completed':False}),flush=True);return
    try:
        if not (HOME/'preflight.json').exists():run('consistent_teacher_training.py','consistent_teacher_preflight.log','--check')
        args=['--resume'] if (HOME/'config.json').exists() and not (HOME/'training_complete.json').exists() else []
        run('consistent_teacher_training.py','consistent_teacher_training.log',*args)
        if not (HOME/'independent_audit.json').exists():run('audit_consistent_teacher.py','consistent_teacher_audit.log')
        proof=read(HOME/'independent_audit.json');assert proof['passed']
        if proof['promotion_passed']:run('evaluate_consistent_teacher.py','consistent_teacher_frozen_test.log')
        print(json.dumps({'status':'completed','promotion_passed':proof['promotion_passed'],
            'target_tests_started':proof['promotion_passed'],'SOTA_goal_completed':False}),flush=True)
    finally:
        subprocess.run([sys.executable,str(HERE/'update_progress_report.py')],cwd=ROOT,check=False)


if __name__=='__main__':main()
