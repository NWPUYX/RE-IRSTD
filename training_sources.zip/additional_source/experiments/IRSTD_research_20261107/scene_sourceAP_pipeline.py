"""Wait for source audit; perform the separately declared diagnostic only."""
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
TRAIN = HERE/'scene_scale_joint_v1'
CONTROL = HERE/'scene_scale_sourceAP_control_v1'
ROOT = HERE.parents[1]


def main():
    while not (TRAIN/'independent_audit.json').exists():
        if (TRAIN/'failure.json').exists():
            raise RuntimeError((TRAIN/'failure.json').read_text(encoding='utf-8'))
        time.sleep(10)
    with (HERE/'scene_sourceAP_freeze.log').open('w', encoding='utf-8') as stream:
        subprocess.run([sys.executable, str(HERE/'freeze_scene_sourceAP.py')], cwd=ROOT,
                       stdout=stream, stderr=subprocess.STDOUT, check=True)
    selection = json.loads((CONTROL/'selection.json').read_text(encoding='utf-8'))
    if not selection['eligible_for_diagnostic_test']:
        print(json.dumps({'status': 'source_ineligible', 'target_tests_started': False}), flush=True)
        return
    done = json.loads((TRAIN/'training_complete.json').read_text(encoding='utf-8'))
    if selection['equivalent_to_normal_candidate'] and done['promotion_passed']:
        (CONTROL/'equivalent_normal_test.json').write_text(json.dumps({
            'same_model_tensors_and_threshold': True, 'reference': str(TRAIN/'source_qualified_tests'),
            'reason': 'avoid duplicate inference for two roles of the same frozen model'}), encoding='utf-8')
        print(json.dumps({'status': 'linked_identical_normal_test', 'reference': str(TRAIN/'source_qualified_tests')}), flush=True)
        return
    with (HERE/'scene_sourceAP_frozen_test.log').open('w', encoding='utf-8') as stream:
        subprocess.run([sys.executable, str(HERE/'evaluate_scene_sourceAP.py')], cwd=ROOT,
                       stdout=stream, stderr=subprocess.STDOUT, check=True)
    print(json.dumps({'status': 'completed', 'role': 'source-AP diagnostic; source failures retained'}), flush=True)


if __name__ == '__main__':
    main()
