"""Verify public decoder equivalence and the interior floating-point edge case."""
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from anchor_preserving_decode import decode_raw
from irstd.inference.decoder import decode
from irstd_v2.settings import write_json,now
from native_unit_prior_evaluation import sha
import benchmark_fastdecode as fast


def main():
    fast.install();cases=[]
    for h,w,x,y in [(160,192,127,127),(512,512,511,127),(1088,1440,1023,1023),(32,32,4,5)]:
        out={'center_logits':torch.full((1,1,h,w),-30.),'offsets':torch.zeros(1,2,h,w),'log_size':torch.zeros(1,2,h,w)}
        out['center_logits'][0,0,y,x]=2.;out['offsets'][0,:,y,x]=1.5
        if x+1<w and y+1<h:out['log_size'][0,:,y+1,x+1]=torch.tensor([2.,3.]).log()
        actual=decode_raw(out,[16.,16.])[0];public=decode(out,1e-5,{'box_nms_iou':None},[16.,16.])[0];raw=actual['raw']
        assert torch.equal(raw[:,:2],public['centers']) and torch.equal(raw[:,4],public['scores'])
        boxes=torch.cat((raw[:,:2]-raw[:,2:4]/2,raw[:,:2]+raw[:,2:4]/2),1)
        boxes[:,[0,2]]=boxes[:,[0,2]].clamp(0,w);boxes[:,[1,3]]=boxes[:,[1,3]].clamp(0,h)
        assert torch.equal(boxes,public['boxes']) and actual['anchors'].tolist()==[[x,y]]
        recovered=raw[:,:2].floor().long()
        legacy_wh=16*out['log_size'][0,:,recovered[:,1],recovered[:,0]].T.exp()
        cases.append({'shape':[h,w],'peak':[x,y],'recovered_peak':recovered.tolist(),
            'new_size':raw[:,2:4].tolist(),'legacy_size':legacy_wh.tolist(),
            'public_clipped_boxes_equal':True,'legacy_changed_cell':not torch.equal(recovered,actual['anchors'])})
    empty={'center_logits':torch.full((1,1,32,32),-30.),'offsets':torch.zeros(1,2,32,32),'log_size':torch.zeros(1,2,32,32)}
    assert decode_raw(empty,[16,16])[0]['raw'].shape==(0,6)
    assert any(c['legacy_changed_cell'] and c['new_size']!=c['legacy_size'] for c in cases)
    write_json(HERE/'anchor_preserving_decoder_audit.json',{'passed':True,'cases':cases,'empty_checked':True,
        'helper_sha256':sha(HERE/'anchor_preserving_decode.py'),'public_decoder_sha256':sha(ROOT.parent/'IRSTD/src/irstd/inference/decoder.py'),
        'script_sha256':sha(__file__),'updated_at':now()})
    print(json.dumps(cases),flush=True)


if __name__=='__main__':main()
