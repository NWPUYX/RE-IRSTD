"""Finish the bounded run and release the paused field evaluation on every exit."""
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];HOME=HERE/'integral_joint_v1'
PRIORITY=HERE/'primary_work_priority.json'


def execute(script,log):
    with (HERE/log).open('a',encoding='utf-8') as stream:
        subprocess.run([sys.executable,str(HERE/script)],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)


def main():
    try:
        assert json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))['passed']
        execute('integral_joint_training.py','integral_joint_training.log')
        execute('audit_integral_joint.py','integral_joint_independent_audit.log')
        audit=json.loads((HOME/'independent_audit.json').read_text(encoding='utf-8'))
        assert audit['passed']
        if audit['promotion_passed']:execute('evaluate_integral_joint.py','integral_joint_frozen_test.log')
        print(json.dumps({'status':'completed','promotion_passed':audit['promotion_passed'],
            'target_tests_started':audit['promotion_passed']}),flush=True)
    finally:
        if PRIORITY.exists():
            flag=json.loads(PRIORITY.read_text(encoding='utf-8-sig'))
            if flag.get('stage')=='integral_joint_v1':PRIORITY.unlink()


if __name__=='__main__':main()
