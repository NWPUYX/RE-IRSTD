"""Supplemental matched source-pixel-density protocol, not the fixed512 table."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import argparse
import json
from pathlib import Path
import shutil
import sys
import time
import numpy as np
from PIL import Image
import torch
from torch.utils.data import DataLoader,Dataset

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE),str(ROOT.parent/'IRSTD/src')]
from native_unit_prior_evaluation import build,sha,source_statistics
from irstd_population_t.model import PopulationTModel
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.data import Data
from irstd.inference.decoder import decode as decode_centers
from evaluation import decode,postprocess,match_frame,metrics
from benchmark_cluster_bootstrap import cluster_ci
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast

MODELS=['irstd_robust','irstd_population','aa_yolo','yolo26']


def paths(name):
    if name=='irstd_population':
        home=HERE/'population_T_sourceAP_control_v1'
        return home/'best.pt',home/'epoch_01_predictions.json',home/'source_qualified_tests/original'
    stage={'irstd_robust':'native_unit_irstd_robust_native_residual_v1',
           'aa_yolo':'native_unit_aa_yolo_native_residual_v1','yolo26':'native_unit_yolo26_native_residual_v1'}[name]
    folder=HERE/stage
    checkpoint={'irstd_robust':HERE/'robust_T_composed_v1/best.pt',
                'aa_yolo':ROOT/'runs/AA-YOLO/DAUB-R/seed_3407/best.pt',
                'yolo26':HERE/'yolo26n_p2_DAUB_3407/best.pt'}[name]
    return checkpoint,folder/'source_val_predictions.json',folder/'frozen_four_domain_test'


def factory(name,checkpoint):
    if name in ['irstd_robust','yolo26']:
        model,state,_,actual=build(name)
        assert actual==checkpoint
    else:
        state=torch.load(checkpoint,map_location='cpu',weights_only=False)
        if name=='irstd_population':
            model=PopulationTModel(state['config']['recipe']).cuda().eval()
            model.load_state_dict(state['model']);model.set_mode(final=False)
            audit=json.loads((checkpoint.parent/'independent_audit.json').read_text(encoding='utf-8'))
            assert audit['passed'] and audit['checkpoint_sha256']==sha(checkpoint)
            for file,digest in {**state['config']['source_hashes'],**state['config']['diagnostic_hashes']}.items():assert sha(ROOT.parent/file)==digest,file
        else:
            identity=json.loads((HERE/'native_unit_aa_yolo_native_residual_v1/config.json').read_text(encoding='utf-8'))
            assert identity['checkpoint_sha256']==sha(checkpoint)
            for file,digest in identity['source_hashes'].items():assert sha(ROOT/file)==digest,file
            from model_adapter import build as aa_build
            model,criterion=aa_build('AA-YOLO');del criterion
            model.load_state_dict(state['model']);model.cuda().eval();os.chdir(ROOT)
    for p in model.parameters():p.requires_grad_(False)
    return model,state


class NativePixels(Dataset):
    def __init__(self,name,domain):
        self.name=name
        self.records=json.loads((ROOT/f'splits/{domain}_test.json').read_text(encoding='utf-8'))

    def __len__(self):return len(self.records)

    def image(self,record):
        w,h=record['width']*2,record['height']*2
        assert w%32==h%32==0
        with Image.open(record['path']) as source:
            assert source.size==(record['width'],record['height'])
            image=source.convert('RGB').resize((w,h),Image.Resampling.BICUBIC)
            if self.name.startswith('irstd_'):
                return torch.from_numpy(np.array(image.convert('L'),dtype=np.float32)/255.)[None]
            return torch.from_numpy(np.array(image,dtype=np.uint8)).permute(2,0,1)

    def __getitem__(self,index):return self.image(self.records[index]),index


def collate(batch):
    images,indices=zip(*batch)
    return torch.stack(images),indices


def source_equivalence(name,source,old_folder,state):
    payload=json.loads(source.read_text(encoding='utf-8'));summary=validation_summary(payload['frames'])
    expected=state.get('source_validation')
    if expected is not None:assert summary==expected
    elif name=='aa_yolo':assert abs(summary['pooled']['AP50']-state['source_val_AP50'])<1e-6
    else:assert summary['pooled']==state['validation']
    manifest=json.loads((old_folder/'freeze_manifest.json').read_text(encoding='utf-8'))
    checkpoint,_,_=paths(name)
    assert manifest['checkpoint_sha256']==sha(checkpoint) and manifest['threshold']==summary['threshold']
    for split in ['val','test']:
        records=json.loads((ROOT/f'splits/DAUB-R_{split}.json').read_text(encoding='utf-8'))
        assert all(r['width']==r['height']==256 for r in records)
    if name.startswith('irstd_'):
        recipe=state['config']['recipe'];base=Data('DAUB-R','val',recipe);renderer=NativePixels(name,'DAUB-R')
        for i in np.linspace(0,len(base)-1,16,dtype=int):assert torch.equal(renderer.image(base.records[i]),base.base_sample(i)['image'])
    else:
        from data_pipeline import load_frame
        records=json.loads((ROOT/'splits/DAUB-R_val.json').read_text(encoding='utf-8'))
        renderer=NativePixels(name,'DAUB-R')
        for i in np.linspace(0,len(records)-1,16,dtype=int):
            image,trans=load_frame(records[i]['path'])
            assert trans==(2.,2.,0,0) and torch.equal(renderer.image(records[i]),torch.from_numpy(image).permute(2,0,1))
    return summary


@torch.inference_mode()
def infer(name,model,loader,reference,destination):
    frames,predictions=[],[]
    for images,indices in loader:
        images=images.cuda()
        if not name.startswith('irstd_'):images=images.float()/255
        h,w=images.shape[-2:]
        if name.startswith('irstd_'):
            out=model(images);proposals=decode_centers(out,1e-5,{'box_nms_iou':None},reference);raws=[]
            for b,proposal in enumerate(proposals):
                center,score=proposal['centers'].cuda(),proposal['scores'].cuda();q=center.floor().long()
                value=out['log_size'][b,:,q[:,1],q[:,0]].T.float();ref=value.new_tensor(reference)
                wh=ref*torch.minimum(value.clamp_min(-20),(value.new_tensor([w,h])/ref).log()).exp()
                raws.append(torch.cat((center,wh,score[:,None],torch.ones_like(score[:,None])),1))
        elif name=='aa_yolo':raws=decode('AA-YOLO',model(images))
        else:
            from yolo26_matched.model import predict
            raws=predict(model,images)
        for raw,index in zip(raws,indices):
            record=loader.dataset.records[index];prediction=postprocess(raw,record,(2.,2.,0,0))
            frames.append(match_frame(prediction,record))
            predictions.extend({'image_id':record['id'],'category_id':1,'bbox':[x,y,x2-x,y2-y],'score':score}
                               for x,y,x2,y2,score in prediction.tolist())
    temp=destination.with_suffix('.tmp');temp.write_text(json.dumps({'frames':frames,'predictions':predictions},separators=(',',':')),encoding='utf-8');temp.replace(destination)
    return frames


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=MODELS,required=True);parser.add_argument('--source-only',action='store_true');args=parser.parse_args()
    name=args.model;home=HERE/f'native_pixel_{name}_v1';home.mkdir(exist_ok=True)
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    checkpoint,source,old=paths(name);model,state=factory(name,checkpoint)
    source_summary=source_equivalence(name,source,old,state);threshold=source_summary['threshold'];stats=source_statistics()
    assert stats['resize_median']==[2.,2.]
    for w,h in [(256,256),(720,480),(640,512),(640,480)]:
        raw=torch.tensor([[float(w),float(h),16.,16.,.9,1.]])
        pred=postprocess(raw,{'width':w,'height':h},(2.,2.,0,0))
        np.testing.assert_allclose((pred[0,:2]+pred[0,2:4])/2,[w/2,h/2],atol=1e-5,rtol=0)
        np.testing.assert_allclose(pred[0,2:4]-pred[0,:2],[8,8],atol=1e-5,rtol=0)
    identity={'model':name,'source':'DAUB-R','seed':3407,'checkpoint_sha256':sha(checkpoint),
        'script_sha256':sha(__file__),'plan_sha256':sha(HERE/'源像素密度四域公平诊断方案.md'),
        'source_cache_sha256':sha(source),'old_manifest_sha256':sha(old/'freeze_manifest.json'),
        'source_statistics':stats,'split_hashes':split_hashes(),'threshold':threshold,'native_resize':[2.,2.],
        'batch_cross_domain':1,'source_DAUB_cached_batch':4,'optimization_updates':0,
        'evaluation_hashes':{str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'evaluation.py',ROOT/'benchmark_fastdecode.py',ROOT/'benchmark_cluster_bootstrap.py',ROOT/'data_pipeline.py',HERE/'native_unit_prior_evaluation.py']},
        'source_equivalence_16_pixel_checks':True,'source_validation':source_summary,
        'role':'supplemental native-pixel diagnostic; different input budget; not fixed512 promotion or SOTA confirmation'}
    config=home/'config.json'
    if config.exists():assert json.loads(config.read_text(encoding='utf-8'))==identity
    else:write_json(config,identity)
    write_json(home/'source_preflight.json',{'passed':True,'config_sha256':sha(config),'source_pixel_checks':16,
        'coordinate_roundtrip_cases':4,'source_validation_cache_verified':True,'optimization_updates':0,'updated_at':now()})
    if args.source_only:return
    for suffix in ['predictions','metrics']:
        source_path=old/f'DAUB-R_{suffix}.json';path=home/f'DAUB-R_{suffix}.json'
        if path.exists():assert sha(path)==sha(source_path)
        else:shutil.copyfile(source_path,path)
    for domain in ['IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=home/f'{domain}_metrics.json'
        if path.exists():continue
        dataset=NativePixels(name,domain);loader=DataLoader(dataset,batch_size=1,num_workers=2,collate_fn=collate)
        loader=ReportingLoader(loader,home/'progress.json',domain)
        predictions=home/f'{domain}_predictions.json';started=time.perf_counter();torch.cuda.reset_peak_memory_stats()
        frames=json.loads(predictions.read_text(encoding='utf-8'))['frames'] if predictions.exists() else infer(name,model,loader,stats['input_median'],predictions)
        overall=metrics(frames,threshold);ci=cluster_ci(frames)
        if ci is not None:overall['AP50_cluster_CI95']=ci
        sizes=sorted({(r['width']*2,r['height']*2) for r in dataset.records})
        result={'source':'DAUB-R','target':domain,'seed':3407,'overall':overall,
            'by_group':{g:metrics([f for f in frames if f['group']==g],threshold) for g in sorted({f['group'] for f in frames})},
            'input_sizes':sizes,'input_pixel_ratios_vs512':[w*h/512**2 for w,h in sizes],
            'max_allocated_bytes':torch.cuda.max_memory_allocated(),'elapsed_seconds_under_shared_load':time.perf_counter()-started,'updated_at':now()}
        write_json(path,result);print(json.dumps({'target':domain,**overall}),flush=True)
    assert sha(checkpoint)==identity['checkpoint_sha256']
    assert sha(__file__)==identity['script_sha256'] and sha(HERE/'源像素密度四域公平诊断方案.md')==identity['plan_sha256']
    for file,digest in identity['evaluation_hashes'].items():assert sha(ROOT/file)==digest,file
    assert all(torch.equal(v.cpu(),state['model'][k]) for k,v in model.state_dict().items())
    cross=[json.loads((home/f'{d}_metrics.json').read_text(encoding='utf-8'))['overall'] for d in ['IRDST-H','IRSTD-UAV','ITSDT-15K']]
    result={'status':'completed','source':'DAUB-R','seed':3407,'completed_cells':4,
        'cross_domain_macro':{k:sum(r[k] for r in cross)/3 for k in ['AP50','AP50_95','F1','center_Pd_3px']},
        'all_tensors_unchanged':True,'optimization_updates':0,'role':identity['role'],'updated_at':now()}
    write_json(home/'summary.json',result);write_json(home/'progress.json',result)


if __name__=='__main__':main()
