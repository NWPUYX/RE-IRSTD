"""Gated fixed512 four-domain test of one source-selected locked readout."""
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from locked_readout_source import HOME,identity,build,infer,sha
from irstd_v2.data import make_loader
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now
from benchmark_progress import ReportingLoader
from benchmark_cluster_bootstrap import cluster_ci
from evaluation import metrics
import benchmark_fastdecode as fast


def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    audit_path=HOME/'independent_audit.json';audit=json.loads(audit_path.read_text(encoding='utf-8'))
    assert audit['passed'] and audit['promotion_passed']
    state=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False);bound,_=identity()
    weight=state['config']['locked_selected_weight'];key=str(weight)
    assert state['config']=={**bound,'locked_selected_weight':weight}
    assert sha(HOME/'best.pt')==audit['checkpoint_sha256']
    source=HOME/f'a{key}_source_val.json'
    assert validation_summary(json.loads(source.read_text(encoding='utf-8'))['frames'])==state['source_validation']
    model=build(bound,state['model']);folder=HOME/'source_qualified_tests';folder.mkdir(exist_ok=True)
    threshold=state['source_validation']['threshold']
    manifest={'checkpoint_sha256':sha(HOME/'best.pt'),'audit_sha256':sha(audit_path),'source_cache_sha256':sha(source),
        'script_sha256':sha(__file__),'decoder_sha256':sha(HERE/'locked_peak_decode.py'),
        'source_driver_sha256':sha(HERE/'locked_readout_source.py'),'evaluation_sha256':sha(ROOT/'evaluation.py'),
        'split_hashes':bound['split_hashes'],'threshold':threshold,'weight':weight,
        'input':'original fixed512 RGB bicubic letterbox then gray','size_rule':'original learned input-pixel size',
        'role':'source-qualified locked readout development; not independent SOTA confirmation'}
    path=folder/'freeze_manifest.json'
    if path.exists():assert json.loads(path.read_text(encoding='utf-8'))==manifest
    else:write_json(path,manifest)
    for domain in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=folder/f'{domain}_metrics.json'
        if path.exists():continue
        predictions=folder/f'{domain}_predictions.json'
        if not predictions.exists():
            loader=ReportingLoader(make_loader(domain,'test',bound['recipe']),folder/'progress.json',domain)
            write_json(predictions,infer(model,loader,bound['size_reference_512'],[weight],verify=True)[key])
        frames=json.loads(predictions.read_text(encoding='utf-8'))['frames'];overall=metrics(frames,threshold)
        ci=cluster_ci(frames)
        if ci is not None:overall['AP50_cluster_CI95']=ci
        result={'source':'DAUB-R','target':domain,'seed':3407,'overall':overall,
            'by_group':{g:metrics([f for f in frames if f['group']==g],threshold) for g in sorted({f['group'] for f in frames})},'updated_at':now()}
        write_json(path,result);print(json.dumps({'target':domain,**overall}),flush=True)
    assert all(torch.equal(value.cpu(),state['model'][name]) for name,value in model.state_dict().items())
    cross=[json.loads((folder/f'{d}_metrics.json').read_text(encoding='utf-8'))['overall'] for d in ['IRDST-H','IRSTD-UAV','ITSDT-15K']]
    result={'status':'completed','source':'DAUB-R','seed':3407,'completed_cells':4,
        'threshold':threshold,'weight':weight,'all_tensors_unchanged':True,
        'cross_domain_macro':{k:sum(x[k] for x in cross)/3 for k in ['AP50','AP50_95','F1','center_Pd_3px']},
        'role':manifest['role'],'updated_at':now()}
    write_json(folder/'summary.json',result);write_json(folder/'progress.json',result)


if __name__=='__main__':main()
