"""Summarize this round's completed controls and explicit failures."""
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from irstd_v2.settings import now


def main():
    stages = [('原IRSTD，原图固定尺寸', 'native_unit_irstd_v1_native_constant_v1'),
              ('联合IRSTD，原图固定尺寸', 'native_unit_irstd_robust_native_constant_v1'),
              ('联合IRSTD，原图尺寸残差', 'native_unit_irstd_robust_native_residual_v1'),
              ('联合IRSTD，输入固定尺寸', 'native_unit_irstd_robust_input_constant_v1'),
              ('正确统计IRSTD，原图固定尺寸', 'native_unit_irstd_stable_native_constant_v1'),
              ('MPR-Net，原图固定尺寸', 'native_unit_mpr_native_constant_v1'),
              ('YOLO26，原图固定尺寸', 'native_unit_yolo26_native_constant_v1'),
              ('AA-YOLO，原图固定尺寸', 'native_unit_aa_yolo_native_constant_v1')]
    lines = ['# 本轮验证结果与后续实验', '', f'[KNOWN｜HIGH] 更新时间{now()}。训练源DAUB-R、种子3407；所有完整测试使用各自源验证冻结阈值。此轮为开发诊断，不是四源三种子或独立SOTA确认。', '',
             '[COMPUTED｜HIGH] 下表每行均来自同一个模型/规则的完整三个跨域宏均值，不拼接不同版本的最佳指标。', '',
             '| 冻结版本 | AP50 | AP50:95 | F1 | 中心Pd3px | 宏FP/帧 |', '|---|---:|---:|---:|---:|---:|']
    completed = 0
    for name, stage in stages:
        folder = HERE/stage/'frozen_four_domain_test'
        path = folder/'summary.json'
        if not path.exists():
            continue
        value = json.loads(path.read_text(encoding='utf-8'))
        assert value['status'] == 'completed' and value['completed_cells'] == 4
        macro = value['cross_domain_macro']
        fp = sum(json.loads((folder/f'{d}_metrics.json').read_text(encoding='utf-8'))['overall']['FP_per_frame']
                 for d in ['IRDST-H', 'IRSTD-UAV', 'ITSDT-15K'])/3
        lines.append(f"| {name} | {macro['AP50']*100:.4f}% | {macro['AP50_95']*100:.4f}% | {macro['F1']*100:.4f}% | {macro['center_Pd_3px']*100:.4f}% | {fp:.5f} |")
        completed += 4
    lines += ['', f'[COMPUTED｜HIGH] 已完成上述{completed}个测试单元。原图固定尺寸来自源训练8×8；constant版本旁路尺寸头，native_residual保留尺寸残差；输入固定16对照分离坐标单位作用。三项核心结构仍用于中心/偏移，但此后处理偏离必须披露。', '',
              '[KNOWN｜HIGH] MPR-Net有多帧和冻结CLIP文本外部信息；AA-YOLO与YOLO26为单帧从头重训。各自适配/预算差异另列；不能把本表当成作者论文数字复现或当前全部SOTA覆盖。', '',
              '[COMPUTED｜HIGH] T特征对应6278参数的一轮训练完成2091更新及独立审计；源AP50/AP95/F1为80.1718%/63.8087%/76.0775%，强噪声AP50/F1为83.8116%/50.0000%。精细定位、背景AP、强噪声AP和极端尺度未全部通过，未做目标测试。', '',
              '[COMPUTED｜HIGH] 全热图分数标准化的两个候选未过源预筛；图外中心过滤对源四分之一缩放的已知尺寸F1仅由5.7143%变为5.8140%，没有解决主要问题。未扩大这两个方向的目标测试。', '',
              '[COMPUTED｜HIGH] 局部性审计中保持前景半径20、Z/C和stem局部输入逐值不变，stem GN输出MSE=1.1253066，T在GT点MSE=0.2046635。源统计T_only校准使T配对误差为0，并提高源24帧清洁及轻噪声排序；但强噪声F1下降，未过预筛。T_final还损害清洁准确率，未采用。', '',
              '[INFERRED｜MED] 后续针对已定位的T归一化背景耦合与读出失配进行受保护适配，而非继续平移阈值。T_only校准只作明确失败的初始化；训练T/final/现有四头23252参数，最大两轮，保留全部原源条件并增加T局部性核查。全部源条件与独立审计通过才进入新目标测试。', '',
              '[KNOWN｜HIGH] 仍保留原相对证据、条件零和/三膨胀率混合和全分辨率T；T专用stem共享卷积及affine，改用源训练固定统计，上下文与末端在线GN保留。64统计标量中T_only启用48，另外16是融合层对照的已存统计；学习参数仍808952。旧TF32证据算术未在本阶段修复，新颖性仍须对照DHiF等近邻工作及机制消融。', '',
              '[KNOWN｜HIGH] 当前没有整体SOTA或可直接发表结论。原测试已参与开发诊断，后续需要冻结完整训练配方、统一预算和后处理、四源三种子与未参与开发的确认场景。原始测试结果表不覆盖。']
    output = HERE/'本轮验证结果与后续实验_20261108.md'
    output.write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({'completed_cells': completed, 'report': str(output)}), flush=True)


if __name__ == '__main__':
    main()
