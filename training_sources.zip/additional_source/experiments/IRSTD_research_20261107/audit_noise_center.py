"""Recompute source gates and verify the fresh, center-only optimization chain."""
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_noise_center.run import sha,native_gates
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,split_hashes,now
from evaluation import metrics
from benchmark_center_metrics import center_metrics


def main():
    home=HERE/'noise_center_peak_guarded_v1'
    done=json.loads((home/'training_complete.json').read_text(encoding='utf-8'))
    state=torch.load(home/'best.pt',map_location='cpu',weights_only=False)
    last=torch.load(home/'last.pt',map_location='cpu',weights_only=False)
    cfg=state['config'];parent_path=HERE/'background_center_interpolation_refine_v1/best.pt'
    parent=torch.load(parent_path,map_location='cpu',weights_only=False)
    assert cfg==last['config'] and split_hashes()==cfg['split_hashes']
    assert sha(parent_path)==cfg['parent_sha256']
    for name,digest in cfg['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
    assert sha(HERE/'noise_validation_diagnostic/baseline.json')==cfg['noise_baseline_sha256']
    assert done['updates']==last['updates']==state['updates']==2091
    assert last['next_epoch']==done['epochs_run']==state['epoch']==1
    opt=last['optimizer']['state'];assert len(opt)==4
    assert all(int(v['step'])==2091 for v in opt.values())
    frozen=0;changed=[]
    for name,value in parent['model'].items():
        if not name.startswith('heads.center.'):
            for candidate in [state['model'],last['model'],last['ema']]:assert torch.equal(value,candidate[name]),name
            frozen+=1
        elif not torch.equal(value,state['model'][name]):changed.append(name)
    assert len(changed)==4
    assert all(torch.equal(v,last['ema'][n]) for n,v in state['model'].items())
    cached=json.loads((home/'epoch_01_predictions.json').read_text(encoding='utf-8'))['frames']
    assert len(cached)==1801 and validation_summary(cached)==state['source_validation']
    bg=json.loads((home/'epoch_01_swapped_predictions.json').read_text(encoding='utf-8'))['frames']
    original_threshold=torch.load(HERE/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)['source_validation']['threshold']
    assert metrics(bg,original_threshold)==state['background']['swapped_metrics']
    threshold=state['source_validation']['threshold']
    for factor in [4,16]:
        frames=json.loads((home/f'epoch_01_noise{factor}_predictions.json').read_text(encoding='utf-8'))['frames']
        assert len(frames)==24
        assert metrics(frames,threshold)==state['noise'][str(factor)]['box']
        assert center_metrics(frames,threshold)==state['noise'][str(factor)]['center']
    baseline=json.loads((home/'background_baseline.json').read_text(encoding='utf-8'))
    gates=native_gates(state,parent,baseline)
    assert gates==state['gates']==done['gates'] and all(gates.values())==done['promotion_passed']
    result={'passed':True,'promotion_passed':done['promotion_passed'],'checkpoint_sha256':sha(home/'best.pt'),
        'optimizer_steps':2091,'frozen_tensors':frozen,'changed_tensors':changed,'source_metrics_recalculated':True,
        'gates':gates,'updated_at':now()}
    write_json(home/'independent_audit.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
