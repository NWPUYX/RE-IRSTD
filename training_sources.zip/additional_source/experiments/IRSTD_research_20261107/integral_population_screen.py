"""Train-only population recalibration, then unchanged source AP prescreen."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
from collections import defaultdict
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.utils.data import DataLoader,Subset

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from integral_population_model import IntegralPopulationModel
from population_precision_screen import evaluate
from source_noise_geometry_probe import Clean
from irstd_scene_scale.run import locality_probe
from irstd_v2.data import Data,collate
from irstd_noise_center.data import validation_loader
from irstd_background_center.data import swapped_loader
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint
from native_unit_prior_evaluation import sha
import benchmark_fastdecode as fast

HOME=HERE/'integral_population_screen_v1'


@torch.inference_mode()
def calibrate(model,cfg):
    data=Data('DAUB-R','train',cfg);groups=defaultdict(list)
    for i,record in enumerate(data.records):groups[record['group']].append(i)
    indices=[items[j] for items in groups.values() for j in np.linspace(0,len(items)-1,min(12,len(items)),dtype=int)]
    assert len(indices)==84
    report=[]
    for name,module in model.population_modules():
        if name=='backbone.final.1':continue
        assert module.use_population
        total=torch.zeros(module.num_groups,dtype=torch.float64,device='cuda');second=torch.zeros_like(total);count=0
        def hook(norm,args):
            nonlocal total,second,count
            value=args[0].double().reshape(args[0].shape[0],module.num_groups,-1)
            total+=value.sum((0,2));second+=value.square().sum((0,2));count+=value.shape[0]*value.shape[2]
        handle=module.register_forward_pre_hook(hook)
        try:
            loader=DataLoader(Subset(data,indices),batch_size=4,num_workers=2,collate_fn=collate)
            for images,_ in loader:model(images.cuda())
        finally:handle.remove()
        old_mean=module.population_mean.clone();old_var=module.population_variance.clone()
        mean=total/count;variance=(second/count-mean.square()).clamp_min(0)
        module.population_mean.copy_(mean.float());module.population_variance.copy_(variance.float())
        report.append({'module':name,'count_per_group':count,'old_mean':old_mean.tolist(),'old_variance':old_var.tolist(),
            'mean':module.population_mean.tolist(),'variance':module.population_variance.tolist()})
    return {'source':'DAUB-R_train_only','indices':indices,'record_ids':[data.records[i]['id'] for i in indices],
        'layers':report,'moments':48}


@torch.inference_mode()
def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    endpoints={str(e):HERE/f'scene_scale_joint_v1/epoch_{e:02d}_ema.pt' for e in [2,4]}
    legacy=json.loads((HERE/'population_precision_screen_v1/result.json').read_text(encoding='utf-8'))['results']
    noise=json.loads((HERE/'noise_validation_diagnostic/baseline.json').read_text(encoding='utf-8'))['results']
    bg=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    config={'script_sha256':sha(__file__),'plan_sha256':sha(HERE/'积分证据源统计校准预筛方案.md'),
        'model_sha256':sha(HERE/'integral_population_model.py'),'evidence_sha256':sha(HERE/'integral_evidence_prototype.py'),
        'checkpoint_sha256':{e:sha(p) for e,p in endpoints.items()},'split_hashes':split_hashes(),'optimization_updates':0,'target_frames':0}
    write_json(HOME/'config.json',config);results={}
    for epoch,path in endpoints.items():
        state=torch.load(path,map_location='cpu',weights_only=False);recipe={**state['config']['recipe'],'evidence_arithmetic':'integral_FP64'}
        model=IntegralPopulationModel(recipe).cuda().eval();model.load_state_dict(state['model']);model.set_mode(final=False)
        initial={k:v.detach().clone() for k,v in model.named_parameters()};calibration=None
        for mode in ['original_moments','source_recalibrated']:
            if mode=='source_recalibrated':
                calibration=calibrate(model,recipe)
                save_checkpoint(HOME/f'epoch{epoch}_calibrated.pt',{'model':model.state_dict(),'config':{**state['config'],'recipe':recipe,
                    'screen_identity':config,'calibration':calibration,'role':'zero-step source-statistics recalibration; not promoted'},'optimization_updates':0})
            row={}
            for view in ['clean','noise4','noise16','swapped']:
                if view=='clean':loader=DataLoader(Clean(recipe),batch_size=4,num_workers=2,collate_fn=collate)
                elif view=='swapped':loader=swapped_loader(recipe)
                else:loader=validation_loader(recipe,int(view.removeprefix('noise')))
                row[view]=evaluate(model,loader,state['config']['size_reference_512'],state['source_validation']['threshold'])
            row['T_pair_MSE']=locality_probe(model,recipe,'cuda')
            row['prescreen']={'clean_AP_retained':row['clean']['AP50']>=legacy[f'{epoch}/legacy']['clean']['AP50']-.02,
                'noise4_AP_retained':row['noise4']['AP50']>=noise['4']['box']['AP50']-.005,
                'noise16_AP_plus2pp':row['noise16']['AP50']>=noise['16']['box']['AP50']+.02,
                'background_AP_retained':row['swapped']['AP50']>=bg['swapped_metrics']['AP50'],'T_locality':row['T_pair_MSE']<=1e-10}
            row['prescreen_passed']=all(row['prescreen'].values());row['calibration']=calibration
            assert all(torch.equal(value,initial[name]) for name,value in model.named_parameters())
            allowed={f'{name}.{suffix}' for name,_ in model.population_modules() if name!='backbone.final.1' for suffix in ['population_mean','population_variance']}
            for name,value in model.state_dict().items():
                if name not in allowed:assert torch.equal(value.cpu(),state['model'][name]),name
            results[f'{epoch}/{mode}']=row;write_json(HOME/'partial.json',{'results':results,'updated_at':now()})
        del model;torch.cuda.empty_cache()
    write_json(HOME/'result.json',{'status':'completed','results':results,'all_parameters_unchanged':True,'optimization_updates':0,'target_frames':0,'updated_at':now()})
    print(json.dumps({k:{'cleanAP':v['clean']['AP50'],'noise16AP':v['noise16']['AP50'],'prescreen':v['prescreen']} for k,v in results.items()}),flush=True)


if __name__=='__main__':main()
