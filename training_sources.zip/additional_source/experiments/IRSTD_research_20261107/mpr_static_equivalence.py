"""Verify the zero-gradient prompt cache before any matched MPR training."""
import hashlib
import json
from pathlib import Path
import sys
import torch

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'vendor_sota'),str(ROOT/'repositories/CLIP'),str(ROOT/'repositories/MPR-Net')]
from mpr_matched.model import StaticText,CACHE,CLIP_SHA
from irstd_v2.settings import write_json,now


def main():
    torch.set_num_threads(2);torch.manual_seed(3407)
    import clip
    original=clip.load
    clip.load=lambda name,*args,**kwargs:original(name,device='cpu',download_root=str(CACHE.parent))
    assert hashlib.sha256((CACHE.parent/'ViT-B-32.pt').read_bytes()).hexdigest()==CLIP_SHA
    from nets.MPR_DAUB import MPR
    model=MPR(num_classes=1,num_frame=5).eval()
    encoder=model.target_encoder
    # CLIP text transformer has no stochastic layers; causal attention keeps
    # the contexts at positions 61:77 out of the preceding EOT output.
    prototype=encoder.encode_target_classes(model.target_classes).detach().clone()
    with torch.no_grad():
        encoder.learnable_ctx.normal_(mean=10.,std=20.)
        encoder.clear_text_cache()
        changed=encoder.encode_target_classes(model.target_classes)
        context_error=float((changed-prototype).abs().max())
    assert context_error==0.
    for p in encoder.clip_model.parameters():p.requires_grad_(False)
    inputs=torch.randn(2,3,1,256,256);motion=torch.rand_like(inputs)
    model.zero_grad(set_to_none=True)
    before=model(inputs,motion_diffs=motion)
    before_loss=sum(v.square().mean() for v in before);before_loss.backward()
    grads={n:p.grad.detach().clone() for n,p in model.named_parameters() if p.grad is not None and not n.startswith('target_encoder.')}
    model.zero_grad(set_to_none=True)
    model.target_encoder=StaticText(prototype,model.target_classes,encoder.learnable_ctx)
    after=model(inputs,motion_diffs=motion)
    error=max(float((a.detach()-b.detach()).abs().max()) for a,b in zip(before,after))
    sum(v.square().mean() for v in after).backward()
    gradient_error=max(float((p.grad-grads[n]).abs().max()) for n,p in model.named_parameters() if n in grads)
    assert error==0. and gradient_error==0.
    CACHE.parent.mkdir(parents=True,exist_ok=True)
    torch.save({'prototypes':prototype,'names':model.target_classes,'CLIP_sha256':CLIP_SHA,
        'equivalence_passed':True,'context_independence_max_error':context_error,
        'CPU_detector_output_max_error':error,'CPU_detector_gradient_max_error':gradient_error},CACHE)
    report={'passed':True,'scope':'CPU FP32 eval-mode forward/backward equivalence; source training not yet run',
        'context_independence_max_error':context_error,'output_max_error':error,'gradient_max_error':gradient_error,
        'detector_gradients_checked':len(grads),'cached_prototype_shape':list(prototype.shape),
        'cache_sha256':hashlib.sha256(CACHE.read_bytes()).hexdigest(),'updated_at':now()}
    write_json(HOME/'mpr_static_equivalence.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
