"""Sequential four-model supplemental diagnostic; never select on test outcomes."""
import json
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PREVIOUS=HERE/'population_T_sourceAP_control_v1/source_qualified_tests/progress.json'


def main():
    while True:
        if PREVIOUS.exists():
            try:complete=json.loads(PREVIOUS.read_text(encoding='utf-8')).get('status')=='completed'
            except json.JSONDecodeError:complete=False
            if complete:break
        time.sleep(10)
    for model in ['irstd_population','aa_yolo','yolo26','irstd_robust']:
        home=HERE/f'native_pixel_{model}_v1'
        assert json.loads((home/'source_preflight.json').read_text(encoding='utf-8'))['passed']
        python=str(ROOT/'.venv/Scripts/python.exe') if model=='aa_yolo' else sys.executable
        with (HERE/f'native_pixel_{model}.log').open('a',encoding='utf-8') as stream:
            subprocess.run([python,str(HERE/'native_pixel_evaluation.py'),'--model',model],cwd=ROOT,
                stdout=stream,stderr=subprocess.STDOUT,check=True)
        print(json.dumps({'completed_model':model,'protocol':'source-native pixel density, not fixed512'}),flush=True)
    print(json.dumps({'status':'completed','models':4,'cells':16,'optimization_updates':0}),flush=True)


if __name__=='__main__':main()
