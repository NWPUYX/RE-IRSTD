"""Full clean-source threshold calibration after the isolated arithmetic repair."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import hashlib
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_stable_evidence.model import StableModel
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint
from irstd_native_precision.run import quality
from irstd_geometry_balance.run import probe
from irstd_background_center.run import background_diagnostic
from irstd_noise_center.data import validation_loader
from benchmark_progress import ReportingLoader
from benchmark_center_metrics import center_metrics
from evaluation import metrics
import benchmark_fastdecode as fast

HOME=HERE/'stable_evidence_source_calibrated_v1'
PARENT=HERE/'background_center_interpolation_refine_v1'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def gates(row,parent):
    full,original,large,margin=quality(row)
    v,p=row['source_validation'],parent['source_validation']
    fine=[v['pooled']['AP50_95']-p['pooled']['AP50_95']+.005]
    fine.extend(v['by_group'][g]['AP50_95']-b['AP50_95']+.005 for g,b in p['by_group'].items())
    numeric=json.loads((HERE/'native_size_evidence_probe.json').read_text(encoding='utf-8'))['summary']
    return {'original_source_and_geometry_gates':original,'enlarge_original':large,'fine_AP95_v1':margin>=0,
        'fine_AP95_parent':min(fine)>=0,'source_F1_recalibrated':v['pooled']['F1']>=p['pooled']['F1']-.02,
        'evidence_numerical_error_90percent':numeric['centered_IEEE']['Z_MAE']<=.1*numeric['raw_default']['Z_MAE']}


@torch.inference_mode()
def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    if (HOME/'source_complete.json').exists():return
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False)
    recipe={**parent['config']['recipe'],'name':HOME.name,'evidence_arithmetic':'centered_IEEE',
        'initialization':'unchanged_parent_EMA_no_optimization','epochs':0,'zero_extra_training':True}
    files=[* (ROOT/'irstd_stable_evidence').glob('*.py'),Path(__file__),ROOT/'benchmark_progress.py']
    diagnostic=[HERE/'native_size_evidence_probe.json',HERE/'evidence_numeric_probe.json',HERE/'stable_evidence_source_cohort_v1/result.json']
    config={'recipe':recipe,'source':'DAUB-R','seed':3407,'split_hashes':split_hashes(),'parent_sha256':sha(PARENT/'best.pt'),
        'zero_extra_training':True,'size_reference_512':parent['config']['size_reference_512'],
        'source_hashes':{**parent['config']['source_hashes'],**{str(p.relative_to(ROOT.parent)):sha(p) for p in files}},
        'diagnostic_hashes':{str(p.relative_to(ROOT.parent)):sha(p) for p in diagnostic}}
    for name,value in {**config['source_hashes'],**config['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==value,name
    if (HOME/'config.json').exists():assert json.loads((HOME/'config.json').read_text(encoding='utf-8'))==config
    else:write_json(HOME/'config.json',config)
    model=StableModel(recipe).cuda().eval();model.load_state_dict(parent['model'])
    for p in model.parameters():p.requires_grad_(False)
    assert sum(p.numel() for p in model.parameters())==808952
    assert all(torch.equal(v.cpu(),parent['model'][n]) for n,v in model.state_dict().items())
    reference=config['size_reference_512'];device=torch.device('cuda');path=HOME/'best_source_val_predictions.json'
    frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,
        ReportingLoader(make_loader('DAUB-R','val',recipe),HOME/'progress.json','source_val'),device,reference,path)
    validation=validation_summary(frames);write_json(HOME/'progress.json',{'status':'source_validation','phase':'geometry and diagnostics','updated_at':now()})
    geom,per_scale=probe(model,recipe,reference,device)
    row={'epoch':parent['epoch'],'updates':0,'source_validation':validation,'geometry_probe':geom,'per_scale':per_scale,
        'background':background_diagnostic(model,recipe,reference,device,HOME,'calibrated'),'noise':{}}
    for factor in [4,16]:
        f=evaluate(model,validation_loader(recipe,factor),device,reference,HOME/f'noise{factor}_predictions.json')
        row['noise'][str(factor)]={'box':metrics(f,validation['threshold']),'center':center_metrics(f,validation['threshold'])}
    row['gates']=gates(row,parent)
    assert all(torch.equal(v.cpu(),parent['model'][n]) for n,v in model.state_dict().items())
    assert torch.backends.cudnn.conv.fp32_precision=='tf32'
    for name,value in {**config['source_hashes'],**config['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==value,name
    save_checkpoint(HOME/'best.pt',{**row,'model':model.state_dict(),'config':config})
    write_json(HOME/'source_complete.json',{'status':'completed','promotion_passed':all(row['gates'].values()),'gates':row['gates'],
        'optimization_updates':0,'all_learned_tensors_unchanged':True,'target_test_cells':0,'updated_at':now()})
    write_json(HOME/'progress.json',json.loads((HOME/'source_complete.json').read_text(encoding='utf-8')))
    write_json(HOME/'source_result.json',row);print(json.dumps(row),flush=True)


if __name__=='__main__':main()
