"""Execute the fixed six-epoch budget, source audit, and qualified four-domain test."""
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];HOME=HERE/'peak_calibrated_v1'


def run(script,log,*args):
    with (HERE/log).open('a',encoding='utf-8') as stream:
        subprocess.run([sys.executable,str(HERE/script),*args],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)


def main():
    assert json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))['passed']
    try:
        run('peak_calibrated_training.py','peak_calibrated_training.log')
        run('audit_peak_calibrated.py','peak_calibrated_audit.log')
        audit=json.loads((HOME/'independent_audit.json').read_text(encoding='utf-8'));assert audit['passed']
        if audit['promotion_passed']:run('evaluate_peak_calibrated.py','peak_calibrated_frozen_test.log')
        print(json.dumps({'status':'completed','promotion_passed':audit['promotion_passed'],
            'target_tests_started':audit['promotion_passed']}),flush=True)
    finally:
        subprocess.run([sys.executable,str(HERE/'update_progress_report.py')],cwd=ROOT,check=False)


if __name__=='__main__':main()
