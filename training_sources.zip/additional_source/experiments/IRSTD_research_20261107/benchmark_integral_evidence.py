"""Component-only timing under shared GPU load; not deployment FPS."""
import json
from pathlib import Path
import sys
import statistics
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from integral_evidence_prototype import IntegralEvidence
from irstd.models.relative_evidence import RelativeEvidenceEncoder
from irstd_adapter import model_config
from irstd_v2.settings import write_json,now
from native_unit_prior_evaluation import sha


@torch.inference_mode()
def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    cfg=model_config()['model']['evidence']
    models={'legacy':RelativeEvidenceEncoder(cfg).cuda().eval(),'integral64':IntegralEvidence(cfg).cuda().eval()}
    generator=torch.Generator(device='cuda').manual_seed(3407);results={}
    for side in [512,1024]:
        image=torch.rand(1,1,side,side,generator=generator,device='cuda')*.5+.25
        for model in models.values():
            for _ in range(2):model(image)
        torch.cuda.synchronize();times={k:[] for k in models};memory={k:[] for k in models}
        for repeat in range(6):
            for name in (list(models) if repeat%2==0 else list(reversed(models))):
                start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
                torch.cuda.reset_peak_memory_stats();start.record();out=models[name](image);end.record();end.synchronize()
                times[name].append(start.elapsed_time(end));memory[name].append(torch.cuda.max_memory_allocated());del out
        results[str(side)]={name:{'median_GPU_elapsed_ms_under_shared_load':statistics.median(values),
            'range_ms':[min(values),max(values)],'max_allocated_bytes_process':max(memory[name])} for name,values in times.items()}
    write_json(HERE/'integral_evidence_component_benchmark.json',{'results':results,'batch':1,
        'repeats':6,'interleaved_order':True,'implementation_sha256':sha(HERE/'integral_evidence_prototype.py'),
        'script_sha256':sha(__file__),'scope':'evidence component only; shared GPU; not full model or isolated deployment throughput','updated_at':now()})
    print(json.dumps(results),flush=True)


if __name__=='__main__':main()
