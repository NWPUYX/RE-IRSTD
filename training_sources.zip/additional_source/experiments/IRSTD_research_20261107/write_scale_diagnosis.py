"""Summarize source-only scale controls without claiming target improvements."""
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    renderer=read(HERE/'source_renderer_probe_v1/result.json')['results']
    mosaic=read(HERE/'source_mosaic_probe_v1/result.json')['results']
    density=read(HERE/'source_pixel_density_probe_v1/result.json')['results']
    for name in ['aa_yolo','yolo26']:
        path=HERE/f'source_pixel_density_{name}_v1/result.json'
        if path.exists():density.update(read(path)['results'])
    lines=['# 源域尺度诊断与下一轮训练依据','',
        '[COMPUTED｜HIGH] 本文仅涉及源验证衍生场景；没有目标域测试、没有权重更新、没有在受试子集重选阈值。它们是开发诊断，不是独立泛化成绩。', '',
        '| 模型 | 渲染/相对尺度 | 已知源尺寸AP50 | 已知源尺寸F1 | 目标邻域平均分数 |',
        '|---|---|---:|---:|---:|']
    for model,report in renderer.items():
        for key,row in report['results'].items():
            if key.startswith('torch8bit'):continue
            m=row['known_source_size']
            lines.append(f"| {model} | {key} | {m['AP50']*100:.4f}% | {m['F1']*100:.4f}% | {row['mean_GT_peak']:.4f} |")
    lines+=['', '[COMPUTED｜HIGH] 相同几何下PIL与浮点bicubic渲染表现不同；量化到8位没有全面恢复响应。四分之一尺度仍失败，因此不能把全部退化归于插值。平移、有效区域与目标尺度仍会共同影响检测。', '',
        '| 模型 | 拼接阶数 | 学习尺寸AP50 | 已知尺寸AP50 | 已知尺寸F1 | 尺寸log-MAE |',
        '|---|---:|---:|---:|---:|---:|']
    for model,report in mosaic.items():
        for k,row in report['results'].items():
            lines.append(f"| {model} | {k} | {row['learned']['AP50']*100:.4f}% | {row['known_source_size']['AP50']*100:.4f}% | {row['known_source_size']['F1']*100:.4f}% | {row['size_log_MAE']:.6f} |")
    lines+=['', '[COMPUTED｜HIGH] 完整源图拼接没有灰色填充且保留全部标签，但更小目标的置信度和尺寸响应仍退化。该控制同时改变目标数量、场景内容及接缝，不能作为纯粹填充因果分解。', '',
        '| 模型 | 相同2×2场景输入 | 学习尺寸AP50 | 学习尺寸F1 | 已知尺寸AP50 | 原图中心Pd |',
        '|---|---:|---:|---:|---:|---:|']
    for model,report in density.items():
        for side,row in report['results'].items():
            m=row['learned']
            lines.append(f"| {model} | {side} | {m['AP50']*100:.4f}% | {m['F1']*100:.4f}% | {row['known_source_size']['AP50']*100:.4f}% | {m['center_Pd_3px']*100:.4f}% |")
    lines+=['', '[COMPUTED｜HIGH] 1024输入相比512处理四倍像素，坐标均逆映射回相同原拼接图后评价。没有把阈值重选或已知尺寸结果替换进学习头成绩。耗时来自并行训练/测试中的小样本测量，不可作为独占部署速度。', '',
        '[INFERRED｜MED] 相同源场景恢复训练像素密度后响应显著恢复，支持继续检查输入像素密度失配；目前不能据此推断真实跨域恢复幅度。单帧对照同策略的结果用于识别共同的预处理增益。', '',
        '[KNOWN｜HIGH] 正在进行的scene_scale_joint_v1固定为最多四轮、18项源检查：全参数低学习率适配，完整场景小目标/清洁缩放/噪声/背景联合监督；不在训练中途更换配方。相对证据、条件零和、全分辨率T保留；固定T统计和额外预算显式记录。', '',
        '[KNOWN｜HIGH] 残差尺寸是源先验再校准，并非已确认坐标错误修复。当前尺寸头直接监督输入尺寸；若学会正确尺度，残差可能重复校正。原解码继续作为主规则。']
    (HERE/'源尺度诊断结果与训练依据.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps({'renderer_models':list(renderer),'density_models':list(density)}),flush=True)


if __name__=='__main__':main()
