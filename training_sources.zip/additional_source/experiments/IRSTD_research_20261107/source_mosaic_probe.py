"""All-label source-val mosaics: a diagnostic, never a target-driven fit."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import random
import sys
import numpy as np
from PIL import Image
import torch
from torch.utils.data import DataLoader, Dataset

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from source_renderer_probe import build, sha, source_statistics, PopulationTModel
from irstd_v2.data import Data, collate, original_boxes
from irstd_v2.settings import write_json, now, split_hashes
from irstd.inference.decoder import decode
from evaluation import postprocess, match_frame, metrics
import benchmark_fastdecode as fast

HOME = HERE/'source_mosaic_probe_v1'


def mosaic(base, indices, k):
    assert len(indices) == k*k and len(set(indices)) == k*k
    canvas = Image.new('RGB', (256*k, 256*k))
    boxes, identities = [], []
    for slot, index in enumerate(indices):
        record = base.records[index]
        assert record['width'] == record['height'] == 256
        with Image.open(record['path']) as image:
            assert image.size == (256, 256)
            canvas.paste(image.convert('RGB'), ((slot % k)*256, (slot//k)*256))
        box = original_boxes(record)
        box += torch.tensor([(slot % k)*256, (slot//k)*256]*2)
        boxes.append(box*(2/k))
        identities.append(record['id'])
    image = canvas.resize((512, 512), Image.Resampling.BICUBIC).convert('L')
    image = torch.from_numpy(np.array(image, dtype=np.float32)/255.)[None]
    boxes = torch.cat(boxes)
    assert len(boxes) == sum(len(base.records[i]['boxes']) for i in indices)
    assert (boxes >= 0).all() and (boxes <= 512).all()
    if k == 1:
        sample = base.base_sample(indices[0])
        assert torch.equal(image, sample['image']) and torch.equal(boxes, sample['boxes'])
    return image, boxes, identities


class Probe(Dataset):
    def __init__(self, recipe):
        self.base = Data('DAUB-R', 'val', recipe)
        spec = json.loads((HERE/'wide_scale_source_probe.json').read_text(encoding='utf-8'))
        self.rows = []
        for i, identity in zip(spec['source_indices'], spec['source_record_ids']):
            assert self.base.records[i]['id'] == identity
            pool = [j for j in range(len(self.base)) if j != i]
            random.Random(3407+i).shuffle(pool)
            for k in [1, 2, 3, 4]:
                self.rows.append((k, [i]+pool[:k*k-1]))

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        k, ids = self.rows[index]
        image, boxes, identities = mosaic(self.base, ids, k)
        value = boxes.clone()
        value[:, 2:] -= value[:, :2]
        record = {'id': f'mosaic_val_{index}', 'group': f'mosaic_{index//4}',
                  'width': 512, 'height': 512, 'boxes': value.tolist()}
        return {'image': image, 'boxes': boxes, 'k': k, 'record': record, 'source_ids': identities}


@torch.inference_mode()
def main():
    HOME.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    fast.install()
    stats = source_statistics()
    config = {'script_sha256': sha(__file__), 'plan_sha256': sha(HERE/'完整源图拼接尺度诊断方案.md'),
              'source_subset_sha256': sha(HERE/'wide_scale_source_probe.json'), 'split_hashes': split_hashes(),
              'source_split': 'DAUB-R_val_only', 'optimization_updates': 0, 'target_frames': 0}
    if (HOME/'config.json').exists():
        assert json.loads((HOME/'config.json').read_text(encoding='utf-8')) == config
    else:
        write_json(HOME/'config.json', config)
    results = {}
    for name in ['robust', 'population']:
        if name == 'robust':
            model, state, recipe, checkpoint = build('irstd_robust')
        else:
            checkpoint = HERE/'population_T_sourceAP_control_v1/best.pt'
            state = torch.load(checkpoint, map_location='cpu', weights_only=False)
            recipe = state['config']['recipe']
            model = PopulationTModel(recipe).cuda().eval()
            model.load_state_dict(state['model'], strict=True)
            model.set_mode(final=False)
        checkpoint_hash = sha(checkpoint)
        threshold = state['source_validation']['threshold']
        rows = {}
        loader = DataLoader(Probe(recipe), batch_size=4, num_workers=2, collate_fn=collate)
        for images, samples in loader:
            out = model(images.cuda())
            decoded = decode(out, 1e-5, {'box_nms_iou': None}, stats['input_median'])
            for b, (proposal, sample) in enumerate(zip(decoded, samples)):
                row = rows.setdefault(str(sample['k']), {'learned': [], 'known_source_size': [], 'peaks': [], 'size_log_error': [], 'source_ids': []})
                center, score = proposal['centers'].cuda(), proposal['scores'].cuda()
                q = center.floor().long()
                value = out['log_size'][b, :, q[:, 1], q[:, 0]].T.float()
                ref = value.new_tensor(stats['input_median'])
                wh = ref*torch.minimum(value.clamp_min(-20), (value.new_tensor([512, 512])/ref).log()).exp()
                raw = torch.cat((center, wh, score[:, None], torch.ones_like(score[:, None])), 1)
                for rule in ['learned', 'known_source_size']:
                    candidate = raw.clone()
                    if rule == 'known_source_size':
                        candidate[:, 2:4] = candidate.new_tensor(stats['input_median'])/sample['k']
                    row[rule].append(match_frame(postprocess(candidate, sample['record'], (1., 1., 0, 0)), sample['record']))
                for box in sample['boxes']:
                    x, y = ((box[:2]+box[2:])/2).floor().long().tolist()
                    row['peaks'].append(float(out['center_logits'][b, 0, max(y-3, 0):min(y+4, 512), max(x-3, 0):min(x+4, 512)].max().sigmoid()))
                    target = ((box[2:]-box[:2])/torch.tensor(stats['input_median'])).log().cuda()
                    row['size_log_error'].append(float((out['log_size'][b, :, y, x]-target).abs().mean()))
                row['source_ids'].append(sample['source_ids'])
        assert all(torch.equal(v.cpu(), state['model'][k]) for k, v in model.state_dict().items())
        assert sha(checkpoint) == checkpoint_hash
        results[name] = {'checkpoint_sha256': checkpoint_hash, 'threshold': threshold, 'all_tensors_unchanged': True,
            'results': {k: {**{rule: metrics(row[rule], threshold) for rule in ['learned', 'known_source_size']},
                           'mean_GT_peak': float(np.mean(row['peaks'])),
                           'GT_peak_above_threshold_fraction': float(np.mean(np.array(row['peaks']) >= threshold)),
                           'size_log_MAE': float(np.mean(row['size_log_error'])), 'source_ids': row['source_ids']} for k, row in rows.items()}}
        del model
        torch.cuda.empty_cache()
    write_json(HOME/'result.json', {'status': 'completed', 'results': results, 'optimization_updates': 0,
                                    'target_frames': 0, 'updated_at': now()})
    print(json.dumps({name: {k: {'AP': value['known_source_size']['AP50'], 'F1': value['known_source_size']['F1'],
        'size_log_MAE': value['size_log_MAE']} for k, value in report['results'].items()} for name, report in results.items()}), flush=True)


if __name__ == '__main__':
    main()
