"""Source-paired T/D feature intervention; no optimization or target data."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import sys
import hashlib
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from irstd_background_center.data import Pairs, collate_pairs
from classification_feature_probe import views
from native_unit_prior_evaluation import build, source_statistics, apply_prior
from irstd.inference.decoder import decode
from evaluation import postprocess, match_frame, metrics
from irstd_v2.settings import write_json, now, split_hashes
import benchmark_fastdecode as fast


class Paired(Dataset):
    def __init__(self, recipe, kind):
        self.pairs = Pairs(recipe, 'val')
        self.records = self.pairs.records
        self.kind = kind

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, index):
        if self.kind == 'background':
            return self.pairs[index]
        i = self.pairs.indices[index]
        original = self.pairs.base.base_sample(i)
        images, _ = views(original, i+100000000)
        return ({**original, 'view_type': 'native'},
                {**original, 'image': images[1 if self.kind == 'noise4' else 2], 'view_type': self.kind})


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def matched(outputs, samples, records, stats):
    frames = []
    output = {'center_logits': outputs['center_logits'], 'offsets': outputs['offsets'], 'log_size': None}
    decoded = decode(output, 1e-5, {'box_nms_iou': None}, stats['input_median'])
    for proposal, sample in zip(decoded, samples):
        center, score = proposal['centers'].cuda(), proposal['scores'].cuda()
        raw = torch.cat((center, torch.ones_like(center), score[:, None], torch.ones_like(score[:, None])), 1)
        raw = apply_prior(raw, sample['trans'], stats, 'native_constant')
        record = records[sample['record_index']]
        frames.append(match_frame(postprocess(raw, record, sample['trans']), record))
    return frames


@torch.inference_mode()
def main():
    folder = HERE/'paired_path_intervention_v1'
    folder.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    fast.install()
    model, state, recipe, checkpoint = build('irstd_robust')
    threshold = state['source_validation']['threshold']
    stats = source_statistics()
    identity = {'checkpoint_sha256': sha(checkpoint), 'script_sha256': sha(__file__), 'split_hashes': split_hashes(),
                'source_statistics': stats, 'threshold': threshold, 'optimization_updates': 0,
                'scope': 'source24 paired hidden-feature interventions, not deployed models or target tests'}
    if (folder/'config.json').exists():
        assert json.loads((folder/'config.json').read_text(encoding='utf-8')) == identity
    else:
        write_json(folder/'config.json', identity)
    results = {}
    for kind in ['background', 'noise4', 'noise16']:
        path = folder/f'{kind}_result.json'
        if path.exists():
            results[kind] = json.loads(path.read_text(encoding='utf-8'))
            continue
        dataset = Paired(recipe, kind)
        loader = DataLoader(dataset, batch_size=2, num_workers=2, collate_fn=collate_pairs)
        frames = {k: [] for k in ['cleanT_cleanD', 'augT_augD', 'cleanT_augD', 'augT_cleanD']}
        peak = {k: [] for k in frames}
        identities, replay = [], 0
        for batch, (images, samples) in enumerate(loader):
            n = len(samples)//2
            saved = []
            handle = model.backbone.final.register_forward_pre_hook(lambda module, args: saved.append(args[0]))
            try:
                actual = model(images.cuda(), valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
            finally:
                handle.remove()
            assert len(saved) == 1
            fused = saved[0]
            width = fused.shape[1]//2
            restored = model.backbone.final(fused)
            for key, head in [('center_logits', model.heads.center), ('offsets', model.heads.offset)]:
                assert torch.equal(head(restored), actual[key]), key
            replay += 1
            mixed = torch.cat((torch.cat((fused[:n, :width], fused[n:, width:]), 1),
                               torch.cat((fused[n:, :width], fused[:n, width:]), 1)), 0)
            final = model.backbone.final(mixed)
            logits, offsets = model.heads.center(final), model.heads.offset(final)
            outputs = {
                'cleanT_cleanD': {k: actual[k][:n] for k in ['center_logits', 'offsets']},
                'augT_augD': {k: actual[k][n:] for k in ['center_logits', 'offsets']},
                'cleanT_augD': {'center_logits': logits[:n], 'offsets': offsets[:n]},
                'augT_cleanD': {'center_logits': logits[n:], 'offsets': offsets[n:]},
            }
            for name, output in outputs.items():
                frames[name].extend(matched(output, samples[:n], dataset.records, stats))
                for b, sample in enumerate(samples[:n]):
                    for box in sample['boxes']:
                        x, y = ((box[:2]+box[2:])/2).floor().long().tolist()
                        patch = output['center_logits'][b, 0, max(y-3, 0):min(y+4, 512), max(x-3, 0):min(x+4, 512)]
                        peak[name].append(float(patch.max()))
            identities.extend(s['sample_id'] for s in samples[:n])
            write_json(folder/'progress.json', {'status': 'source_intervention', 'kind': kind, 'batch': batch+1,
                                              'total_batches': len(loader), 'updated_at': now()})
        assert all(len(v) == 24 for v in frames.values())
        baseline = np.asarray(peak['cleanT_cleanD'])
        row = {'frames': 24, 'source_record_ids': identities, 'identity_replay_batches_passed': replay,
               'metrics': {k: metrics(v, threshold) for k, v in frames.items()},
               'peak_logit': {k: {'mean': float(np.mean(v)), 'paired_clean_MSE': float(np.mean((np.asarray(v)-baseline)**2)),
                                  'values': v} for k, v in peak.items()}}
        write_json(path, row)
        results[kind] = row
        print(json.dumps({'kind': kind, 'metrics': row['metrics'],
                          'peak_MSE': {k: v['paired_clean_MSE'] for k, v in row['peak_logit'].items()}}), flush=True)
    assert all(torch.equal(v.cpu(), state['model'][k]) for k, v in model.state_dict().items())
    assert sha(checkpoint) == identity['checkpoint_sha256']
    result = {'status': 'completed', 'all_tensors_unchanged': True, 'optimization_updates': 0,
              'results': results, 'scope': identity['scope'], 'updated_at': now()}
    write_json(folder/'result.json', result)
    write_json(folder/'progress.json', {'status': 'completed', 'updated_at': now()})


if __name__ == '__main__':
    main()
