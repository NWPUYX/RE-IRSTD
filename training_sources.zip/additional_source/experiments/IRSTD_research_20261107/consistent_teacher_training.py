"""Bounded source-only adaptation; no target-based selection or gate relaxation."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
from collections import Counter
import copy
import json
import math
from pathlib import Path
import random
import shutil
import sys
import time
import traceback
import numpy as np
import torch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from peak_calibrated_model import PeakCalibratedModel as IntegralPopulationModel
from integral_evidence_prototype import IntegralEvidence
from consistent_teacher_loss import losses
from peak_calibrated_evaluation import evaluate,background_diagnostic,evaluate_mosaics
from irstd_population_t.model import PopulationTModel
from irstd_scene_scale.run import gates,row_key,locality_probe,buffers_fixed
from irstd_scene_scale.data import training_loader
from irstd_robust_t.run import sha,mechanisms
from irstd_robust_t.probe import extreme_probe
from irstd_adapter import model_config
from irstd_v2.data import make_loader
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint,rng_state,restore_rng
from irstd_geometry_balance.run import probe
from irstd_noise_center.data import validation_loader
from benchmark_progress import ReportingLoader
from benchmark_center_metrics import center_metrics
from evaluation import metrics
import benchmark_fastdecode as fast

HOME=HERE/'consistent_teacher_v1'
INITIAL=HERE/'peak_calibrated_v1/best.pt'
CLEAN_TEACHER=HERE/'scene_scale_joint_v1/epoch_02_ema.pt'
NOISE_TEACHER=HERE/'integral_joint_v1/epoch_01_ema.pt'
GATE_PARENT=HERE/'robust_T_composed_v1/best.pt'
PRIORITY=HERE/'primary_work_priority.json'
PREFIXES=('backbone.target_path.','backbone.final.','heads.')


def construct(cfg,state,device):
    model=IntegralPopulationModel(cfg).to(device);model.load_state_dict(state,strict=True);model.set_mode(final=False)
    assert isinstance(model.evidence,IntegralEvidence)
    exempt={id(p) for module in model.modules() if isinstance(module,torch.nn.GroupNorm) for p in module.parameters(recurse=False)}
    exempt.update(id(p) for n,p in model.named_parameters() if n.endswith(('.bias','.gamma')))
    groups={}
    for name,p in model.named_parameters():
        p.requires_grad_(True)
        lr=5e-5 if name.startswith(PREFIXES) else 1e-5
        groups.setdefault((lr,0. if id(p) in exempt else .0005),[]).append(p)
    optimizer=torch.optim.AdamW([{'params':v,'lr':lr,'weight_decay':wd} for (lr,wd),v in groups.items()],betas=tuple(model_config()['train']['betas']))
    teachers=[]
    for path in [CLEAN_TEACHER,NOISE_TEACHER]:
        saved=torch.load(path,map_location='cpu',weights_only=False)
        teacher_class=PopulationTModel if path==CLEAN_TEACHER else IntegralPopulationModel
        teacher=teacher_class(saved['config']['recipe']).to(device)
        teacher.load_state_dict(saved['model'],strict=True);teacher.set_mode(final=False);teacher.eval()
        for p in teacher.parameters():p.requires_grad_(False)
        teachers.append(teacher)
    return model,teachers,optimizer


def identity():
    initial=torch.load(INITIAL,map_location='cpu',weights_only=False)
    proof=json.loads((INITIAL.parent/'independent_audit.json').read_text(encoding='utf-8'))
    assert proof['passed'] and not proof['promotion_passed'] and proof['checkpoint_sha256']==sha(INITIAL)
    cfg={**initial['config']['recipe'],'name':HOME.name,'epochs':2,
        'evidence_arithmetic':'local_integral_FP64_to_FP32','population_moments_frozen':True,
        'clean_teacher':'training-GT-IoU selection between scene E2 and integral E1 raw-main native outputs',
        'noise_teacher':'frozen integral E1; same numerical evidence and calibrated score map',
        'native_teacher_selection':'source_train_GT_neighborhood_clipped_box_IoU_mean; legacy on tie',
        'native_T_local_weight':0.,'native_T_global_weight':0.,'paired_T_local_weight':1.,
        'photo_teacher_weights':{'peak':.5,'shape':.1,'hard_negative_union':.05,'geometry':.25},
        'teacher_T_feature_matching':False,'maximum_validation_checks':2,
        'initialization':'source-selected peak calibrated best; prior failed source stages retained; fresh AdamW',
        'decoder':'raw_main_peaks_calibrated_score_map', 'locked_readout_weight':.25,
        'native_location_KL_weight':.5,'native_location_temperature':.5,
        'all_augmented_positive_weight':0.,'geometry_positive_weight':.1,'photo_positive_extra_weight':0.,'positive_logit_margin':2.,
        'learning_rates':{'T_fusion_center_aux':5e-5,'offset_size':5e-5,'stem_context':1e-5}}
    files=[Path(__file__),HERE/'consistent_teacher_loss.py',HERE/'native_teacher_selection.py',HERE/'peak_calibrated_model.py',
        HERE/'peak_calibrated_evaluation.py',HERE/'locked_peak_decode.py',HERE/'数值一致教师与几何校准后续方案.md']
    evidence=[HERE/'peak_calibrated_v1/independent_audit.json',HERE/'source_head_gradient_diagnostic_v1/result.json']
    result={**initial['config'],'recipe':cfg,
        'source_hashes':{**initial['config']['source_hashes'],**{str(p.relative_to(ROOT.parent)):sha(p) for p in files}},
        'diagnostic_hashes':{**initial['config']['diagnostic_hashes'],**{str(p.relative_to(ROOT.parent)):sha(p) for p in evidence}},
        'initialization_checkpoint_sha256':sha(INITIAL),'clean_teacher_checkpoint_sha256':sha(CLEAN_TEACHER),'noise_teacher_checkpoint_sha256':sha(NOISE_TEACHER),
        'gate_parent_sha256':sha(GATE_PARENT),'target_test_selection':False}
    assert result['split_hashes']==split_hashes()
    for name,digest in {**result['source_hashes'],**result['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
    return result,initial['model']


def validate(model,cfg,reference,device,epoch,parent,binding):
    manifest=HOME/f'epoch_{epoch:02d}_prediction_manifest.json'
    if manifest.exists():assert json.loads(manifest.read_text(encoding='utf-8'))==binding
    else:write_json(manifest,binding)
    path=HOME/f'epoch_{epoch:02d}_predictions.json'
    frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,
        ReportingLoader(make_loader('DAUB-R','val',cfg),HOME/'progress.json','source_val'),device,reference,path)
    write_json(HOME/'progress.json',{'status':'source_validation','epoch':epoch,'phase':'controlled diagnostics','updated_at':now()})
    geometry,per_scale=probe(model,cfg,reference,device)
    row={'epoch':epoch,'source_validation':validation_summary(frames),'geometry_probe':geometry,'per_scale':per_scale,
        'background':background_diagnostic(model,cfg,reference,device,HOME,f'epoch_{epoch:02d}'),
        'noise':{},'extreme_geometry':extreme_probe(model,cfg,reference,device)}
    threshold=row['source_validation']['threshold']
    for factor in [4,16]:
        path=HOME/f'epoch_{epoch:02d}_noise{factor}_predictions.json'
        frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,validation_loader(cfg,factor),device,reference,path)
        row['noise'][str(factor)]={'box':metrics(frames,threshold),'center':center_metrics(frames,threshold)}
    row['T_pair_MSE']=locality_probe(model,cfg,device)
    row['mosaics']=evaluate_mosaics(model,cfg,reference,device,threshold)
    baseline=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    row['gates']=gates(row,parent,baseline)
    return row


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    assert torch.backends.cudnn.conv.fp32_precision=='tf32'
    if (HOME/'training_complete.json').exists() and not args.check:return
    random.seed(3407);np.random.seed(3407);torch.manual_seed(3407);torch.cuda.manual_seed_all(3407)
    bound,initial=identity();cfg=bound['recipe'];reference=bound['size_reference_512'];device=torch.device('cuda')
    fast.install();model,teachers,opt=construct(cfg,initial,device);clean,noise=teachers
    frozen_teachers=[{n:v.detach().cpu().clone() for n,v in t.state_dict().items()} for t in teachers]
    def teacher_check():
        for teacher,state in zip(teachers,frozen_teachers):
            assert all(p.grad is None and not p.requires_grad for p in teacher.parameters())
            assert all(torch.equal(v.cpu(),state[n]) for n,v in teacher.state_dict().items())
    if args.check:
        from irstd_background_center.data import collate_pairs
        data=training_loader(cfg);data.dataset.epoch=1;seen=[];photo_terms=[];new_terms=[];tick=time.perf_counter()
        for indices in [[0,1],[2,3],[4,8],[13,6]]:
            images,samples=collate_pairs([data.dataset[i] for i in indices]);seen.extend(s['view_type'] for s in samples[2:])
            opt.zero_grad(set_to_none=True);model.eval();loss,terms=losses(model,clean,noise,images,samples,reference,{**cfg,'verify_new_loss_gradients':True},device);loss.backward()
            assert terms['new_loss_gradients_verified']
            new_terms.append({k:v for k,v in terms.items() if k in ['native_location_KL','augmented_positive_calibration','calibrated_augmented_targets','expected_augmented_targets','native_teacher_selection']})
            assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
            if terms['photo_teacher_images']:
                photo_terms.append({k:v for k,v in terms.items() if k.startswith('photo_')})
                assert terms['photo_teacher_peak']>0 and terms['photo_teacher_negative']>0
            else:assert all(v==0 for k,v in terms.items() if k.startswith('photo_'))
            torch.nn.utils.clip_grad_norm_(model.parameters(),10.,error_if_nonfinite=True);opt.step()
            buffers_fixed(model,initial);teacher_check();mechanisms(model)
        images,samples=collate_pairs([data.dataset[i] for i in [4,9]])
        assert all(sample['view_type']=='noise' for sample in samples[2:])
        opt.zero_grad(set_to_none=True)
        _,noise_terms=losses(model,clean,noise,images,samples,reference,{**cfg,'verify_new_loss_gradients':True},device)
        assert noise_terms['calibrated_augmented_targets']==0 and noise_terms['noise_only_extra_calibration_zero']
        assert isinstance(noise,IntegralPopulationModel)
        teacher_check()
        assert set(seen)=={'noise','background_noise','shrink','enlarge','mosaic'}
        assert len(opt.state)==sum(1 for _ in model.parameters()) and all(int(v['step'])==4 for v in opt.state.values())
        assert locality_probe(model,cfg,device)<=1e-10
        from audit_conditional_function import functional_responses
        functional=functional_responses(model)
        save_checkpoint(HOME/'preflight_step.pt',{'model':model.state_dict(),'optimizer':opt.state_dict()})
        saved=torch.load(HOME/'preflight_step.pt',map_location='cpu',weights_only=False)
        restored=IntegralPopulationModel(cfg).to(device);restored.load_state_dict(saved['model']);restored.set_mode(final=False);restored.eval()
        with torch.no_grad():before=model(images.to(device));after=restored(images.to(device))
        assert all(torch.equal(v,after[n]) for n,v in before.items())
        from peak_calibrated_model import decode_calibrated
        from locked_peak_decode import base_candidates,rescore
        from anchor_preserving_decode import decode_raw
        original_output={**before,'center_logits':before['main_peak_logits']}
        candidates=base_candidates(original_output,reference)
        zero=rescore(original_output,candidates,0.)
        assert all(torch.equal(x['raw'],y['raw']) for x,y in zip(zero,decode_raw(original_output,reference)))
        calibrated=decode_calibrated(before,reference)
        for b,(old,new) in enumerate(zip(candidates,calibrated)):
            x,y=new['anchors'].unbind(1)
            assert torch.equal(new['raw'][:,4],before['center_logits'][b,0,y,x].float().sigmoid())
            lookup={tuple(q):i for i,q in enumerate(old['anchors'].tolist())}
            assert torch.equal(new['raw'][:,:4],old['raw'][[lookup[tuple(q)] for q in new['anchors'].tolist()],:4])
        write_json(HOME/'preflight.json',{'passed':True,'identity':bound,'optimizer_steps':4,'parameters':808952,
            'teacher_states_unchanged':True,'buffers_unchanged':True,'all_original_parameter_gradients_finite':True,
            'save_reload_exact':True,'photo_loss_checks':photo_terms,'new_loss_gradient_checks':new_terms,
            'deployed_training_scores_exact':True,'original_peak_geometry_exact':True,'noise_only_extra_calibration_zero':True,'numerically_consistent_noise_teacher':True,'conditional_function':functional,
            'view_types':seen,'seconds':time.perf_counter()-tick,'updated_at':now()})
        print(json.dumps({'preflight_passed':True,'seconds':time.perf_counter()-tick}),flush=True);return
    assert json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))['identity']==bound
    if (HOME/'config.json').exists():assert args.resume and json.loads((HOME/'config.json').read_text(encoding='utf-8'))==bound
    write_json(HOME/'config.json',bound);write_json(HOME/'recipe.json',cfg)
    ema=copy.deepcopy(model).eval()
    for p in ema.parameters():p.requires_grad_(False)
    updates=0;completed=0;best=None;rows=[]
    if args.resume and (HOME/'last.pt').exists():
        saved=torch.load(HOME/'last.pt',map_location='cpu',weights_only=False);assert saved['config']==bound
        model.load_state_dict(saved['model']);ema.load_state_dict(saved['ema']);opt.load_state_dict(copy.deepcopy(saved['optimizer']));restore_rng(saved['rng'])
        updates=saved['updates'];completed=saved['epoch']
    if (HOME/'best.pt').exists():best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
    parent=torch.load(GATE_PARENT,map_location='cpu',weights_only=False)
    for epoch in range(1,cfg['epochs']+1):
        rowpath=HOME/f'epoch_{epoch:02d}_row.json'
        if rowpath.exists():
            row=json.loads(rowpath.read_text(encoding='utf-8'));rows.append(row)
            if all(row['gates'].values()):break
            continue
        if completed<epoch:
            train=training_loader(cfg);train.dataset.epoch=epoch;train.generator.manual_seed(3407+epoch*1000003)
            views=Counter();objects=Counter();donors=0;tick=time.perf_counter()
            for j,(images,samples) in enumerate(train):
                model.eval();opt.zero_grad(set_to_none=True)
                loss,terms=losses(model,clean,noise,images,samples,reference,cfg,device);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),10.,error_if_nonfinite=True);opt.step();updates+=1
                decay=.9999*(1-math.exp(-updates/2000))
                with torch.no_grad():
                    for a,b in zip(ema.parameters(),model.parameters()):a.mul_(decay).add_(b,alpha=1-decay)
                views.update(s['view_type'] for s in samples)
                for sample in samples:objects[sample['view_type']]+=len(sample['boxes'])
                donors+=sum(len(s.get('mosaic_indices',[]))-1 for s in samples if s['view_type']=='mosaic')
                if j%100==0:
                    progress={'status':'training','epoch':epoch,'batch':j+1,'total_batches':len(train),'updates':updates,
                        'view_counts':dict(views),'object_view_counts':dict(objects),'extra_donor_frames':donors,
                        'loss_terms':terms,'elapsed_seconds':time.perf_counter()-tick,'updated_at':now()}
                    write_json(HOME/'progress.json',progress);print(json.dumps(progress),flush=True)
            assert sum(views.values())==8362 and views['native']==4181 and updates==epoch*2091
            buffers_fixed(model,initial);buffers_fixed(ema,initial);teacher_check();mechanisms(ema)
            assert len(opt.state)==sum(1 for _ in model.parameters()) and all(int(v['step'])==updates for v in opt.state.values())
            state={'model':model.state_dict(),'ema':ema.state_dict(),'optimizer':opt.state_dict(),'config':bound,
                'updates':updates,'epoch':epoch,'rng':rng_state(),'view_counts':dict(views),'object_view_counts':dict(objects),
                'extra_donor_frames':donors,'train_seconds':time.perf_counter()-tick}
            save_checkpoint(HOME/f'epoch_{epoch:02d}_training.pt',state);shutil.copyfile(HOME/f'epoch_{epoch:02d}_training.pt',HOME/'last.pt');completed=epoch
        row=validate(ema,cfg,reference,device,epoch,parent,{'trained_checkpoint_sha256':sha(HOME/f'epoch_{epoch:02d}_training.pt'),
            'decoder_helper_sha256':sha(HERE/'anchor_preserving_decode.py')})
        row['updates']=updates;checkpoint={**row,'model':ema.state_dict(),'config':bound}
        save_checkpoint(HOME/f'epoch_{epoch:02d}_ema.pt',checkpoint)
        if best is None or row_key(row)>row_key(best):
            save_checkpoint(HOME/'best.pt',checkpoint);shutil.copyfile(HOME/f'epoch_{epoch:02d}_predictions.json',HOME/'best_source_val_predictions.json')
            best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
        write_json(rowpath,row);rows.append(row)
        (HOME/'history.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows),encoding='utf-8')
        for name,digest in {**bound['source_hashes'],**bound['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
        print(json.dumps({'validated_epoch':epoch,'gates':row['gates']}),flush=True)
        if all(row['gates'].values()):break
    done={'status':'completed','promotion_passed':all(best['gates'].values()),'best_epoch':best['epoch'],
        'gates':best['gates'],'epochs_run':completed,'updates':updates,'target_test_cells':0,'updated_at':now()}
    write_json(HOME/'training_complete.json',done);write_json(HOME/'progress.json',done);print(json.dumps(done),flush=True)


if __name__=='__main__':
    try:main()
    except Exception:
        HOME.mkdir(exist_ok=True);write_json(HOME/'failure.json',{'traceback':traceback.format_exc(),'updated_at':now()});raise
