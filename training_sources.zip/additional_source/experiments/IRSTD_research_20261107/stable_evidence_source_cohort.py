"""No-optimization source cohort control for the evidence arithmetic correction."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import hashlib
import json
from pathlib import Path
import sys
import torch
from torch.utils.data import Dataset,DataLoader

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_stable_evidence.model import StableModel
from irstd_t_size.model import TSizeModel
from irstd_background_center.data import Pairs
from irstd_noise_center.data import validation_loader
from irstd_v2.data import collate
from irstd_v2.evaluate import evaluate
from irstd_v2.settings import write_json,now
from evaluation import metrics
from benchmark_center_metrics import center_metrics
import benchmark_fastdecode as fast


class NativeCohort(Dataset):
    def __init__(self,cfg):
        self.pairs=Pairs(cfg,'val');self.records=self.pairs.records
    def __len__(self):return len(self.pairs)
    def __getitem__(self,i):return self.pairs.base.base_sample(self.pairs.indices[i])


@torch.inference_mode()
def main():
    folder=HERE/'stable_evidence_source_cohort_v1';folder.mkdir(exist_ok=True)
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    path=HERE/'background_center_interpolation_refine_v1/best.pt';parent=torch.load(path,map_location='cpu',weights_only=False)
    cfg=parent['config']['recipe'];threshold=parent['source_validation']['threshold'];reference=parent['config']['size_reference_512']
    # No process-global all-network precision change: only the evidence module
    # enters IEEE mode and restores the pre-existing convolution setting.
    previous=torch.backends.cudnn.conv.fp32_precision;assert previous=='tf32'
    results={}
    for mode in ['original','raw_IEEE','centered_IEEE']:
        recipe={**cfg,'evidence_arithmetic':mode}
        model=(TSizeModel if mode=='original' else StableModel)(recipe).cuda().eval();model.load_state_dict(parent['model'])
        assert sum(p.numel() for p in model.parameters())==808952
        assert all(torch.equal(v.cpu(),parent['model'][n]) for n,v in model.state_dict().items())
        results[mode]={}
        for view in ['native','noise4','noise16']:
            if view=='native':data=DataLoader(NativeCohort(cfg),batch_size=4,num_workers=2,collate_fn=collate)
            else:data=validation_loader(cfg,int(view.removeprefix('noise')))
            write_json(folder/'progress.json',{'mode':mode,'view':view,'updated_at':now()})
            frames=evaluate(model,data,torch.device('cuda'),reference,folder/f'{mode}_{view}_predictions.json')
            assert torch.backends.cudnn.conv.fp32_precision==previous
            results[mode][view]={'box':metrics(frames,threshold),'center':center_metrics(frames,threshold)}
        assert all(torch.equal(v.cpu(),parent['model'][n]) for n,v in model.state_dict().items())
        del model
    original=results['original']['native']['box']
    retention={mode:all(results[mode]['native']['box'][k]>=original[k]-.02 for k in ['AP50','AP50_95','F1'])
        for mode in ['raw_IEEE','centered_IEEE']}
    selected=next((mode for mode in ['centered_IEEE','raw_IEEE'] if retention[mode]),None)
    report={'scope':'fixed24-source-validation cohort; source threshold frozen from clean full parent validation; no optimization or target data',
        'cohort_retention':'native AP50, AP50:95 and F1 each lose no more than2pp; subset screen only, full source gates still required',
        'selection':'most accurate arithmetic passing native cohort retention, centered_IEEE before raw_IEEE',
        'checkpoint_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'threshold':threshold,
        'all_learned_tensors_unchanged':True,'results':results,'native_retention':retention,'selected':selected,'updated_at':now()}
    write_json(folder/'result.json',report);write_json(folder/'progress.json',{'status':'completed','selected':selected,'updated_at':now()})
    print(json.dumps(report),flush=True)


if __name__=='__main__':main()
