"""Select native training teachers by existing training-box geometry only."""
import torch
from torch import nn


class NativeTeacherSelection(nn.Module):
    def __init__(self,legacy,consistent,samples,reference):
        super().__init__();self.legacy=legacy;self.consistent=consistent
        assert all(sample['split']=='source_train' for sample in samples)
        self.samples=samples;self.reference=reference;self.last_selection=None

    @torch.no_grad()
    def quality(self,outputs,b,sample):
        values=[]
        for truth in sample['boxes'].to(outputs['center_logits'].device):
            x,y=((truth[:2]+truth[2:])/2).floor().long().tolist()
            ys=slice(max(y-3,0),min(y+4,512));xs=slice(max(x-3,0),min(x+4,512))
            patch=outputs['center_logits'][b,0,ys,xs];point=int(patch.argmax())
            py=ys.start+point//patch.shape[1];px=xs.start+point%patch.shape[1]
            center=truth.new_tensor([px,py])+outputs['offsets'][b,:,py,px].float().clamp(0,1-1e-6)
            bound=center.new_tensor([512.,512.]);center=torch.minimum(center,torch.nextafter(bound,torch.zeros_like(bound)))
            value=outputs['log_size'][b,:,py,px].float();reference=value.new_tensor(self.reference)
            size=reference*torch.minimum(value.clamp_min(-20),(bound/reference).log()).exp()
            prediction=torch.cat((center-size/2,center+size/2)).clamp(0,512)
            intersection=(torch.minimum(prediction[2:],truth[2:])-torch.maximum(prediction[:2],truth[:2])).clamp_min(0).prod()
            union=(prediction[2:]-prediction[:2]).prod()+(truth[2:]-truth[:2]).prod()-intersection
            values.append(intersection/union.clamp_min(1e-12))
        return float(torch.stack(values).mean()) if values else 0.

    @torch.no_grad()
    def forward(self,images,valid_mask=None):
        a=self.legacy(images,valid_mask=valid_mask);raw=self.consistent(images,valid_mask=valid_mask)
        # Native location transfer must use the actual main peak map, not an
        # auxiliary peak that the deployed locked decoder would never propose.
        b={**raw,'center_logits':raw['main_peak_logits']}
        qa=[self.quality(a,i,s) for i,s in enumerate(self.samples)]
        qb=[self.quality(b,i,s) for i,s in enumerate(self.samples)]
        use_b=[y>x for x,y in zip(qa,qb)]
        self.last_selection={'consistent_selected':sum(use_b),'native_images':len(use_b),
            'legacy_mean_training_IoU':sum(qa)/max(len(qa),1),'consistent_mean_training_IoU':sum(qb)/max(len(qb),1)}
        return {key:torch.stack([b[key][i] if chosen else a[key][i] for i,chosen in enumerate(use_b)]) for key in a}
