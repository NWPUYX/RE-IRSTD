"""Finish this fixed at-most-four-epoch experiment; gate evaluation, never search targets."""
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
HOME = HERE/'scene_scale_joint_v1'
ROOT = HERE.parents[1]


def main():
    last = None
    while not (HOME/'training_complete.json').exists():
        if (HOME/'failure.json').exists():
            raise RuntimeError((HOME/'failure.json').read_text(encoding='utf-8'))
        path = HOME/'progress.json'
        if path.exists():
            try:
                progress = json.loads(path.read_text(encoding='utf-8'))
            except json.JSONDecodeError:
                progress = None
            if progress and progress != last:
                print(json.dumps(progress), flush=True)
                last = progress
        time.sleep(10)
    with (HERE/'scene_scale_independent_audit.log').open('w', encoding='utf-8') as stream:
        subprocess.run([sys.executable, str(HERE/'audit_scene_scale.py')], cwd=ROOT, stdout=stream,
                       stderr=subprocess.STDOUT, check=True)
    audit = json.loads((HOME/'independent_audit.json').read_text(encoding='utf-8'))
    assert audit['passed']
    if audit['promotion_passed']:
        with (HERE/'scene_scale_frozen_test.log').open('w', encoding='utf-8') as stream:
            subprocess.run([sys.executable, str(HERE/'evaluate_scene_scale.py')], cwd=ROOT, stdout=stream,
                           stderr=subprocess.STDOUT, check=True)
        print(json.dumps({'status': 'completed', 'source_gates_passed': True, 'test_rules': ['original', 'native_residual']}), flush=True)
    else:
        print(json.dumps({'status': 'completed_source_failure', 'source_gates_passed': False,
                          'gates': audit['gates'], 'target_tests_started': False}), flush=True)
    subprocess.run([sys.executable, str(HERE/'update_progress_report.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
