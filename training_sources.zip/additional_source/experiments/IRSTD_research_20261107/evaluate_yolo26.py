"""Freeze the completed single-frame baseline, then use the shared test protocol."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import torch
from torch.utils.data import DataLoader

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from yolo26_matched.model import build,REPO
from yolo26_matched.run import evaluate
from data_pipeline import VideoData,collate,worker_seed
from evaluation import metrics,select_threshold
from benchmark_cluster_bootstrap import cluster_ci
from benchmark_progress import ReportingLoader
from irstd_v2.settings import write_json,now,split_hashes


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    home=HOME/'yolo26n_p2_DAUB_3407';folder=home/'frozen_four_domain_test';folder.mkdir(exist_ok=True)
    assert json.loads((home/'training_complete.json').read_text(encoding='utf-8'))['completed']
    state=torch.load(home/'best.pt',map_location='cpu',weights_only=False);cfg=state['config']
    assert split_hashes()==cfg['split_hashes']
    for name,digest in cfg['source_hashes'].items():assert sha(ROOT/name)==digest,name
    assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()==cfg['repository_commit']
    assert subprocess.run(['git','-C',str(REPO),'diff','--quiet','HEAD']).returncode==0
    source_frames=json.loads((home/f"source_val_epoch_{state['epoch']:03d}.json").read_text(encoding='utf-8'))['frames']
    threshold=select_threshold(source_frames);assert metrics(source_frames,threshold)==state['validation']
    manifest={'checkpoint_sha256':sha(home/'best.pt'),'source':cfg['source'],'seed':cfg['seed'],'epoch':state['epoch'],
        'threshold':threshold,'split_hashes':split_hashes(),'script_sha256':sha(__file__),
        'bootstrap_helper_sha256':sha(ROOT/'benchmark_cluster_bootstrap.py'),'model':'YOLO26n-P2','frames':1,'pretrained':False}
    if (folder/'freeze_manifest.json').exists():assert json.loads((folder/'freeze_manifest.json').read_text(encoding='utf-8'))==manifest
    else:write_json(folder/'freeze_manifest.json',manifest)
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;device=torch.device('cuda')
    model=build().to(device);model.load_state_dict(state['model']);model.eval()
    for p in model.parameters():p.requires_grad_(False)
    results=[]
    for target in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=folder/f'{target}_metrics.json'
        if path.exists():result=json.loads(path.read_text(encoding='utf-8'))
        else:
            data=DataLoader(VideoData(target,'test','AA-YOLO'),batch_size=4,num_workers=2,collate_fn=collate,
                worker_init_fn=worker_seed,persistent_workers=False,pin_memory=False)
            frames=evaluate(model,ReportingLoader(data,folder/'progress.json',target),device,folder/f'{target}_predictions.json')
            overall=metrics(frames,threshold);ci=cluster_ci(frames)
            if ci is not None:overall['AP50_cluster_CI95']=ci
            result={'source':cfg['source'],'target':target,'seed':cfg['seed'],'checkpoint_sha256':manifest['checkpoint_sha256'],
                'overall':overall,'by_group':{g:metrics([f for f in frames if f['group']==g],threshold) for g in sorted({f['group'] for f in frames})},'updated_at':now()}
            assert sha(home/'best.pt')==manifest['checkpoint_sha256'];write_json(path,result)
        results.append(result);print(json.dumps({'target':target,**result['overall']}),flush=True)
    cross=[r['overall'] for r in results if r['target']!=cfg['source']]
    summary={'status':'completed','source':cfg['source'],'seed':cfg['seed'],'completed_cells':len(results),
        'cross_domain_macro':{k:sum(r[k] for r in cross)/3 for k in ['AP50','AP50_95','F1','center_Pd_3px']},'updated_at':now()}
    write_json(folder/'summary.json',summary);write_json(folder/'progress.json',summary)


if __name__=='__main__':main()
