"""Parameter-free deployment readout of already-supervised T logits."""
from integral_population_model import IntegralPopulationModel
from irstd_population_t.model import PopulationTModel


def blend(outputs,weight):
    if not 0<=weight<=1:raise ValueError('readout weight outside [0,1]')
    if weight==0:return outputs
    center=outputs['auxiliary_center_logits'] if weight==1 else (
        (1-weight)*outputs['center_logits']+weight*outputs['auxiliary_center_logits'])
    return {**outputs,'center_logits':center}


class ReadoutMixin:
    def __init__(self,recipe):
        super().__init__(recipe)
        self.local_readout_weight=float(recipe['local_readout_weight'])

    def forward(self,*args,**kwargs):
        return blend(super().forward(*args,**kwargs),self.local_readout_weight)


class IntegralReadoutModel(ReadoutMixin,IntegralPopulationModel):
    pass


class PopulationReadoutModel(ReadoutMixin,PopulationTModel):
    pass
