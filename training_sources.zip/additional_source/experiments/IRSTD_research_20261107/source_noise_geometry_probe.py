"""Source-only noise AP decomposition; four decoders share one forward."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader,Dataset

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_population_t.model import PopulationTModel
from irstd_noise_center.data import NoiseValidation,validation_loader
from irstd_v2.data import collate
from irstd_v2.settings import write_json,now,split_hashes
from native_unit_prior_evaluation import source_statistics,sha
from evaluation import postprocess,match_frame,metrics
import benchmark_fastdecode as fast

HOME=HERE/'source_noise_geometry_probe_v1'


class Clean(Dataset):
    def __init__(self,cfg):self.noise=NoiseValidation(cfg,4);self.records=self.noise.records
    def __len__(self):return len(self.noise)
    def __getitem__(self,index):return self.noise.pairs.base.base_sample(self.noise.pairs.indices[index])


@torch.inference_mode()
def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    endpoints={'population':HERE/'population_T_sourceAP_control_v1/best.pt','scene_epoch2':HERE/'scene_scale_joint_v1/epoch_02_ema.pt'}
    config={'script_sha256':sha(__file__),'plan_sha256':sha(HERE/'噪声退化定位源域诊断方案.md'),
        'checkpoint_sha256':{k:sha(p) for k,p in endpoints.items()},'split_hashes':split_hashes(),
        'source_only':True,'optimization_updates':0}
    write_json(HOME/'config.json',config);stats=source_statistics();results={}
    for name,path in endpoints.items():
        state=torch.load(path,map_location='cpu',weights_only=False);cfg=state['config']['recipe']
        model=PopulationTModel(cfg).cuda().eval();model.load_state_dict(state['model']);model.set_mode(final=False)
        threshold=state['source_validation']['threshold'];model_results={}
        for factor in [0,4,16]:
            loader=DataLoader(Clean(cfg),batch_size=4,num_workers=2,collate_fn=collate) if factor==0 else validation_loader(cfg,factor)
            rows={k:[] for k in ['actual','anchor_preserving','constant_size','zero_offset','constant_size_zero_offset']}
            size_error_gt=[];size_error_peak=[];offset_error_gt=[];anchor_recovery_mismatches=0
            for images,samples in loader:
                out=model(images.cuda());scores=out['center_logits'].sigmoid();mask=(scores==F.max_pool2d(scores,3,1,1))&(scores>=1e-5)
                for b,sample in enumerate(samples):
                    q=torch.tensor(fast.representatives(scores[b,0].cpu().numpy(),mask[b,0].cpu().numpy()),device='cuda',dtype=torch.long).reshape(-1,2)
                    confidence=scores[b,0,q[:,1],q[:,0]];offsets=out['offsets'][b,:,q[:,1],q[:,0]].T.float().clamp(0,1-1e-6)
                    center=q.float()+offsets;bounds=center.new_tensor([512,512]);center=torch.minimum(center,torch.nextafter(bounds,torch.zeros_like(bounds)))
                    anchor_recovery_mismatches+=int((center.floor().long()!=q).any(1).sum())
                    value=out['log_size'][b,:,q[:,1],q[:,0]].T.float();reference=value.new_tensor(stats['input_median'])
                    wh=reference*torch.minimum(value.clamp_min(-20),(value.new_tensor([512,512])/reference).log()).exp()
                    recovered=center.floor().long()
                    legacy_value=out['log_size'][b,:,recovered[:,1],recovered[:,0]].T.float()
                    legacy_wh=reference*torch.minimum(legacy_value.clamp_min(-20),(value.new_tensor([512,512])/reference).log()).exp()
                    record=loader.dataset.records[sample['record_index']]
                    for rule in rows:
                        xy=q.float() if 'zero_offset' in rule else center
                        size=wh if rule=='anchor_preserving' else (legacy_wh if rule in ['actual','zero_offset'] else wh.new_tensor(stats['native_median'])*wh.new_tensor(sample['trans'][:2]).abs())
                        raw=torch.cat((xy,size.expand_as(wh),confidence[:,None],torch.ones_like(confidence[:,None])),1)
                        rows[rule].append(match_frame(postprocess(raw,record,sample['trans']),record))
                    for box in sample['boxes']:
                        target_center=(box[:2]+box[2:])/2;x,y=target_center.floor().long().tolist()
                        target=((box[2:]-box[:2])/torch.tensor(stats['input_median'])).log().cuda()
                        size_error_gt.append(float((out['log_size'][b,:,y,x]-target).abs().mean()))
                        offset_error_gt.append(float((out['offsets'][b,:,y,x]-(target_center-target_center.floor()).cuda()).abs().mean()))
                        patch=scores[b,0,max(0,y-3):min(512,y+4),max(0,x-3):min(512,x+4)];position=int(patch.argmax());py=max(0,y-3)+position//patch.shape[1];px=max(0,x-3)+position%patch.shape[1]
                        size_error_peak.append(float((out['log_size'][b,:,py,px]-target).abs().mean()))
            report={k:metrics(frames,threshold) for k,frames in rows.items()}
            if factor:
                assert report['actual']==state['noise'][str(factor)]['box'],(name,factor,report['actual'],state['noise'][str(factor)]['box'])
            model_results[str(factor)]={'metrics':report,'size_log_MAE_at_GT':float(np.mean(size_error_gt)),
                'size_log_MAE_at_GT_peak':float(np.mean(size_error_peak)),'offset_MAE_at_GT':float(np.mean(offset_error_gt)),
                'anchor_recovery_mismatches':anchor_recovery_mismatches}
        assert all(torch.equal(v.cpu(),state['model'][k]) for k,v in model.state_dict().items()) and sha(path)==config['checkpoint_sha256'][name]
        results[name]=model_results;del model;torch.cuda.empty_cache()
    write_json(HOME/'result.json',{'status':'completed','results':results,'optimization_updates':0,'target_frames':0,'all_tensors_unchanged':True,'updated_at':now()})
    print(json.dumps(results),flush=True)


if __name__=='__main__':main()
