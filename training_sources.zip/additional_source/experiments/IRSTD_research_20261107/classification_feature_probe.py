"""Source-train group-held-out noise classification probe; not detector AP."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.nn import functional as F

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path[:0]=[str(ROOT),str(HOME)]
from irstd_t_size.model import TSizeModel
from irstd_v2.data import Data
from irstd_v2.settings import write_json,now
import benchmark_fastdecode as fast


def views(sample,index):
    image=sample['image'];valid=sample['valid_mask'];background=valid.clone();background[:,:2]=False;background[:,-2:]=False
    background[:,:,:2]=False;background[:,:,-2:]=False;amplitudes=[]
    yy,xx=torch.meshgrid(torch.arange(512),torch.arange(512),indexing='ij')
    for box in sample['boxes']:
        x1,y1,x2,y2=box.tolist();background[:,max(0,int(y1)-14):min(512,int(y2)+15),max(0,int(x1)-14):min(512,int(x2)+15)]=False
        qx,qy=((box[:2]+box[2:])/2).floor().long().tolist();radius=torch.maximum((xx-qx).abs(),(yy-qy).abs())
        ring=(radius>=10)&(radius<=16)&valid[0]
        amplitudes.append(float((image[0,max(0,qy-3):min(512,qy+4),max(0,qx-3):min(512,qx+4)]-image[0][ring].median()).abs().max()))
    kernel=image.new_tensor([[1,-2,1],[-2,4,-2],[1,-2,1]])[None,None]
    residual=F.conv2d(image[None],kernel,padding=1)[0]
    proxy=max(float(residual[background].abs().median())/(.67448975*6),1/255)
    result=[]
    for factor in [0,4,16]:
        sigma=min(factor*proxy,min(amplitudes)/2);rng=torch.Generator().manual_seed(3407+index*97+factor*1009)
        result.append((image+sigma*torch.randn(image.shape,generator=rng)*valid).clamp(0,1))
    return torch.stack(result),background


def ridge(x,y,fit):
    mu=x[fit].mean(0);sd=x[fit].std(0).clip(1e-5);z=(x-mu)/sd
    design=np.column_stack([z,np.ones(len(z))]);a=design[fit];b=y[fit]
    weights=np.where(b>0,(b==0).sum()/max((b>0).sum(),1),1.)
    regularizer=np.eye(a.shape[1]);regularizer[-1,-1]=0
    theta=np.linalg.solve(a.T@(a*weights[:,None])+regularizer,a.T@(b*weights))
    return design@theta


def ap(scores,labels):
    ordered=labels[np.argsort(-scores,kind='stable')];total=int(ordered.sum());hits=np.flatnonzero(ordered)
    if not total or not len(hits):return 0.
    counts=np.arange(1,len(hits)+1);r=counts/total;p=counts/(hits+1);p=np.maximum.accumulate(p[::-1])[::-1]
    index=np.searchsorted(r,np.linspace(0,1,101),side='left');values=np.zeros(101);valid=index<len(p);values[valid]=p[index[valid]]
    return float(values.mean())


@torch.inference_mode()
def main():
    folder=HOME/'classification_noise_probe';folder.mkdir(exist_ok=True)
    torch.set_num_threads(3);fast.cv2.setNumThreads(1);torch.backends.cudnn.benchmark=False
    path=HOME/'background_center_interpolation_refine_v1/best.pt';state=torch.load(path,map_location='cpu',weights_only=False)
    cfg=state['config']['recipe'];data=Data('DAUB-R','train',cfg);model=TSizeModel(cfg).cuda().eval();model.load_state_dict(state['model'])
    groups=defaultdict(list)
    for i,r in enumerate(data.records):groups[r['group']].append(i)
    ids=[items[j] for items in groups.values() for j in np.linspace(0,len(items)-1,12,dtype=int)]
    fit_groups={'data10','data13','data14','data16'};captured={}
    hook=model.backbone.register_forward_hook(lambda m,a,o:captured.update(fused=o[0],T=o[1]))
    x={'fused':[],'T':[]};labels=[];meta=[];native_scores=[];aux_scores=[]
    for n,i in enumerate(ids):
        sample=data.base_sample(i);images,background=views(sample,i);out=model(images.cuda())
        padded={name:F.pad(value,(1,1,1,1)) for name,value in captured.items()}
        for b,factor in enumerate([0,4,16]):
            negatives=set()
            for field in ['center_logits','auxiliary_center_logits']:
                score=out[field][b,0].float();mask=(score==F.max_pool2d(score[None,None],3,1,1)[0,0])&background[0].cuda()
                points=fast.representatives(score.cpu().numpy(),mask.cpu().numpy())
                negatives.update(points[:12])
            positives=[tuple(((box[:2]+box[2:])/2).floor().long().tolist()) for box in sample['boxes']]
            points=[*( (q,1) for q in positives),*((q,0) for q in sorted(negatives,key=lambda q:(q[1],q[0])))]
            for (qx,qy),label in points:
                for name in x:x[name].append(padded[name][b,:,qy:qy+3,qx:qx+3].flatten().cpu().numpy())
                labels.append(label);meta.append({'group':data.records[i]['group'],'record_index':i,'factor':factor})
                native_scores.append(float(out['center_logits'][b,0,qy,qx]));aux_scores.append(float(out['auxiliary_center_logits'][b,0,qy,qx]))
        captured.clear()
        if n%12==0:write_json(folder/'progress.json',{'records':n+1,'total_records':len(ids),'updated_at':now()})
    hook.remove();y=np.asarray(labels,dtype=float);fit=np.asarray([r['group'] in fit_groups for r in meta]);hold=~fit
    features={name:np.asarray(value,dtype=np.float64) for name,value in x.items()}
    predictions={'current_main_head':np.asarray(native_scores),'current_aux_head':np.asarray(aux_scores)}
    for name,value in features.items():predictions[name+'_ridge']=ridge(value,y,fit)
    predictions['joint_ridge']=ridge(np.concatenate([features['fused'],features['T']],axis=1),y,fit)
    result={}
    for name,scores in predictions.items():
        result[name]={'overall_proxy_AP':ap(scores[hold],y[hold]),'by_noise_factor':{}}
        for factor in [0,4,16]:
            selected=hold&np.asarray([r['factor']==factor for r in meta]);result[name]['by_noise_factor'][str(factor)]=ap(scores[selected],y[selected])
    np.savez_compressed(folder/'features.npz',**features,y=y,fit=fit,main_scores=native_scores,aux_scores=aux_scores)
    write_json(folder/'metadata.json',meta)
    report={'scope':'source_train group-held-out binary classification proxy; sampled GT anchors and up to24 hard-background points per view; NOT detector AP50',
        'fit_groups':sorted(fit_groups),'holdout_groups':sorted(set(groups)-fit_groups),'records':len(ids),'rows':len(y),'holdout_positive_points':int(y[hold].sum()),
        'probe':'3x3 feature patches, standardized on fit groups, weighted ridge alpha1 fixed; no validation or target fitting',
        'checkpoint_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'results':result,'updated_at':now()}
    write_json(folder/'result.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
