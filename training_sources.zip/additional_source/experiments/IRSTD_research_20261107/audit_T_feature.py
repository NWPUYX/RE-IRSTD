"""Independent final-state, source-metric and mechanism audit; never steps SGD."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import sys
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from irstd_t_feature_consistency.run import HOME, PARENT, PREFIX, construct, sha, frozen
from irstd_robust_t.run import mechanisms, gates
from irstd_robust_t.probe import extreme_probe
from irstd_geometry_balance.run import probe
from irstd.models.blocks import REBlock
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json, now, split_hashes
from evaluation import metrics
from benchmark_center_metrics import center_metrics


def main():
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    done = json.loads((HOME/'training_complete.json').read_text(encoding='utf-8'))
    best = torch.load(HOME/'best.pt', map_location='cpu', weights_only=False)
    last = torch.load(HOME/'trained_last.pt', map_location='cpu', weights_only=False)
    parent = torch.load(PARENT/'best.pt', map_location='cpu', weights_only=False)
    cfg = best['config']
    assert cfg == last['config'] and cfg['split_hashes'] == split_hashes()
    assert sha(PARENT/'best.pt') == cfg['parent_sha256']
    for name, digest in {**cfg['source_hashes'], **cfg['diagnostic_hashes']}.items():
        assert sha(ROOT.parent/name) == digest, name
    assert best['epoch'] == done['epochs_run'] == 1
    assert best['updates'] == last['updates'] == done['updates'] == 2091
    assert all(torch.equal(v, last['ema'][k]) for k, v in best['model'].items())
    assert json.loads((HOME/'source_prediction_manifest.json').read_text(encoding='utf-8'))['trained_checkpoint_sha256'] == sha(HOME/'trained_last.pt')
    device = torch.device('cuda')
    model, _, optimizer = construct(cfg['recipe'], best['model'], device)
    assert sum(p.numel() for p in model.parameters() if p.requires_grad) == 6278
    assert len(last['optimizer']['state']) == sum(p.requires_grad for p in model.parameters()) == 24
    assert all(int(v['step']) == 2091 for v in last['optimizer']['state'].values())
    for saved, expected in zip(last['optimizer']['param_groups'], optimizer.param_groups):
        assert saved['lr'] == expected['lr'] and saved['weight_decay'] == expected['weight_decay']
        assert len(saved['params']) == len(expected['params'])
    expected_views = {'native': 4181, 'noise': 1393, 'background_noise': 1394, 'shrink': 697, 'enlarge': 697}
    assert last['view_counts'] == expected_views
    changed = []
    for candidate in [last['model'], last['ema'], best['model']]:
        frozen(model, parent['model'])
        for name, value in candidate.items():
            assert torch.isfinite(value).all()
            if not name.startswith(PREFIX):
                assert torch.equal(value, parent['model'][name]), name
    for name, value in best['model'].items():
        if not torch.equal(value, parent['model'][name]):
            assert name.startswith(PREFIX)
            changed.append(name)
    assert changed
    model.eval()
    blocks = mechanisms(model)
    sensitivity = {}
    with torch.inference_mode():
        for name, module in model.named_modules():
            if isinstance(module, REBlock):
                x = torch.zeros(1, module.channels, 16, 16, device=device)
                c = torch.linspace(-1, 1, 4*16*16, device=device).reshape(1, 4, 16, 16)
                alpha = module.mixing_weights(x, c)
                assert alpha.shape == (1, 3, 16, 16) and (alpha >= 0).all() and torch.isfinite(alpha).all()
                torch.testing.assert_close(alpha.sum(1), torch.ones_like(alpha[:, 0]), rtol=0, atol=1e-6)
                sensitivity[name] = float((alpha-module.mixing_weights(x, torch.zeros_like(c))).abs().mean())
                if name.startswith('backbone.target_path.'):
                    assert sensitivity[name] > 1e-8, name
    frames = json.loads((HOME/'epoch_01_predictions.json').read_text(encoding='utf-8'))['frames']
    assert len(frames) == 1801 and validation_summary(frames) == best['source_validation']
    threshold = best['source_validation']['threshold']
    for factor in [4, 16]:
        frames = json.loads((HOME/f'epoch_01_noise{factor}_predictions.json').read_text(encoding='utf-8'))['frames']
        assert len(frames) == 24 and metrics(frames, threshold) == best['noise'][str(factor)]['box']
        assert center_metrics(frames, threshold) == best['noise'][str(factor)]['center']
    original = torch.load(HERE/'native_precision_w4_v1/best.pt', map_location='cpu', weights_only=False)['source_validation']['threshold']
    frames = json.loads((HOME/'epoch_01_swapped_predictions.json').read_text(encoding='utf-8'))['frames']
    assert metrics(frames, original) == best['background']['swapped_metrics']
    geometry, per_scale = probe(model, cfg['recipe'], cfg['size_reference_512'], device)
    assert geometry == best['geometry_probe'] and per_scale == best['per_scale']
    assert extreme_probe(model, cfg['recipe'], cfg['size_reference_512'], device) == best['extreme_geometry']
    baseline = json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    computed = gates(best, parent, baseline)
    assert computed == best['gates'] == done['gates'] and all(computed.values()) == done['promotion_passed']
    report = {'passed': True, 'promotion_passed': done['promotion_passed'], 'checkpoint_sha256': sha(HOME/'best.pt'),
              'parameters': 808952, 'trainable_parameters': 6278, 'optimizer_state_count': 24, 'optimizer_steps': 2091,
              'changed_tensors': changed, 'other_tensors_unchanged': True, 'REBlock_constraints_checked': blocks,
              'conditional_response_to_changed_C': sensitivity, 'cached_metrics_recalculated': True,
              'geometry_remeasured': True, 'evidence_arithmetic': 'original (TF32); precision repair not part of this stage',
              'gates': computed, 'updated_at': now()}
    write_json(HOME/'independent_audit.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
