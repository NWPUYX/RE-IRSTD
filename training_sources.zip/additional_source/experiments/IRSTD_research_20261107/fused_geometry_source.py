"""Source-only size-head repair for the variable-box IRDST source."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
from collections import defaultdict,Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import random
import sys
import time
import traceback
import numpy as np
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_adapter import targets,model_config
from irstd_v2.model import Model
from irstd_v2.data import Data,make_loader,choose_plan,render
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.losses import decoded_geometry
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint,rng_state,restore_rng
from irstd_geometry_balance.data import training_loader
from irstd_t_size.model import optimizer
from irstd_native_precision.run import loss_for

SOURCE='IRDST-H';SEED=3407
HOME=HERE/'IRDST_fused_size_w4_v1'
START=ROOT/'runs/IRSTD'/SOURCE/f'seed_{SEED}/best.pt'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def recipe():
    c=json.loads((HERE/'native_precision_w4_v1/recipe.json').read_text(encoding='utf-8'))
    c.update(name=HOME.name,epochs=3,additional_epochs=3,parent_epochs=0,size_feature_source='fused',native_regression_weight=4.)
    c['geometry']['minimum_box_side']=1.
    return c


def construct(c,state,device):
    model=Model(c).to(device);model.load_state_dict(state,strict=True)
    for name,p in model.named_parameters():p.requires_grad_(name.startswith('heads.size.'))
    assert sum(p.numel() for p in model.parameters() if p.requires_grad)==5258
    return model


def frozen(model,parent):
    for n,v in model.state_dict().items():
        if not n.startswith('heads.size.'):assert torch.equal(v.cpu(),parent[n]),n


def probe_spec(c):
    data=Data(SOURCE,'val',c);groups=defaultdict(list)
    for i,r in enumerate(data.records):groups[r['group']].append(i)
    ids=[];screen={};g=dict(c['geometry'],maximum_attempts=1)
    for group,indices in sorted(groups.items()):
        eligible=[i for i in indices if all(not choose_plan(data.records[i],g,random.Random(0),forced_scale=s,flip_override=False)['fallback'] for s in [.6,1.4])]
        assert eligible,group
        screen[group]={'total':len(indices),'eligible':len(eligible)}
        ids.extend(eligible[j] for j in np.linspace(0,len(eligible)-1,min(12,len(eligible)),dtype=int))
    return {'indices':ids,'feasibility':screen,'scales':[.6,1.4],'scope':'source-val GT-anchor diagnostic, fixed feasible subset'}


@torch.inference_mode()
def probe(model,c,reference,device,spec):
    data=Data(SOURCE,'val',c);values=[];model.eval()
    for i in spec['indices']:
        r=data.records[i]
        for scale in spec['scales']:
            seed=int.from_bytes(hashlib.sha256(f'{SOURCE}/{r["id"]}/{scale}'.encode()).digest()[:8],'little')
            plan=choose_plan(r,c['geometry'],random.Random(seed),forced_scale=scale,flip_override=False);assert not plan['fallback']
            image,boxes,valid=render(r,plan);sample={**data.base_sample(i),'image':image,'boxes':boxes,'valid_mask':valid,'ignore_mask':~valid}
            t=targets([sample],model_config(),reference,device,'shared_regression')
            out=model(image[None].to(device),valid_mask=valid[None].to(device));center,wh=decoded_geometry(out,t,reference)
            gt_wh=t['sizes'].exp()*wh.new_tensor(reference)
            values.append({'scale':scale,'targets':len(wh),'size_error_sum':float((wh.log()-gt_wh.log()).abs().sum()),
                'center_error_sum':float((center-(t['anchors'][:,1:]+t['offsets'])).abs().sum())})
    def mean(rows):
        n=sum(r['targets'] for r in rows)
        return {'targets':n,'log_size_error':sum(r['size_error_sum'] for r in rows)/(2*n),'center_error_input_px':sum(r['center_error_sum'] for r in rows)/(2*n)}
    return {'overall':mean(values),'by_scale':{str(s):mean([r for r in values if r['scale']==s]) for s in spec['scales']}}


def gates(row,base):
    v,b=row['validation'],base['validation'];g=row['geometry'];bg=base['geometry']
    fine=[v['pooled']['AP50_95']-b['pooled']['AP50_95']+.02]
    fine.extend(v['by_group'][group]['AP50_95']-value['AP50_95']+.02 for group,value in b['by_group'].items())
    return {'macro_AP50':v['group_macro_AP50']>=b['group_macro_AP50']-.02,
        'pooled_AP50':v['pooled']['AP50']>=b['pooled']['AP50']-.02,
        'scale_error_20percent':g['overall']['log_size_error']<=bg['overall']['log_size_error']*.8,
        'enlarge_no_worse':g['by_scale']['1.4']['log_size_error']<=bg['by_scale']['1.4']['log_size_error'],
        'fine_AP95_pooled_and_groups':min(fine)>=0.}


def key(row,base):
    gs=gates(row,base)
    return (all(gs.values()),sum(gs.values()),-row['geometry']['overall']['log_size_error'],row['validation']['group_macro_AP50'])


def main():
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--resume',action='store_true');a=p.parse_args()
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    random.seed(SEED);np.random.seed(SEED);torch.manual_seed(SEED);torch.cuda.manual_seed_all(SEED)
    c=recipe();device=torch.device('cuda');parent=torch.load(START,map_location='cpu',weights_only=False)
    reference=parent['config']['size_reference_512'];assert split_hashes()==parent['config']['split_hashes']
    files=[Path(__file__)]
    for folder in ['irstd_v2','irstd_geometry_balance','irstd_replay','irstd_t_size','irstd_native_precision']:
        files.extend((ROOT/folder).glob('*.py'))
    files.extend((ROOT.parent/'IRSTD/src/irstd').rglob('*.py'));files.append(ROOT/'irstd_adapter.py')
    config={'source':SOURCE,'seed':SEED,'recipe':c,'initial_checkpoint':str(START),'parent_sha256':sha(START),'split_hashes':split_hashes(),
        'size_reference_512':reference,'source_hashes':{str(p.relative_to(ROOT.parent)):sha(p) for p in files},
        'hypothesis':'native weighted balanced geometry can improve scale with original fused size features',
        'protocol_change':'minimum augmented box side1 instead of2, retains continuous tiny labels; source-val feasibility-screened probe'}
    model=construct(c,parent['model'],device);opt=optimizer(model,c)
    if a.check:
        data=training_loader(SOURCE,c,SEED);data.dataset.epoch=1;images,samples=next(iter(data))
        loss,_=loss_for(model,images,samples,reference,c,device);loss.backward()
        assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith('heads.size.'))
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.heads.size.parameters())
        before={n:v.cpu().clone() for n,v in model.state_dict().items()};opt.step();frozen(model,parent['model'])
        assert any(not torch.equal(v.cpu(),before[n]) for n,v in model.state_dict().items() if n.startswith('heads.size.'))
        write_json(HOME/'preflight.json',{'passed':True,'config':config,'trainable_parameters':5258,'views':dict(Counter(s['view_type'] for s in samples)),'updated_at':now()})
        return
    assert json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))['config']==config
    if (HOME/'training_complete.json').exists():return
    if (HOME/'config.json').exists():assert a.resume and json.loads((HOME/'config.json').read_text(encoding='utf-8'))==config
    write_json(HOME/'config.json',config);write_json(HOME/'recipe.json',c);write_json(HOME/'process.json',{'pid':os.getpid(),'updated_at':now()})
    ema=copy.deepcopy(model).eval()
    for p in ema.parameters():p.requires_grad_(False)
    train=training_loader(SOURCE,c,SEED);val=make_loader(SOURCE,'val',c);spec=probe_spec(c)
    write_json(HOME/'probe_spec.json',spec);started=time.perf_counter();first=0;updates=0;prior=0.
    try:
        if not (HOME/'baseline.json').exists():
            write_json(HOME/'progress.json',{'status':'baseline_source_validation','updated_at':now()})
            frames=evaluate(ema,val,device,reference,HOME/'baseline_predictions.json')
            base={'epoch':0,'validation':validation_summary(frames),'geometry':probe(ema,c,reference,device,spec)}
            write_json(HOME/'baseline.json',base);save_checkpoint(HOME/'best.pt',{**base,'model':ema.state_dict(),'config':config})
            write_json(HOME/'best_gates.json',gates(base,base))
        base=json.loads((HOME/'baseline.json').read_text(encoding='utf-8'))
        if a.resume and (HOME/'last.pt').exists():
            s=torch.load(HOME/'last.pt',map_location='cpu',weights_only=False);assert s['config']==config
            model.load_state_dict(s['model']);ema.load_state_dict(s['ema']);opt.load_state_dict(s['optimizer'])
            updates=s['updates'];first=s['next_epoch'];prior=s['elapsed_seconds'];restore_rng(s['rng'])
        best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False);best_key=key(best,base);del best
        current=None
        for epoch in range(first,3):
            counts=Counter();tick=time.perf_counter();train.dataset.epoch=epoch+1
            for j,(images,samples) in enumerate(train):
                model.eval();model.heads.size.train();opt.zero_grad(set_to_none=True)
                loss,_=loss_for(model,images,samples,reference,c,device);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.heads.size.parameters(),10.,error_if_nonfinite=True);opt.step();updates+=1
                decay=.9999*(1-math.exp(-updates/2000))
                with torch.no_grad():
                    for x,y in zip(ema.heads.size.parameters(),model.heads.size.parameters()):x.mul_(decay).add_(y,alpha=1-decay)
                for s in samples:counts[s['view_type']]+=1
                if j%100==0:
                    progress={'status':'training','epoch':epoch+1,'batch':j+1,'total_batches':len(train),'updates':updates,'views':dict(counts),'updated_at':now()}
                    write_json(HOME/'progress.json',progress);print(json.dumps(progress),flush=True)
            assert sum(counts.values())==len(train.dataset);frozen(model,parent['model']);frozen(ema,parent['model'])
            train_seconds=time.perf_counter()-tick;write_json(HOME/'progress.json',{'status':'source_validation','epoch':epoch+1,'updated_at':now()})
            frames=evaluate(ema,val,device,reference,HOME/f'epoch_{epoch+1:02d}_predictions.json')
            row={'epoch':epoch+1,'updates':updates,'validation':validation_summary(frames),'geometry':probe(ema,c,reference,device,spec),
                'views':dict(counts),'train_seconds':train_seconds,'elapsed_seconds':prior+time.perf_counter()-started}
            current=gates(row,base);row['gates']=current
            for name,digest in config['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
            checkpoint={**row,'model':ema.state_dict(),'config':config};save_checkpoint(HOME/f'epoch_{epoch+1:02d}_ema.pt',checkpoint)
            if key(row,base)>best_key:best_key=key(row,base);save_checkpoint(HOME/'best.pt',checkpoint);write_json(HOME/'best_gates.json',current)
            save_checkpoint(HOME/'last.pt',{'model':model.state_dict(),'ema':ema.state_dict(),'optimizer':opt.state_dict(),'config':config,
                'updates':updates,'next_epoch':epoch+1,'rng':rng_state(),'elapsed_seconds':row['elapsed_seconds']})
            with (HOME/'history.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
            print(json.dumps({'validated_epoch':epoch+1,'gates':current,'geometry':row['geometry'],'macro_AP50':row['validation']['group_macro_AP50']}),flush=True)
            if all(current.values()):break
        final=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
        done={'status':'completed','promotion_passed':all(gates(final,base).values()),'gates':gates(final,base),'best_epoch':final['epoch'],
            'epochs_run':epoch+1,'updates':updates,'target_test_cells':0,'updated_at':now()}
        write_json(HOME/'training_complete.json',done);write_json(HOME/'progress.json',done)
    except Exception:write_json(HOME/'failure.json',{'traceback':traceback.format_exc(),'updated_at':now()});raise


if __name__=='__main__':main()
