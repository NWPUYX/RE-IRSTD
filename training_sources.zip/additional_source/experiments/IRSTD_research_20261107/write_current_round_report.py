"""Concise evidence ledger; never invent pending validation or test scores."""
import json
from pathlib import Path
from datetime import datetime

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]


def read(path):return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None


def main():
    lines=['# 本轮验证效果与正在执行的改进','',
        f'[KNOWN｜HIGH] 更新：{datetime.now().astimezone().isoformat(timespec="seconds")}。主口径为单帧、相同监督和外部信息；全部当前新候选为DAUB-R源、3407种子。',
        '', '[COMPUTED｜HIGH] 当前尚未达到论文/SOTA验收。固定512阶段只提高了部分跨域指标；大输入下超过这里两个单帧对照，不等于固定512胜出或完整四源三种子胜出。',
        '', '| 固定512、原学习尺寸规则 | 三目标域宏AP50 | 三目标域宏F1 |','|---|---:|---:|']
    scene=read(HERE/'scene_scale_sourceAP_control_v1/source_qualified_tests/original/summary.json')
    if scene:
        m=scene['cross_domain_macro'];lines.append(f"| 场景E4源AP诊断 | {m['AP50']*100:.4f}% | {m['F1']*100:.4f}% |")
    aa=[read(ROOT/f'runs/AA-YOLO/DAUB-R/seed_3407/test_{d}_metrics.json') for d in ['IRDST-H','IRSTD-UAV','ITSDT-15K']]
    if all(aa):lines.append(f"| AA-YOLO | {sum(r['overall']['AP50'] for r in aa)/3*100:.4f}% | {sum(r['overall']['F1'] for r in aa)/3*100:.4f}% |")
    review=read(HERE/'paper_metric_review_consistent_teacher_v1/summary.json')
    if review:
        m=review['cross_domain_macro'];lines.append(f"| 最新数值一致教师主指标复核 | {m['AP50']*100:.4f}% | {m['F1']*100:.4f}% |")
        lines[4]='[COMPUTED｜HIGH] 最新固定512原尺寸主指标已超过当前两个单帧对照的跨域宏AP50与F1；源15/18历史失败保留。尚未完成四训练源、重复种子、机制与预算对照，不能据这一阶段宣布全面SOTA。历史场景E4及大输入结果继续分列。'
    density=read(HERE/'native_pixel_results_audit_v2/result.json')
    if density:
        assert density['passed'] and len(density['cells'])==20
        lines+=['','[COMPUTED｜HIGH] 五模型像素密度对照20/20完成，指标缓存重算审查通过。此协议使用约4.69—5.27倍输入像素，独立列示：',
            '','| 模型 | 跨域宏AP50 | 跨域宏F1 |','|---|---:|---:|']
        for name,m in density['cross_domain_macros'].items():lines.append(f"| {name} | {m['AP50']*100:.4f}% | {m['F1']*100:.4f}% |")
    cases=[]
    for epoch in [1,2]:
        row=read(HERE/f'integral_joint_v1/epoch_{epoch:02d}_row.json')
        if row:cases.append((f'积分联合E{epoch}',row))
    row=read(HERE/'local_readout_qualified_v1/source_row.json')
    if row:cases.append(('场景E2混合热图a0.25',row))
    locked=read(HERE/'locked_peak_readout_v1/rows.json') or {}
    cases.extend((f'积分E1固定峰a{a}',row) for a,row in locked.items())
    if cases:
        lines+=['','[COMPUTED｜HIGH] 后续源域验证如下；原18项门槛不变。未通过者没有以本阶段正式候选身份进入目标测试。',
            '','| 阶段 | 源AP50 | 源AP50:95 | 源F1 | 强噪声AP50 | 源通过数 |','|---|---:|---:|---:|---:|---:|']
        for label,row in cases:
            m=row['source_validation']['pooled'];lines.append(f"| {label} | {m['AP50']*100:.4f}% | {m['AP50_95']*100:.4f}% | {m['F1']*100:.4f}% | {row['noise']['16']['box']['AP50']*100:.4f}% | {sum(row['gates'].values())}/18 |")
    lines+=['','[COMPUTED｜HIGH] 数值正确的积分端点固定原峰和框后，精细定位与拼接F1仍未通过：a0.25的data19 AP50:95为74.5108%，原保护值约75.1163%；2/3/4阶拼接F1均为0。噪声排序改善并未自动带来这些改善。',
        '[INFERRED｜HIGH] 不能把各阶段全部失败统一归因于混合热图移峰。场景E2和积分E1是不同权重；尚未完成场景E2同权重固定峰完整对照，不能用跨端点比较单独量化其移峰贡献。',
        '', '[KNOWN｜HIGH] 当前一次有界联合适配保留数值正确的FP64环带积分、14个条件零和算子、全分辨率T及全部808952原参数。训练/部署固定a0.25评分，部署仍在原主峰读取原offset/尺寸。新增原图局部空间KL保持峰定位，全部增强GT锚点的softplus校准覆盖所有供体；源统计和教师冻结。最多六轮12546次更新，完整源验证后再决定资格，不降低既有门槛。']
    folder=HERE/'peak_calibrated_v1';preflight=read(folder/'preflight.json');progress=read(folder/'training_complete.json') or read(folder/'progress.json')
    if preflight:lines+=['','[COMPUTED｜HIGH] 新训练预检通过：五种视图反传、全部参数有限梯度、新损失梯度、供体覆盖、教师/统计不变、部署与训练分数一致、原峰几何、保存重载、T局部性和条件算子检查。']
    if progress:
        if progress['status']=='training':status=f"第{progress['epoch']}轮，批次{progress['batch']}/{progress['total_batches']}，正式更新{progress['updates']}次"
        elif progress.get('status')=='completed':status=f"源训练完成，最佳第{progress['best_epoch']}轮，源全部通过={progress['promotion_passed']}"
        else:status=f"{progress['status']}，{progress.get('target',progress.get('phase',''))}，{progress.get('frames_completed','')}/{progress.get('total_frames','')}"
        lines+=['',f'[COMPUTED｜HIGH] 当前记录：{status}。']
    for path in sorted(folder.glob('epoch_*_row.json')):
        row=read(path);m=row['source_validation']['pooled'];failed=[k for k,v in row['gates'].items() if not v]
        lines+=['',f"[COMPUTED｜HIGH] 新训练E{row['epoch']}：源AP50/AP50:95/F1={m['AP50']*100:.4f}%/{m['AP50_95']*100:.4f}%/{m['F1']*100:.4f}%；{sum(row['gates'].values())}/18；未通过：{'、'.join(failed) or '无'}。"]
    result=read(folder/'source_qualified_tests/summary.json')
    if result:
        m=result['cross_domain_macro'];lines+=['',f"[COMPUTED｜HIGH] 新训练已完成四域测试：跨域宏AP50/F1={m['AP50']*100:.4f}%/{m['F1']*100:.4f}%；这是该固定模型与固定规则的完整三目标域均值。"]
    gradient=read(HERE/'source_head_gradient_diagnostic_v1/result.json')
    if gradient:
        lines+=['',f"[COMPUTED｜HIGH] 零更新诊断：冻结第1轮权重，在{gradient['source_train_records']}个源训练组各1帧上分离骨干特征，仅计算{gradient['head_parameters']}个检测头参数的选定损失梯度；参数和buffer未变。额外正例校准与噪声输出教师约束如下：",
            '','| 视图 | 梯度余弦中位数 | 负余弦比例 |','|---|---:|---:|']
        for view in ['noise4','noise16','background_noise16']:
            value=gradient['summary'][view]['positive_vs_noise_teacher_cosine']
            lines.append(f"| {view} | {value['median']:.4f} | {value['negative_fraction']*100:.1f}% |")
        lines+=['','[INFERRED｜MED] 这些选定头部梯度存在相反方向，支持检查目标冲突；它不是全网络梯度或退化原因的单独证明。诊断中的原图约束列为局部代理，本表只使用噪声输出约束列。当前六轮训练不据此中途改配方。']
    if (HERE/'数值一致教师与几何校准后续方案.md').exists():
        lines+=['','[KNOWN｜HIGH] 已准备条件后续：若六轮结束且独立审查通过但源仍失败，先真实预检，再使用同数值实现与读出的积分噪声教师，原生教师按训练框IoU质量选择，仅对几何/拼接目标增加正例校准，最多两轮。教师选择只用于源训练；源通过则跳过此后续并完成当前模型四域测试。该后续当前是否实际启动，以以下状态记录为准。']
        next_folder=HERE/'consistent_teacher_v1';next_progress=read(next_folder/'training_complete.json') or read(next_folder/'progress.json')
        if next_progress:lines+=['',f"[COMPUTED｜HIGH] 条件后续状态：{next_progress.get('status')}；轮次{next_progress.get('epoch',next_progress.get('best_epoch',''))}，批次{next_progress.get('batch','')}/{next_progress.get('total_batches','')}。"]
        else:lines+=['','[KNOWN｜HIGH] 条件后续尚未实际预检或训练。']
        for path in sorted(next_folder.glob('epoch_*_row.json')):
            row=read(path);m=row['source_validation']['pooled'];failed=[k for k,v in row['gates'].items() if not v]
            lines+=['',f"[COMPUTED｜HIGH] 条件后续E{row['epoch']}：源AP50/AP50:95/F1={m['AP50']*100:.4f}%/{m['AP50_95']*100:.4f}%/{m['F1']*100:.4f}%；{sum(row['gates'].values())}/18；未通过：{'、'.join(failed) or '无'}。"]
        test=read(next_folder/'source_qualified_tests/summary.json')
        if test:
            m=test['cross_domain_macro'];lines+=['',f"[COMPUTED｜HIGH] 条件后续已完成四域：跨域宏AP50/F1={m['AP50']*100:.4f}%/{m['F1']*100:.4f}%。"]
    lines+=['','[KNOWN｜HIGH] 源门槛和代码审查通过不等于SOTA。仍须核对同条件完整对照、训练源与随机种子、累计训练预算、三项机制消融及未参与开发的确认场景。当前开发测试不能改称独立最终测试。']
    destination=ROOT/'results/IRSTD本轮验证效果_20261109.md';destination.write_text('\n'.join(lines),encoding='utf-8')
    print(str(destination),flush=True)


if __name__=='__main__':main()
