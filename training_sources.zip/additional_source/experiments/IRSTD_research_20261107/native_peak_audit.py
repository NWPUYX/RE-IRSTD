"""Read-only comparison of GT-near native predictions before/after head training."""
from collections import defaultdict
import json
from pathlib import Path
import sys
import numpy as np

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_v2.settings import write_json,now


def candidates(path):
    data=json.loads(path.read_text(encoding='utf-8'));grouped=defaultdict(list)
    for pred in data['predictions']:grouped[str(pred['image_id'])].append(pred)
    return grouped


def top_near(predictions,box):
    gt=np.asarray(box,dtype=float);center=gt[:2]+gt[2:]/2
    ordered=sorted(predictions,key=lambda p:-p['score'])
    for p in ordered:
        b=np.asarray(p['bbox']);c=b[:2]+b[2:]/2
        if np.linalg.norm(c-center)<=3:
            a=np.maximum(b[:2],gt[:2]);z=np.minimum(b[:2]+b[2:],gt[:2]+gt[2:]);intersection=np.maximum(z-a,0).prod()
            iou=intersection/(b[2:].prod()+gt[2:].prod()-intersection)
            return {'bbox':b,'center':c,'iou':float(iou),'score':p['score']}
    return None


def main():
    parent=candidates(HOME/'native_precision_w4_v1/best_source_val_predictions.json')
    newer=candidates(HOME/'background_center_guarded_v1/epoch_01_predictions.json')
    records=json.loads((ROOT/'splits/DAUB-R_val.json').read_text(encoding='utf-8'));rows=[];missing=0
    for record in records:
        assert len(record['boxes'])==1
        a=top_near(parent[str(record['id'])],record['boxes'][0]);b=top_near(newer[str(record['id'])],record['boxes'][0])
        if a is None or b is None:missing+=1;continue
        rows.append({'group':record['group'],'id':record['id'],'same_bbox':bool(np.allclose(a['bbox'],b['bbox'],atol=1e-5,rtol=0)),
            'center_distance_change':float(np.linalg.norm(a['center']-b['center'])),'parent_iou':a['iou'],'new_iou':b['iou'],
            'parent_score':a['score'],'new_score':b['score']})
    def summarize(selected):
        return {'targets_compared':len(selected),'same_bbox_fraction':sum(r['same_bbox'] for r in selected)/len(selected),
            'changed_peak_count':sum(not r['same_bbox'] for r in selected),
            'parent_hits_IoU95':sum(r['parent_iou']>=.95-1e-7 for r in selected),
            'new_hits_IoU95':sum(r['new_iou']>=.95-1e-7 for r in selected),
            'lost_IoU95':sum(r['parent_iou']>=.95-1e-7 and r['new_iou']<.95-1e-7 for r in selected),
            'gained_IoU95':sum(r['parent_iou']<.95-1e-7 and r['new_iou']>=.95-1e-7 for r in selected),
            'center_change_quantiles':np.quantile([r['center_distance_change'] for r in selected],[.5,.9,.99]).tolist()}
    report={'scope':'source-val saved predictions only; GT-near highest-score candidate within3 native pixels; not target fitting',
        'overall':summarize(rows),'by_group':{g:summarize([r for r in rows if r['group']==g]) for g in sorted({r['group'] for r in rows})},
        'missing_near_candidate_in_either':missing,'rows':rows,'updated_at':now()}
    write_json(HOME/'background_center_guarded_v1/native_peak_audit.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)


if __name__=='__main__':main()
