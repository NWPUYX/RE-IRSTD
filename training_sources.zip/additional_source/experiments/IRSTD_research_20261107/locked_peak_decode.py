"""Keep main-head anchors and geometry; rescore with the trained local T head."""
import torch
from anchor_preserving_decode import decode_raw


def base_candidates(outputs,reference):
    return decode_raw(outputs,reference,threshold=torch.finfo(torch.float32).tiny)


def rescore(outputs,candidates,weight,threshold=1e-5):
    if not 0<=weight<=1:raise ValueError('invalid readout weight')
    result=[]
    for b,item in enumerate(candidates):
        anchors=item['anchors'];x,y=anchors.unbind(1)
        if weight==0:score=item['raw'][:,4]
        elif weight==1:score=outputs['auxiliary_center_logits'][b,0,y,x].float().sigmoid()
        else:
            logit=(1-weight)*outputs['center_logits'][b,0,y,x].float()+weight*outputs['auxiliary_center_logits'][b,0,y,x].float()
            score=logit.sigmoid()
        keep=score>=threshold;raw=item['raw'][keep].clone();raw[:,4]=score[keep]
        result.append({'raw':raw,'anchors':anchors[keep]})
    return result


def decode_locked(outputs,reference,weight):
    return rescore(outputs,base_candidates(outputs,reference),weight)
