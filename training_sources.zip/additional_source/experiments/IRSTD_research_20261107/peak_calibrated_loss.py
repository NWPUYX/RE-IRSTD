"""Spatial localization transfer and all-augmented-target confidence calibration."""
import torch
from torch.nn import functional as F
from integral_joint_loss import losses as base_loss
from irstd_adapter import targets,model_config


def losses(model,clean_teacher,noise_teacher,images,samples,reference,cfg,device):
    student=[];teacher=[]
    handles=[model.register_forward_hook(lambda m,args,out:student.append(out)),
        clean_teacher.register_forward_hook(lambda m,args,out:teacher.append(out))]
    try:loss,terms=base_loss(model,clean_teacher,noise_teacher,images,samples,reference,cfg,device)
    finally:
        for handle in handles:handle.remove()
    assert len(student)==len(teacher)==1
    out=student[0];fixed=teacher[0];n=len(samples)//2
    t=targets(samples,model_config(),reference,device,'shared_regression');anchor=t['anchors'];location=[]
    temperature=.5
    for b,x,y in anchor[anchor[:,0]<n].tolist():
        ys=slice(max(y-3,0),min(y+4,512));xs=slice(max(x-3,0),min(x+4,512))
        a=out['main_peak_logits'][b,0,ys,xs].flatten()/temperature
        z=fixed['center_logits'][b,0,ys,xs].detach().flatten()/temperature
        location.append(F.kl_div(F.log_softmax(a,0),F.softmax(z,0),reduction='sum')*temperature**2)
    selected=anchor[anchor[:,0]>=n]
    if len(selected):
        b,x,y=selected.unbind(1);positive=out['center_logits'][b,0,y,x]
        calibrated=F.softplus(2-positive).mean()
    else:positive=out['center_logits'].new_empty(0);calibrated=loss*0
    spatial=torch.stack(location).mean() if location else loss*0
    if cfg.get('verify_new_loss_gradients',False):
        grad= torch.autograd.grad(calibrated,out['center_logits'],retain_graph=True)[0]
        b,x,y=selected.unbind(1)
        assert torch.isfinite(grad).all() and (grad[b,0,y,x]<0).all()
        delta=torch.autograd.grad(spatial,out['main_peak_logits'],retain_graph=True)[0]
        assert torch.isfinite(delta).all() and torch.count_nonzero(delta)>0
        assert not fixed['center_logits'].requires_grad
    loss=loss+.5*spatial+.1*calibrated;assert torch.isfinite(loss)
    terms.update(native_location_KL=float(spatial.detach()),augmented_positive_calibration=float(calibrated.detach()),
        calibrated_augmented_targets=len(selected),expected_augmented_targets=sum(len(s['boxes']) for s in samples[n:]),
        calibrated_positive_logit_mean=float(positive.detach().mean()) if len(positive) else 0.,actual_loss=float(loss.detach()))
    terms['new_loss_gradients_verified']=bool(cfg.get('verify_new_loss_gradients',False))
    assert terms['calibrated_augmented_targets']==terms['expected_augmented_targets']
    return loss,terms
