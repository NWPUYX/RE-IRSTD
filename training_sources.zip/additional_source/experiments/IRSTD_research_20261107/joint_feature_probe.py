"""Read-only source-train ridge test for complementarity of existing features."""
import json
from pathlib import Path
import numpy as np
from feature_probe import fit_predict

HOME=Path(__file__).resolve().parent


def main():
    output={}
    for source in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        folder=HOME if source=='DAUB-R' else HOME/'cross_source_probes'/source
        arrays=folder/('feature_probe_arrays.npz' if source=='DAUB-R' else 'arrays.npz')
        if not arrays.exists():continue
        meta=json.loads((folder/('feature_probe_metadata.json' if source=='DAUB-R' else 'metadata.json')).read_text(encoding='utf-8'))
        a=np.load(arrays);train=a['train'];hold=~train;y=a['y'];results={}
        for name,x in [('T',a['T']),('fused',a['fused']),('joint',np.concatenate([a['fused'],a['T']],axis=1))]:
            pred=fit_predict(x.astype(np.float64),y,train);err=np.abs(pred-y)
            results[name]={'overall_MAE':float(err[hold].mean()),'by_scale':{}}
            for scale in [.6,1.,1.4]:
                selected=hold&np.array([r['scale']==scale for r in meta]);results[name]['by_scale'][str(scale)]=float(err[selected].mean())
        output[source]=results
    (HOME/'joint_feature_probe.json').write_text(json.dumps({'scope':'post-probe source-train exploratory comparison; alpha1 fixed; not validation AP','results':output},indent=2),encoding='utf-8')
    print(json.dumps(output),flush=True)


if __name__=='__main__':main()
