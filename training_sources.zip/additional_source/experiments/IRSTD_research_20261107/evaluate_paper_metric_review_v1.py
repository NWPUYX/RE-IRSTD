"""Frozen primary-metric review; source18 failures explicitly retained."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from consistent_teacher_training import HOME,identity,sha
from peak_calibrated_model import PeakCalibratedModel as IntegralPopulationModel
from peak_calibrated_evaluation import evaluate
from irstd_v2.data import make_loader
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now
from benchmark_progress import ReportingLoader
from benchmark_cluster_bootstrap import cluster_ci
from evaluation import metrics
import benchmark_fastdecode as fast


def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    audit_path=HOME/'independent_audit.json';audit=json.loads(audit_path.read_text(encoding='utf-8'))
    assert audit['passed'] # Separate diagnostic role; preserve original source failure.
    checkpoint=HOME/'best.pt';state=torch.load(checkpoint,map_location='cpu',weights_only=False)
    bound,_=identity();assert state['config']==bound and sha(checkpoint)==audit['checkpoint_sha256']
    source=HOME/'best_source_val_predictions.json'
    assert validation_summary(json.loads(source.read_text(encoding='utf-8'))['frames'])==state['source_validation']
    model=IntegralPopulationModel(bound['recipe']).cuda().eval();model.load_state_dict(state['model']);model.set_mode(final=False)
    for p in model.parameters():p.requires_grad_(False)
    folder=HERE/'paper_metric_review_consistent_teacher_v1';folder.mkdir(exist_ok=True)
    threshold=state['source_validation']['threshold']
    manifest={'checkpoint_sha256':sha(checkpoint),'audit_sha256':sha(audit_path),'source_predictions_sha256':sha(source),
        'threshold':threshold,'split_hashes':bound['split_hashes'],'script_sha256':sha(__file__),
        'source_evaluator_sha256':sha(HERE/'peak_calibrated_evaluation.py'),'score_decoder_sha256':sha(HERE/'peak_calibrated_model.py'),'locked_anchor_sha256':sha(HERE/'locked_peak_decode.py'),
        'evaluation_sha256':sha(ROOT/'evaluation.py'),'input':'fixed512 original RGB bicubic letterbox then gray',
        'size_rule':'original learned input-pixel units; no extra size prior',
        'readout_weight':.25,'peak_policy':'raw main peaks; calibrated T score map','role':'primary-metric diagnostic review; source18 failure retained; not independent SOTA confirmation', 'source_gates':state['gates'], 'plan_sha256':sha(HERE/'论文主指标审查测试冻结方案_20261110.md')}
    path=folder/'freeze_manifest.json'
    if path.exists():assert json.loads(path.read_text(encoding='utf-8'))==manifest
    else:write_json(path,manifest)
    for domain in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=folder/f'{domain}_metrics.json'
        if path.exists():continue
        predictions=folder/f'{domain}_predictions.json'
        if predictions.exists():frames=json.loads(predictions.read_text(encoding='utf-8'))['frames']
        else:frames=evaluate(model,ReportingLoader(make_loader(domain,'test',bound['recipe']),folder/'progress.json',domain),
            torch.device('cuda'),bound['size_reference_512'],predictions)
        overall=metrics(frames,threshold);ci=cluster_ci(frames)
        if ci is not None:overall['AP50_cluster_CI95']=ci
        result={'source':'DAUB-R','target':domain,'seed':3407,'overall':overall,
            'by_group':{g:metrics([f for f in frames if f['group']==g],threshold) for g in sorted({f['group'] for f in frames})},'updated_at':now()}
        write_json(path,result);print(json.dumps(result),flush=True)
    assert all(torch.equal(v.cpu(),state['model'][name]) for name,v in model.state_dict().items())
    cross=[json.loads((folder/f'{d}_metrics.json').read_text(encoding='utf-8'))['overall'] for d in ['IRDST-H','IRSTD-UAV','ITSDT-15K']]
    result={'status':'completed','source':'DAUB-R','seed':3407,'completed_cells':4,'threshold':threshold,
        'all_tensors_unchanged':True,'cross_domain_macro':{key:sum(r[key] for r in cross)/3 for key in ['AP50','AP50_95','F1','center_Pd_3px']},
        'role':manifest['role'],'updated_at':now()}
    write_json(folder/'summary.json',result);write_json(folder/'progress.json',result)


if __name__=='__main__':main()
