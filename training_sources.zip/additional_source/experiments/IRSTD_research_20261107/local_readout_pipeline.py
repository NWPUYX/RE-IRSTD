"""Bounded source qualification, independent audit, then gated four-domain test."""
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];HOME=HERE/'local_readout_qualified_v1'


def run(script,log,*args):
    with (HERE/log).open('a',encoding='utf-8') as stream:
        subprocess.run([sys.executable,str(HERE/script),*args],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)


def main():
    result=json.loads((HERE/'local_readout_screen_v1/result.json').read_text(encoding='utf-8'))
    if result['selected_for_full_source_validation'] is None:
        print(json.dumps({'status':'no_source_prescreen_candidate','target_tests_started':False}),flush=True);return
    try:
        run('qualify_local_readout.py','local_readout_qualification.log')
        run('qualify_local_readout.py','local_readout_audit.log','--audit')
        audit=json.loads((HOME/'independent_audit.json').read_text(encoding='utf-8'));assert audit['passed']
        if audit['promotion_passed']:run('evaluate_local_readout.py','local_readout_frozen_test.log')
        print(json.dumps({'status':'completed','promotion_passed':audit['promotion_passed'],
            'target_tests_started':audit['promotion_passed']}),flush=True)
    finally:
        subprocess.run([sys.executable,str(HERE/'update_progress_report.py')],cwd=ROOT,check=False)


if __name__=='__main__':main()
