"""Zero-training valid-region/GN candidates selected strictly on source data."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import copy
import hashlib
import json
from pathlib import Path
import sys
import torch
from torch.nn import functional as F

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_v2.model import Model,MaskedGN
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_geometry_balance.run import probe,gates
from irstd_native_precision.run import quality
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint
import benchmark_fastdecode as fast

PARENT=HERE/'native_precision_w4_v1'
HOME=HERE/'P3_zero_training_source_v1'


class P3Route(Model):
    def forward(self,image,valid_mask=None,return_features=False,diagnostics=False):
        if valid_mask is None:valid_mask=torch.ones_like(image,dtype=torch.bool)
        h,w=image.shape[-2:]
        if self.recipe['masked_group_norm']:
            for module in self.modules():
                if isinstance(module,MaskedGN):module.mask=valid_mask
        if self.recipe['valid_region_evidence']:
            zs=[];cs=[]
            for x,mask in zip(image,valid_mask):
                positions=mask[0].nonzero();assert len(positions)
                y0,x0=positions.min(0).values.tolist();y1,x1=(positions.max(0).values+1).tolist()
                z,c=self.evidence(x[None,:,y0:y1,x0:x1],diagnostics)
                padding=(x0,w-x1,y0,h-y1);zs.append(F.pad(z,padding));cs.append(F.pad(c,padding))
            z,c=torch.cat(zs),torch.cat(cs)
        else:z,c=self.evidence(image,diagnostics)
        padding=(0,(-w)%8,0,(-h)%8)
        final,target=self.backbone(F.pad(z,padding,mode='replicate'),F.pad(c,padding,mode='replicate'),diagnostics)
        output={'center_logits':self.heads.center(final),'offsets':self.heads.offset(final),
            'log_size':self.heads.size(target),'auxiliary_center_logits':self.heads.aux(target)}
        output={name:value[...,:h,:w] for name,value in output.items()}
        if return_features:output['final_features']=final[...,:h,:w]
        return output


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(3);torch.backends.cudnn.benchmark=False;device=torch.device('cuda')
    assert not (HOME/'source_complete.json').exists(),'Already completed; preserve prior selection'
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False)
    reference=parent['config']['size_reference_512'];assert split_hashes()==parent['config']['split_hashes']
    check=json.loads((HERE/'fastdecode_equivalence.json').read_text(encoding='utf-8'));assert check['passed'] and check['source_sha256']==sha(ROOT/'benchmark_fastdecode.py');fast.install()
    variants=[('valid_evidence',True,False),('masked_GN',False,True),('valid_evidence_and_masked_GN',True,True)]
    plan={'zero_training':True,'variants':variants,'selection':'all previous source quality gates, then smallest pressure size error, then macroAP50; no target feedback',
        'parent_sha256':sha(PARENT/'best.pt'),'source':'DAUB-R','seed':3407,'updated_at':now()}
    write_json(HOME/'plan.json',plan);rows=[];selected=None;best_key=None
    for index,(name,evidence,gn) in enumerate(variants):
        folder=HOME/name;folder.mkdir(exist_ok=True);cfg=copy.deepcopy(parent['config']['recipe'])
        cfg.update(name=name,valid_region_evidence=evidence,masked_group_norm=gn)
        identity={'source':'DAUB-R','seed':3407,'recipe':cfg,'size_reference_512':reference,'split_hashes':split_hashes(),
            'model_class':'p3_source_only.P3Route','initial_checkpoint':str(PARENT/'best.pt'),'parent_sha256':plan['parent_sha256'],
            'source_hashes':{**parent['config']['source_hashes'],str(Path(__file__).relative_to(ROOT.parent)):sha(__file__),
                str((ROOT/'benchmark_fastdecode.py').relative_to(ROOT.parent)):sha(ROOT/'benchmark_fastdecode.py')}}
        model=P3Route(cfg).to(device);model.load_state_dict(parent['model'],strict=True);model.eval()
        assert sum(p.numel() for p in model.parameters())==808952
        for p in model.parameters():p.requires_grad_(False)
        for key,value in model.state_dict().items():assert torch.equal(value.cpu(),parent['model'][key]),key
        write_json(HOME/'progress.json',{'status':'source_validation','variant':name,'index':index+1,'total_variants':3,'updated_at':now()})
        path=folder/'source_predictions.json';frames=evaluate(model,make_loader('DAUB-R','val',cfg),device,reference,path)
        total,scales=probe(model,cfg,reference,device)
        row={'epoch':parent['epoch'],'variant':name,'source_validation':validation_summary(frames),'geometry_probe':total,'per_scale':scales,
            'weights_unchanged':True,'training_updates':0}
        full,original,large,margin=quality(row);row['gates']={'all_quality':full,'original_three':original,'enlarge':large,'fine_AP95':margin>=0}
        row['fine_margin']=margin;write_json(folder/'result.json',row);write_json(folder/'config.json',identity)
        save_checkpoint(folder/'candidate.pt',{**row,'model':model.state_dict(),'config':identity})
        rows.append(row);key=(full,-total['log_size_error'],row['source_validation']['group_macro_AP50'])
        if full and (best_key is None or key>best_key):best_key=key;selected=name
        print(json.dumps({'variant':name,'gates':row['gates'],'macro_AP50':row['source_validation']['group_macro_AP50'],'geometry':total}),flush=True)
        del model
    result={'status':'completed_zero_training','selected_variant':selected,'promotion_passed':selected is not None,'results':rows,
        'training_updates':0,'target_test_cells':0,'updated_at':now()}
    if selected:
        candidate=torch.load(HOME/selected/'candidate.pt',map_location='cpu',weights_only=False)
        save_checkpoint(HOME/'best.pt',candidate);write_json(HOME/'config.json',candidate['config'])
        import shutil
        shutil.copyfile(HOME/selected/'source_predictions.json',HOME/'best_source_val_predictions.json')
    write_json(HOME/'source_complete.json',result);write_json(HOME/'progress.json',result)


if __name__=='__main__':main()
