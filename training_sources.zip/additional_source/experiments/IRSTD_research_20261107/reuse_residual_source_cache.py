"""Reuse legacy learned-size cells only where the residual unit factor is one."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from irstd_v2.settings import write_json, now
from irstd_v2.evaluate import validation_summary


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def copy_verified(source, destination):
    if destination.exists():
        assert sha(source) == sha(destination)
    else:
        shutil.copyfile(source, destination)


def main():
    parent_home = HERE/'robust_T_composed_v1'
    control_home = HERE/'robust_T_sourceAP_control_v1'
    parent = torch.load(parent_home/'best.pt', map_location='cpu', weights_only=False)
    control = torch.load(control_home/'best.pt', map_location='cpu', weights_only=False)
    assert parent['config']['recipe'] == control['config']['recipe']
    assert parent['model'].keys() == control['model'].keys()
    assert all(torch.equal(v, control['model'][k]) for k, v in parent['model'].items())
    old_test = control_home/'frozen_four_domain_test'
    manifest = json.loads((old_test/'freeze_manifest.json').read_text(encoding='utf-8'))
    assert manifest['checkpoint_sha256'] == sha(control_home/'best.pt')
    assert manifest['split_hashes'] == parent['config']['split_hashes']
    proof = {}
    for split in ['val', 'test']:
        path = ROOT/f'splits/DAUB-R_{split}.json'
        records = json.loads(path.read_text(encoding='utf-8'))
        for record in records:
            ratio = min(512/record['width'], 512/record['height'])
            scale = np.array([int(record['width']*ratio)/record['width'], int(record['height']*ratio)/record['height']])
            np.testing.assert_array_equal(scale/np.array([2., 2.]), np.ones(2))
        proof[split] = {'frames': len(records), 'split_sha256': sha(path), 'residual_unit_factor_exactly_one': True}
    source = parent_home/'epoch_01_predictions.json'
    frames = json.loads(source.read_text(encoding='utf-8'))['frames']
    assert validation_summary(frames) == parent['source_validation']
    home = HERE/'native_unit_irstd_robust_native_residual_v1'
    home.mkdir(exist_ok=True)
    test = home/'frozen_four_domain_test'
    test.mkdir(exist_ok=True)
    copy_verified(source, home/'source_val_predictions.json')
    copy_verified(old_test/'DAUB-R_predictions.json', test/'DAUB-R_predictions.json')
    metric = json.loads((old_test/'DAUB-R_metrics.json').read_text(encoding='utf-8'))
    destination = test/'DAUB-R_metrics.json'
    if not destination.exists():
        write_json(destination, {**metric, 'elapsed_seconds': 0., 'cache_reuse': {
            'from': str(old_test), 'reason': 'identical model tensors and raw sizes multiplied by exactly one on this partition',
            'input_predictions_sha256': sha(old_test/'DAUB-R_predictions.json')}, 'updated_at': now()})
    write_json(home/'source_cache_equivalence.json', {'passed': True, 'partitions': proof,
        'checkpoint_sha256': sha(parent_home/'best.pt'), 'cached_control_checkpoint_sha256': manifest['checkpoint_sha256'],
        'all_model_tensors_identical': True, 'recipe_identical': True, 'source_predictions_sha256': sha(source),
        'no_target_boxes_used_for_equivalence': True, 'updated_at': now()})
    print(json.dumps({'passed': True, 'reused_source_frames': len(frames), 'reused_DAUB_test_frames': proof['test']['frames']}), flush=True)


if __name__ == '__main__':
    main()
