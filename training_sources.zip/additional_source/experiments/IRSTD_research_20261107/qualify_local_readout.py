"""Qualify the unique source-prescreen winner; preserve failed parent stages."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from local_readout_model import IntegralReadoutModel,PopulationReadoutModel,blend
from local_readout_screen import ENDPOINTS
from anchor_source_evaluation import evaluate,background_diagnostic,evaluate_mosaics
from irstd_v2.data import make_loader
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_v2.train import save_checkpoint
from irstd_scene_scale.run import gates,locality_probe
from irstd_geometry_balance.run import probe
from irstd_robust_t.probe import extreme_probe
from irstd_robust_t.run import sha,mechanisms
from audit_conditional_function import functional_responses
from evaluation import metrics
from benchmark_center_metrics import center_metrics
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast

HOME=HERE/'local_readout_qualified_v1';SCREEN=HERE/'local_readout_screen_v1'
PARENT=HERE/'robust_T_composed_v1/best.pt'


def build(state):
    cfg=state['config']['recipe']
    cls=IntegralReadoutModel if state['config']['readout_endpoint'].startswith('integral') else PopulationReadoutModel
    model=cls(cfg).cuda().eval();model.load_state_dict(state['model'],strict=True);model.set_mode(final=False)
    for p in model.parameters():p.requires_grad_(False)
    return model


def bound_identity():
    result=json.loads((SCREEN/'result.json').read_text(encoding='utf-8'));winner=result['selected_for_full_source_validation']
    assert winner is not None,'no eligible source prescreen candidate'
    endpoint,weight=winner.split('/');path=ENDPOINTS[endpoint]
    original=torch.load(path,map_location='cpu',weights_only=False)
    screen_cfg=json.loads((SCREEN/'config.json').read_text(encoding='utf-8'))
    assert sha(path)==screen_cfg['checkpoint_sha256'][endpoint]
    assert screen_cfg['script_sha256']==sha(HERE/'local_readout_screen.py')
    assert screen_cfg['helper_sha256']==sha(HERE/'local_readout_model.py')
    assert screen_cfg['decoder_sha256']==sha(HERE/'anchor_preserving_decode.py')
    files=[Path(__file__),HERE/'local_readout_model.py',HERE/'anchor_source_evaluation.py',HERE/'T局部读出零训练筛查方案.md']
    config={**original['config'],'recipe':{**original['config']['recipe'],'local_readout_weight':float(weight)},
        'readout_endpoint':endpoint,'readout_parent_checkpoint_sha256':sha(path),
        'readout_screen_result_sha256':sha(SCREEN/'result.json'),'readout_screen_config_sha256':sha(SCREEN/'config.json'),
        'source_hashes':{**original['config']['source_hashes'],**{str(p.relative_to(ROOT.parent)):sha(p) for p in files}},
        'gate_parent_sha256':sha(PARENT),'optimization_updates_this_stage':0}
    assert config['split_hashes']==split_hashes()
    for name,digest in {**config['source_hashes'],**config['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
    return config,original,winner


def qualify():
    HOME.mkdir(exist_ok=True);bound,original,winner=bound_identity()
    path=HOME/'config.json'
    if path.exists():assert json.loads(path.read_text(encoding='utf-8'))==bound
    else:write_json(path,bound)
    if (HOME/'source_complete.json').exists():return
    state={'config':bound,'model':original['model']};model=build(state)
    cfg=bound['recipe'];reference=bound['size_reference_512'];device=torch.device('cuda')
    path=HOME/'source_val_predictions.json'
    frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,
        ReportingLoader(make_loader('DAUB-R','val',cfg),HOME/'progress.json','source_val'),device,reference,path)
    summary=validation_summary(frames);geometry,per_scale=probe(model,cfg,reference,device)
    write_json(HOME/'progress.json',{'status':'source_validation','phase':'original18 source diagnostics','updated_at':now()})
    row={'source_validation':summary,'geometry_probe':geometry,'per_scale':per_scale,
        'background':background_diagnostic(model,cfg,reference,device,HOME,'selected'),
        'noise':{},'extreme_geometry':extreme_probe(model,cfg,reference,device)}
    threshold=summary['threshold'];endpoint,weight=winner.split('/')
    for factor in [4,16]:
        path=SCREEN/f'{endpoint}_a{weight}_noise{factor}_frames.json'
        payload=json.loads(path.read_text(encoding='utf-8'));frames=payload['frames'];assert len(frames)==24
        row['noise'][str(factor)]={'box':metrics(frames,threshold),'center':center_metrics(frames,threshold)}
        write_json(HOME/f'noise{factor}_frames.json',{'frames':frames,'source_cache_sha256':sha(path)})
    row['T_pair_MSE']=locality_probe(model,cfg,device)
    row['mosaics']=evaluate_mosaics(model,cfg,reference,device,threshold)
    baseline=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    row['gates']=gates(row,torch.load(PARENT,map_location='cpu',weights_only=False),baseline);assert len(row['gates'])==18
    assert all(torch.equal(v.cpu(),original['model'][name]) for name,v in model.state_dict().items())
    checkpoint={**row,'model':original['model'],'config':bound,'optimization_updates':0,
        'parent_training_updates':original.get('updates'),'role':'zero-training readout development; parent failures retained'}
    save_checkpoint(HOME/'best.pt',checkpoint);write_json(HOME/'source_row.json',row)
    done={'status':'completed','promotion_passed':all(row['gates'].values()),'selected_readout':winner,
        'gates':row['gates'],'optimization_updates':0,'target_frames':0,'updated_at':now()}
    write_json(HOME/'source_complete.json',done);write_json(HOME/'progress.json',done)
    print(json.dumps({'selected':winner,'source':summary['pooled'],'gates':row['gates']}),flush=True)


def audit():
    bound,original,winner=bound_identity();state=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
    done=json.loads((HOME/'source_complete.json').read_text(encoding='utf-8'))
    assert bound==state['config'] and state['optimization_updates']==done['optimization_updates']==0
    assert all(torch.equal(v,original['model'][name]) for name,v in state['model'].items())
    model=build(state);assert sum(p.numel() for p in model.parameters())==808952
    # Independent forward equivalence to the parent plus the declared scalar readout.
    baseline=build({'config':{**bound,'recipe':{**bound['recipe'],'local_readout_weight':0.}},'model':original['model']})
    images,_=next(iter(make_loader('DAUB-R','val',bound['recipe'])))
    with torch.inference_mode():
        actual=model(images.cuda());expected=blend(baseline(images.cuda()),bound['recipe']['local_readout_weight'])
    assert all(torch.equal(value,expected[name]) for name,value in actual.items())
    del baseline
    frames=json.loads((HOME/'source_val_predictions.json').read_text(encoding='utf-8'))['frames']
    assert len(frames)==1801 and validation_summary(frames)==state['source_validation']
    threshold=state['source_validation']['threshold']
    for factor in [4,16]:
        data=json.loads((HOME/f'noise{factor}_frames.json').read_text(encoding='utf-8'))
        endpoint,weight=winner.split('/');path=SCREEN/f'{endpoint}_a{weight}_noise{factor}_frames.json'
        assert data['source_cache_sha256']==sha(path) and data['frames']==json.loads(path.read_text(encoding='utf-8'))['frames']
        assert metrics(data['frames'],threshold)==state['noise'][str(factor)]['box']
        assert center_metrics(data['frames'],threshold)==state['noise'][str(factor)]['center']
    from irstd_background_center.run import reference_threshold
    frames=json.loads((HOME/'selected_swapped_predictions.json').read_text(encoding='utf-8'))['frames']
    assert metrics(frames,reference_threshold())==state['background']['swapped_metrics']
    cfg=bound['recipe'];reference=bound['size_reference_512'];device=torch.device('cuda')
    geometry,per_scale=probe(model,cfg,reference,device)
    assert geometry==state['geometry_probe'] and per_scale==state['per_scale']
    assert extreme_probe(model,cfg,reference,device)==state['extreme_geometry']
    assert locality_probe(model,cfg,device)==state['T_pair_MSE']<=1e-10
    assert evaluate_mosaics(model,cfg,reference,device,threshold)==state['mosaics']
    functional=functional_responses(model);blocks=mechanisms(model)
    baseline=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    computed=gates(state,torch.load(PARENT,map_location='cpu',weights_only=False),baseline)
    assert computed==state['gates']==done['gates'] and all(computed.values())==done['promotion_passed']
    assert all(torch.equal(v.cpu(),original['model'][name]) for name,v in model.state_dict().items())
    result={'passed':True,'promotion_passed':all(computed.values()),'checkpoint_sha256':sha(HOME/'best.pt'),
        'parent_sha256':bound['readout_parent_checkpoint_sha256'],'all_parameters_and_buffers_unchanged':True,
        'source_metrics_recalculated':True,'geometry_remeasured':True,'readout_forward_exact':True,
        'REBlocks':blocks,'functional_C_output_responses':functional,'T_pair_MSE':state['T_pair_MSE'],
        'gates':computed,'optimization_updates':0,'script_sha256':sha(__file__),'updated_at':now()}
    write_json(HOME/'independent_audit.json',result)
    print(json.dumps({'passed':True,'promotion_passed':result['promotion_passed'],'gates':computed}),flush=True)


if __name__=='__main__':
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    parser=argparse.ArgumentParser();parser.add_argument('--audit',action='store_true');args=parser.parse_args()
    audit() if args.audit else qualify()
