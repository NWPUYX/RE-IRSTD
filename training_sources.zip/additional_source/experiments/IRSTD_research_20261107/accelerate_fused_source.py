"""Run unchanged source-only experiment with the audited decoder helper."""
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
import irstd_adapter
import benchmark_fastdecode as fast
import fused_geometry_source
from irstd_v2.settings import write_json,now


if __name__=='__main__':
    digest=hashlib.sha256((ROOT/'benchmark_fastdecode.py').read_bytes()).hexdigest()
    check=json.loads((HERE/'fastdecode_equivalence.json').read_text(encoding='utf-8'))
    assert check['passed'] and check['source_sha256']==digest
    write_json(fused_geometry_source.HOME/'decoder_execution_manifest.json',{'helper_sha256':digest,
        'equivalence_check':check,'model_loss_selection_thresholds_unchanged':True,'updated_at':now()})
    fast.install();fused_geometry_source.main()
