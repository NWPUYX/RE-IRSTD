"""Check constant-image and brightness-shift behavior of the numerical backends."""
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from integral_evidence_prototype import IntegralEvidence
from irstd.models.relative_evidence import RelativeEvidenceEncoder
from irstd_stable_evidence.model import StableEvidence
from irstd_adapter import model_config
from irstd_v2.settings import write_json,now
from native_unit_prior_evaluation import sha


@torch.inference_mode()
def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;cfg=model_config()['model']['evidence']
    results={}
    for name,model in [('legacy',RelativeEvidenceEncoder(cfg)),('raw_IEEE',StableEvidence(cfg,'raw_IEEE')),('integral64',IntegralEvidence(cfg))]:
        model=model.cuda().eval();rows={}
        for value in [.2,.5,.8]:
            image=torch.full((1,1,512,512),value,device='cuda');z,c=model(image,diagnostics=True)
            rows[str(value)]={'Z_channel_mean':z.mean((0,2,3)).tolist(),'C_channel_mean':c.mean((0,2,3)).tolist(),
                'Z_absolute_max':float(z.abs().max()),'C_absolute_max':float(c.abs().max()),'scale_stats':dict(model.last_stats)}
        generator=torch.Generator(device='cuda').manual_seed(3407);image=torch.rand(1,1,512,512,generator=generator,device='cuda')*.05+.3
        z,c=model(image);zs,cs=model(image+.2)
        results[name]={'constant':rows,'global_additive_shift_Z_MAE':float((z-zs).abs().mean()),
            'global_additive_shift_C_MAE':float((c-cs).abs().mean())}
    write_json(HERE/'evidence_constant_and_shift_audit.json',{'results':results,'optimization_updates':0,'target_frames':0,
        'cudnn_conv_fp32_precision':torch.backends.cudnn.conv.fp32_precision,
        'prototype_sha256':sha(HERE/'integral_evidence_prototype.py'),'script_sha256':sha(__file__),'updated_at':now()})
    print(json.dumps(results),flush=True)


if __name__=='__main__':main()
