"""Verify zero optimization, calibrated source metrics and repaired evidence route."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from stable_evidence_source_calibration import HOME,PARENT,sha,gates
from irstd_stable_evidence.model import StableModel
from irstd_geometry_balance.run import probe
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from evaluation import metrics
from benchmark_center_metrics import center_metrics


def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    done=json.loads((HOME/'source_complete.json').read_text(encoding='utf-8'))
    state=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False);cfg=state['config']
    assert done['optimization_updates']==state['updates']==0 and cfg['zero_extra_training']
    assert split_hashes()==cfg['split_hashes'] and sha(PARENT/'best.pt')==cfg['parent_sha256']
    for name,digest in {**cfg['source_hashes'],**cfg['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
    assert state['model'].keys()==parent['model'].keys()
    assert all(torch.equal(v,parent['model'][n]) for n,v in state['model'].items())
    frames=json.loads((HOME/'best_source_val_predictions.json').read_text(encoding='utf-8'))['frames']
    assert len(frames)==1801 and validation_summary(frames)==state['source_validation']
    threshold=state['source_validation']['threshold']
    for factor in [4,16]:
        f=json.loads((HOME/f'noise{factor}_predictions.json').read_text(encoding='utf-8'))['frames']
        assert len(f)==24 and metrics(f,threshold)==state['noise'][str(factor)]['box']
        assert center_metrics(f,threshold)==state['noise'][str(factor)]['center']
    original_threshold=torch.load(HERE/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)['source_validation']['threshold']
    f=json.loads((HOME/'calibrated_swapped_predictions.json').read_text(encoding='utf-8'))['frames']
    assert metrics(f,original_threshold)==state['background']['swapped_metrics']
    model=StableModel(cfg['recipe']).cuda().eval();model.load_state_dict(state['model'])
    assert sum(p.numel() for p in model.parameters())==808952
    geometry,per_scale=probe(model,cfg['recipe'],cfg['size_reference_512'],torch.device('cuda'))
    assert geometry==state['geometry_probe'] and per_scale==state['per_scale']
    assert torch.backends.cudnn.conv.fp32_precision=='tf32'
    computed=gates(state,parent)
    assert computed==state['gates']==done['gates'] and all(computed.values())==done['promotion_passed']
    result={'passed':True,'promotion_passed':done['promotion_passed'],'checkpoint_sha256':sha(HOME/'best.pt'),
        'optimization_updates':0,'all_tensors_unchanged':True,'evidence_only_IEEE_restore_verified':True,
        'source_metrics_recalculated':True,'geometry_remeasured':True,'gates':computed,'updated_at':now()}
    write_json(HOME/'independent_audit.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
