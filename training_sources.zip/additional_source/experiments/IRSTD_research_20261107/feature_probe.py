"""Source-train group-held-out feature probe; never fit on val/test labels."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import random
import sys
import time
import numpy as np
import torch
from torch.nn import functional as F

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_adapter import targets, model_config
from irstd_v2.model import Model
from irstd_v2.data import Data, render, choose_plan
from irstd_v2.settings import write_json, now

TRAIN_GROUPS={"data10","data13","data14","data16"}
HOLDOUT_GROUPS={"data17","data8","data9"}
SCALES=[.6,1.,1.4]
CHECKPOINT=ROOT / "runs/IRSTD/DAUB-R/seed_3407/best.pt"
CFG_PATH=ROOT / "experiments/IRSTD_v2/v1_geometry_balanced_direction_2epoch_v1/recipe.json"


def fit_predict(x,y,train,alpha=1.):
    # Standardization is fitted only on four training groups, never holdout.
    mu=x[train].mean(0); sd=x[train].std(0).clip(1e-5)
    z=(x-mu)/sd
    ym=y[train].mean(0)
    a=z[train]; b=y[train]-ym
    weights=np.linalg.solve(a.T@a+alpha*np.eye(a.shape[1]),a.T@b)
    return z@weights+ym


@torch.inference_mode()
def main():
    torch.set_num_threads(8); torch.backends.cudnn.benchmark=False
    started=time.perf_counter(); HOME.mkdir(parents=True,exist_ok=True)
    cfg=json.loads(CFG_PATH.read_text(encoding="utf-8"))
    model=Model(cfg).cuda().eval()
    state=torch.load(CHECKPOINT,map_location="cpu",weights_only=False)
    model.load_state_dict(state["model"]); reference=state["config"]["size_reference_512"]
    data=Data("DAUB-R","train",cfg)
    groups=defaultdict(list)
    for i,r in enumerate(data.records): groups[r["group"]].append(i)
    assert set(groups)==TRAIN_GROUPS|HOLDOUT_GROUPS
    # A fixed 1.4x view is infeasible for some border targets under the frozen
    # translation bound. Compare both representations on the same feasible
    # subset, rather than treating an identity fallback as a 1.4x image.
    eligible=defaultdict(list); screened={}
    screen_geometry=dict(cfg["geometry"],maximum_attempts=1)
    for group,indices in sorted(groups.items()):
        for i in indices:
            valid_all=True
            for scale in SCALES:
                p=choose_plan(data.records[i],screen_geometry,random.Random(0),forced_scale=scale,flip_override=False)
                if p["fallback"]: valid_all=False; break
            if valid_all: eligible[group].append(i)
        screened[group]={"total":len(indices),"eligible":len(eligible[group])}
        assert len(eligible[group])>=12
    ids=[indices[j] for group,indices in sorted(eligible.items()) for j in np.linspace(0,len(indices)-1,12,dtype=int)]
    captured={}
    def capture(module,inputs,output): captured.update(fused=output[0],T=output[1])
    hook=model.backbone.register_forward_hook(capture)
    features={"T":[],"fused":[]}; labels=[]; metadata=[]
    for j,i in enumerate(ids):
        record=data.records[i]
        for scale in SCALES:
            seed=int.from_bytes(hashlib.sha256(f"train_probe/{record['id']}/{scale}".encode()).digest()[:8],"little")
            plan=choose_plan(record,cfg["geometry"],random.Random(seed),forced_scale=scale,flip_override=False)
            assert not plan["fallback"]
            image,boxes,valid=render(record,plan)
            sample={**data.base_sample(i),"image":image,"boxes":boxes,"valid_mask":valid,"ignore_mask":~valid}
            target=targets([sample],model_config(),reference,torch.device("cuda"),"shared_regression")
            model(image[None].cuda(),valid_mask=valid[None].cuda())
            for name,values in features.items():
                padded=F.pad(captured[name],(1,1,1,1))
                for b,x,y in target["anchors"].cpu().tolist():
                    values.append(padded[b,:,y:y+3,x:x+3].flatten().cpu().numpy())
            labels.extend(target["sizes"].cpu().numpy())
            metadata.extend({"group":record["group"],"record_index":i,"scale":scale,"split":"source_train"} for _ in target["anchors"])
            captured.clear()
        if j%12==0:
            write_json(HOME / "feature_probe_progress.json",{"records":j+1,"total_records":len(ids),"updated_at":now()})
    hook.remove()
    y=np.asarray(labels,dtype=np.float64)
    train=np.array([r["group"] in TRAIN_GROUPS for r in metadata])
    hold=~train
    predictions={"constant_reference":np.zeros_like(y)}
    for name,values in features.items(): predictions[name]=fit_predict(np.asarray(values,dtype=np.float64),y,train)
    results={}
    for name,pred in predictions.items():
        row={"overall_MAE":float(np.abs(pred[hold]-y[hold]).mean()),"by_scale":{},"by_group":{}}
        for scale in SCALES:
            use=hold&np.array([r["scale"]==scale for r in metadata])
            row["by_scale"][str(scale)]=float(np.abs(pred[use]-y[use]).mean())
        for group in sorted(HOLDOUT_GROUPS):
            use=np.array([r["group"]==group for r in metadata])
            row["by_group"][group]=float(np.abs(pred[use]-y[use]).mean())
        results[name]=row
    decision=results["T"]["overall_MAE"]<results["fused"]["overall_MAE"] and results["T"]["by_scale"]["1.4"]<results["fused"]["by_scale"]["1.4"]
    output={"scope":"Source-train feature probe only; not detector validation or target score",
        "train_groups":sorted(TRAIN_GROUPS),"holdout_training_groups":sorted(HOLDOUT_GROUPS),
        "records":len(ids),"views":len(metadata),"scales":SCALES,"train_targets":int(train.sum()),"holdout_targets":int(hold.sum()),
        "fixed_scale_feasibility_screen":screened,"limitation":"Fixed-scale feasible subset only; border-infeasible records not represented in this diagnostic",
        "probe":"standardized 3x3 features; ridge alpha=1 fixed before fitting; two log-size outputs",
        "checkpoint_sha256":hashlib.sha256(CHECKPOINT.read_bytes()).hexdigest(),"results":results,
        "T_route_screen_passed":bool(decision),"elapsed_seconds":time.perf_counter()-started,"updated_at":now()}
    np.savez_compressed(HOME / "feature_probe_arrays.npz",T=np.asarray(features["T"]),fused=np.asarray(features["fused"]),y=y,train=train)
    write_json(HOME / "feature_probe_metadata.json",metadata)
    write_json(HOME / "feature_probe.json",output)
    print(json.dumps(output,indent=2),flush=True)


if __name__=="__main__": main()
