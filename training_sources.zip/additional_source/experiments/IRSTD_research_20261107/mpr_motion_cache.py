"""Matched-causal MPR motion maps; all neighbors remain inside frozen splits."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import sys
import time
import numpy as np
from PIL import Image

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path[:0]=[str(ROOT/"vendor_sota"),str(ROOT/"repositories/MPR-Net"),str(ROOT)]
CACHE=ROOT/"motion_cache/MPR_causal_matched_v2"


def worker(job):
    import cv2
    import torch
    from data_pipeline import load_frame
    from motion_diff.explicit_motion_modeling import EMMConfig, motion_prior_three_frames, motion_prior_to_uint8
    cv2.setNumThreads(1); cv2.setRNGSeed(3407); torch.set_num_threads(1)
    destination,paths,index=job
    out=Path(destination)
    if out.exists():
        with Image.open(out) as existing: assert existing.size==(512,512)
        return index,"cached"
    frames=[cv2.cvtColor(load_frame(p)[0],cv2.COLOR_RGB2GRAY) for p in paths]
    # This is explicitly a causal protocol adaptation: neighbors t-2 and t-1,
    # rather than the future frame used by the author's original EMM.
    prior,*_=motion_prior_three_frames(frames[0],frames[1],frames[2],EMMConfig())
    out.parent.mkdir(parents=True,exist_ok=True)
    temp=out.with_suffix(".tmp")
    Image.fromarray(motion_prior_to_uint8(prior)).save(temp,format="PNG",compress_level=1)
    temp.replace(out)
    return index,"created"


def main():
    p=argparse.ArgumentParser(); p.add_argument("--source",default="DAUB-R"); p.add_argument("--split",default="train",choices=["train","val","test"])
    p.add_argument("--limit",type=int,default=0); p.add_argument("--workers",type=int,default=2)
    args=p.parse_args(); assert args.source in ["DAUB-R","IRDST-H","IRSTD-UAV","ITSDT-15K"]
    path=ROOT/"splits"/f"{args.source}_{args.split}.json"; records=json.loads(path.read_text(encoding="utf-8"))
    groups={}; jobs=[]; windows=[]
    for i,r in enumerate(records): groups.setdefault(r["group"],[]).append(i)
    for group,ids in groups.items():
        start=0
        for pos,i in enumerate(ids):
            def number(k): return int(re.findall(r"\d+",Path(records[k]["path"]).stem)[-1])
            if pos and number(i)!=number(ids[pos-1])+1: start=pos
            a=ids[max(start,pos-2)]; b=ids[max(start,pos-1)]
            assert a<=i and b<=i and records[a]["group"]==group==records[b]["group"]
            dest=CACHE/args.source/args.split/f"{i:06d}.png"
            jobs.append((str(dest),[records[a]["path"],records[i]["path"],records[b]["path"]],i))
            assert jobs[-1][1][1]==records[i]["path"]
            windows.append({"index":i,"older":a,"previous":b,"group":group})
    folder=CACHE/args.source/args.split; folder.mkdir(parents=True,exist_ok=True)
    spec={"source":args.source,"split":args.split,"split_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
        "EMM_source_sha256":hashlib.sha256((ROOT/"repositories/MPR-Net/motion_diff/explicit_motion_modeling.py").read_bytes()).hexdigest(),
        "generator_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "motion_recipe":"EMMConfig defaults frozen across all domains; letterbox512 before EMM; two causal past neighbors",
        "future_frames_used":False,"record_count":len(records),"windows":windows}
    from data_pipeline import VideoData
    official_windows=VideoData(args.source,args.split,"MPR-Net").windows
    assert all([r["older"],r["previous"],r["index"]]==official_windows[r["index"]][-3:] for r in windows)
    manifest=folder/"manifest.json"
    if manifest.exists(): assert json.loads(manifest.read_text(encoding="utf-8"))==spec
    else: manifest.write_text(json.dumps(spec),encoding="utf-8")
    if args.limit: jobs=jobs[:args.limit]
    started=time.perf_counter(); n=0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for index,status in pool.map(worker,jobs,chunksize=1):
            n+=1
            if n%32==0 or n==len(jobs):
                row={"source":args.source,"split":args.split,"completed":n,"requested":len(jobs),
                    "elapsed_seconds":time.perf_counter()-started,"complete_full_split":n==len(records)}
                (folder/"progress.json").write_text(json.dumps(row),encoding="utf-8"); print(json.dumps(row),flush=True)


if __name__=="__main__": main()
