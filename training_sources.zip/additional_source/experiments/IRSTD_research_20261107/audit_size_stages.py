"""Independent, CPU-only verification of completed size-only experiments."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def audit(home):
    assert (home/'training_complete.json').exists(),'Stage still running'
    cfg=json.loads((home/'config.json').read_text(encoding='utf-8'))
    assert cfg['split_hashes']==split_hashes()
    for name,digest in cfg['source_hashes'].items(): assert sha(ROOT.parent/name)==digest,name
    initial=Path(cfg['initial_checkpoint'])
    assert sha(initial)==cfg.get('parent_checkpoint_sha256',cfg.get('checkpoint_sha256'))
    parent=torch.load(initial,map_location='cpu',weights_only=False)
    last=torch.load(home/'last.pt',map_location='cpu',weights_only=False)
    best=torch.load(home/'best.pt',map_location='cpu',weights_only=False)
    # T-route changes feature routing, not tensors outside the size head.
    frozen=[n for n in parent['model'] if not n.startswith('heads.size.')]
    for states in (last['model'],last['ema'],best['model']):
        for n in frozen: assert torch.equal(states[n],parent['model'][n]),n
    assert len(last['optimizer']['state'])==4
    assert all(int(v['step'])==last['updates'] for v in last['optimizer']['state'].values())
    all_ids=[i for g in last['optimizer']['param_groups'] for i in g['params']]
    assert len(all_ids)==len(set(all_ids))==4
    assert all(torch.isfinite(v).all() for v in last['model'].values() if v.is_floating_point())
    frames=json.loads((home/'best_source_val_predictions.json').read_text(encoding='utf-8'))['frames']
    recalculated=validation_summary(frames)
    assert recalculated==best['source_validation'],'Cached metrics mismatch'
    history=[json.loads(s) for s in (home/'history.jsonl').read_text(encoding='utf-8').splitlines()]
    assert len({r['epoch'] for r in history})==len(history)
    done=json.loads((home/'training_complete.json').read_text(encoding='utf-8'))
    assert done['updates']==last['updates'] and done['best_epoch']==best['epoch']
    result={'passed':True,'frozen_tensor_count':len(frozen),'optimizer_tensor_count':4,
        'updates':last['updates'],'best_epoch':best['epoch'],'source_metrics_recalculated_exactly':True,
        'best_checkpoint_sha256':sha(home/'best.pt'),'split_and_source_hashes_verified':True,
        'finite_parameters':True,'scope':'CPU integrity audit, not independent performance replication','updated_at':now()}
    write_json(home/'independent_audit.json',result)
    print(json.dumps({'stage':home.name,**result}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stages',nargs='+');a=p.parse_args()
    torch.set_num_threads(2)
    for stage in a.stages: audit(HERE/stage)
