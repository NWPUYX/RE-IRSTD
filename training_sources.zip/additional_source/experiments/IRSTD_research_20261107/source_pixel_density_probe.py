"""Same source mosaic field, two pixel densities, no target inference."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import sys
import time
import numpy as np
from PIL import Image
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from source_mosaic_probe import Probe,build,sha,source_statistics,PopulationTModel
from irstd_v2.data import original_boxes
from irstd.inference.decoder import decode
from irstd_v2.settings import write_json,now,split_hashes
from evaluation import postprocess,match_frame,metrics
import benchmark_fastdecode as fast

HOME=HERE/'source_pixel_density_probe_v1'


@torch.inference_mode()
def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    config={'script_sha256':sha(__file__),'plan_sha256':sha(HERE/'源像素密度诊断方案.md'),
        'subset_sha256':sha(HERE/'wide_scale_source_probe.json'),'split_hashes':split_hashes(),
        'source_val_only':True,'optimization_updates':0,'target_frames':0,'batch':1,'resolutions':[512,1024]}
    write_json(HOME/'config.json',config);results={};stats=source_statistics()
    for name in ['robust','population']:
        if name=='robust':model,state,recipe,checkpoint=build('irstd_robust')
        else:
            checkpoint=HERE/'population_T_sourceAP_control_v1/best.pt';state=torch.load(checkpoint,map_location='cpu',weights_only=False)
            recipe=state['config']['recipe'];model=PopulationTModel(recipe).cuda().eval();model.load_state_dict(state['model']);model.set_mode(final=False)
        digest=sha(checkpoint);dataset=Probe(recipe);rows={}
        for _,indices in [row for row in dataset.rows if row[0]==2]:
            canvas=Image.new('RGB',(512,512));boxes=[]
            for slot,index in enumerate(indices):
                record=dataset.base.records[index]
                with Image.open(record['path']) as image:canvas.paste(image.convert('RGB'),((slot%2)*256,(slot//2)*256))
                boxes.append(original_boxes(record)+torch.tensor([(slot%2)*256,(slot//2)*256]*2))
            boxes=torch.cat(boxes);xywh=boxes.clone();xywh[:,2:]-=xywh[:,:2]
            record={'width':512,'height':512,'boxes':xywh.tolist(),'group':str(indices[0])}
            assert len(boxes)==4 and dataset.base.split=='source_val'
            for side in [512,1024]:
                factor=side/512;image=torch.from_numpy(np.array(canvas.resize((side,side),Image.Resampling.BICUBIC).convert('L'),dtype=np.float32)/255.)[None,None].cuda()
                torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();started=time.perf_counter();out=model(image)
                proposals=decode(out,1e-5,{'box_nms_iou':None},stats['input_median'])[0]
                center,score=proposals['centers'].cuda(),proposals['scores'].cuda();q=center.floor().long()
                value=out['log_size'][0,:,q[:,1],q[:,0]].T.float();ref=value.new_tensor(stats['input_median'])
                wh=ref*torch.minimum(value.clamp_min(-20),(value.new_tensor([side,side])/ref).log()).exp()
                raw=torch.cat((center,wh,score[:,None],torch.ones_like(score[:,None])),1)
                row=rows.setdefault(str(side),{'learned':[],'known_source_size':[],'seconds':[],'peak_allocated_bytes':[]})
                for rule in ['learned','known_source_size']:
                    candidate=raw.clone()
                    if rule=='known_source_size':candidate[:,2:4]=candidate.new_tensor(stats['native_median'])*factor
                    row[rule].append(match_frame(postprocess(candidate,record,(factor,factor,0,0)),record))
                torch.cuda.synchronize();row['seconds'].append(time.perf_counter()-started);row['peak_allocated_bytes'].append(torch.cuda.max_memory_allocated())
                del out,image,raw,proposals
        assert all(torch.equal(v.cpu(),state['model'][k]) for k,v in model.state_dict().items()) and sha(checkpoint)==digest
        threshold=state['source_validation']['threshold']
        results[name]={'checkpoint_sha256':digest,'all_tensors_unchanged':True,'threshold':threshold,
            'results':{side:{**{rule:metrics(row[rule],threshold) for rule in ['learned','known_source_size']},
                'mean_seconds':float(np.mean(row['seconds'])),'max_allocated_bytes':max(row['peak_allocated_bytes'])} for side,row in rows.items()}}
        del model;torch.cuda.empty_cache()
    write_json(HOME/'result.json',{'status':'completed','results':results,'target_frames':0,'optimization_updates':0,'updated_at':now()})
    print(json.dumps(results),flush=True)


if __name__=='__main__':main()
