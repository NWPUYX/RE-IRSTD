"""Compare fixed evidence statistics to a float64 reference; source/synthetic only."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_adapter import model_config
from irstd.models.relative_evidence import RelativeEvidenceEncoder
from irstd_v2.data import Data
from irstd_v2.settings import write_json,now
import benchmark_fastdecode as fast


def reference(image,encoder):
    cv2=fast.cv2;x=image[0,0].cpu().numpy().astype(np.float64);means=[];scales=[];signed=[]
    for i in range(3):
        kernel=getattr(encoder,f'kernel_{i}')[0,0].cpu().double().numpy();kernel/=kernel.sum()
        mean=cv2.filter2D(x,cv2.CV_64F,kernel,borderType=cv2.BORDER_REFLECT_101)
        variance=np.maximum(cv2.filter2D(x*x,cv2.CV_64F,kernel,borderType=cv2.BORDER_REFLECT_101)-mean*mean,0)
        sigma=np.sqrt(variance+encoder.floor**2);means.append(mean);scales.append(sigma);signed.append(np.clip((x-mean)/sigma,-encoder.clip,encoder.clip))
    z=np.stack(signed);z=np.concatenate((z,np.abs(z)),axis=0)
    gx=cv2.filter2D(means[2],cv2.CV_64F,np.array([[-.5,0,.5]]),borderType=cv2.BORDER_REFLECT_101)/scales[2]
    gy=cv2.filter2D(means[2],cv2.CV_64F,np.array([[-.5],[0],[.5]]),borderType=cv2.BORDER_REFLECT_101)/scales[2]
    c=np.clip(np.stack([gx,gy,np.log(scales[0]/scales[2]),np.log(scales[1]/scales[2])]),-encoder.clip,encoder.clip)
    return z,c


@torch.inference_mode()
def main():
    torch.set_num_threads(3);fast.cv2.setNumThreads(1);torch.backends.cudnn.benchmark=False
    parent=HERE/'background_center_interpolation_refine_v1/best.pt';state=torch.load(parent,map_location='cpu',weights_only=False)
    data=Data('DAUB-R','train',state['config']['recipe']);groups=defaultdict(list)
    for i,r in enumerate(data.records):groups[r['group']].append(i)
    samples=[]
    for group,ids in list(sorted(groups.items()))[:4]:
        i=ids[len(ids)//2];sample=data.base_sample(i);box=sample['boxes'][0];qx,qy=((box[:2]+box[2:])/2).floor().long().tolist()
        x0=min(max(0,qx-64),384);y0=min(max(0,qy-64),384)
        samples.append((f'{group}/{data.records[i]["id"]}',sample['image'][:,y0:y0+128,x0:x0+128][None]))
    generator=torch.Generator().manual_seed(3407)
    yy,xx=torch.meshgrid(torch.arange(128),torch.arange(128),indexing='ij');spot=torch.exp(-((xx-64).square()+(yy-64).square())/(2*1.2**2))
    for sigma in [.0005,.004]:
        image=.8+sigma*torch.randn(128,128,generator=generator)+.01*spot
        samples.append((f'synthetic_noise{sigma}',image[None,None]))
    encoder=RelativeEvidenceEncoder(model_config()['model']['evidence']).cuda().eval();rows=[];drift=[]
    modes=[('raw_default',True,False),('raw_IEEE',False,False),('centered_default',True,True),('centered_IEEE',False,True)]
    for name,sample in samples:
        base=sample*.8+.1;captured={};refs={}
        for shift in [0.,.05,-.05]:
            image=(base+shift).cuda();assert float(image.min())>0 and float(image.max())<1
            rz,rc=reference(image,encoder);refs[shift]=(rz,rc)
            for mode,tf32,center in modes:
                torch.backends.cudnn.allow_tf32=tf32
                value=image-image.mean((-2,-1),keepdim=True) if center else image
                z,c=encoder(value);z=z[0].cpu().numpy().astype(np.float64);c=c[0].cpu().numpy().astype(np.float64)
                captured[(mode,shift)]=(z,c);delta=np.abs(z-rz);cd=np.abs(c-rc)
                rows.append({'sample':name,'shift':shift,'mode':mode,'Z_MAE_to_FP64':float(delta.mean()),
                    'Z_p99_error':float(np.quantile(delta,.99)),'Z_max_error':float(delta.max()),'C_MAE_to_FP64':float(cd.mean())})
        for mode,_,_ in modes:
            for shift in [.05,-.05]:
                a,b=captured[(mode,0.)],captured[(mode,shift)]
                drift.append({'sample':name,'mode':mode,'shift':shift,'Z_shift_MAE':float(np.abs(a[0]-b[0]).mean()),
                    'C_shift_MAE':float(np.abs(a[1]-b[1]).mean()),'FP64_Z_shift_MAE':float(np.abs(refs[0.][0]-refs[shift][0]).mean())})
    summary={mode:{key:float(np.mean([r[key] for r in rows if r['mode']==mode])) for key in ['Z_MAE_to_FP64','Z_p99_error','C_MAE_to_FP64']} for mode,_,_ in modes}
    report={'scope':'four source-train GT crops and two synthetic crops; evidence arithmetic only, not detector validation or target test',
        'reference':'float64 OpenCV correlation, true unit-sum annular kernels, same reflect101/floor/clip',
        'input_transform':'0.8*source_or_synthetic +0.1, then brightness shifts +/-0.05; no clipping',
        'original_tf32_default':True,'rows':rows,'brightness_drift':drift,'summary':summary,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'updated_at':now()}
    write_json(HERE/'evidence_numeric_probe.json',report);print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
