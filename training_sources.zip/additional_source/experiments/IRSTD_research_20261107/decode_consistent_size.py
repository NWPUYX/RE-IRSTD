"""Continue the IRDST diagnostic with decoder-consistent frozen centers."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import traceback
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
import fused_geometry_source as prior
from irstd_adapter import targets,model_config
from irstd.data.targets import gather_centers
from irstd.losses.detection import detection_losses
from irstd_v2.losses import giou_pairs
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.data import make_loader
from irstd_geometry_balance.data import training_loader
from irstd_v2.train import save_checkpoint,rng_state,restore_rng
from irstd_v2.settings import write_json,now,split_hashes
from irstd_t_size.model import optimizer
import benchmark_fastdecode as fast

PARENT=HERE/'IRDST_fused_size_w4_v1'
HOME=HERE/'IRDST_decode_consistent_size_v1'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def loss_for(model,images,samples,reference,cfg,device):
    t=targets(samples,model_config(),reference,device,'shared_regression')
    valid=torch.stack([s['valid_mask'] for s in samples]).to(device);out=model(images.to(device),valid_mask=valid)
    w=images.new_tensor([4. if s['view_type']=='native' else 1. for s in samples]).to(device)
    denominator=max(sum(float(w[i])*len(s['boxes']) for i,s in enumerate(samples)),1.)
    terms=detection_losses(out,t,model_config()['loss'],w,{'images':float(w.sum()),'targets':denominator,'boxes':denominator})
    anchors=t['anchors'];flags=t['has_box'];q=anchors[:,1:].float()
    # Same bound and offset operations as the deployed decoder; retain the
    # existing unconstrained SmoothL1 size supervision separately.
    offset=gather_centers(out['offsets'].float(),anchors).clamp(0,1-1e-6)
    bounds=q.new_tensor([images.shape[-1],images.shape[-2]])
    center=torch.minimum(q+offset,torch.nextafter(bounds,torch.zeros_like(bounds)))
    raw=gather_centers(out['log_size'].float(),anchors);ref=raw.new_tensor(reference)
    wh=ref*torch.minimum(raw.clamp_min(-20),(bounds/ref).log()).exp()
    gtcenter=q+t['offsets'];gtwh=t['sizes'].exp()*ref
    predicted=torch.cat([center-wh/2,center+wh/2],1)[flags]
    truth=torch.cat([gtcenter-gtwh/2,gtcenter+gtwh/2],1)[flags]
    giou=((1-giou_pairs(predicted,truth))*w[anchors[flags,0]]).sum()/denominator
    loss=model_config()['loss']['size_weight']*terms['size']+cfg['giou_weight']*giou
    assert torch.isfinite(loss)
    return loss,{'size':float(terms['size'].detach()),'giou':float(giou.detach())}


def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;device=torch.device('cuda')
    fast_check=json.loads((HERE/'fastdecode_equivalence.json').read_text(encoding='utf-8'))
    assert fast_check['passed'] and fast_check['source_sha256']==sha(ROOT/'benchmark_fastdecode.py');fast.install()
    start=PARENT/'last.pt';s=torch.load(start,map_location='cpu',weights_only=False)
    assert s['next_epoch']==1,'Continue exactly after diagnostic epoch1'
    cfg=s['config']['recipe'];base=json.loads((PARENT/'baseline.json').read_text(encoding='utf-8'))
    spec=json.loads((PARENT/'probe_spec.json').read_text(encoding='utf-8'));reference=s['config']['size_reference_512']
    assert split_hashes()==s['config']['split_hashes']
    for name,digest in s['config']['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
    config={**s['config'],'initial_checkpoint':str(start),'parent_sha256':sha(start),
        'repair':'Frozen offset clamped identically to decoder in GIoU; log-size decode bounds match inference',
        'additional_epochs':2,'parent_epochs':1,'source_hashes':{**s['config']['source_hashes'],
            str(Path(__file__).relative_to(ROOT.parent)):sha(__file__),str((ROOT/'benchmark_fastdecode.py').relative_to(ROOT.parent)):sha(ROOT/'benchmark_fastdecode.py')}}
    assert not (HOME/'config.json').exists(),'New isolated experiment required'
    write_json(HOME/'config.json',config);write_json(HOME/'baseline.json',base);write_json(HOME/'probe_spec.json',spec)
    write_json(HOME/'process.json',{'pid':os.getpid(),'updated_at':now()})
    model=prior.construct(cfg,s['model'],device);opt=optimizer(model,cfg);opt.load_state_dict(s['optimizer'])
    ema=copy.deepcopy(model).eval();ema.load_state_dict(s['ema'])
    for p in ema.parameters():p.requires_grad_(False)
    initial=s['model'];updates=s['updates'];assert updates==2087 and all(int(v['step'])==updates for v in opt.state.values())
    train=training_loader(prior.SOURCE,cfg,prior.SEED);val=make_loader(prior.SOURCE,'val',cfg)
    # Independent smoke update on a copy, then exact raw/EMA/optimizer/RNG reset.
    restore_rng(s['rng']);train.dataset.epoch=2;images,samples=next(iter(train))
    opt.zero_grad(set_to_none=True);loss,_=loss_for(model,images,samples,reference,cfg,device);loss.backward()
    assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith('heads.size.'))
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.heads.size.parameters())
    torch.nn.utils.clip_grad_norm_(model.heads.size.parameters(),10.,error_if_nonfinite=True);opt.step();prior.frozen(model,initial)
    model.load_state_dict(s['model']);opt.load_state_dict(s['optimizer']);opt.zero_grad(set_to_none=True);restore_rng(s['rng'])
    write_json(HOME/'preflight.json',{'passed':True,'parent_updates':updates,'optimizer_EMA_RNG_continued':True,'only_size_head_gradients':True,'updated_at':now()})
    parent_row=json.loads((PARENT/'history.jsonl').read_text(encoding='utf-8').splitlines()[-1]);best_key=prior.key(parent_row,base)
    save_checkpoint(HOME/'best.pt',{**parent_row,'model':ema.state_dict(),'config':config})
    started=time.perf_counter()
    try:
        for epoch in range(1,3):
            train.dataset.epoch=epoch+1;counts=Counter();tick=time.perf_counter()
            for j,(images,samples) in enumerate(train):
                model.eval();model.heads.size.train();opt.zero_grad(set_to_none=True)
                loss,_=loss_for(model,images,samples,reference,cfg,device);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.heads.size.parameters(),10.,error_if_nonfinite=True);opt.step();updates+=1
                decay=.9999*(1-math.exp(-updates/2000))
                with torch.no_grad():
                    for a,b in zip(ema.heads.size.parameters(),model.heads.size.parameters()):a.mul_(decay).add_(b,alpha=1-decay)
                for sample in samples:counts[sample['view_type']]+=1
                if j%100==0:
                    r={'status':'training','epoch':epoch+1,'batch':j+1,'total_batches':len(train),'updates':updates,'updated_at':now()}
                    write_json(HOME/'progress.json',r);print(json.dumps(r),flush=True)
            prior.frozen(model,initial);prior.frozen(ema,initial);assert sum(counts.values())==8345
            train_seconds=time.perf_counter()-tick;write_json(HOME/'progress.json',{'status':'source_validation','epoch':epoch+1,'updated_at':now()})
            frames=evaluate(ema,val,device,reference,HOME/f'epoch_{epoch+1:02d}_predictions.json')
            row={'epoch':epoch+1,'updates':updates,'validation':validation_summary(frames),'geometry':prior.probe(ema,cfg,reference,device,spec),
                'views':dict(counts),'train_seconds':train_seconds,'elapsed_seconds':time.perf_counter()-started}
            row['gates']=prior.gates(row,base);checkpoint={**row,'model':ema.state_dict(),'config':config}
            for name,digest in config['source_hashes'].items():assert sha(ROOT.parent/name)==digest,name
            save_checkpoint(HOME/f'epoch_{epoch+1:02d}_ema.pt',checkpoint)
            if prior.key(row,base)>best_key:best_key=prior.key(row,base);save_checkpoint(HOME/'best.pt',checkpoint)
            save_checkpoint(HOME/'last.pt',{'model':model.state_dict(),'ema':ema.state_dict(),'optimizer':opt.state_dict(),'config':config,
                'updates':updates,'next_epoch':epoch+1,'rng':rng_state(),'elapsed_seconds':row['elapsed_seconds']})
            with (HOME/'history.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
            print(json.dumps({'epoch':epoch+1,'gates':row['gates'],'geometry':row['geometry']}),flush=True)
            if all(row['gates'].values()):break
        best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
        done={'status':'completed','best_epoch':best['epoch'],'epochs_run':epoch+1,'updates':updates,
            'promotion_passed':all(prior.gates(best,base).values()),'gates':prior.gates(best,base),'target_test_cells':0,'updated_at':now()}
        write_json(HOME/'training_complete.json',done);write_json(HOME/'progress.json',done)
    except Exception:write_json(HOME/'failure.json',{'traceback':traceback.format_exc(),'updated_at':now()});raise


if __name__=='__main__':main()
