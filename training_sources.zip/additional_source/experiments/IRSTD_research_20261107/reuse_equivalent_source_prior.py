"""Reuse only partitions where input/native prior predictions are identical."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_v2.settings import write_json,now


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    source=HERE/'native_unit_irstd_robust_native_constant_v1'
    target=HERE/'native_unit_irstd_robust_input_constant_v1';target.mkdir(exist_ok=True)
    cfg=json.loads((source/'config.json').read_text(encoding='utf-8'));stats=cfg['source_statistics'];proof={}
    assert cfg['model']=='irstd_robust' and cfg['prior']=='native_constant'
    for split in ['val','test']:
        path=ROOT/f'splits/DAUB-R_{split}.json';records=json.loads(path.read_text(encoding='utf-8'))
        for r in records:
            ratio=min(512/r['width'],512/r['height']);scale=[int(r['width']*ratio)/r['width'],int(r['height']*ratio)/r['height']]
            np.testing.assert_array_equal(np.asarray(stats['native_median'])*scale,stats['input_median'])
        proof[split]={'frames':len(records),'split_sha256':sha(path),'all_prior_width_heights_exactly_equal':True}
    prior=source/'source_val_predictions.json';destination=target/prior.name
    if destination.exists():assert sha(destination)==sha(prior)
    else:shutil.copyfile(prior,destination)
    folder=target/'frozen_four_domain_test';folder.mkdir(exist_ok=True)
    src=source/'frozen_four_domain_test';prior=src/'DAUB-R_predictions.json';destination=folder/prior.name
    if destination.exists():assert sha(destination)==sha(prior)
    else:shutil.copyfile(prior,destination)
    metric=json.loads((src/'DAUB-R_metrics.json').read_text(encoding='utf-8'))
    write_json(folder/'DAUB-R_metrics.json',{**metric,'elapsed_seconds':0.,
        'cache_reuse':{'from':str(src),'reason':'same checkpoint/centers/scores and exactly identical per-image input widths/heights',
            'input_predictions_sha256':sha(prior)},'updated_at':now()})
    write_json(target/'source_cache_equivalence.json',{'passed':True,'checkpoint_sha256':cfg['checkpoint_sha256'],
        'source_predictions_sha256':sha(source/'source_val_predictions.json'),'partitions':proof,
        'source_prior':stats,'no_target_labels_used_for_equivalence':True,'updated_at':now()})
    print(json.dumps({'passed':True,'reused_source_frames':1801,'reused_native_test_frames':4277}),flush=True)


if __name__=='__main__':main()
