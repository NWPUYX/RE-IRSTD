"""Source-only zero-training review with unchanged pixels embedded in a canvas."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.nn import functional as F

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from p3_source_only import P3Route
from irstd_v2.data import Data
from irstd_v2.settings import write_json,now
from irstd_v2.train import save_checkpoint

HOME=HERE/'P3_padding_review_v1'
P3=HERE/'P3_zero_training_source_v1'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


@torch.inference_mode()
def main():
    assert (P3/'source_complete.json').exists()
    assert not (HOME/'source_complete.json').exists()
    HOME.mkdir(exist_ok=True);torch.set_num_threads(3);torch.backends.cudnn.benchmark=False
    # This is a new source-only criterion, recorded before its computation.
    write_json(HOME/'plan.json',{'scope':'new exploratory source-only padding review; no P3 target results used',
        'canvas':'unchanged512 image embedded centrally in768 square, fill128/255, known valid mask',
        'data':'four evenly spaced source_train records per acquisition group, fixed',
        'selection':'existing native and scale guards plus GT-logit padding MSE<=80percent parent; minimum padding MSE',
        'training_updates':0,'source_parent':str(P3),'updated_at':now()})
    parent=torch.load(HERE/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)
    cfg=parent['config']['recipe'];data=Data('DAUB-R','train',cfg);groups={}
    for i,r in enumerate(data.records):groups.setdefault(r['group'],[]).append(i)
    ids=[items[j] for items in groups.values() for j in np.linspace(0,len(items)-1,4,dtype=int)]
    candidates=[('parent',parent)]+[(name,torch.load(P3/name/'candidate.pt',map_location='cpu',weights_only=False))
        for name in ['valid_evidence','masked_GN','valid_evidence_and_masked_GN']]
    results={};selected=None;best=None;parent_mse=None
    for name,state in candidates:
        recipe=state['config']['recipe'];model=P3Route(recipe).cuda().eval();model.load_state_dict(state['model'])
        for p in model.parameters():p.requires_grad_(False)
        records=[];write_json(HOME/'progress.json',{'status':'source_padding_review','variant':name,'updated_at':now()})
        for i in ids:
            sample=data.base_sample(i);image=sample['image'][None].cuda();mask=sample['valid_mask'][None].cuda()
            native=model(image,valid_mask=mask)
            canvas=F.pad(image,(128,128,128,128),value=128/255);valid=F.pad(mask,(128,128,128,128),value=False)
            padded=model(canvas,valid_mask=valid)
            for box in sample['boxes']:
                qx,qy=((box[:2]+box[2:])/2).floor().long().tolist()
                a=float(native['center_logits'][0,0,qy,qx]);b=float(padded['center_logits'][0,0,qy+128,qx+128])
                records.append({'record_index':i,'group':data.records[i]['group'],'native_logit':a,'padded_logit':b,
                    'squared_logit_difference':(a-b)**2,
                    'log_size_absolute_difference':float((native['log_size'][0,:,qy,qx]-padded['log_size'][0,:,qy+128,qx+128]).abs().mean())})
        mse=float(np.mean([r['squared_logit_difference'] for r in records]));row={'GT_logit_padding_MSE':mse,'targets':len(records),'rows':records}
        if name=='parent':parent_mse=mse
        else:
            eligible=state['gates']['all_quality'] and mse<=parent_mse*.8
            row['source_and_padding_passed']=eligible
            if eligible and (best is None or mse<best):best=mse;selected=name
        results[name]=row;print(json.dumps({'variant':name,'GT_logit_padding_MSE':mse,'source_and_padding_passed':row.get('source_and_padding_passed')}),flush=True)
        del model
    if selected:
        state=torch.load(P3/selected/'candidate.pt',map_location='cpu',weights_only=False)
        state['config']=copy.deepcopy(state['config']);state['config']['source_hashes'][str(Path(__file__).relative_to(ROOT.parent))]=sha(__file__)
        state['padding_source_review']=results[selected];save_checkpoint(HOME/'best.pt',state)
        write_json(HOME/'config.json',state['config'])
        import shutil
        shutil.copyfile(P3/selected/'source_predictions.json',HOME/'best_source_val_predictions.json')
    report={'status':'completed_zero_training','selected_variant':selected,'promotion_passed':selected is not None,
        'training_updates':0,'target_test_cells':0,'results':results,'updated_at':now()}
    write_json(HOME/'source_complete.json',report);write_json(HOME/'progress.json',report)


if __name__=='__main__':main()
