"""Read-only head-gradient conflict probe; detached features, never optimizer steps."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
from collections import defaultdict
import json
from pathlib import Path
import random
import sys
import numpy as np
import torch
from torch.nn import functional as F

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from peak_calibrated_model import PeakCalibratedModel
from irstd_population_t.model import PopulationTModel
from irstd_v2.data import Data
from irstd_scene_scale.data import mosaic
from irstd_background_center.data import union_swap
from classification_feature_probe import views
from irstd_adapter import targets,model_config
from irstd.losses.detection import center_loss
from irstd_robust_t.run import sha
from irstd_v2.settings import write_json,now,split_hashes

HOME=HERE/'source_head_gradient_diagnostic_v1'
CHECKPOINT=HERE/'peak_calibrated_v1/epoch_01_ema.pt'


def teacher(path):
    state=torch.load(path,map_location='cpu',weights_only=False)
    model=PopulationTModel(state['config']['recipe']).cuda().eval();model.load_state_dict(state['model']);model.set_mode(final=False)
    for p in model.parameters():p.requires_grad_(False)
    return model


def preserved(student,raw_main,fixed,t,spatial):
    pieces=[]
    for _,x,y in t['anchors'].tolist():
        ys=slice(max(y-3,0),min(y+4,512));xs=slice(max(x-3,0),min(x+4,512))
        a=student[0,0,ys,xs];b=fixed[0,0,ys,xs]
        pieces.append(.5*(a.max()-b.max()).square()+.1*((a-a.max())-(b-b.max())).square().mean())
        if spatial:
            a=raw_main[0,0,ys,xs].flatten()/.5;b=b.flatten()/.5
            pieces[-1]=pieces[-1]+.5*.25*F.kl_div(F.log_softmax(a,0),F.softmax(b,0),reduction='sum')
    loss=torch.stack(pieces).mean()
    mask=t['negative'][0].flatten().bool()&(t['heatmap'][0].flatten()<.01);k=min(128,int(mask.sum()))
    if k:
        a=student[0].flatten();b=fixed[0].flatten()
        selected=torch.unique(torch.cat((a.detach().masked_fill(~mask,-torch.inf).topk(k).indices,
            b.masked_fill(~mask,-torch.inf).topk(k).indices)))
        loss=loss+.05*(a[selected]-b[selected]).square().mean()
    return loss


def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(3);torch.backends.cudnn.benchmark=False
    state=torch.load(CHECKPOINT,map_location='cpu',weights_only=False);cfg=state['config']['recipe'];reference=state['config']['size_reference_512']
    model=PeakCalibratedModel(cfg).cuda().eval();model.load_state_dict(state['model']);model.set_mode(final=False)
    for p in model.parameters():p.requires_grad_(False)
    parameters=list(model.heads.center.parameters())+list(model.heads.aux.parameters())
    for p in parameters:p.requires_grad_(True)
    clean_teacher=teacher(HERE/'scene_scale_joint_v1/epoch_02_ema.pt')
    noise_teacher=teacher(HERE/'population_T_sourceAP_control_v1/best.pt')
    data=Data('DAUB-R','train',cfg);groups=defaultdict(list)
    for i,record in enumerate(data.records):groups[record['group']].append(i)
    indices=[items[len(items)//2] for items in groups.values()]
    def output(sample):
        features=[];handle=model.backbone.target_path.register_forward_hook(lambda m,args,out:features.append(out))
        try:
            with torch.no_grad():out=model(sample['image'][None].cuda(),return_features=True)
        finally:handle.remove()
        main=model.heads.center(out['final_features']);aux=model.heads.aux(features[0])
        return main,aux,.75*main+.25*aux
    def grad(loss):
        values=torch.autograd.grad(loss,parameters,retain_graph=True,allow_unused=True)
        return torch.cat([(v if v is not None else torch.zeros_like(p)).flatten() for v,p in zip(values,parameters)]).detach()
    def cosine(a,b):
        denominator=a.norm()*b.norm()
        return float(a.dot(b)/denominator) if float(denominator)>0 else None
    rows=[]
    for i in indices:
        native=data.base_sample(i);main,aux,score=output(native)
        t=targets([native],model_config(),reference,'cuda','shared_regression')
        with torch.no_grad():fixed=clean_teacher(native['image'][None].cuda())['center_logits']
        native_grad=grad(preserved(score,main,fixed,t,True))
        other=next(j for j,r in enumerate(data.records) if r['group']!=data.records[i]['group'])
        swapped={**native,'image':union_swap(native,data.base_sample(other),cfg)[0]}
        pool=[j for j in range(len(data)) if j!=i]
        image,boxes=mosaic(data,[i]+random.Random(3407+i).sample(pool,8),3)
        mosaic_sample={**native,'image':image,'boxes':boxes,'valid_mask':torch.ones_like(native['valid_mask']),
            'ignore_mask':torch.zeros_like(native['ignore_mask'])}
        cases={'noise4':{**native,'image':views(native,i+100000000)[0][1]},
            'noise16':{**native,'image':views(native,i+100000000)[0][2]},
            'background_noise16':{**swapped,'image':views(swapped,i+200000000)[0][2]},'mosaic3':mosaic_sample}
        for name,sample in cases.items():
            main,aux,score=output(sample);t=targets([sample],model_config(),reference,'cuda','shared_regression')
            b,x,y=t['anchors'].unbind(1);positive=.1*F.softplus(2-score[b,0,y,x]).mean();positive_grad=grad(positive)
            lc=model_config()['loss'];supervised=center_loss(score,t,lc['center_focal_alpha'],lc['center_focal_beta']).mean()+lc['auxiliary_weight']*center_loss(aux,t,lc['center_focal_alpha'],lc['center_focal_beta']).mean()
            supervised_grad=grad(supervised);photo_grad=None
            if name!='mosaic3':
                with torch.no_grad():fixed=noise_teacher(sample['image'][None].cuda())['center_logits']
                photo_grad=grad(preserved(score,main,fixed,t,False))
            rows.append({'record_id':data.records[i]['id'],'group':data.records[i]['group'],'view':name,'targets':len(t['anchors']),
                'positive_loss':float(positive.detach()),'positive_gradient_norm':float(positive_grad.norm()),
                'positive_vs_native_teacher_cosine':cosine(positive_grad,native_grad),
                'positive_vs_augmented_supervision_cosine':cosine(positive_grad,supervised_grad),
                'positive_vs_noise_teacher_cosine':cosine(positive_grad,photo_grad) if photo_grad is not None else None})
    assert all(torch.equal(value.cpu(),state['model'][name]) for name,value in model.state_dict().items())
    assert all(p.grad is None for p in model.parameters())
    summary={}
    for view in cases:
        summary[view]={}
        for key in ['positive_vs_native_teacher_cosine','positive_vs_augmented_supervision_cosine','positive_vs_noise_teacher_cosine']:
            values=[row[key] for row in rows if row['view']==view and row[key] is not None]
            summary[view][key]={'median':float(np.median(values)),'negative_fraction':sum(v<0 for v in values)/len(values)} if values else None
    result={'passed':True,'scope':'center/aux head gradients only, detached backbone features; not full-network gradients or causal proof',
        'head_parameters':sum(p.numel() for p in parameters),'source_train_records':len(indices),'rows':rows,'summary':summary,
        'checkpoint_sha256':sha(CHECKPOINT),'source_split_sha256':split_hashes()['DAUB-R_train'],
        'model_and_buffers_unchanged':True,'optimization_updates':0,'target_frames':0,'script_sha256':sha(__file__),'updated_at':now()}
    write_json(HOME/'result.json',result);print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
