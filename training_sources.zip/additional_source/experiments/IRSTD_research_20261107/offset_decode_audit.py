"""Quantify frozen offset train/decode mismatch at source-val probe anchors."""
import json
from pathlib import Path
import random
import sys
import numpy as np
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_v2.model import Model
from irstd_v2.data import Data,choose_plan,render
from irstd_adapter import targets,model_config
from irstd.data.targets import gather_centers
from irstd_v2.settings import write_json,now


@torch.inference_mode()
def main():
    torch.set_num_threads(2);torch.backends.cudnn.benchmark=False
    cfg=json.loads((HERE/'IRDST_fused_size_w4_v1/recipe.json').read_text(encoding='utf-8'))
    state=torch.load(ROOT/'runs/IRSTD/IRDST-H/seed_3407/best.pt',map_location='cpu',weights_only=False)
    reference=state['config']['size_reference_512'];model=Model(cfg).cuda().eval();model.load_state_dict(state['model'])
    data=Data('IRDST-H','val',cfg)
    spec=json.loads((HERE/'IRDST_fused_size_w4_v1/probe_spec.json').read_text(encoding='utf-8'))
    rows=[]
    # First four evenly spaced probe frames per source-val group; independent
    # of measured outputs. This audit does not optimize any model parameter.
    groups={}
    for i in spec['indices']:groups.setdefault(data.records[i]['group'],[]).append(i)
    ids=[indices[j] for indices in groups.values() for j in np.linspace(0,len(indices)-1,min(4,len(indices)),dtype=int)]
    for i in ids:
        for scale in [.6,1.,1.4]:
            plan=choose_plan(data.records[i],cfg['geometry'],random.Random(3407+i),forced_scale=scale,flip_override=False);assert not plan['fallback']
            image,boxes,valid=render(data.records[i],plan)
            sample={**data.base_sample(i),'image':image,'boxes':boxes,'valid_mask':valid,'ignore_mask':~valid}
            t=targets([sample],model_config(),reference,torch.device('cuda'),'shared_regression');out=model(image[None].cuda())
            offset=gather_centers(out['offsets'],t['anchors']);truth=t['offsets'];clamped=offset.clamp(0,1-1e-6)
            for v,gt,c in zip(offset.cpu().tolist(),truth.cpu().tolist(),clamped.cpu().tolist()):
                rows.append({'scale':scale,'record_index':i,'offset':v,'truth':gt,'outside_components':sum(x<0 or x>=1 for x in v),
                    'raw_center_error':float(np.abs(np.asarray(v)-gt).mean()),'decoded_center_error':float(np.abs(np.asarray(c)-gt).mean())})
    summary={}
    for scale in [.6,1.,1.4]:
        selected=[r for r in rows if r['scale']==scale]
        summary[str(scale)]={'targets':len(selected),'outside_component_fraction':sum(r['outside_components'] for r in selected)/(2*len(selected)),
            'raw_center_error_input_px':float(np.mean([r['raw_center_error'] for r in selected])),
            'decoded_center_error_input_px':float(np.mean([r['decoded_center_error'] for r in selected]))}
    report={'scope':'source-val frozen offset diagnostic only, not target testing','summary':summary,'rows':rows,'updated_at':now()}
    write_json(HERE/'offset_decode_audit.json',report);print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
