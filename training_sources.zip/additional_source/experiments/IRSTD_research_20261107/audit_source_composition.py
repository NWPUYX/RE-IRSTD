"""Independent tensor-origin and source-metric audit of a zero-step composition."""
import json
import itertools
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from source_model_composition import HOME,NEW,OLD,PARENT,sha,network,mixed_state,gates,row_key,locality_probe
from irstd_scene_scale.probe import evaluate_mosaics
from irstd_robust_t.run import mechanisms
from irstd_robust_t.probe import extreme_probe
from irstd_geometry_balance.run import probe
from irstd_noise_center.data import validation_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from evaluation import metrics
from irstd.models.blocks import REBlock
from audit_conditional_function import functional_responses
import benchmark_fastdecode as fast


def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
    summary=json.loads((HOME/'summary.json').read_text(encoding='utf-8'));cfg=best['config']
    assert cfg['old_endpoint_sha256']==sha(OLD) and cfg['new_endpoint_sha256']==sha(NEW/'best.pt')
    assert cfg['split_hashes']==split_hashes() and cfg['optimization_updates']==0
    assert not any(key in best for key in ['optimizer','updates'])
    for file,digest in {**cfg['source_hashes'],**cfg['diagnostic_hashes']}.items():assert sha(ROOT.parent/file)==digest,file
    old=torch.load(OLD,map_location='cpu',weights_only=False);new=torch.load(NEW/'best.pt',map_location='cpu',weights_only=False)
    model=network(cfg['recipe'],best['model']);parameters=set(dict(model.named_parameters()))
    expected=mixed_state(old['model'],new['model'],tuple(map(int,best['assignment'])),parameters)
    assert all(torch.equal(value,expected[name]) for name,value in best['model'].items())
    assert sum(p.numel() for p in model.parameters())==808952
    assert all(torch.equal(value.cpu(),old['model'][name]) for name,value in model.named_buffers())
    rows=[json.loads(p.read_text(encoding='utf-8')) for p in HOME.glob('*/row.json')]
    noise_limit=json.loads((HERE/'noise_validation_diagnostic/baseline.json').read_text(encoding='utf-8'))['results']['16']['box']['AP50']+.02
    for bits in itertools.product([0,1],repeat=3):
        label=''.join(map(str,bits));folder=HOME/label
        if not (folder/'row.json').exists():
            screen=json.loads((folder/'prescreen.json').read_text(encoding='utf-8'))
            frames=json.loads((folder/'noise16_prescreen_predictions.json').read_text(encoding='utf-8'))['frames']
            assert metrics(frames,old['source_validation']['threshold'])['AP50']==screen['strong_noise_AP50']
            assert not screen['passed'] and screen['strong_noise_AP50']<noise_limit
    assert max(rows,key=row_key)['assignment']==best['assignment']==summary['best_assignment']
    frames=json.loads((HOME/'best_source_val_predictions.json').read_text(encoding='utf-8'))['frames']
    assert len(frames)==1801 and validation_summary(frames)==best['source_validation']
    conditional={}
    with torch.inference_mode():
        for name,module in model.named_modules():
            if isinstance(module,REBlock):
                x=torch.zeros(1,module.channels,16,16,device='cuda');c=torch.linspace(-1,1,4*16*16,device='cuda').reshape(1,4,16,16)
                alpha=module.mixing_weights(x,c)
                assert torch.isfinite(alpha).all() and (alpha>=0).all()
                torch.testing.assert_close(alpha.sum(1),torch.ones_like(alpha[:,0]),atol=1e-6,rtol=0)
                conditional[name]=float((alpha-module.mixing_weights(x,torch.zeros_like(c))).abs().mean())
                assert conditional[name]>1e-8
    blocks=mechanisms(model);functional=functional_responses(model);recipe=cfg['recipe'];reference=cfg['size_reference_512'];threshold=best['source_validation']['threshold']
    geometry,per_scale=probe(model,recipe,reference,'cuda')
    assert geometry==best['geometry_probe'] and per_scale==best['per_scale']
    assert extreme_probe(model,recipe,reference,'cuda')==best['extreme_geometry']
    assert locality_probe(model,recipe,'cuda')==best['T_pair_MSE']<=1e-10
    assert evaluate_mosaics(model,recipe,reference,'cuda',threshold)==best['mosaics']
    for factor in [4,16]:
        path=HOME/f'audit_noise{factor}_predictions.json'
        frames=evaluate(model,validation_loader(recipe,factor),'cuda',reference,path)
        assert metrics(frames,threshold)==best['noise'][str(factor)]['box']
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False)
    bg=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    recomputed=gates(best,parent,bg);assert recomputed==best['gates']==summary['gates']
    assert all(recomputed.values())==summary['promotion_passed']
    assert all(torch.equal(value.cpu(),best['model'][name]) for name,value in model.state_dict().items())
    result={'passed':True,'promotion_passed':summary['promotion_passed'],'checkpoint_sha256':sha(HOME/'best.pt'),
        'selected_assignment':best['assignment'],'parameters':808952,'optimization_updates':0,
        'all_parameter_sources_verified':True,'population_buffers_unchanged':True,
        'REBlock_constraints_checked':blocks,'conditional_response_to_changed_C':conditional,
        'functional_C_output_responses':functional,'functional_audit_helper_sha256':sha(HERE/'audit_conditional_function.py'),
        'T_pair_MSE':best['T_pair_MSE'],'source_metrics_recalculated':True,'geometry_remeasured':True,
        'gates':recomputed,'updated_at':now()}
    write_json(HOME/'independent_audit.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
