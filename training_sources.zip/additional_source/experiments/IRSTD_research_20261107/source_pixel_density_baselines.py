"""Same source mosaic field, two pixel densities, no target inference."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import argparse
import json
from pathlib import Path
import sys
import time
import numpy as np
from PIL import Image
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE),str(ROOT.parent/'IRSTD/src')]
from source_mosaic_probe import Probe,build,sha,source_statistics,PopulationTModel
from irstd_v2.data import original_boxes
from irstd.inference.decoder import decode
from irstd_v2.settings import write_json,now,split_hashes
from evaluation import postprocess,match_frame,metrics,decode as decode_baseline
import benchmark_fastdecode as fast

HOME=HERE/'source_pixel_density_probe_v1'


@torch.inference_mode()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['aa_yolo','yolo26'],required=True);args=parser.parse_args()
    global HOME
    HOME=HERE/f'source_pixel_density_{args.model}_v1'
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    config={'script_sha256':sha(__file__),'plan_sha256':sha(HERE/'源像素密度基线补充方案.md'),
        'subset_sha256':sha(HERE/'wide_scale_source_probe.json'),'split_hashes':split_hashes(),
        'source_val_only':True,'optimization_updates':0,'target_frames':0,'batch':1,'resolutions':[512,1024]}
    write_json(HOME/'config.json',config);results={};stats=source_statistics()
    for name in [args.model]:
        recipe=torch.load(HERE/'robust_T_composed_v1/best.pt',map_location='cpu',weights_only=False)['config']['recipe']
        if name=='aa_yolo':
            from model_adapter import build as build_aa
            checkpoint=ROOT/'runs/AA-YOLO/DAUB-R/seed_3407/best.pt';state=torch.load(checkpoint,map_location='cpu',weights_only=False)
            identity=json.loads((HERE/'native_unit_aa_yolo_native_residual_v1/config.json').read_text(encoding='utf-8'))
            assert sha(checkpoint)==identity['checkpoint_sha256']
            for file,digest in identity['source_hashes'].items():assert sha(ROOT/file)==digest,file
            model,criterion=build_aa('AA-YOLO');del criterion;model.load_state_dict(state['model']);model.cuda().eval();os.chdir(ROOT)
        else:
            model,state,_,checkpoint=build('yolo26')
        threshold=json.loads((HERE/f'native_unit_{name}_native_residual_v1/source_validation.json').read_text(encoding='utf-8'))['threshold']
        digest=sha(checkpoint);dataset=Probe(recipe);rows={}
        for _,indices in [row for row in dataset.rows if row[0]==2]:
            canvas=Image.new('RGB',(512,512));boxes=[]
            for slot,index in enumerate(indices):
                record=dataset.base.records[index]
                with Image.open(record['path']) as image:canvas.paste(image.convert('RGB'),((slot%2)*256,(slot//2)*256))
                boxes.append(original_boxes(record)+torch.tensor([(slot%2)*256,(slot//2)*256]*2))
            boxes=torch.cat(boxes);xywh=boxes.clone();xywh[:,2:]-=xywh[:,:2]
            record={'width':512,'height':512,'boxes':xywh.tolist(),'group':str(indices[0])}
            assert len(boxes)==4 and dataset.base.split=='source_val'
            for side in [512,1024]:
                factor=side/512;image=torch.from_numpy(np.array(canvas.resize((side,side),Image.Resampling.BICUBIC).convert('RGB'),dtype=np.float32)/255.).permute(2,0,1)[None].cuda()
                torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();started=time.perf_counter();out=model(image) if name=='aa_yolo' else None
                if name=='aa_yolo':raw=decode_baseline('AA-YOLO',out)[0]
                else:
                    # Reuse this output rather than forwarding twice; official
                    # dual-branch output requires the existing predict wrapper.
                    del out
                    from yolo26_matched.model import predict
                    raw=predict(model,image)[0]
                    out=None
                row=rows.setdefault(str(side),{'learned':[],'known_source_size':[],'seconds':[],'peak_allocated_bytes':[]})
                for rule in ['learned','known_source_size']:
                    candidate=raw.clone()
                    if rule=='known_source_size':candidate[:,2:4]=candidate.new_tensor(stats['native_median'])*factor
                    row[rule].append(match_frame(postprocess(candidate,record,(factor,factor,0,0)),record))
                torch.cuda.synchronize();row['seconds'].append(time.perf_counter()-started);row['peak_allocated_bytes'].append(torch.cuda.max_memory_allocated())
                del out,image,raw
        assert all(torch.equal(v.cpu(),state['model'][k]) for k,v in model.state_dict().items()) and sha(checkpoint)==digest
        results[name]={'checkpoint_sha256':digest,'all_tensors_unchanged':True,'threshold':threshold,
            'results':{side:{**{rule:metrics(row[rule],threshold) for rule in ['learned','known_source_size']},
                'mean_seconds':float(np.mean(row['seconds'])),'max_allocated_bytes':max(row['peak_allocated_bytes'])} for side,row in rows.items()}}
        del model;torch.cuda.empty_cache()
    write_json(HOME/'result.json',{'status':'completed','results':results,'target_frames':0,'optimization_updates':0,'updated_at':now()})
    print(json.dumps(results),flush=True)


if __name__=='__main__':main()
