"""Describe source-training annotation units without inspecting target splits."""
import hashlib
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def main():
    rows = []
    for source in ['DAUB-R', 'IRDST-H', 'IRSTD-UAV', 'ITSDT-15K']:
        path = ROOT/f'splits/{source}_train.json'
        records = json.loads(path.read_text(encoding='utf-8'))
        native, scaled, resize = [], [], []
        for record in records:
            ratio = min(512/record['width'], 512/record['height'])
            transform = np.array([int(record['width']*ratio)/record['width'], int(record['height']*ratio)/record['height']])
            resize.append(transform)
            for box in record['boxes']:
                native.append(box[2:])
                scaled.append(np.array(box[2:])*transform)
        values = {}
        for name, array in [('native_wh', native), ('input_wh', scaled), ('resize_xy', resize)]:
            values[name] = {'q10': np.quantile(array, .1, axis=0).tolist(),
                            'median': np.median(array, axis=0).tolist(), 'q90': np.quantile(array, .9, axis=0).tolist()}
        rows.append({'source': source, 'frames': len(records), 'boxes': len(native),
                     'train_split_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), **values})
    (HERE/'四源训练尺寸单位统计.json').write_text(json.dumps({'scope': 'each row uses that dataset train split; only its own row may inform a single-source model; no test/val statistics', 'rows': rows}, indent=2), encoding='utf-8')
    lines = ['# 四个源训练集的尺寸单位', '',
        '[COMPUTED｜HIGH] 以下分别只读取该源的冻结train清单；不使用其余域作为该源的目标标签。数值依次为宽、高的中位数，512输入采用既有整数letterbox缩放。', '',
        '| 源训练集 | 帧数 | 框数 | 原图宽高 | 输入宽高 | resize中位数 |', '|---|---:|---:|---|---|---|']
    for row in rows:
        lines.append(f"| {row['source']} | {row['frames']} | {row['boxes']} | {row['native_wh']['median']} | {row['input_wh']['median']} | {row['resize_xy']['median']} |")
    lines += ['', '[KNOWN｜HIGH] 尺寸统计描述监督与预处理，不证明标注错误或物理目标大小。variable原图尺寸时，median(native×resize)一般不等于median(native)×median(resize)；DAUB固定resize2恰好相等。', '',
        '[KNOWN｜HIGH] 此表是四源数据审计。对DAUB单源模型，其他三行属于外部域标签信息，不可用于拟合、选择先验尺寸或阈值；当前DAUB先验仍仅取自身8×8，未按其他行修改。本轮T特征方案在此统计前已冻结启动。', '',
        '[INFERRED｜MED] 若后续将尺寸头改为原图单位残差，应按每幅已知letterbox变换定义训练参考，而非机械移植DAUB的固定除2规则。合成几何增强仍改变监督框及物体尺度，不能把所有增强都当作无需学习的预处理缩放。该训练参数化尚未实现或验证。']
    (HERE/'四源训练尺寸单位统计.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps(rows), flush=True)


if __name__ == '__main__':
    main()
