"""Check that changing C affects block outputs, beyond softmax weights alone."""
import torch
from irstd.models.blocks import REBlock


@torch.inference_mode()
def functional_responses(model):
    results={}
    device=next(model.parameters()).device
    yy,xx=torch.meshgrid(torch.arange(16,device=device),torch.arange(16,device=device),indexing='ij')
    for name,module in model.named_modules():
        if not isinstance(module,REBlock):continue
        feature=(torch.sin(xx.float()/3)+torch.cos(yy.float()/4))[None,None]
        feature=feature+torch.linspace(-.5,.5,module.channels,device=device)[None,:,None,None]
        condition=torch.linspace(-1,1,4*16*16,device=device).reshape(1,4,16,16)
        changed=module(feature,condition);control=module(feature,torch.zeros_like(condition))
        delta=float((changed-control).square().mean().sqrt())
        assert torch.isfinite(changed).all() and torch.isfinite(control).all() and delta>0,name
        results[name]={'output_C_change_RMS':delta,'gamma_absolute_mean':float(module.gamma.abs().mean()),
            'gamma_absolute_max':float(module.gamma.abs().max()),
            'effective_kernel_DC_max':max(float(k.sum((-2,-1)).abs().max()) for k in module.effective_kernels())}
    assert len(results)==14
    return results
