"""Audit robust-T state, numerical mechanisms and independently recomputed sources."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_robust_t.run import HOME,PARENT,PREFIXES,sha,construct,mechanisms,gates
from irstd_robust_t.probe import extreme_probe
from irstd_geometry_balance.run import probe
from irstd.models.blocks import REBlock
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from evaluation import metrics
from benchmark_center_metrics import center_metrics


def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    done=json.loads((HOME/'training_complete.json').read_text(encoding='utf-8'))
    best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
    last=torch.load(HOME/'trained_last.pt',map_location='cpu',weights_only=False)
    parent=torch.load(PARENT/'best.pt',map_location='cpu',weights_only=False);cfg=best['config']
    assert cfg==last['config'] and split_hashes()==cfg['split_hashes']
    assert sha(PARENT/'best.pt')==cfg['parent_sha256']
    for name,digest in {**cfg['source_hashes'],**cfg['diagnostic_hashes']}.items():assert sha(ROOT.parent/name)==digest,name
    assert json.loads((HOME/'source_prediction_manifest.json').read_text(encoding='utf-8'))['trained_checkpoint_sha256']==sha(HOME/'trained_last.pt')
    augmentation=json.loads((HOME/'augmentation_plan_audit.json').read_text(encoding='utf-8'))
    assert augmentation['passed'] and augmentation['data_sha256']==sha(ROOT/'irstd_robust_t/data.py')
    assert last['updates']==best['updates']==done['updates']==2091
    assert done['epochs_run']==best['epoch']==1
    assert sum(last['view_counts'].values())==8362 and last['view_counts']['native']==4181
    expected_views={'native':4181,'noise':1393,'background_noise':1394,'shrink_noise':697,'enlarge_noise':697}
    assert last['view_counts']==expected_views,last['view_counts']
    device=torch.device('cuda');model,_,opt=construct(cfg['recipe'],best['model'],device)
    trainable=sum(p.requires_grad for p in model.parameters())
    assert len(last['optimizer']['state'])==trainable
    assert all(int(v['step'])==2091 for v in last['optimizer']['state'].values())
    changed=[];frozen=0
    for name,value in parent['model'].items():
        if not name.startswith(PREFIXES):
            for candidate in [best['model'],last['model'],last['ema']]:assert torch.equal(value,candidate[name]),name
            frozen+=1
        elif not torch.equal(value,best['model'][name]):changed.append(name)
    assert all(torch.equal(v,last['ema'][n]) for n,v in best['model'].items())
    assert all(any(n.startswith(prefix) for n in changed) for prefix in ['backbone.target_path.','backbone.final.','heads.center.','heads.offset.','heads.size.','heads.aux.'])
    model.eval();blocks=mechanisms(model)
    conditional_sensitivity={}
    with torch.inference_mode():
        for name,module in model.named_modules():
            if isinstance(module,REBlock):
                feature=torch.zeros(1,module.channels,16,16,device=device)
                condition=torch.linspace(-1,1,4*16*16,device=device).reshape(1,4,16,16)
                alpha=module.mixing_weights(feature,condition)
                assert alpha.shape==(1,3,16,16) and torch.isfinite(alpha).all() and (alpha>=0).all()
                torch.testing.assert_close(alpha.sum(1),torch.ones_like(alpha[:,0]),rtol=0,atol=1e-6)
                uniform_condition=module.mixing_weights(feature,torch.zeros_like(condition))
                conditional_sensitivity[name]=float((alpha-uniform_condition).abs().mean())
    cached=json.loads((HOME/'epoch_01_predictions.json').read_text(encoding='utf-8'))['frames']
    assert len(cached)==1801 and validation_summary(cached)==best['source_validation']
    original_threshold=torch.load(HERE/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)['source_validation']['threshold']
    frames=json.loads((HOME/'epoch_01_swapped_predictions.json').read_text(encoding='utf-8'))['frames']
    assert metrics(frames,original_threshold)==best['background']['swapped_metrics']
    threshold=best['source_validation']['threshold']
    for factor in [4,16]:
        frames=json.loads((HOME/f'epoch_01_noise{factor}_predictions.json').read_text(encoding='utf-8'))['frames']
        assert len(frames)==24
        assert metrics(frames,threshold)==best['noise'][str(factor)]['box']
        assert center_metrics(frames,threshold)==best['noise'][str(factor)]['center']
    geometry,per_scale=probe(model,cfg['recipe'],cfg['size_reference_512'],device)
    assert geometry==best['geometry_probe'] and per_scale==best['per_scale']
    assert extreme_probe(model,cfg['recipe'],cfg['size_reference_512'],device)==best['extreme_geometry']
    baseline=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    computed=gates(best,parent,baseline)
    assert computed==best['gates']==done['gates'] and all(computed.values())==done['promotion_passed']
    result={'passed':True,'promotion_passed':done['promotion_passed'],'checkpoint_sha256':sha(HOME/'best.pt'),
        'parameters':808952,'trainable_parameters':23252,'optimizer_state_count':trainable,'optimizer_steps':2091,
        'frozen_tensors':frozen,'changed_tensors':changed,'REBlock_constraints_checked':blocks,
        'conditional_response_to_changed_C':conditional_sensitivity,
        'T_gamma_abs_mean':{label:float(torch.cat([v.flatten() for n,v in values.items() if n.startswith('backbone.target_path.') and n.endswith('.gamma')]).abs().mean())
            for label,values in [('parent',parent['model']),('candidate',best['model'])]},
        'cached_metrics_recalculated':True,'geometry_remeasured':True,'gates':computed,'updated_at':now()}
    write_json(HOME/'independent_audit.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
