"""Check the newer robust-T weights with corrected evidence before more training."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import hashlib
import json
from pathlib import Path
import sys
import torch
from torch.utils.data import DataLoader

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from stable_evidence_source_cohort import NativeCohort
from irstd_t_size.model import TSizeModel
from irstd_stable_evidence.model import StableModel
from irstd_noise_center.data import validation_loader
from irstd_v2.data import collate
from irstd_v2.evaluate import evaluate
from irstd_v2.settings import write_json,now
from evaluation import metrics
import benchmark_fastdecode as fast


@torch.inference_mode()
def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    home=HERE/'stable_robust_source_cohort_v1';home.mkdir(exist_ok=True)
    path=HERE/'robust_T_composed_v1/best.pt';s=torch.load(path,map_location='cpu',weights_only=False)
    cfg=s['config']['recipe'];results={}
    for mode in ['original','centered_IEEE']:
        recipe={**cfg,'evidence_arithmetic':mode}
        model=(TSizeModel if mode=='original' else StableModel)(recipe).cuda().eval();model.load_state_dict(s['model'])
        results[mode]={}
        for view in (['native'] if mode=='original' else ['native','noise4','noise16']):
            data=DataLoader(NativeCohort(cfg),batch_size=4,num_workers=2,collate_fn=collate) if view=='native' else validation_loader(cfg,int(view[5:]))
            write_json(home/'progress.json',{'mode':mode,'view':view,'updated_at':now()})
            f=evaluate(model,data,torch.device('cuda'),s['config']['size_reference_512'],home/f'{mode}_{view}_predictions.json')
            results[mode][view]=metrics(f,s['source_validation']['threshold'])
        assert all(torch.equal(v.cpu(),s['model'][n]) for n,v in model.state_dict().items())
        del model
    old=results['original']['native'];new=results['centered_IEEE']['native']
    screen=all(new[k]>=old[k]-.02 for k in ['AP50','AP50_95'])
    report={'scope':'fixed24-source validation with newer robust-T weights, no additional optimization; same predeclared numerical correction',
        'screen':'native AP50 and AP50:95 within2pp; fixed-old-threshold F1 reported, final threshold must come from full clean source validation',
        'native_AP_screen_passed':screen,'results':results,'checkpoint_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'updated_at':now()}
    write_json(home/'result.json',report);write_json(home/'progress.json',{'status':'completed','native_AP_screen_passed':screen,'updated_at':now()})
    print(json.dumps(report),flush=True)


if __name__=='__main__':main()
