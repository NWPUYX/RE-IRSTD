"""Require complete source-metric equivalence before changing the sampling rule."""
import json
from pathlib import Path
import torch
from anchor_preserving_decode import decode_raw
from native_unit_prior_evaluation import sha
from irstd_v2.data import make_loader
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd_noise_center.data import validation_loader
from irstd_background_center.data import swapped_loader
from evaluation import postprocess,match_frame,metrics
from benchmark_progress import ReportingLoader

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


@torch.inference_mode()
def evaluate_pair(model,loader,reference,path):
    if path.exists():return json.loads(path.read_text(encoding='utf-8'))
    frames,legacy,predictions=[],[],[];mismatches=0
    for images,samples in loader:
        out=model(images.cuda(),valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
        for b,(item,sample) in enumerate(zip(decode_raw(out,reference),samples)):
            raw=item['raw'];q=raw[:,:2].floor().long();mismatches+=int((q!=item['anchors']).any(1).sum())
            values=out['log_size'][b,:,q[:,1],q[:,0]].T.float();ref=values.new_tensor(reference)
            wh=ref*torch.minimum(values.clamp_min(-20),(values.new_tensor([512,512])/ref).log()).exp()
            old=raw.clone();old[:,2:4]=wh
            record=loader.dataset.records[sample['record_index']]
            new_pred=postprocess(raw,record,sample['trans']);old_pred=postprocess(old,record,sample['trans'])
            frames.append(match_frame(new_pred,record));legacy.append(match_frame(old_pred,record))
            predictions.extend({'image_id':record['id'],'category_id':1,'bbox':[x,y,x2-x,y2-y],'score':score}
                for x,y,x2,y2,score in new_pred.tolist())
    result={'frames':frames,'legacy_frames':legacy,'predictions':predictions,'changed_anchor_candidates':mismatches}
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(result,separators=(',',':')),encoding='utf-8');temp.replace(path)
    return result


def verify_bridge(model,state,folder,checkpoint):
    folder.mkdir(exist_ok=True)
    identity={'checkpoint_sha256':sha(checkpoint),'bridge_sha256':sha(__file__),
        'decoder_sha256':sha(HERE/'anchor_preserving_decode.py'),'evaluation_sha256':sha(ROOT/'evaluation.py'),
        'split_hashes':split_hashes(),'policy':'exact full-source and controlled-source metric equivalence; otherwise no target test'}
    path=folder/'config.json'
    if path.exists():assert json.loads(path.read_text(encoding='utf-8'))==identity
    else:write_json(path,identity)
    if (folder/'result.json').exists():
        result=json.loads((folder/'result.json').read_text(encoding='utf-8'))
        for name,digest in result['payload_hashes'].items():assert sha(folder/name)==digest,name
        return result
    recipe=state['config']['recipe'];reference=state['config']['size_reference_512'];threshold=state['source_validation']['threshold']
    reference_threshold=torch.load(HERE/'native_precision_w4_v1/best.pt',map_location='cpu',weights_only=False)['source_validation']['threshold']
    checks={};details={};paths=[]
    for name in ['source_val','noise4','noise16','swapped']:
        if name=='source_val':loader=make_loader('DAUB-R','val',recipe)
        elif name=='swapped':loader=swapped_loader(recipe)
        else:loader=validation_loader(recipe,int(name.removeprefix('noise')))
        path=folder/f'{name}_predictions.json';paths.append(path)
        payload=evaluate_pair(model,ReportingLoader(loader,folder/'progress.json',name),reference,path)
        if name=='source_val':
            actual=validation_summary(payload['frames']);legacy=validation_summary(payload['legacy_frames']);expected=state['source_validation']
        else:
            tau=reference_threshold if name=='swapped' else threshold
            actual=metrics(payload['frames'],tau);legacy=metrics(payload['legacy_frames'],tau)
            expected=state['background']['swapped_metrics'] if name=='swapped' else state['noise'][name.removeprefix('noise')]['box']
        checks[f'{name}_legacy_replayed']=legacy==expected
        checks[f'{name}_anchor_metrics_equal']=actual==legacy
        details[name]={'anchor_preserving':actual,'legacy':legacy,'expected':expected,'changed_anchor_candidates':payload['changed_anchor_candidates']}
    result={'passed':all(checks.values()),'checks':checks,'details':details,
        'payload_hashes':{p.name:sha(p) for p in paths},'optimization_updates':0,'updated_at':now()}
    write_json(folder/'result.json',result)
    return result
