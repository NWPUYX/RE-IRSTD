"""Resume frozen T-route tests using a verified equivalent plateau helper."""
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
import irstd_adapter
import benchmark_fastdecode as fast
from irstd_v2.settings import write_json,now
import evaluate_t_candidate


if __name__=='__main__':
    stage=sys.argv[sys.argv.index('--stage')+1]
    folder=HERE/stage/'frozen_four_domain_test'
    check=json.loads((HERE/'fastdecode_equivalence.json').read_text(encoding='utf-8'))
    digest=hashlib.sha256((ROOT/'benchmark_fastdecode.py').read_bytes()).hexdigest()
    assert check['passed'] and check['source_sha256']==digest
    manifest={'helper_sha256':digest,'equivalence_check':check,'model_threshold_NMS_unchanged':True,
        'existing_completed_cells_preserved':[p.name for p in folder.glob('*_metrics.json')],
        'original_evaluation_script_sha256':hashlib.sha256((HERE/'evaluate_t_candidate.py').read_bytes()).hexdigest(),
        'updated_at':now()}
    write_json(folder/'decoder_execution_manifest.json',manifest)
    fast.install();evaluate_t_candidate.main()
