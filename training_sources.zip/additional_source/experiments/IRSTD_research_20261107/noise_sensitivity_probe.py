"""Source-train noise stress: distinguish weak ranking from score calibration."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.nn import functional as F

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_t_size.model import TSizeModel
from irstd_v2.data import Data
from irstd_v2.settings import write_json,now


def main():
    torch.set_num_threads(2);torch.backends.cudnn.benchmark=False
    checkpoint=HOME/'background_center_interpolation_refine_v1/best.pt'
    state=torch.load(checkpoint,map_location='cpu',weights_only=False);cfg=state['config']['recipe']
    data=Data('DAUB-R','train',cfg);groups=defaultdict(list)
    for i,r in enumerate(data.records):groups[r['group']].append(i)
    ids=[indices[j] for indices in groups.values() for j in np.linspace(0,len(indices)-1,4,dtype=int)]
    model=TSizeModel(cfg).cuda().eval();model.load_state_dict(state['model'])
    captured={};hook=model.evidence.register_forward_hook(lambda m,a,o:captured.update(z=o[0]))
    kernel=torch.tensor([[1.,-2.,1.],[-2.,4.,-2.],[1.,-2.,1.]])[None,None]
    rows=[];threshold=state['source_validation']['threshold']
    with torch.inference_mode():
        for i in ids:
            sample=data.base_sample(i);image=sample['image'];background=sample['valid_mask'].clone()
            background[:,:2]=False;background[:,-2:]=False;background[:,:,:2]=False;background[:,:,-2:]=False
            amplitudes=[]
            yy,xx=torch.meshgrid(torch.arange(512),torch.arange(512),indexing='ij')
            for box in sample['boxes']:
                x1,y1,x2,y2=box.tolist();background[:,max(0,int(y1)-14):min(512,int(y2)+15),max(0,int(x1)-14):min(512,int(x2)+15)]=False
                qx,qy=((box[:2]+box[2:])/2).floor().long().tolist()
                radius=torch.maximum((xx-qx).abs(),(yy-qy).abs())
                ring=(radius>=10)&(radius<=16)&sample['valid_mask'][0]
                assert ring.any()
                patch=image[0,max(0,qy-3):min(512,qy+4),max(0,qx-3):min(512,qx+4)]
                amplitudes.append(float((patch-image[0][ring].median()).abs().max()))
            assert amplitudes and background.any()
            residual=F.conv2d(image[None],kernel,padding=1)[0]
            proxy=max(float(residual[background].abs().median())/(.67448975*6),1/255)
            images=[];metadata=[]
            for factor in [0,4,16]:
                sigma=min(factor*proxy,min(amplitudes)/2)
                generator=torch.Generator().manual_seed(3407+i*97+factor*1009)
                raw=image+sigma*torch.randn(image.shape,generator=generator)*sample['valid_mask']
                images.append(raw.clamp(0,1));metadata.append({'factor':factor,'sigma_added':sigma,'proxy_sigma':proxy,
                    'clipped_fraction':float(((raw<0)|(raw>1)).float().mean()),'minimum_contrast_to_total_proxy_noise':min(amplitudes)/(proxy**2+sigma**2)**.5})
            out=model(torch.stack(images).cuda());logits=out['center_logits'][:,0];local=logits==F.max_pool2d(logits[:,None],3,1,1)[:,0]
            for box in sample['boxes']:
                qx,qy=((box[:2]+box[2:])/2).floor().long().tolist()
                for b,meta in enumerate(metadata):
                    peak=logits[b,max(0,qy-3):qy+4,max(0,qx-3):qx+4].max()
                    bg=local[b]&background[0].cuda();rank=1+int((logits[b][bg]>=peak).sum())
                    rows.append({'record_index':i,'group':data.records[i]['group'],**meta,'local_peak_score':float(peak.sigmoid()),
                        'background_peak_rank':rank,'z_at_GT':captured['z'][b,:3,qy,qx].cpu().tolist()})
            captured.clear()
    hook.remove();summary={}
    for factor in [0,4,16]:
        selected=[r for r in rows if r['factor']==factor]
        summary[str(factor)]={'targets':len(selected),'mean_local_peak_score':float(np.mean([r['local_peak_score'] for r in selected])),
            'above_frozen_threshold':sum(r['local_peak_score']>=threshold for r in selected),
            'median_background_peak_rank':float(np.median([r['background_peak_rank'] for r in selected])),
            'median_added_sigma':float(np.median([r['sigma_added'] for r in selected])),
            'maximum_clipped_fraction':max(r['clipped_fraction'] for r in selected),
            'median_z_at_GT':np.median([r['z_at_GT'] for r in selected],axis=0).tolist()}
    report={'scope':'source_train exploratory diagnostic only, no training and no target-label fitting',
        'noise_proxy':'median absolute second-difference residual/(0.67448975*6), floor1/255; not calibrated sensor noise',
        'constraint':'additional sigma capped at half the minimum local target peak contrast; all boxes retained',
        'checkpoint_sha256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),'threshold':threshold,'summary':summary,'rows':rows,'updated_at':now()}
    write_json(HOME/'noise_sensitivity_probe.json',report);print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
