"""Wider source-only geometry stress; no optimization or target access."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import random
import sys
import numpy as np
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_t_size.model import TSizeModel
from irstd_v2.model import Model
from irstd_v2.data import Data,choose_plan,render
from irstd_adapter import targets,model_config
from irstd_v2.settings import write_json,now


@torch.inference_mode()
def main():
    torch.set_num_threads(4);device=torch.device('cuda')
    path=HERE/'background_center_interpolation_refine_v1/best.pt'
    state=torch.load(path,map_location='cpu',weights_only=False);cfg=state['config']['recipe'];reference=state['config']['size_reference_512']
    data=Data('DAUB-R','val',cfg);scales=[.25,.35,.5,.75,1.,1.4,2.]
    grouped=defaultdict(list)
    for i,r in enumerate(data.records):grouped[r['group']].append(i)
    ids=[];screen={};g=dict(cfg['geometry'],maximum_attempts=1)
    for group,indices in sorted(grouped.items()):
        eligible=[i for i in indices if all(not choose_plan(data.records[i],g,random.Random(0),forced_scale=s,flip_override=False)['fallback'] for s in scales)]
        assert eligible,group
        ids.extend(eligible[j] for j in np.linspace(0,len(eligible)-1,min(8,len(eligible)),dtype=int))
        screen[group]={'total':len(indices),'eligible_all_scales':len(eligible)}
    oldpath=ROOT/'runs/IRSTD/DAUB-R/seed_3407/best.pt';old=torch.load(oldpath,map_location='cpu',weights_only=False)
    model=TSizeModel(cfg).to(device);model.load_state_dict(state['model']);model.eval()
    original=Model(cfg).to(device);original.load_state_dict(old['model']);original.eval()
    rows=[]
    for i in ids:
        record=data.records[i]
        for scale in ['native']+scales:
            if scale=='native':
                sample=data.base_sample(i);image=sample['image'];valid=sample['valid_mask']
            else:
                plan=choose_plan(record,g,random.Random(0),forced_scale=scale,flip_override=False);assert not plan['fallback']
                image,boxes,valid=render(record,plan)
                sample={**data.base_sample(i),'image':image,'boxes':boxes,'valid_mask':valid,'ignore_mask':~valid}
            target=targets([sample],model_config(),reference,device,'shared_regression')
            for name,net in [('v1_fused',original),('Tsize_BG',model)]:
                out=net(image[None].to(device),valid_mask=valid[None].to(device))
                for j,(batch,qx,qy) in enumerate(target['anchors'].tolist()):
                    # Adapter anchors are (batch,x,y), as used by the deployed decoder.
                    qx,qy=int(qx),int(qy)
                    gtwh=target['sizes'][j].exp()*image.new_tensor(reference).to(device)
                    logwh=out['log_size'][0,:,qy,qx]
                    predwh=(logwh.clamp(-10,10).exp()*logwh.new_tensor(reference)).clamp(1,512)
                    predicted_offset=out['offsets'][0,:,qy,qx].clamp(0,1-1e-6)
                    sizeerr=float((predwh.log()-gtwh.log()).abs().mean())
                    centererr=float((predicted_offset-target['offsets'][j]).abs().mean())
                    patch=out['center_logits'][0,0,max(0,qy-3):min(512,qy+4),max(0,qx-3):min(512,qx+4)]
                    rows.append({'sample_id':record['id'],'group':record['group'],'scale':scale,'model':name,
                        'log_size_MAE':sizeerr,'decoded_center_MAE':centererr,'near_GT_peak_score':float(patch.max().sigmoid()),
                        'GT_width':float(gtwh[0]),'GT_height':float(gtwh[1])})
    summary=[]
    for name in ['v1_fused','Tsize_BG']:
        for scale in ['native']+scales:
            selected=[r for r in rows if r['model']==name and r['scale']==scale]
            summary.append({'model':name,'scale':scale,'targets':len(selected),**{key:float(np.mean([r[key] for r in selected]))
                for key in ['log_size_MAE','decoded_center_MAE','near_GT_peak_score','GT_width','GT_height']}})
    write_json(HERE/'wide_scale_source_probe.json',{'scope':'fixed source-val all-scales-feasible subset; GT-anchor geometry and GT-near peaks, not deployed AP',
        'source':'DAUB-R','feasibility':screen,'source_indices':ids,'source_record_ids':[data.records[i]['id'] for i in ids],
        'rendering':'identical bicubic geometric renderer at every scale including1.0; not native PIL letterbox validation',
        'checkpoint_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'v1_sha256':hashlib.sha256(oldpath.read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'summary':summary,'rows':rows,'updated_at':now()})
    print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
