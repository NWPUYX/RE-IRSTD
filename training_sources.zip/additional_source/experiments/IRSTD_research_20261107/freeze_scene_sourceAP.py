"""Source-only diagnostic selection; never erase failed extended gates."""
import copy
import json
from pathlib import Path
import shutil
import sys
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from irstd_scene_scale.run import HOME as TRAIN, PARENT, INITIAL, construct, buffers_fixed, gates, locality_probe, sha
from irstd_scene_scale.probe import evaluate_mosaics
from irstd_robust_t.probe import extreme_probe
from irstd_geometry_balance.run import probe
from audit_conditional_function import functional_responses
from irstd_robust_t.run import mechanisms
from irstd_geometry_repair.run import baseline as original_baseline
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json, now
from evaluation import metrics

HOME = HERE/'scene_scale_sourceAP_control_v1'


def main():
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    HOME.mkdir(exist_ok=True)
    done = json.loads((TRAIN/'training_complete.json').read_text(encoding='utf-8'))
    audited = json.loads((TRAIN/'independent_audit.json').read_text(encoding='utf-8'))
    assert audited['passed'] and audited['checkpoint_sha256'] == sha(TRAIN/'best.pt')
    parent = torch.load(PARENT/'best.pt', map_location='cpu', weights_only=False)
    base = original_baseline()['validation']
    rows = []
    for epoch in range(1, done['epochs_run']+1):
        row = json.loads((TRAIN/f'epoch_{epoch:02d}_row.json').read_text(encoding='utf-8'))
        source = row['source_validation']
        original_fine = source['pooled']['AP50_95'] >= base['pooled']['AP50_95']-.02
        original_fine &= all(source['by_group'][g]['AP50_95'] >= v['AP50_95']-.02 for g, v in base['by_group'].items())
        eligible = original_fine and all(row['gates'][k] for k in ['macro_AP50_original', 'pooled_AP50_original', 'native_F1_parent'])
        eligible &= source['pooled']['AP50'] > parent['source_validation']['pooled']['AP50']
        rows.append({'epoch': epoch, 'eligible': bool(eligible), 'original_fine_retained': bool(original_fine),
                     'source_AP50': source['pooled']['AP50'], 'extended_gates': row['gates']})
    candidates = [r for r in rows if r['eligible']]
    if not candidates:
        write_json(HOME/'selection.json', {'eligible_for_diagnostic_test': False, 'candidates': rows, 'updated_at': now()})
        print(json.dumps({'eligible_for_diagnostic_test': False}), flush=True)
        return
    winner = max(candidates, key=lambda r: r['source_AP50'])
    epoch = winner['epoch']
    selected_path = TRAIN/f'epoch_{epoch:02d}_ema.pt'
    selected = torch.load(selected_path, map_location='cpu', weights_only=False)
    training_path = TRAIN/f'epoch_{epoch:02d}_training.pt'
    training = torch.load(training_path, map_location='cpu', weights_only=False)
    initial = torch.load(INITIAL, map_location='cpu', weights_only=False)['model']
    assert selected['config'] == training['config']
    assert selected['updates'] == training['updates'] == epoch*2091
    assert all(torch.equal(v, training['ema'][k]) for k, v in selected['model'].items())
    assert all(int(v['step']) == training['updates'] for v in training['optimizer']['state'].values())
    for name, digest in {**selected['config']['source_hashes'], **selected['config']['diagnostic_hashes']}.items():
        assert sha(ROOT.parent/name) == digest, name
    model, _, _ = construct(selected['config']['recipe'], selected['model'], torch.device('cuda'))
    buffers_fixed(model, initial)
    assert len(training['optimizer']['state'])==sum(p.requires_grad for p in model.parameters())
    for name, value in training['model'].items():
        if name in dict(model.named_buffers()):
            assert torch.equal(value, initial[name]), name
    model.eval()
    blocks = mechanisms(model)
    functional=functional_responses(model)
    geometry,per_scale=probe(model,selected['config']['recipe'],selected['config']['size_reference_512'],'cuda')
    assert geometry==selected['geometry_probe'] and per_scale==selected['per_scale']
    assert extreme_probe(model,selected['config']['recipe'],selected['config']['size_reference_512'],'cuda')==selected['extreme_geometry']
    assert evaluate_mosaics(model,selected['config']['recipe'],selected['config']['size_reference_512'],'cuda',selected['source_validation']['threshold'])==selected['mosaics']
    assert locality_probe(model, selected['config']['recipe'], torch.device('cuda')) == selected['T_pair_MSE'] <= 1e-10
    source_path = TRAIN/f'epoch_{epoch:02d}_predictions.json'
    source = json.loads(source_path.read_text(encoding='utf-8'))['frames']
    assert validation_summary(source) == selected['source_validation']
    for factor in [4, 16]:
        frames = json.loads((TRAIN/f'epoch_{epoch:02d}_noise{factor}_predictions.json').read_text(encoding='utf-8'))['frames']
        assert metrics(frames, selected['source_validation']['threshold']) == selected['noise'][str(factor)]['box']
    background = json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    assert gates(selected, parent, background) == selected['gates']
    role = 'source-AP-selected complete-scene frozen diagnostic; extended18 failures retained; not final promotion'
    config = {**selected['config'], 'role': role, 'source_selection': 'native-quality-guarded source pooled AP50, no target selection',
              'selected_epoch_checkpoint_sha256': sha(selected_path), 'selected_training_sha256': sha(training_path),
              'control_freeze_script_sha256': sha(__file__)}
    if (HOME/'best.pt').exists():
        control = torch.load(HOME/'best.pt', map_location='cpu', weights_only=False)
        assert control['config'] == config
        assert all(torch.equal(v, control['model'][k]) for k, v in selected['model'].items())
    else:
        control = copy.deepcopy(selected)
        control['config'] = config
        torch.save(control, HOME/'best.pt')
    if not (HOME/'best_source_val_predictions.json').exists():
        shutil.copyfile(source_path, HOME/'best_source_val_predictions.json')
    assert sha(HOME/'best_source_val_predictions.json') == sha(source_path)
    normal = torch.load(TRAIN/'best.pt', map_location='cpu', weights_only=False)
    equivalent = (selected['source_validation']['threshold'] == normal['source_validation']['threshold'] and
                  selected['model'].keys() == normal['model'].keys() and
                  all(torch.equal(v, normal['model'][k]) for k, v in selected['model'].items()))
    selection = {'eligible_for_diagnostic_test': True, 'selected_epoch': epoch, 'candidates': rows,
                 'role': role, 'extended_source_gates': selected['gates'], 'equivalent_to_normal_candidate': equivalent}
    write_json(HOME/'selection.json', selection)
    audit = {'passed': True, 'eligible_for_diagnostic_test': True, 'promotion_passed': all(selected['gates'].values()),
             'checkpoint_sha256': sha(HOME/'best.pt'), 'selected_epoch': epoch, 'selected_updates': epoch*2091,
             'source_predictions_sha256': sha(source_path), 'all_selected_model_tensors_match_training_EMA': True,
             'context_adapted_fixed_population_buffers_preserved':True,'functional_C_output_responses':functional,'functional_audit_helper_sha256':sha(HERE/'audit_conditional_function.py'), 'REBlock_constraints_checked': blocks,
             'T_pair_MSE': selected['T_pair_MSE'], 'extended_source_gates': selected['gates'],
             'equivalent_to_normal_candidate': equivalent, 'role': role}
    if (HOME/'independent_audit.json').exists():
        assert json.loads((HOME/'independent_audit.json').read_text(encoding='utf-8')) == audit
    else:
        write_json(HOME/'independent_audit.json', audit)
    print(json.dumps(selection), flush=True)


if __name__ == '__main__':
    main()
