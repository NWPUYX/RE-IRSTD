"""Source-train-only, target-preserving background sensitivity diagnostic."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import random
import sys
import torch
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_t_size.model import TSizeModel
from irstd_v2.data import Data,union_swap
from irstd_v2.settings import write_json,now


@torch.inference_mode()
def main():
    torch.set_num_threads(2);torch.backends.cudnn.benchmark=False
    path=HERE/'native_precision_w4_v1/best.pt';state=torch.load(path,map_location='cpu',weights_only=False)
    cfg=state['config']['recipe'];data=Data('DAUB-R','train',cfg)
    model=TSizeModel(cfg).cuda().eval();model.load_state_dict(state['model'])
    groups=defaultdict(list)
    for i,r in enumerate(data.records):groups[r['group']].append(i)
    ids=[indices[j] for indices in groups.values() for j in np.linspace(0,len(indices)-1,4,dtype=int)]
    rows=[]
    for i in ids:
        sample=data.base_sample(i);r=data.records[i]
        donors=[j for group,indices in groups.items() if group!=r['group'] for j in indices]
        donor_id=random.Random(3407+i*97).choice(donors);donor=data.base_sample(donor_id)
        image,alpha,_=union_swap(sample,donor,cfg)
        assert alpha.max()>0 and sample['split']==donor['split']=='source_train'
        pair=torch.stack([sample['image'],image]).cuda()
        out=model(pair,return_features=True);z,c=model.evidence(pair)
        for box in sample['boxes']:
            center=(box[:2]+box[2:])/2;qx,qy=center.floor().long().tolist()
            # Protected input support is larger than the local evidence ring.
            local_error=float((z[0,:,qy,qx]-z[1,:,qy,qx]).abs().max())
            condition_error=float((c[0,:,qy,qx]-c[1,:,qy,qx]).abs().max())
            logits=out['center_logits'][:,0,qy,qx];scores=logits.sigmoid()
            peak=out['center_logits'][:,0,max(0,qy-3):qy+4,max(0,qx-3):qx+4].flatten(1).max(1).values.sigmoid()
            features=out['final_features'][:,:,qy,qx]
            rows.append({'group':r['group'],'record_index':i,'donor_group':data.records[donor_id]['group'],
                'swapped_fraction':float(alpha.mean()),'evidence_at_GT_max_difference':local_error,
                'condition_at_GT_max_difference':condition_error,'original_logit':float(logits[0]),'swapped_logit':float(logits[1]),
                'original_score':float(scores[0]),'swapped_score':float(scores[1]),
                'original_local_peak_score':float(peak[0]),'swapped_local_peak_score':float(peak[1]),
                'feature_cosine':float(torch.nn.functional.cosine_similarity(features[0],features[1],dim=0)),
                'log_size_max_difference':float((out['log_size'][0,:,qy,qx]-out['log_size'][1,:,qy,qx]).abs().max())})
    threshold=state['source_validation']['threshold']
    def quantile(key):return np.quantile([r[key] for r in rows],[.1,.5,.9]).tolist()
    report={'scope':'source-train diagnostic only; no training/validation/test score','checkpoint_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'samples':len(ids),'targets':len(rows),'threshold_from_source_val':threshold,
        'quantiles':{k:quantile(k) for k in ['evidence_at_GT_max_difference','condition_at_GT_max_difference','feature_cosine','swapped_fraction','log_size_max_difference']},
        'mean_original_peak_score':float(np.mean([r['original_local_peak_score'] for r in rows])),
        'mean_swapped_peak_score':float(np.mean([r['swapped_local_peak_score'] for r in rows])),
        'original_peak_above_source_threshold':sum(r['original_local_peak_score']>=threshold for r in rows),
        'swapped_peak_above_source_threshold':sum(r['swapped_local_peak_score']>=threshold for r in rows),
        'rows':rows,'updated_at':now()}
    write_json(HERE/'background_sensitivity_probe.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)


if __name__=='__main__':main()
