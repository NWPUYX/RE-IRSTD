"""Read-only source-label support; no fit, target test labels, or label changes."""
import hashlib
import json
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    result={}
    for domain in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=ROOT/f'splits/{domain}_train.json'
        records=json.loads(path.read_text(encoding='utf-8'))
        wh=np.asarray([box[2:] for record in records for box in record['boxes']],dtype=float)
        assert (wh>0).all();ratio=wh[:,0]/wh[:,1]
        result[domain]={'training_frames':len(records),'targets':len(wh),
            'aspect_ratio_quantiles_0_5_25_50_75_95_100':np.quantile(ratio,[0,.05,.25,.5,.75,.95,1]).tolist(),
            'square_targets':int((ratio==1).sum()),'wider_than_tall':int((ratio>1).sum()),
            'original_WH_median':np.median(wh,axis=0).tolist(),'manifest_sha256':sha(path)}
    code=ROOT/'irstd_v2/data.py';scene=ROOT/'irstd_scene_scale/data.py'
    payload={'training_sources':result,'current_geometry':'shared absolute sx=sy for jitter; equal cell mosaic scaling; horizontal flip',
        'geometry_implementation_sha256':sha(code),'scene_implementation_sha256':sha(scene),
        'new_model_updates':0,'target_test_frames':0,'source_labels_changed':False,'script_sha256':sha(__file__)}
    (HERE/'source_geometry_support_audit.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    lines=['# 源几何监督支持范围审查','',
        '[COMPUTED｜HIGH] 只读取四个训练源的冻结标签；没有使用目标测试标签、拟合参数或更改标注。DAQ适配仍只使用DAQ训练源，其他训练源统计不用于拟合DAQ尺寸规则。',
        '', '| 训练源 | 目标数 | 正方形比例 | 宽大于高的目标数 | 原图宽高比5%/50%/95%分位 |',
        '|---|---:|---:|---:|---|']
    for domain,row in result.items():
        q=row['aspect_ratio_quantiles_0_5_25_50_75_95_100']
        lines.append(f"| {domain} | {row['targets']} | {row['square_targets']/row['targets']*100:.3f}% | {row['wider_than_tall']} | {q[1]:.4f}/{q[3]:.4f}/{q[5]:.4f} |")
    lines+=['','[COMPUTED｜HIGH] 当前抖动的横纵绝对缩放相等，mosaic单元也等比例缩放；水平翻转不改变宽高比。因此这些增强扩展了像素尺度和目标数量，却没有扩展同一原始标签的宽高比支持。',
        '', '[INFERRED｜MED] 这是几何泛化不足的另一项竞争解释，不能单凭标签统计断言它导致了当前AP/F1差距。下一步若研究该方向，应先在源验证构造预先固定的非等比、保留全部目标的几何挑战，将中心排序、实际尺寸和真值尺寸辅助诊断分开；当前正在训练的数值与噪声配方不临时加入该改变。',
        '', '[KNOWN｜HIGH] 图像和框同时缩放不改变框与成像响应的相对范围；这一统计不能消除先前标注范围诊断中的不确定性。不得依据目标测试框搜索各域倍率或改动真值来提高分数。']
    (HERE/'源几何支持范围审查.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(result),flush=True)


if __name__=='__main__':main()
