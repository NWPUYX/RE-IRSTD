"""One inference pass for two disclosed size-unit rules, only after source audit."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import sys
import time
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from irstd_scene_scale.run import HOME, sha
from irstd_population_t.model import PopulationTModel
from irstd_v2.data import make_loader
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json, now, split_hashes
from anchor_preserving_decode import decode_raw
from anchor_source_bridge import verify_bridge
from native_unit_prior_evaluation import source_statistics, apply_prior
from evaluation import postprocess, match_frame, metrics
from benchmark_progress import ReportingLoader
from benchmark_cluster_bootstrap import cluster_ci
import benchmark_fastdecode as fast


@torch.inference_mode()
def infer(model, loader, reference, stats, rules):
    payload = {rule: {'frames': [], 'predictions': []} for rule in rules}
    for images, samples in loader:
        out = model(images.cuda(), valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
        decoded = decode_raw(out, reference)
        for b, (proposal, sample) in enumerate(zip(decoded, samples)):
            raw = proposal['raw']
            record = loader.dataset.records[sample['record_index']]
            for rule in rules:
                value = raw if rule == 'original' else apply_prior(raw, sample['trans'], stats, 'native_residual')
                pred = postprocess(value, record, sample['trans'])
                payload[rule]['frames'].append(match_frame(pred, record))
                payload[rule]['predictions'].extend({'image_id': record['id'], 'category_id': 1,
                    'bbox': [x, y, x2-x, y2-y], 'score': confidence} for x, y, x2, y2, confidence in pred.tolist())
    return payload


def main():
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    fast.install()
    audit_path = HOME/'independent_audit.json'
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    assert audit['passed'] and audit['promotion_passed'], 'source/independent audit did not qualify this candidate'
    checkpoint = HOME/'best.pt'
    assert sha(checkpoint) == audit['checkpoint_sha256']
    state = torch.load(checkpoint, map_location='cpu', weights_only=False)
    cfg = state['config']
    assert cfg['split_hashes'] == split_hashes()
    for name, digest in {**cfg['source_hashes'], **cfg['diagnostic_hashes']}.items():
        assert sha(ROOT.parent/name) == digest, name
    source_path = HOME/'best_source_val_predictions.json'
    assert validation_summary(json.loads(source_path.read_text(encoding='utf-8'))['frames']) == state['source_validation']
    stats = source_statistics()
    assert cfg['size_reference_512'] == stats['input_median']
    records = json.loads((ROOT/'splits/DAUB-R_val.json').read_text(encoding='utf-8'))
    assert all(r['width'] == r['height'] == 256 for r in records)
    threshold = state['source_validation']['threshold']
    rules = ['original', 'native_residual']
    model = PopulationTModel(cfg['recipe']).cuda().eval()
    model.load_state_dict(state['model'], strict=True)
    model.set_mode(final=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    bridge=verify_bridge(model,state,HOME/'anchor_bridge_v2',checkpoint)
    assert bridge['passed'], 'anchor-source metrics changed; requalification required before targets'
    root = HOME/'source_qualified_tests'
    root.mkdir(exist_ok=True)
    common = {'source': 'DAUB-R', 'seed': 3407, 'checkpoint_sha256': sha(checkpoint),
              'audit_sha256': sha(audit_path), 'source_predictions_sha256': sha(source_path),
              'threshold': threshold, 'source_statistics': stats, 'split_hashes': split_hashes(),
              'script_sha256': sha(__file__), 'decoder_sha256': sha(ROOT/'benchmark_fastdecode.py'), 'anchor_decoder_sha256':sha(HERE/'anchor_preserving_decode.py'), 'anchor_bridge_sha256':sha(HOME/'anchor_bridge_v2/result.json'),
              'evaluation_sha256': sha(ROOT/'evaluation.py'), 'bootstrap_sha256': sha(ROOT/'benchmark_cluster_bootstrap.py'),
              'role': 'source-qualified single-source development evaluation; not independent SOTA confirmation',
              'source_prior_equivalence': 'all source-val resize factors are2; native residual factor exactly1',
              'test_rules': rules, 'evidence_arithmetic': 'original (legacy TF32)',
              'normalization_mode': 'T_only source-population moments; final/context GN retained',
              'calibration_checkpoint_sha256': cfg['calibration_checkpoint_sha256'],
              'policy': 'report both fixed rules; no target-based rule selection'}
    for rule in rules:
        folder = root/rule
        folder.mkdir(exist_ok=True)
        manifest = {**common, 'size_rule': rule}
        path = folder/'freeze_manifest.json'
        if path.exists():
            assert json.loads(path.read_text(encoding='utf-8')) == manifest
        else:
            write_json(path, manifest)
    for domain in ['DAUB-R', 'IRDST-H', 'IRSTD-UAV', 'ITSDT-15K']:
        pending = [r for r in rules if not (root/r/f'{domain}_metrics.json').exists()]
        needed = [r for r in pending if not (root/r/f'{domain}_predictions.json').exists()]
        started = time.perf_counter()
        if needed:
            loader = ReportingLoader(make_loader(domain, 'test', cfg['recipe']), root/'progress.json', domain)
            payloads = infer(model, loader, cfg['size_reference_512'], stats, needed)
            if domain == 'DAUB-R' and len(needed) == 2:
                assert payloads['original'] == payloads['native_residual']
            for rule, payload in payloads.items():
                path = root/rule/f'{domain}_predictions.json'
                temp = path.with_suffix('.tmp')
                temp.write_text(json.dumps(payload, separators=(',', ':')), encoding='utf-8')
                temp.replace(path)
            del payloads
        for rule in pending:
            path = root/rule/f'{domain}_predictions.json'
            frames = json.loads(path.read_text(encoding='utf-8'))['frames']
            overall = metrics(frames, threshold)
            ci = cluster_ci(frames)
            if ci is not None:
                overall['AP50_cluster_CI95'] = ci
            result = {'source': 'DAUB-R', 'target': domain, 'seed': 3407, 'overall': overall,
                      'by_group': {g: metrics([f for f in frames if f['group'] == g], threshold) for g in sorted({f['group'] for f in frames})},
                      'size_rule': rule, 'shared_inference_elapsed_seconds': time.perf_counter()-started, 'updated_at': now()}
            write_json(root/rule/f'{domain}_metrics.json', result)
            print(json.dumps({'rule': rule, 'target': domain, **overall}), flush=True)
    assert all(torch.equal(v.cpu(), state['model'][k]) for k, v in model.state_dict().items())
    for rule in rules:
        cross = [json.loads((root/rule/f'{d}_metrics.json').read_text(encoding='utf-8'))['overall'] for d in ['IRDST-H', 'IRSTD-UAV', 'ITSDT-15K']]
        result = {'status': 'completed', 'source': 'DAUB-R', 'seed': 3407, 'completed_cells': 4,
                  'size_rule': rule, 'all_tensors_unchanged': True, 'threshold': threshold,
                  'cross_domain_macro': {k: sum(r[k] for r in cross)/3 for k in ['AP50', 'AP50_95', 'F1', 'center_Pd_3px']},
                  'role': common['role'], 'updated_at': now()}
        write_json(root/rule/'summary.json', result)
    write_json(root/'progress.json', {'status': 'completed', 'completed_cells': 8, 'shared_inference_passes': 4, 'updated_at': now()})


if __name__ == '__main__':
    main()
