"""Direct patch oracle versus integral implementation, including image borders."""
import json
from pathlib import Path
import random
import sys
import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from integral_evidence_prototype import IntegralEvidence
from irstd_adapter import model_config
from irstd_v2.settings import write_json,now
from native_unit_prior_evaluation import sha


def oracle(image,cfg,points):
    value=image.double();h,w=value.shape[-2:];cache={}
    def stats(i,y,x):
        key=(i,y,x)
        if key not in cache:
            inner,outer=cfg['annuli'][i];r=outer//2
            p=F.pad(value,(r,)*4,mode='reflect')[0,0,y:y+outer,x:x+outer]
            mask=torch.ones(outer,outer,dtype=torch.bool);start=(outer-inner)//2;mask[start:start+inner,start:start+inner]=False
            pixels=p[mask];mean=pixels.mean();scale=((pixels.square().mean()-mean.square()).clamp_min(0)+cfg['sigma_floor']**2).sqrt()
            cache[key]=(mean,scale)
        return cache[key]
    z,c=[],[]
    def reflect(index,size):
        if index<0:return -index
        if index>=size:return 2*size-2-index
        return index
    for y,x in points:
        means,scales=zip(*(stats(i,y,x) for i in range(3)))
        signed=torch.stack([(value[0,0,y,x]-means[i])/scales[i] for i in range(3)]).clamp(-cfg['clip_abs'],cfg['clip_abs'])
        z.append(torch.cat((signed,signed.abs())).float())
        gx=(stats(2,y,reflect(x+1,w))[0]-stats(2,y,reflect(x-1,w))[0])*.5/scales[2]
        gy=(stats(2,reflect(y+1,h),x)[0]-stats(2,reflect(y-1,h),x)[0])*.5/scales[2]
        c.append(torch.stack((gx,gy,(scales[0]/scales[2]).log(),(scales[1]/scales[2]).log())).clamp(-cfg['clip_abs'],cfg['clip_abs']).float())
    return torch.stack(z),torch.stack(c)


@torch.inference_mode()
def main():
    torch.set_num_threads(4);cfg=model_config()['model']['evidence'];model=IntegralEvidence(cfg).cuda().eval()
    assert sum(p.numel() for p in model.parameters())==0
    generator=torch.Generator().manual_seed(3407)
    cases={'quantized':torch.randint(0,256,(1,1,96,128),generator=generator).float()/255,
        'near_constant':.5+torch.randn(1,1,80,96,generator=generator)*1e-4,
        'constant':torch.full((1,1,64,80),.5)}
    records=json.loads((ROOT/'splits/DAUB-R_val.json').read_text(encoding='utf-8'))
    with Image.open(records[0]['path']) as image:
        image=image.convert('RGB').resize((512,512),Image.Resampling.BICUBIC).convert('L')
        cases['source_512']=torch.from_numpy(np.array(image,dtype=np.float32)/255.)[None,None]
    results={}
    for name,image in cases.items():
        h,w=image.shape[-2:];points=[(0,0),(0,w-1),(h-1,0),(h-1,w-1),(h//2,w//2)]
        rng=random.Random(3407)
        points.extend((rng.randrange(h),rng.randrange(w)) for _ in range(24))
        z,c=model(image.cuda());reference_z,reference_c=oracle(image,cfg,points)
        actual_z=torch.stack([z[0,:,y,x].cpu() for y,x in points]);actual_c=torch.stack([c[0,:,y,x].cpu() for y,x in points])
        error_z=float((actual_z-reference_z).abs().max());error_c=float((actual_c-reference_c).abs().max())
        assert error_z<2e-5 and error_c<2e-5,(name,error_z,error_c)
        if name=='constant':assert torch.count_nonzero(z)==0 and torch.count_nonzero(c)==0
        changed=image.clone();y,x=h//2,w//2;protected=torch.zeros(h,w,dtype=torch.bool);protected[y-16:y+17,x-16:x+17]=True
        replacement=torch.rand(image.shape,generator=generator);changed[0,0,~protected]=replacement[0,0,~protected]
        z2,c2=model(changed.cuda());local_error=float(torch.cat((z[0,:,y,x]-z2[0,:,y,x],c[0,:,y,x]-c2[0,:,y,x])).square().mean())
        assert local_error<1e-10,(name,local_error)
        results[name]={'points':len(points),'Z_max_error_vs_direct_FP64':error_z,'C_max_error_vs_direct_FP64':error_c,
            'far_background_center_MSE':local_error,'all_finite':bool(torch.isfinite(z).all() and torch.isfinite(c).all())}
    result={'passed':True,'cases':results,'learnable_parameters':0,'optimization_updates':0,'target_frames':0,
        'config':cfg,'implementation_sha256':sha(HERE/'integral_evidence_prototype.py'),'script_sha256':sha(__file__),
        'plan_sha256':sha(HERE/'双精度积分证据数值验证方案.md'),'source_image':records[0]['id'],
        'source_image_sha256':sha(records[0]['path']),'updated_at':now()}
    write_json(HERE/'integral_evidence_numeric_audit.json',result);print(json.dumps(results),flush=True)


if __name__=='__main__':main()
