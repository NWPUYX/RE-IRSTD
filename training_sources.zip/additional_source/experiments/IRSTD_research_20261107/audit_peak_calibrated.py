"""Independently replay source decisions, optimizer coverage, and operator behavior."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import json
from pathlib import Path
import sys
import torch
from torch.nn import functional as F

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from peak_calibrated_training import HOME,INITIAL,CLEAN_TEACHER,NOISE_TEACHER,GATE_PARENT,identity,construct,sha
from peak_calibrated_model import PeakCalibratedModel as IntegralPopulationModel,decode_calibrated
from integral_evidence_prototype import IntegralEvidence
from audit_integral_evidence import oracle
from audit_conditional_function import functional_responses
from peak_calibrated_evaluation import evaluate_mosaics
from irstd_scene_scale.run import gates,row_key,locality_probe,buffers_fixed
from irstd_robust_t.run import mechanisms
from irstd_robust_t.probe import extreme_probe
from irstd_geometry_balance.run import probe
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now
from benchmark_center_metrics import center_metrics
from evaluation import metrics
from irstd.models.blocks import REBlock
from irstd_adapter import model_config


@torch.inference_mode()
def numerical_check(model):
    constant={}
    for value in [.2,.5,.8]:
        z,c=model.evidence(torch.full((1,1,512,512),value,device='cuda'))
        constant[str(value)]={'Z_max':float(z.abs().max()),'C_max':float(c.abs().max())}
        assert float(z.abs().max())<1e-6 and float(c.abs().max())<2e-6
    generator=torch.Generator().manual_seed(3407)
    image=torch.randint(0,256,(1,1,96,128),generator=generator).float()/255
    points=[(0,0),(95,127),(48,64),(1,126),(94,1)]
    actual=model.evidence(image.cuda());expected=oracle(image,model_config()['model']['evidence'],points)
    errors=[]
    for tensor,reference in zip(actual,expected):
        sampled=torch.stack([tensor[0,:,y,x].cpu() for y,x in points])
        error=float((sampled-reference).abs().max());assert error<2e-5;errors.append(error)
    return {'constants':constant,'patch_oracle_Z_C_max_errors':errors}


@torch.inference_mode()
def actual_dc(model):
    result={}
    for name,module in model.named_modules():
        if not isinstance(module,REBlock):continue
        maxima=[]
        for side in [64,128,256,512]:
            feature=torch.ones(1,module.channels,side,side,device='cuda')
            for kernel,dilation in zip(module.effective_kernels(),module.dilations):
                value=F.conv2d(F.pad(feature,(dilation,)*4,mode='reflect'),kernel,dilation=dilation,groups=module.channels)
                maxima.append(float(value.abs().max()))
        result[name]=max(maxima);assert result[name]<=1e-6
    assert len(result)==14
    return result


@torch.inference_mode()
def actual_source_condition_variation(model,cfg):
    from irstd_v2.data import make_loader
    from irstd_noise_center.data import validation_loader
    rows={};phase=['clean'];handles=[]
    def capture(name):
        def hook(module,args,logits):
            weights=logits.softmax(1)
            torch.testing.assert_close(weights.sum(1),torch.ones_like(weights[:,0]),rtol=0,atol=1e-6)
            assert torch.isfinite(weights).all()
            rows.setdefault(name,{})[phase[0]]={'mean':weights.mean((0,2,3)).cpu().tolist(),
                'spatial_and_batch_std':weights.std((0,2,3),unbiased=False).cpu().tolist()}
        return hook
    for name,module in model.named_modules():
        if isinstance(module,REBlock):handles.append(module.gate.register_forward_hook(capture(name)))
    assert len(handles)==14
    try:
        for label,loader in [('clean',make_loader('DAUB-R','val',cfg)),('noise16',validation_loader(cfg,16))]:
            phase[0]=label;images,_=next(iter(loader));model(images.cuda())
    finally:
        for handle in handles:handle.remove()
    assert len(rows)==14
    return rows


def main():
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    bound,initial=identity();done=json.loads((HOME/'training_complete.json').read_text(encoding='utf-8'))
    best=torch.load(HOME/'best.pt',map_location='cpu',weights_only=False)
    last=torch.load(HOME/'last.pt',map_location='cpu',weights_only=False)
    assert best['config']==last['config']==bound
    assert sha(INITIAL)==bound['initialization_checkpoint_sha256'] and sha(NOISE_TEACHER)==bound['noise_teacher_checkpoint_sha256']
    assert sha(GATE_PARENT)==bound['gate_parent_sha256']
    assert sha(CLEAN_TEACHER)==bound['clean_teacher_checkpoint_sha256']
    preflight=json.loads((HOME/'preflight.json').read_text(encoding='utf-8'));assert preflight['passed'] and preflight['identity']==bound
    assert preflight['deployed_training_scores_exact'] and preflight['original_peak_geometry_exact']
    assert len(preflight['new_loss_gradient_checks'])==4
    assert all(row['native_location_KL']>0 and row['augmented_positive_calibration']>0 and row['calibrated_augmented_targets']==row['expected_augmented_targets'] for row in preflight['new_loss_gradient_checks'])
    epoch=best['epoch'];selected=torch.load(HOME/f'epoch_{epoch:02d}_training.pt',map_location='cpu',weights_only=False)
    assert done['updates']==last['updates']==last['epoch']*2091 and last['epoch']==done['epochs_run']<=6
    assert best['updates']==selected['updates']==epoch*2091 and epoch==done['best_epoch']
    assert all(torch.equal(v,selected['ema'][name]) for name,v in best['model'].items())
    model,teachers,optimizer=construct(bound['recipe'],best['model'],torch.device('cuda'));model.eval()
    assert isinstance(model.evidence,IntegralEvidence) and sum(p.numel() for p in model.parameters())==808952
    names=list(model.named_parameters());assert all(p.requires_grad for _,p in names)
    for checkpoint in [selected,last]:
        assert len(checkpoint['optimizer']['state'])==len(names)
        assert all(int(value['step'])==checkpoint['updates'] for value in checkpoint['optimizer']['state'].values())
        assert sum(checkpoint['view_counts'].values())==8362 and checkpoint['view_counts']['native']==4181
        assert set(checkpoint['view_counts'])=={'native','noise','background_noise','shrink','enlarge','mosaic'}
        assert sum(checkpoint['object_view_counts'].values())==8362+checkpoint['extra_donor_frames']
        for actual,expected in zip(checkpoint['optimizer']['param_groups'],optimizer.param_groups):
            assert actual['lr']==expected['lr'] and actual['weight_decay']==expected['weight_decay'] and len(actual['params'])==len(expected['params'])
        for state in [checkpoint['model'],checkpoint['ema']]:
            for name in dict(model.named_buffers()):assert torch.equal(state[name],initial[name]),name
    assert all(torch.isfinite(v).all() for v in best['model'].values())
    from irstd_v2.data import make_loader
    from locked_peak_decode import base_candidates
    images,_=next(iter(make_loader('DAUB-R','val',bound['recipe'])))
    with torch.inference_mode():
        output=model(images.cuda());decoded=decode_calibrated(output,bound['size_reference_512'])
        original_output={**output,'center_logits':output['main_peak_logits']}
        candidates=base_candidates(original_output,bound['size_reference_512'])
        for b,(item,base) in enumerate(zip(decoded,candidates)):
            x,y=item['anchors'].unbind(1)
            assert torch.equal(item['raw'][:,4],output['center_logits'][b,0,y,x].sigmoid())
            lookup={tuple(q):i for i,q in enumerate(base['anchors'].tolist())}
            assert torch.equal(item['raw'][:,:4],base['raw'][[lookup[tuple(q)] for q in item['anchors'].tolist()],:4])
    assert any(not torch.equal(v,initial[name]) for name,v in best['model'].items() if name.startswith('backbone.encoders.'))
    buffers_fixed(model,initial);blocks=mechanisms(model);functional=functional_responses(model)
    numeric=numerical_check(model);dc=actual_dc(model)
    actual_condition=actual_source_condition_variation(model,bound['recipe'])
    for name,module in model.population_modules():assert module.use_population==(name!='backbone.final.1')
    manifest=json.loads((HOME/f'epoch_{epoch:02d}_prediction_manifest.json').read_text(encoding='utf-8'))
    assert manifest['trained_checkpoint_sha256']==sha(HOME/f'epoch_{epoch:02d}_training.pt')
    assert manifest['decoder_helper_sha256']==sha(HERE/'anchor_preserving_decode.py')
    frames=json.loads((HOME/'best_source_val_predictions.json').read_text(encoding='utf-8'))['frames']
    assert len(frames)==1801 and validation_summary(frames)==best['source_validation']
    threshold=best['source_validation']['threshold']
    for factor in [4,16]:
        frames=json.loads((HOME/f'epoch_{epoch:02d}_noise{factor}_predictions.json').read_text(encoding='utf-8'))['frames']
        assert len(frames)==24 and metrics(frames,threshold)==best['noise'][str(factor)]['box']
        assert center_metrics(frames,threshold)==best['noise'][str(factor)]['center']
    from irstd_background_center.run import reference_threshold
    frames=json.loads((HOME/f'epoch_{epoch:02d}_swapped_predictions.json').read_text(encoding='utf-8'))['frames']
    assert metrics(frames,reference_threshold())==best['background']['swapped_metrics']
    geometry,per_scale=probe(model,bound['recipe'],bound['size_reference_512'],torch.device('cuda'))
    assert geometry==best['geometry_probe'] and per_scale==best['per_scale']
    assert extreme_probe(model,bound['recipe'],bound['size_reference_512'],torch.device('cuda'))==best['extreme_geometry']
    assert locality_probe(model,bound['recipe'],torch.device('cuda'))==best['T_pair_MSE']<=1e-10
    assert evaluate_mosaics(model,bound['recipe'],bound['size_reference_512'],torch.device('cuda'),threshold)==best['mosaics']
    baseline=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    computed=gates(best,torch.load(GATE_PARENT,map_location='cpu',weights_only=False),baseline)
    assert computed==best['gates']==done['gates'] and all(computed.values())==done['promotion_passed']
    rows=[json.loads((HOME/f'epoch_{e:02d}_row.json').read_text(encoding='utf-8')) for e in range(1,last['epoch']+1)]
    assert max(rows,key=row_key)['epoch']==epoch
    assert all(torch.equal(v.cpu(),best['model'][name]) for name,v in model.state_dict().items())
    result={'passed':True,'promotion_passed':done['promotion_passed'],'checkpoint_sha256':sha(HOME/'best.pt'),
        'selected_epoch':epoch,'selected_updates':best['updates'],'total_updates':last['updates'],
        'parameters':808952,'optimizer_state_count':len(names),'all_population_buffers_unchanged':True,
        'source_metrics_recalculated':True,'geometry_remeasured':True,'T_pair_MSE':best['T_pair_MSE'],
        'REBlocks':blocks,'functional_C_output_responses':functional,'numerical_encoder_checks':numeric,
        'actual_CUDA_constant_kernel_response':dc,'actual_source_C_mixture_variation':actual_condition,'teacher_checkpoints_bound':True,
        'gates':computed,'script_sha256':sha(__file__),'updated_at':now()}
    write_json(HOME/'independent_audit.json',result)
    print(json.dumps({'audit_passed':True,'promotion_passed':result['promotion_passed'],'selected_epoch':epoch,'gates':computed}),flush=True)


if __name__=='__main__':main()
