"""Measure actual source-val noise detection and geometry before further training."""
import hashlib
import json
from pathlib import Path
import sys
import torch

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path[:0]=[str(ROOT),str(HOME)]
from irstd_noise_center.data import validation_loader
from irstd_t_size.model import TSizeModel
from irstd_v2.evaluate import evaluate
from irstd_adapter import targets,model_config
from irstd.data.targets import gather_centers
from evaluation import metrics
from center_metric_diagnostic import center_metrics
from irstd_v2.settings import write_json,now
import benchmark_fastdecode as fast


@torch.inference_mode()
def assess(model,cfg,reference,threshold,folder,label):
    result={}
    for factor in [4,16]:
        loader=validation_loader(cfg,factor)
        frames=evaluate(model,loader,torch.device('cuda'),reference,folder/f'{label}_noise{factor}_predictions.json')
        absolute=0.;center_error=0.;n=0
        for images,samples in loader:
            t=targets(samples,model_config(),reference,torch.device('cuda'),'shared_regression');out=model(images.cuda())
            raw=gather_centers(out['log_size'],t['anchors']);ref=raw.new_tensor(reference)
            decoded=torch.minimum(raw.clamp_min(-20),(raw.new_tensor([512,512])/ref).log())
            absolute+=float((decoded-t['sizes']).abs().sum());n+=len(raw)
            offset=gather_centers(out['offsets'],t['anchors']).clamp(0,1-1e-6)
            center_error+=float((offset-t['offsets']).abs().sum())
        result[str(factor)]={'box':metrics(frames,threshold),'center':center_metrics(frames,threshold),
            'GT_anchor_log_size_MAE':absolute/(2*n),'GT_anchor_decoded_offset_MAE':center_error/(2*n)}
    return result


def main():
    folder=HOME/'noise_validation_diagnostic';folder.mkdir(exist_ok=True)
    torch.set_num_threads(3);torch.backends.cudnn.benchmark=False;fast.install()
    checkpoint=HOME/'background_center_interpolation_refine_v1/best.pt';state=torch.load(checkpoint,map_location='cpu',weights_only=False)
    cfg=state['config']['recipe'];model=TSizeModel(cfg).cuda().eval();model.load_state_dict(state['model'])
    reference=state['config']['size_reference_512'];threshold=state['source_validation']['threshold']
    result=assess(model,cfg,reference,threshold,folder,'parent')
    report={'scope':'fixed24 source-val noise stress, independent noise seeds; no target fitting and no model training',
        'checkpoint_sha256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),'results':result,'updated_at':now()}
    write_json(folder/'baseline.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
