"""Matched source-native size prior for the original single-frame AA-YOLO."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import argparse
import json
from pathlib import Path
import sys
import time
import torch
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(ROOT/'cache/matplotlib'))
os.environ.setdefault('TORCH_HOME', str(ROOT/'cache/torch'))
sys.path[:0] = [str(ROOT), str(HERE), str(ROOT.parent/'IRSTD/src')]
from native_unit_prior_evaluation import source_statistics, geometry_check, apply_prior, sha
from model_adapter import build
from data_pipeline import VideoData, collate, worker_seed
from evaluation import decode, postprocess, match_frame, metrics
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json, now, split_hashes
from benchmark_cluster_bootstrap import cluster_ci
from benchmark_progress import ReportingLoader


def loader(domain, split):
    return DataLoader(VideoData(domain, split, 'AA-YOLO'), batch_size=4, num_workers=2,
        collate_fn=collate, worker_init_fn=worker_seed, persistent_workers=False, pin_memory=False)


@torch.inference_mode()
def evaluate(model, data, stats, path, source_check=False):
    frames, predictions, original = [], [], []
    for images, _, _, indices, transforms in data:
        raw_predictions = decode('AA-YOLO', model(images.cuda().float()/255))
        for raw, index, transform in zip(raw_predictions, indices, transforms):
            record = data.dataset.records[index]
            if source_check:
                original.append(match_frame(postprocess(raw, record, transform), record))
            prediction = postprocess(apply_prior(raw, transform, stats, 'native_constant'), record, transform)
            frames.append(match_frame(prediction, record))
            predictions.extend({'image_id': record['id'], 'category_id': 1,
                'bbox': [x, y, x2-x, y2-y], 'score': score} for x, y, x2, y2, score in prediction.tolist())
    payload = {'frames': frames, 'predictions': predictions}
    if source_check:
        payload['original_frames'] = original
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(payload, separators=(',', ':')), encoding='utf-8')
    temp.replace(path)
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-only', action='store_true')
    args = parser.parse_args()
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    home = HERE/'native_unit_aa_yolo_native_constant_v1'
    home.mkdir(exist_ok=True)
    checkpoint = ROOT/'runs/AA-YOLO/DAUB-R/seed_3407/best.pt'
    state = torch.load(checkpoint, map_location='cpu', weights_only=False)
    for split, digest in state['config']['split_hashes'].items():
        assert sha(ROOT/f'splits/DAUB-R_{split}.json') == digest
    assert state['config']['pretrained'] is False and state['config']['frames'] == 1
    stats = source_statistics()
    geometry_check(stats)
    repo = ROOT/'repositories/AA-YOLO'
    sources = [ROOT/'model_adapter.py', ROOT/'data_pipeline.py', ROOT/'evaluation.py',
               ROOT/'benchmark_progress.py', ROOT/'benchmark_cluster_bootstrap.py',
               *repo.rglob('*.py'), *repo.rglob('*.yaml')]
    identity = {'model': 'AA-YOLO', 'source': 'DAUB-R', 'seed': 3407, 'prior': 'native_constant',
                'checkpoint_sha256': sha(checkpoint), 'source_statistics': stats, 'split_hashes': split_hashes(),
                'script_sha256': sha(__file__), 'source_hashes': {str(p.relative_to(ROOT)): sha(p) for p in sources},
                'optimization_updates': 0, 'role': 'matched diagnostic, source-native8 prior, not paper-score/SOTA confirmation'}
    if (home/'config.json').exists():
        assert json.loads((home/'config.json').read_text(encoding='utf-8')) == identity
    else:
        write_json(home/'config.json', identity)
    model, criterion = build('AA-YOLO')
    del criterion
    model.cuda().eval()
    model.load_state_dict(state['model'], strict=True)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    path = home/'source_val_predictions.json'
    payload = json.loads(path.read_text(encoding='utf-8')) if path.exists() else evaluate(model,
        ReportingLoader(loader('DAUB-R', 'val'), home/'progress.json', 'source_val'), stats, path, True)
    original = validation_summary(payload['original_frames'])
    assert abs(original['pooled']['AP50'] - state['source_val_AP50']) < 1e-6, 'original source AP failed reproduction'
    old_threshold = json.loads((checkpoint.parent/'source_threshold.json').read_text(encoding='utf-8'))
    assert old_threshold['epoch'] == state['epoch']+1
    assert abs(original['threshold']-old_threshold['threshold']) < 1e-6
    source = validation_summary(payload['frames'])
    write_json(home/'source_validation.json', source)
    write_json(home/'source_reproduction.json', {'passed': True, 'original_source_validation': original,
        'checkpoint_source_AP50': state['source_val_AP50'], 'original_source_threshold': old_threshold})
    write_json(home/'source_complete.json', {'status': 'completed', 'source_validation': source,
        'original_source_reproduction_passed': True, 'optimization_updates': 0, 'updated_at': now()})
    threshold = source['threshold']
    if args.source_only:
        return
    test = home/'frozen_four_domain_test'
    test.mkdir(exist_ok=True)
    manifest = {**identity, 'threshold': threshold, 'source_predictions_sha256': sha(path)}
    path = test/'freeze_manifest.json'
    if path.exists():
        assert json.loads(path.read_text(encoding='utf-8')) == manifest
    else:
        write_json(path, manifest)
    results = []
    for domain in ['DAUB-R', 'IRDST-H', 'IRSTD-UAV', 'ITSDT-15K']:
        path = test/f'{domain}_metrics.json'
        if path.exists():
            result = json.loads(path.read_text(encoding='utf-8'))
        else:
            started = time.perf_counter()
            predictions = test/f'{domain}_predictions.json'
            frames = json.loads(predictions.read_text(encoding='utf-8'))['frames'] if predictions.exists() else evaluate(model,
                ReportingLoader(loader(domain, 'test'), test/'progress.json', domain), stats, predictions)['frames']
            overall = metrics(frames, threshold)
            ci = cluster_ci(frames)
            if ci is not None:
                overall['AP50_cluster_CI95'] = ci
            result = {'source': 'DAUB-R', 'target': domain, 'seed': 3407, 'overall': overall,
                      'by_group': {g: metrics([f for f in frames if f['group'] == g], threshold) for g in sorted({f['group'] for f in frames})},
                      'elapsed_seconds': time.perf_counter()-started, 'updated_at': now()}
            write_json(path, result)
        results.append(result)
        assert sha(checkpoint) == identity['checkpoint_sha256']
        print(json.dumps({'target': domain, **result['overall']}), flush=True)
    assert all(torch.equal(v.cpu(), state['model'][k]) for k, v in model.state_dict().items())
    for name, digest in identity['source_hashes'].items():
        assert sha(ROOT/name) == digest, name
    cross = [r['overall'] for r in results if r['target'] != 'DAUB-R']
    summary = {'status': 'completed', 'source': 'DAUB-R', 'seed': 3407, 'completed_cells': 4,
               'cross_domain_macro': {k: sum(r[k] for r in cross)/3 for k in ['AP50', 'AP50_95', 'F1', 'center_Pd_3px']},
               'all_tensors_unchanged': True, 'optimization_updates': 0, 'role': identity['role'], 'updated_at': now()}
    write_json(test/'summary.json', summary)
    write_json(test/'progress.json', summary)


if __name__ == '__main__':
    main()
