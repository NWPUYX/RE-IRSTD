"""Source-selected monotone per-image score offset; exact cached-box rescore."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now
from evaluation import metrics
from benchmark_cluster_bootstrap import cluster_ci


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def descriptor(stage):
    if stage=='robust_raw':return HERE/'robust_T_composed_v1/epoch_01_predictions.json',HERE/'robust_T_sourceAP_control_v1/frozen_four_domain_test'
    return HERE/stage/'source_val_predictions.json',HERE/stage/'frozen_four_domain_test'


def logit(scores):
    p=np.clip(np.asarray(scores,dtype=np.float64),1e-12,1-1e-12)
    return np.log(p)-np.log1p(-p)


def reference(frames):
    centers=[float(np.median(logit(f['scores']))) for f in frames if len(f['scores'])>=20]
    return float(np.median(centers)) if centers else 0.,len(centers)


def transform(frames,alpha,source_center):
    if alpha==0:return frames
    result=[]
    for f in frames:
        old=logit(f['scores']);center=float(np.median(old)) if len(old)>=20 else source_center
        adjusted=old-alpha*(center-source_center)
        values=1/(1+np.exp(-np.clip(adjusted,-700,700)));keep=values>=1e-5
        assert np.all(np.diff(values)<=1e-12)
        ids=np.flatnonzero(keep)
        # The transform is monotone within an image. NMS and the confidence-
        # ordered matching of retained predictions therefore do not change.
        result.append({**f,'scores':values[keep].tolist(),'tp':[f['tp'][i] for i in ids],
            'center_tp':[f['center_tp'][i] for i in ids]})
    return result


def payload(source,alpha,source_center):
    result=transform(source['frames'],alpha,source_center)
    if alpha==0:return source
    output=[];offset=0
    for old,new in zip(source['frames'],result):
        n=len(old['scores']);pred=source['predictions'][offset:offset+n];offset+=n
        assert [p['score'] for p in pred]==old['scores']
        original=logit(old['scores']);center=float(np.median(original)) if n>=20 else source_center
        values=1/(1+np.exp(-np.clip(original-alpha*(center-source_center),-700,700)))
        output.extend({**p,'score':float(s)} for p,s in zip(pred,values) if s>=1e-5)
        assert len(new['scores'])==int((values>=1e-5).sum())
    assert offset==len(source['predictions'])
    return {'frames':result,'predictions':output}


def eligible(v,base):
    if v['pooled']['AP50']<base['pooled']['AP50'] or v['pooled']['F1']<base['pooled']['F1']:return False
    for key in ['AP50','AP50_95']:
        if v['pooled'][key]<base['pooled'][key]-.005:return False
        if any(v['by_group'][g][key]<b[key]-.005 for g,b in base['by_group'].items()):return False
    return True


def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',required=True);p.add_argument('--source-only',action='store_true');a=p.parse_args()
    assert a.stage=='robust_raw' or (a.stage.startswith('native_unit_') and '/' not in a.stage and '\\' not in a.stage)
    source_path,test=descriptor(a.stage);home=HERE/f'score_offset_{a.stage}_v1';home.mkdir(exist_ok=True)
    source=json.loads(source_path.read_text(encoding='utf-8'));base=validation_summary(source['frames']);center,count=reference(source['frames'])
    rows=[];winner=None
    for alpha in [0.,.5,1.]:
        frames=transform(source['frames'],alpha,center);v=validation_summary(frames)
        if alpha==0:assert v==base and frames is source['frames']
        row={'alpha':alpha,'source_validation':v,'eligible':eligible(v,base)};rows.append(row)
        key=(row['eligible'],v['pooled']['AP50'],v['pooled']['F1'])
        if winner is None or key>winner[0]:winner=(key,row)
    selected=winner[1];alpha=selected['alpha'];assert selected['eligible']
    identity={'input_stage':a.stage,'source_predictions_sha256':sha(source_path),'script_sha256':sha(__file__),
        'source_median_logit_center':center,'eligible_source_images':count,'minimum_candidates':20,
        'selected_alpha':alpha,'threshold':selected['source_validation']['threshold'],'alpha_grid':[0.,.5,1.],
        'source_selection':'pooled AP50 then F1, requiring nondecreasing pooled AP/F1 and <=0.5pp per-group fine loss',
        'proposal_policy':'original proposal floor/cap/NMS first; monotone post-NMS score offset; final floor1e-5',
        'optimization_updates':0,'role':'source-selected score-calibration diagnostic, not independent confirmation/SOTA proof'}
    if (home/'freeze_manifest.json').exists():assert json.loads((home/'freeze_manifest.json').read_text(encoding='utf-8'))==identity
    else:write_json(home/'freeze_manifest.json',identity)
    write_json(home/'source_selection.json',{'baseline':base,'candidates':rows,'selected':selected,'updated_at':now()})
    calibrated=payload(source,alpha,center);assert validation_summary(calibrated['frames'])==selected['source_validation']
    (home/'source_val_predictions.json').write_text(json.dumps(calibrated,separators=(',',':')),encoding='utf-8')
    print(json.dumps({'selected_alpha':alpha,'source_AP50':selected['source_validation']['pooled']['AP50'],
        'source_F1':selected['source_validation']['pooled']['F1'],'baseline_AP50':base['pooled']['AP50'],'baseline_F1':base['pooled']['F1']}),flush=True)
    if a.source_only:return
    folder=home/'frozen_four_domain_test';folder.mkdir(exist_ok=True);results=[]
    for target in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=test/f'{target}_predictions.json'
        if not path.exists():continue
        destination=folder/f'{target}_metrics.json'
        if destination.exists():value=json.loads(destination.read_text(encoding='utf-8'))
        else:
            converted=payload(json.loads(path.read_text(encoding='utf-8')),alpha,center);frames=converted['frames']
            (folder/f'{target}_predictions.json').write_text(json.dumps(converted,separators=(',',':')),encoding='utf-8')
            score=metrics(frames,identity['threshold']);ci=cluster_ci(frames)
            if ci is not None:score['AP50_cluster_CI95']=ci
            value={'source':'DAUB-R','target':target,'seed':3407,'overall':score,'input_predictions_sha256':sha(path),
                'by_group':{g:metrics([f for f in frames if f['group']==g],identity['threshold']) for g in sorted({f['group'] for f in frames})},'updated_at':now()}
            write_json(destination,value)
        results.append(value);print(json.dumps({'target':target,**value['overall']}),flush=True)
    if len(results)==4:
        cross=[r['overall'] for r in results if r['target']!='DAUB-R']
        summary={'status':'completed','source':'DAUB-R','seed':3407,'completed_cells':4,
            'cross_domain_macro':{k:sum(r[k] for r in cross)/3 for k in ['AP50','AP50_95','F1','center_Pd_3px']},'updated_at':now()}
        write_json(folder/'summary.json',summary);write_json(folder/'progress.json',summary)


if __name__=='__main__':main()
