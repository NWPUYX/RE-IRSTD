"""Source-only fixed-proposal confidence standardization screen, no SGD."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from stable_evidence_source_cohort import NativeCohort
from irstd_background_center.data import swapped_loader
from irstd_noise_center.data import validation_loader
from irstd_v2.data import collate
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json, now, split_hashes
from evaluation import postprocess, match_frame, metrics
from irstd.inference.decoder import decode
from native_unit_prior_evaluation import build, source_statistics, apply_prior
from score_offset_calibration import logit
import benchmark_fastdecode as fast


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def convert(frames, statistics, alpha):
    if alpha == 0:
        return frames
    out = []
    for frame, stat in zip(frames, statistics):
        old = logit(frame['scores'])
        standardized = (old-stat['mean']) / max(stat['sigma'], .25)
        mixed = (1-alpha)*old + alpha*standardized
        score = 1/(1+np.exp(-np.clip(mixed, -700, 700)))
        assert np.all(np.diff(score) <= 1e-12)
        keep = np.flatnonzero(score >= 1e-5)
        out.append({**frame, 'scores': score[keep].tolist(),
                    'tp': [frame['tp'][j] for j in keep],
                    'center_tp': [frame['center_tp'][j] for j in keep]})
    return out


@torch.inference_mode()
def collect(model, loader, stats):
    frames, statistics = [], []
    for images, samples in loader:
        valid = torch.stack([s['valid_mask'] for s in samples]).cuda()
        output = model(images.cuda(), valid_mask=valid)
        decoded = decode(output, 1e-5, {'box_nms_iou': None}, stats['input_median'])
        for b, (proposal, sample) in enumerate(zip(decoded, samples)):
            values = output['center_logits'][b, 0][valid[b, 0]].double()
            statistics.append({'mean': float(values.mean()), 'sigma': float(values.std(unbiased=False)),
                               'record_index': sample['record_index']})
            center, score = proposal['centers'].cuda(), proposal['scores'].cuda()
            raw = torch.cat((center, torch.ones_like(center), score[:, None], torch.ones_like(score[:, None])), 1)
            raw = apply_prior(raw, sample['trans'], stats, 'native_constant')
            record = loader.dataset.records[sample['record_index']]
            frames.append(match_frame(postprocess(raw, record, sample['trans']), record))
    assert len(frames) == len(statistics) == 24
    return {'frames': frames, 'statistics': statistics}


def qualified(row, base):
    n, b = row['native'], base['native']
    if any(n[k] < b[k]-.005 for k in ['AP50', 'AP50_95']) or n['F1'] < b['F1']-.02:
        return False
    if row['background']['AP50'] < base['background']['AP50']-.005 or row['background']['F1'] < base['background']['F1']-.02:
        return False
    if row['noise4']['AP50'] < base['noise4']['AP50']-.005 or row['noise4']['F1'] < base['noise4']['F1']:
        return False
    return row['noise16']['AP50'] >= base['noise16']['AP50']-.005 and row['noise16']['F1'] >= base['noise16']['F1']+.10


def main():
    folder = HERE/'global_logit_cohort_v1'
    folder.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    fast.install()
    model, state, recipe, checkpoint = build('irstd_robust')
    identity = {'checkpoint_sha256': sha(checkpoint), 'script_sha256': sha(__file__),
                'evaluation_sha256': sha(ROOT/'evaluation.py'), 'split_hashes': split_hashes(),
                'noise_views_sha256': sha(HERE/'classification_feature_probe.py'),
                'source_statistics': source_statistics(), 'sigma_floor': .25, 'alpha_grid': [0, .5, 1],
                'optimization_updates': 0, 'scope': 'source24 native/background/noise4/noise16; no targets'}
    if (folder/'config.json').exists():
        assert json.loads((folder/'config.json').read_text(encoding='utf-8')) == identity
    else:
        write_json(folder/'config.json', identity)
    cache = {}
    for view in ['native', 'background', 'noise4', 'noise16']:
        path = folder/f'{view}_cache.json'
        if path.exists():
            cache[view] = json.loads(path.read_text(encoding='utf-8'))
            continue
        if view == 'native':
            loader = DataLoader(NativeCohort(recipe), batch_size=4, num_workers=2, collate_fn=collate)
        elif view == 'background':
            loader = swapped_loader(recipe)
        else:
            loader = validation_loader(recipe, int(view.removeprefix('noise')))
        write_json(folder/'progress.json', {'status': 'evaluating_source_cohort', 'view': view, 'updated_at': now()})
        cache[view] = collect(model, loader, identity['source_statistics'])
        write_json(path, cache[view])
    candidates = []
    for alpha in identity['alpha_grid']:
        native = convert(cache['native']['frames'], cache['native']['statistics'], alpha)
        validation = validation_summary(native)
        threshold = validation['threshold']
        row = {'alpha': alpha, 'threshold': threshold, 'native': validation['pooled']}
        for view in ['background', 'noise4', 'noise16']:
            row[view] = metrics(convert(cache[view]['frames'], cache[view]['statistics'], alpha), threshold)
        candidates.append(row)
    base = candidates[0]
    assert base['native'] == validation_summary(cache['native']['frames'])['pooled']
    for row in candidates:
        row['qualified'] = row['alpha'] != 0 and qualified(row, base)
    eligible = [r for r in candidates if r['qualified']]
    selected = max(eligible, key=lambda r: tuple(np.mean([r[v][k] for v in ['background', 'noise4', 'noise16']]) for k in ['AP50', 'F1'])) if eligible else None
    assert all(torch.equal(v.cpu(), state['model'][n]) for n, v in model.state_dict().items())
    assert sha(checkpoint) == identity['checkpoint_sha256']
    report = {'status': 'completed', 'candidates': candidates, 'selected_alpha': selected['alpha'] if selected else None,
              'all_tensors_unchanged': True, 'optimization_updates': 0, 'updated_at': now(),
              'scope': identity['scope'], 'next': 'full source verification required' if selected else 'rejected; no target test'}
    write_json(folder/'result.json', report)
    write_json(folder/'progress.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
