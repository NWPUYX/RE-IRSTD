"""CPU audit of matched MPR inputs against the original benchmark loader."""
import importlib.metadata
import json
from pathlib import Path
import random
import subprocess
import sys
import torch

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from mpr_matched.data import MotionData
from data_pipeline import VideoData
from irstd_v2.settings import write_json,now


def main():
    checked=[]
    for split in ['train','val']:
        adapted=MotionData('DAUB-R',split,train=split=='train')
        original=VideoData('DAUB-R',split,'MPR-Net',train=split=='train')
        for i in [0,len(adapted)//2,len(adapted)-1]:
            for seed in [0,1]:
                random.seed(seed);image,prior,target,index,tr=adapted[i]
                random.seed(seed);video,expected,_,old_i,old_tr=original[i]
                assert torch.equal(image[:,0],video[:,-1].float()/255)
                assert torch.equal(target,expected) and index==old_i and tr==old_tr
                assert prior.shape==(3,1,512,512) and torch.equal(prior[0],prior[1])
                assert torch.isfinite(prior).all() and float(prior.min())>=0 and float(prior.max())<=1
                checked.append({'split':split,'index':i,'flip_rng_seed':seed})
    sys.path.insert(0,str(ROOT/'vendor_sota'))
    versions={}
    for package in ['torch','numpy','opencv-python','scipy','einops','torch-geometric','ftfy','regex','torch-dct']:
        try:versions[package]=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:versions[package]=None
    commits={name:subprocess.check_output(['git','-C',str(ROOT/'repositories'/name),'rev-parse','HEAD'],text=True).strip() for name in ['MPR-Net','CLIP','MI-DETR','TY-RIST']}
    result={'passed':True,'current_frame_and_target_equal_original_loader':True,'checked_cases':checked,
        'temporal_input':'Only the last image is consumed by the public MPR forward; two past frames enter cached EMM',
        'versions':versions,'python':sys.version,'repository_commits':commits,'updated_at':now()}
    write_json(HOME/'mpr_data_audit.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
