"""Supplementary center metrics from frozen box-pipeline candidates."""
import json
from pathlib import Path
import sys
import numpy as np

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_v2.settings import write_json,now


def center_metrics(frames,threshold):
    scores=np.concatenate([np.asarray(f['scores']) for f in frames])
    tp=np.concatenate([np.asarray(f['center_tp'],dtype=bool) for f in frames])
    order=np.argsort(-scores,kind='stable');scores=scores[order];tp=tp[order]
    total=sum(f['gt'] for f in frames);hit=np.flatnonzero(tp);ap=0.
    if len(hit) and total:
        cumulative=np.arange(1,len(hit)+1);recall=cumulative/total;precision=cumulative/(hit+1)
        envelope=np.maximum.accumulate(precision[::-1])[::-1];index=np.searchsorted(recall,np.linspace(0,1,101),side='left')
        values=np.zeros(101);valid=index<len(envelope);values[valid]=envelope[index[valid]];ap=float(values.mean())
    selected=scores>=threshold;det=int(selected.sum());correct=int(tp[selected].sum())
    return {'center_AP3px':ap,'center_F1_at_source_box_threshold':2*correct/(det+total) if det+total else 0.,
        'center_Recall_at_source_box_threshold':correct/total if total else 0.,
        'center_FP_per_frame':(det-correct)/len(frames),'detections_at_threshold':det}


def main():
    locations={
        'IRSTD_v1_DAUB':ROOT/'runs/IRSTD/DAUB-R/seed_3407',
        'IRSTD_T_DAUB':HOME/'native_precision_w4_v1/frozen_four_domain_test',
        'MPR_matched_DAUB':HOME/'mpr_causal_DAUB_3407/frozen_four_domain_test',
        'IRSTD_v1_IRDST':ROOT/'runs/IRSTD/IRDST-H/seed_3407',
        'IRSTD_decode_IRDST':HOME/'IRDST_decode_consistent_size_v2/frozen_four_domain_test',
        'IRSTD_BG_DAUB':HOME/'background_center_interpolation_refine_v1/frozen_four_domain_test',
        'IRSTD_padding_DAUB':HOME/'P3_padding_review_v1/frozen_four_domain_test'}
    rows=[]
    for name,folder in locations.items():
        for target in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
            prefix='test_' if name.startswith('IRSTD_v1_') else ''
            metric=folder/f'{prefix}{target}_metrics.json';pred=folder/f'{prefix}{target}_predictions.json'
            if not metric.exists() or not pred.exists():continue
            value=json.loads(metric.read_text(encoding='utf-8'))['overall']
            frames=json.loads(pred.read_text(encoding='utf-8'))['frames']
            result=center_metrics(frames,value['threshold'])
            assert result['center_Recall_at_source_box_threshold']==value['center_Pd_3px']
            rows.append({'model':name,'target':target,'box_AP50':value['AP50'],'box_F1':value['F1'],**result})
    write_json(HOME/'center_metric_diagnostic.json',{'scope':'Supplementary diagnostic on the same frozen box-NMS candidates; no label/threshold changes',
        'results':rows,'updated_at':now()})
    lines=['# 中心检出与框匹配补充分解','','[KNOWN｜HIGH] 使用既有冻结候选、框NMS和原源框F1阈值；中心距离门槛仍为原图3像素。没有改动冻结标签或主AP50/F1协议。中心AP为诊断补充，不冒充新的最终测试方案。','',
        '| 模型/源 | 目标 | 框AP50 | 中心AP3px | 框F1 | 中心F1 |','|---|---|---:|---:|---:|---:|']
    for r in rows:lines.append(f"| {r['model']} | {r['target']} | {r['box_AP50']*100:.4f}% | {r['center_AP3px']*100:.4f}% | {r['box_F1']*100:.4f}% | {r['center_F1_at_source_box_threshold']*100:.4f}% |")
    (HOME/'中心与框指标分解.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps({'cells':len(rows),'results':rows}),flush=True)


if __name__=='__main__':main()
