import json
from pathlib import Path
import sys
import time
import numpy as np

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from evaluation import arrays,ap101
from benchmark_cluster_bootstrap import prepared,weighted_ap,cluster_ci
from irstd_v2.settings import write_json,now


def main():
    folder=HOME/'native_precision_w4_v1/frozen_four_domain_test'
    frames=json.loads((folder/'DAUB-R_predictions.json').read_text(encoding='utf-8'))['frames']
    names=sorted({f['group'] for f in frames});lookup={g:i for i,g in enumerate(names)}
    scores,tp,_,total=arrays(frames)
    raw_scores=np.concatenate([np.asarray(f['scores']) for f in frames])
    pg=np.concatenate([np.full(len(f['scores']),lookup[f['group']],dtype=int) for f in frames])[np.argsort(-raw_scores,kind='stable')]
    prep=prepared(frames,names);rng=np.random.default_rng(3407);checked=0
    for _ in range(6):
        counts=np.bincount(rng.integers(0,len(names),len(names)),minlength=len(names));den=float(prep[3]@counts)
        a=ap101(tp,den,counts[pg])[0];b=weighted_ap(prep,counts);assert a==b,(a,b);checked+=1
    original=json.loads((folder/'DAUB-R_metrics.json').read_text(encoding='utf-8'))['overall']['AP50_cluster_CI95']
    tick=time.perf_counter();new=cluster_ci(frames);seconds=time.perf_counter()-tick
    assert original==new,(original,new)
    result={'passed':True,'real_weighted_draws_exactly_equal':checked,'full200_draw_CI_exactly_equal':True,'CI95':new,
        'optimized200_draw_seconds':seconds,'scope':'AP50 scene-group CI only; detection scores and AP computation unchanged','updated_at':now()}
    write_json(HOME/'bootstrap_equivalence.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
