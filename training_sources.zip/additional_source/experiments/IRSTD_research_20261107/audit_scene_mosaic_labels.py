"""Before training: prove every mosaic donor retains coordinates and supervision."""
import json
from pathlib import Path
import sys
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_scene_scale.run import HOME,INITIAL,construct,losses,sha
from irstd_scene_scale.data import training_loader
from irstd_background_center.data import collate_pairs
from irstd_v2.data import original_boxes
from irstd_adapter import targets,model_config
from irstd_v2.settings import write_json,now


def main():
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark=False
    preflight=json.loads((HOME/'preflight.json').read_text(encoding='utf-8'))
    cfg=preflight['identity']['recipe'];reference=preflight['identity']['size_reference_512']
    initial=torch.load(INITIAL,map_location='cpu',weights_only=False)['model']
    device=torch.device('cuda');model,teacher,_=construct(cfg,initial,device)
    dataset=training_loader(cfg).dataset;dataset.epoch=1
    checked=[]
    for index in [13,3,8]:
        images,samples=collate_pairs([dataset[index]])
        augmented=samples[1];k=augmented['mosaic_grid'];expected=[]
        assert augmented['mosaic_split']=='source_train'
        for source_index,(sx,sy,tx,ty) in zip(augmented['mosaic_indices'],augmented['mosaic_transforms']):
            boxes=original_boxes(dataset.records[source_index]);boxes[:,[0,2]]=boxes[:,[0,2]]*sx+tx;boxes[:,[1,3]]=boxes[:,[1,3]]*sy+ty
            expected.append(torch.cat((torch.minimum(boxes[:,:2],boxes[:,2:]),torch.maximum(boxes[:,:2],boxes[:,2:])),1))
        expected=torch.cat(expected)
        assert torch.allclose(expected,augmented['boxes'],atol=1e-4,rtol=0)
        t=targets(samples,model_config(),reference,device,'shared_regression')
        assert len(t['anchors'])==sum(len(s['boxes']) for s in samples)
        captured=[]
        def hook(module,args,out):
            out['center_logits'].retain_grad();out['log_size'].retain_grad();captured.append(out)
        handle=model.register_forward_hook(hook)
        try:
            model.zero_grad(set_to_none=True)
            loss,terms,_=losses(model,teacher,images,samples,reference,cfg,device)
            loss.backward()
        finally:handle.remove()
        assert len(captured)==1
        out=captured[0];anchors=t['anchors'][t['anchors'][:,0]==1]
        for _,x,y in anchors.tolist():assert out['center_logits'].grad[1,0,y,x]!=0
        donor_anchors=anchors[augmented['recipient_target_count']:]
        assert len(donor_anchors)==k*k-1
        size_gradient=sum(float(out['log_size'].grad[1,:,y,x].abs().sum()) for _,x,y in donor_anchors.tolist())
        assert size_gradient>0 and all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
        checked.append({'grid':k,'source_boxes':len(anchors),'donor_boxes':len(donor_anchors),
                        'donor_center_gradients_nonzero':True,'donor_size_gradient_abs_sum':size_gradient,'loss':float(loss.detach())})
        del captured,out
    assert all(torch.equal(v.cpu(),initial[n]) for n,v in model.state_dict().items())
    assert all(torch.equal(v.cpu(),initial[n]) for n,v in teacher.state_dict().items())
    write_json(HOME/'mosaic_label_gradient_audit.json',{'passed':True,'checked':checked,
        'optimization_updates':0,'all_coordinates_preserved':True,'all_source_train_only':True,
        'all_weights_and_buffers_unchanged':True,'script_sha256':sha(__file__),
        'preflight_sha256':sha(HOME/'preflight.json'),'updated_at':now()})
    print(json.dumps(checked),flush=True)


if __name__=='__main__':main()
