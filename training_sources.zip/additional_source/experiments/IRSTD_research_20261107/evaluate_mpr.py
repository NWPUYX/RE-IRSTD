"""Freeze the completed matched-causal strong baseline before target tests."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import hashlib
import json
from pathlib import Path
import sys
import time
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from mpr_matched.model import build
from mpr_matched.data import loader
from mpr_matched.run import evaluate
from evaluation import metrics,select_threshold
from irstd_v2.settings import write_json,now,split_hashes


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    home=HERE/'mpr_causal_DAUB_3407';folder=home/'frozen_four_domain_test';folder.mkdir(exist_ok=True)
    assert json.loads((home/'training_complete.json').read_text(encoding='utf-8'))['completed']
    state=torch.load(home/'best.pt',map_location='cpu',weights_only=False);cfg=state['config']
    assert split_hashes()==cfg['split_hashes']
    for name,digest in cfg['source_hashes'].items():assert sha(ROOT/name)==digest,name
    source_frames=json.loads((home/f"source_val_epoch_{state['epoch']:03d}.json").read_text(encoding='utf-8'))['frames']
    threshold=select_threshold(source_frames);assert metrics(source_frames,threshold)==state['validation']
    manifest={'checkpoint_sha256':sha(home/'best.pt'),'epoch':state['epoch'],'source':cfg['source'],'seed':cfg['seed'],
        'threshold':threshold,'split_hashes':split_hashes(),'script_sha256':sha(__file__),
        'protocol_label':cfg['protocol_label'],'external_pretraining':cfg['external_pretraining']}
    if (folder/'freeze_manifest.json').exists():assert json.loads((folder/'freeze_manifest.json').read_text(encoding='utf-8'))==manifest
    else:write_json(folder/'freeze_manifest.json',manifest)
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;device=torch.device('cuda')
    model,_=build();model.to(device);model.load_state_dict(state['model']);model.eval()
    for p in model.parameters():p.requires_grad_(False)
    rows=[]
    for target in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=folder/f'{target}_metrics.json'
        if path.exists():result=json.loads(path.read_text(encoding='utf-8'))
        else:
            write_json(folder/'progress.json',{'status':'evaluating','target':target,'updated_at':now()});tick=time.perf_counter()
            frames=evaluate(model,loader(target,'test'),device,folder/f'{target}_predictions.json')
            result={'source':cfg['source'],'target':target,'seed':cfg['seed'],'checkpoint_sha256':manifest['checkpoint_sha256'],
                'overall':metrics(frames,threshold,bootstrap=200),
                'by_group':{g:metrics([r for r in frames if r['group']==g],threshold) for g in sorted({r['group'] for r in frames})},
                'elapsed_seconds':time.perf_counter()-tick,'updated_at':now()}
            assert sha(home/'best.pt')==manifest['checkpoint_sha256'];write_json(path,result)
        rows.append(result);print(json.dumps({'target':target,**result['overall']}),flush=True)
    cross=[r['overall'] for r in rows if r['target']!=cfg['source']]
    summary={'status':'completed','source':cfg['source'],'seed':cfg['seed'],'completed_cells':len(rows),
        'cross_domain_macro':{k:sum(r[k] for r in cross)/3 for k in ['AP50','AP50_95','F1','center_Pd_3px']},'updated_at':now()}
    write_json(folder/'summary.json',summary);write_json(folder/'progress.json',summary)


if __name__=='__main__':main()
