import json
from pathlib import Path
import sys
import time
import numpy as np
import torch

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_background_center.data import fast_distance,union_swap,Pairs
from irstd.augmentation.background_swap import distance_from_protection
from irstd_v2.data import union_swap as original
from irstd_v2.settings import write_json,now


def main():
    rng=np.random.default_rng(3407);old_time=0.;new_time=0.
    for kind in range(8):
        mask=np.zeros((512,512),dtype=bool)
        if kind==1:mask[:]=True
        if kind>1:
            for _ in range(kind):
                y,x=rng.integers(0,450,2);mask[y:y+44,x:x+44]=True
        tick=time.perf_counter();a=distance_from_protection(mask);old_time+=time.perf_counter()-tick
        tick=time.perf_counter();b=fast_distance(mask);new_time+=time.perf_counter()-tick
        assert np.array_equal(a,b)
    cfg=json.loads((HOME/'native_precision_w4_v1/recipe.json').read_text(encoding='utf-8'));data=Pairs(cfg)
    recipient=data.base.base_sample(100);donor=data.donors.base_sample(2000)
    a=original(recipient,donor,cfg);b=union_swap(recipient,donor,cfg)
    assert all(torch.equal(x,y) for x,y in zip(a,b))
    result={'passed':True,'eight_masks_distance_exactly_equal':True,'real_pair_image_alpha_protection_exactly_equal':True,
        'reference_seconds':old_time,'compiled_seconds':new_time,'speed_ratio':old_time/new_time,'updated_at':now()}
    write_json(HOME/'background_acceleration_equivalence.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
