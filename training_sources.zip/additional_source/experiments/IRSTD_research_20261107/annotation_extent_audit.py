"""Read-only annotation/appearance audit on training records of each corpus."""
from collections import defaultdict
import json
from pathlib import Path
import sys
import numpy as np
from PIL import Image

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'vendor_sota')]
import cv2
from data_pipeline import load_frame
from irstd_v2.settings import write_json,now


def main():
    cv2.setNumThreads(1);rows=[];summary={}
    for source in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        records=json.loads((ROOT/'splits'/f'{source}_train.json').read_text(encoding='utf-8'));groups=defaultdict(list)
        for i,r in enumerate(records):groups[r['group']].append(i)
        ids=[indices[j] for indices in groups.values() for j in np.linspace(0,len(indices)-1,min(3,len(indices)),dtype=int)]
        for i in ids:
            record=records[i];array,tr=load_frame(record['path']);x=np.asarray(Image.fromarray(array).convert('L'),dtype=np.float32)/255
            sx,sy,dx,dy=tr
            for bx,by,bw,bh in record['boxes']:
                cx=(bx+bw/2)*sx+dx;cy=(by+bh/2)*sy+dy;qx=int(cx);qy=int(cy)
                if not (16<=qx<496 and 16<=qy<496):continue
                patch=x[qy-16:qy+17,qx-16:qx+17];yy,xx=np.mgrid[-16:17,-16:17];radius=np.maximum(abs(xx),abs(yy))
                bg=float(np.median(patch[(radius>=10)&(radius<=16)]));contrast=patch-bg
                middle=contrast[13:20,13:20];peak=np.unravel_index(np.abs(middle).argmax(),middle.shape)
                py,px=int(peak[0])+13,int(peak[1])+13;amplitude=float(contrast[py,px])
                if abs(amplitude)<1/255:continue
                polarity=1 if amplitude>0 else -1
                mask=(contrast*polarity>=abs(amplitude)*.5).astype(np.uint8)
                _,components=cv2.connectedComponents(mask,connectivity=8);component=components==components[py,px]
                ys,xs=np.where(component);touch=bool((xs==0).any() or (xs==32).any() or (ys==0).any() or (ys==32).any())
                width=float(xs.max()-xs.min()+1);height=float(ys.max()-ys.min()+1)
                rows.append({'source':source,'group':record['group'],'record_index':i,'label_wh':[bw*sx,bh*sy],
                    'half_peak_component_wh':[width,height],'label_to_component_ratio':[bw*sx/width,bh*sy/height],
                    'touches_patch_border':touch,'peak_contrast':amplitude,'polarity':polarity})
        selected=[r for r in rows if r['source']==source and not r['touches_patch_border']]
        summary[source]={'selected_records':len(ids),'valid_components':len(selected),'border_components':sum(r['source']==source and r['touches_patch_border'] for r in rows),
            'quantiles':{name:np.quantile(np.asarray([r[name] for r in selected]),[.1,.5,.9],axis=0).tolist()
                for name in ['label_wh','half_peak_component_wh','label_to_component_ratio']}}
    report={'scope':'dataset-characterization diagnostic on each corpus training labels only; not model fitting or a benchmark score',
        'method':'33x33 fixed patch, ring median at Chebyshev radius10..16, abs peak within7x7, 8-connected half-peak component',
        'limitations':'intensity component is a proxy, not a physical object mask; edges, clutter and unresolved peaks affect it; excluded patch-border components explicit',
        'summary':summary,'rows':rows,'updated_at':now()}
    write_json(HOME/'annotation_extent_audit.json',report);print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
