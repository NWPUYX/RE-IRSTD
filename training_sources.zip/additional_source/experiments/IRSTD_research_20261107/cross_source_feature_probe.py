"""Predeclared source-train-only T/fused feature tests for the other sources."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import random
import sys
import time
import numpy as np
import torch
from torch.nn import functional as F

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]
sys.path[:0]=[str(ROOT),str(HOME)]
from feature_probe import fit_predict
from irstd_adapter import targets,model_config
from irstd_v2.model import Model
from irstd_v2.data import Data,render,choose_plan
from irstd_v2.settings import write_json,now


@torch.inference_mode()
def run(source,reuse=False):
    destination=HOME/'cross_source_probes'/source;destination.mkdir(parents=True,exist_ok=True)
    cfg=json.loads((ROOT/'experiments/IRSTD_v2/v1_geometry_balanced_direction_2epoch_v1/recipe.json').read_text(encoding='utf-8'))
    # This diagnostic retains continuous tiny boxes; it does not change any
    # training recipe or use target-domain annotations.
    cfg['geometry']['minimum_box_side']=.1
    checkpoint=ROOT/'runs/IRSTD'/source/'seed_3407/best.pt'
    state=torch.load(checkpoint,map_location='cpu',weights_only=False)
    model=Model(cfg).cuda().eval();model.load_state_dict(state['model']);reference=state['config']['size_reference_512']
    data=Data(source,'train',cfg);groups=defaultdict(list)
    for i,r in enumerate(data.records):groups[r['group']].append(i)
    ordered=sorted(groups,key=lambda g:hashlib.sha256(g.encode()).hexdigest())
    holdout=set(ordered[::3]);fit=set(groups)-holdout;assert fit and holdout
    scales=[.6,1.,1.4];screen=dict(cfg['geometry'],maximum_attempts=1)
    ids=[];counts={}
    for group,indices in sorted(groups.items()):
        eligible=[i for i in indices if all(not choose_plan(data.records[i],screen,random.Random(0),forced_scale=s,flip_override=False)['fallback'] for s in scales)]
        counts[group]={'total':len(indices),'eligible':len(eligible)}
        if eligible:
            ids.extend(eligible[j] for j in np.linspace(0,len(eligible)-1,min(6,len(eligible)),dtype=int))
    captured={}
    hook=model.backbone.register_forward_hook(lambda m,a,o:captured.update(fused=o[0],T=o[1]))
    x={'T':[],'fused':[]};ys=[];meta=[];tick=time.perf_counter()
    if reuse:
        saved=np.load(destination/'arrays.npz');x={n:saved[n] for n in x};ys=saved['y']
        meta=json.loads((destination/'metadata.json').read_text(encoding='utf-8'))
    for n,i in enumerate([] if reuse else ids):
        record=data.records[i]
        for scale in scales:
            seed=int.from_bytes(hashlib.sha256(f'cross_source_probe/{source}/{record["id"]}/{scale}'.encode()).digest()[:8],'little')
            plan=choose_plan(record,cfg['geometry'],random.Random(seed),forced_scale=scale,flip_override=False);assert not plan['fallback']
            image,boxes,valid=render(record,plan)
            sample={**data.base_sample(i),'image':image,'boxes':boxes,'valid_mask':valid,'ignore_mask':~valid}
            t=targets([sample],model_config(),reference,torch.device('cuda'),'shared_regression')
            model(image[None].cuda(),valid_mask=valid[None].cuda())
            for name in x:
                f=F.pad(captured[name],(1,1,1,1))
                for b,qx,qy in t['anchors'].cpu().tolist():x[name].append(f[b,:,qy:qy+3,qx:qx+3].flatten().cpu().numpy())
            ys.extend(t['sizes'].cpu().numpy());meta.extend({'group':record['group'],'scale':scale} for _ in t['anchors']);captured.clear()
        if n%20==0:write_json(destination/'progress.json',{'records':n+1,'total_records':len(ids),'updated_at':now()})
    hook.remove();y=np.asarray(ys,dtype=np.float64);train=np.array([r['group'] in fit for r in meta]);hold=~train
    predictions={name:fit_predict(np.asarray(v,dtype=np.float64),y,train) for name,v in x.items()}
    predictions['fit_mean']=np.broadcast_to(y[train].mean(0),y.shape).copy();results={}
    for name,pred in predictions.items():
        err=np.abs(pred-y);results[name]={'overall_MAE':float(err[hold].mean()),'by_scale':{},'by_group':{}}
        for scale in scales:
            use=hold&np.array([r['scale']==scale for r in meta]);results[name]['by_scale'][str(scale)]=float(err[use].mean())
        for group in sorted(holdout):
            use=np.array([r['group']==group for r in meta]);results[name]['by_group'][group]=float(err[use].mean()) if use.any() else None
    passed=results['T']['overall_MAE']<results['fused']['overall_MAE'] and results['T']['by_scale']['1.4']<results['fused']['by_scale']['1.4']
    report={'source':source,'scope':'source-train group-held-out diagnostic only; no val/test fitting','fit_groups':sorted(fit),'holdout_groups':sorted(holdout),
        'scales':scales,'records':len(ids),'targets':len(y),'reference':reference,'geometry_minimum_side_diagnostic_only':.1,
        'fixed_scale_feasibility':counts,'unrepresented_groups':[g for g,c in counts.items() if c['eligible']==0],
        'limitation':'Only records feasible at all fixed scales; infeasible groups explicitly unrepresented, no training labels changed',
        'checkpoint_sha256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
        'results':results,'T_screen_passed':bool(passed),'reused_feature_arrays':reuse,'elapsed_seconds':time.perf_counter()-tick,'updated_at':now()}
    np.savez_compressed(destination/'arrays.npz',**{name:np.asarray(v) for name,v in x.items()},y=y,train=train)
    write_json(destination/'metadata.json',meta);write_json(destination/'result.json',report)
    print(json.dumps({'source':source,'passed':bool(passed),'results':results}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--sources',nargs='+',default=['IRDST-H','IRSTD-UAV','ITSDT-15K']);p.add_argument('--reuse',action='store_true');a=p.parse_args()
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False
    for source in a.sources:run(source,a.reuse)
