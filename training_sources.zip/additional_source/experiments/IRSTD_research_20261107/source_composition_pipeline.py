"""Conditional zero-training follow-up after the fixed four-epoch budget."""
import json
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
TRAIN=HERE/'scene_scale_joint_v1'
HOME=HERE/'source_model_composition_v1'


def run(script,log):
    with (HERE/log).open('w',encoding='utf-8') as stream:
        subprocess.run([sys.executable,str(HERE/script)],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)


def main():
    while not (TRAIN/'independent_audit.json').exists():
        if (TRAIN/'failure.json').exists():raise RuntimeError((TRAIN/'failure.json').read_text(encoding='utf-8'))
        time.sleep(10)
    audit=json.loads((TRAIN/'independent_audit.json').read_text(encoding='utf-8'));assert audit['passed']
    if audit['promotion_passed']:
        print(json.dumps({'status':'skipped','reason':'parent passed; no composition needed'}),flush=True);return
    run('source_model_composition.py','source_composition_run.log')
    run('audit_source_composition.py','source_composition_audit.log')
    audit=json.loads((HOME/'independent_audit.json').read_text(encoding='utf-8'));assert audit['passed']
    if audit['promotion_passed']:
        run('evaluate_source_composition.py','source_composition_frozen_test.log')
        print(json.dumps({'status':'completed','source_gates_passed':True}),flush=True)
    else:
        print(json.dumps({'status':'source_failed','source_gates_passed':False,'gates':audit['gates'],'target_tests_started':False}),flush=True)
    subprocess.run([sys.executable,str(HERE/'update_progress_report.py')],cwd=ROOT,check=True)


if __name__=='__main__':main()
