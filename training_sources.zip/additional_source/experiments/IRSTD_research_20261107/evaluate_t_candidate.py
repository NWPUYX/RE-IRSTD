"""Freeze a source-qualified T-route checkpoint before four-domain evaluation."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import torch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from irstd_t_size.model import TSizeModel
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate,validation_summary
from irstd_v2.settings import write_json,split_hashes,now
from evaluation import metrics

DOMAINS=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',required=True);a=p.parse_args()
    home=HERE/a.stage; destination=home/'frozen_four_domain_test';destination.mkdir(exist_ok=True)
    done=json.loads((home/'training_complete.json').read_text(encoding='utf-8'))
    assert done['promotion_passed'],'Source promotion must pass before target evaluation'
    assert json.loads((home/'independent_audit.json').read_text(encoding='utf-8'))['passed']
    path=home/'best.pt'; digest=sha(path)
    state=torch.load(path,map_location='cpu',weights_only=False);cfg=state['config'];recipe=cfg['recipe']
    assert cfg['split_hashes']==split_hashes()
    for name,value in cfg['source_hashes'].items():assert sha(ROOT.parent/name)==value,name
    source=cfg['source']; threshold=state['source_validation']['threshold']
    cached=json.loads((home/'best_source_val_predictions.json').read_text(encoding='utf-8'))['frames']
    assert validation_summary(cached)==state['source_validation']
    manifest={'checkpoint_sha256':digest,'source':source,'seed':cfg['seed'],'epoch':state['epoch'],
        'threshold':threshold,'threshold_scope':'source validation only, fixed across targets',
        'targets':DOMAINS,'split_hashes':split_hashes(),'model_class':'irstd_t_size.model.TSizeModel',
        'comparison_scope':'one source / one seed; not a completed SOTA claim',
        'evaluation_script_sha256':sha(__file__)}
    manifest_path=destination/'freeze_manifest.json'
    if manifest_path.exists():assert json.loads(manifest_path.read_text(encoding='utf-8'))==manifest
    else:write_json(manifest_path,manifest)
    torch.set_num_threads(8);torch.backends.cudnn.benchmark=False;device=torch.device('cuda')
    model=TSizeModel(recipe).to(device);model.load_state_dict(state['model'],strict=True);model.eval()
    for v in model.parameters():v.requires_grad_(False)
    results=[]
    for target in DOMAINS:
        result_path=destination/f'{target}_metrics.json';pred_path=destination/f'{target}_predictions.json'
        if result_path.exists():
            result=json.loads(result_path.read_text(encoding='utf-8'));assert result['checkpoint_sha256']==digest
        else:
            tick=time.perf_counter();write_json(destination/'progress.json',{'status':'evaluating','target':target,'updated_at':now()})
            frames=evaluate(model,make_loader(target,'test',recipe),device,cfg['size_reference_512'],pred_path)
            result={'checkpoint_sha256':digest,'source':source,'target':target,'seed':cfg['seed'],'epoch':state['epoch'],
                'overall':metrics(frames,threshold,bootstrap=200),
                'by_group':{g:metrics([f for f in frames if f['group']==g],threshold) for g in sorted({f['group'] for f in frames})},
                'elapsed_seconds':time.perf_counter()-tick,'updated_at':now()}
            assert sha(path)==digest and split_hashes()==manifest['split_hashes']
            write_json(result_path,result)
        results.append(result)
        print(json.dumps({'target':target,**result['overall']}),flush=True)
    cross=[r['overall'] for r in results if r['target']!=source]
    summary={'source':source,'seed':cfg['seed'],'checkpoint_sha256':digest,'cross_domain_macro':
        {k:sum(r[k] for r in cross)/len(cross) for k in ('AP50','AP50_95','F1','Recall','Precision','center_Pd_3px')},
        'completed_cells':len(results),'status':'completed','updated_at':now()}
    write_json(destination/'summary.json',summary);write_json(destination/'progress.json',summary)


if __name__=='__main__':main()
