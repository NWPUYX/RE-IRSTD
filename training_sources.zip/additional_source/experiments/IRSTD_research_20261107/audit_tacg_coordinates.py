"""Isolated arithmetic check of the official snapshot's CGL coordinate contract."""
import ast
import hashlib
import json
import math
from pathlib import Path
import subprocess
import torch

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / 'repositories/TACG'


def main():
    path = REPO / 'utils/loss.py'
    source = path.read_text(encoding='utf-8')
    tree = ast.parse(source)
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'wasserstein_distance')
    namespace = {'torch': torch}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(path), 'exec'), namespace)
    nwd = namespace['wasserstein_distance']
    # One stride8 cell, 16-input-pixel square. Shift the image's positive and
    # negative boxes together by 64px without altering their relative geometry.
    positive_local = torch.tensor([[.5, .5, 2., 2.]])
    negative_normalized = torch.tensor([[264/512, 256/512, 16/512, 16/512]])
    translated_normalized = negative_normalized + torch.tensor([[64/512, 0., 0., 0.]])
    actual = float(nwd(positive_local, negative_normalized, constant=1.))
    translated = float(nwd(positive_local, translated_normalized, constant=1.))
    aligned_negative = torch.tensor([[1.5, .5, 2., 2.]])
    aligned = float(nwd(positive_local, aligned_negative, constant=1.))
    expected_xywh = math.exp(-math.sqrt(1. + 1e-7))
    # The caller supplies local-cell pbox and original normalized-image negative
    # boxes without a grid/stride transform. This audit does not fix that code.
    mismatch_observed = abs(actual - translated) > 1e-7
    assert mismatch_observed
    commit = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
    report = {'commit': commit, 'loss_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
              'isolated_function': 'official wasserstein_distance AST only; no training imports or package changes',
              'mixed_coordinate_NWD': actual, 'mixed_coordinate_after_joint_translation_NWD': translated,
              'same_relative_geometry_aligned_local_NWD': aligned,
              'analytical_aligned_xywh_NWD': expected_xywh,
              'xywh_format_heuristic_mismatch_observed': abs(aligned - expected_xywh) > 1e-6,
              'translation_contract_violation_observed': mismatch_observed,
              'scope': 'static caller contract and isolated arithmetic; not reproduction or invalidation of paper results'}
    (HERE / 'TACG坐标契约核查.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
