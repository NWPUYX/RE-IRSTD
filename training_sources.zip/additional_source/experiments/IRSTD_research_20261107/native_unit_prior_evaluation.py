"""Matched, source-derived native-pixel box-prior diagnostic; no optimization."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
import torch
from torch.utils.data import DataLoader

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_v2.data import make_loader
from irstd_v2.evaluate import validation_summary
from irstd_v2.settings import write_json,now,split_hashes
from irstd.inference.decoder import decode as decode_centers
from evaluation import decode,postprocess,match_frame,metrics
from benchmark_cluster_bootstrap import cluster_ci
from benchmark_progress import ReportingLoader
import benchmark_fastdecode as fast

MODELS=['irstd_v1','irstd_robust','irstd_stable','mpr','yolo26']
PRIORS=['native_constant','input_constant','native_residual']


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def source_statistics():
    path=ROOT/'splits/DAUB-R_train.json';records=json.loads(path.read_text(encoding='utf-8'))
    native=[];scaled=[];resize=[]
    for r in records:
        ratio=min(512/r['width'],512/r['height']);sx=int(r['width']*ratio)/r['width'];sy=int(r['height']*ratio)/r['height']
        resize.append([sx,sy])
        for box in r['boxes']:native.append(box[2:]);scaled.append([box[2]*sx,box[3]*sy])
    return {'source':'DAUB-R','train_split_sha256':sha(path),'native_median':np.median(native,axis=0).tolist(),
        'input_median':np.median(scaled,axis=0).tolist(),'resize_median':np.median(resize,axis=0).tolist(),
        'native_size_counts':{str(k):v for k,v in Counter(map(tuple,native)).items()},'source_frames':len(records),
        'source_image_size_counts':{str(k):v for k,v in Counter((r['width'],r['height']) for r in records).items()}}


def apply_prior(raw,trans,stats,mode):
    raw=raw.clone()
    if mode=='native_constant':raw[:,2:4]=raw.new_tensor(stats['native_median'])*raw.new_tensor(trans[:2]).abs()
    elif mode=='input_constant':raw[:,2:4]=raw.new_tensor(stats['input_median'])
    else:raw[:,2:4]*=raw.new_tensor(trans[:2]).abs()/raw.new_tensor(stats['resize_median'])
    return raw


def geometry_check(stats):
    for w,h in [(256,256),(777,333),(301,906)]:
        scale=min(512/w,512/h);nw,nh=int(w*scale),int(h*scale);sx,sy=nw/w,nh/h;dx,dy=(512-nw)//2,(512-nh)//2
        trans=(sx,sy,dx,dy);record={'width':w,'height':h}
        raw=torch.tensor([[w/2*sx+dx,h/2*sy+dy,16.,16.,.9,1.]])
        pred=postprocess(apply_prior(raw,trans,stats,'native_constant'),record,trans)
        np.testing.assert_allclose(pred[0,2:4]-pred[0,:2],stats['native_median'],atol=1e-4,rtol=0)


def build(name):
    if name=='irstd_v1':
        path=ROOT/'runs/IRSTD/DAUB-R/seed_3407/best.pt'
        state=torch.load(path,map_location='cpu',weights_only=False)
        recipe=torch.load(HERE/'robust_T_composed_v1/best.pt',map_location='cpu',weights_only=False)['config']['recipe']
        from irstd_v2.model import Model
        model=Model(recipe)
    elif name in ['irstd_robust','irstd_stable']:
        stage='robust_T_composed_v1' if name=='irstd_robust' else 'stable_robust_separated_v1'
        path=HERE/stage/'best.pt';state=torch.load(path,map_location='cpu',weights_only=False);recipe=state['config']['recipe']
        if name=='irstd_robust':
            from irstd_t_size.model import TSizeModel
            model=TSizeModel(recipe)
        else:
            from irstd_stable_evidence.model import StableModel
            model=StableModel(recipe)
    elif name=='mpr':
        path=HERE/'mpr_causal_DAUB_3407/best.pt';state=torch.load(path,map_location='cpu',weights_only=False);recipe=None
        from mpr_matched.model import build as factory
        model,_=factory()
    else:
        path=HERE/'yolo26n_p2_DAUB_3407/best.pt';state=torch.load(path,map_location='cpu',weights_only=False);recipe=None
        from yolo26_matched.model import build as factory
        model=factory()
    cfg=state['config']
    if 'source_hashes' in cfg:
        for key,digest in cfg['source_hashes'].items():
            candidates=[ROOT.parent/key,ROOT/key]
            assert any(p.exists() and sha(p)==digest for p in candidates),key
    model.load_state_dict(state['model'],strict=True);model=model.cuda().eval()
    for p in model.parameters():p.requires_grad_(False)
    return model,state,recipe,path


def data(name,domain,split,recipe):
    if name.startswith('irstd_'):return make_loader(domain,split,recipe)
    if name=='mpr':
        from mpr_matched.data import loader
        return loader(domain,split)
    from data_pipeline import VideoData,collate,worker_seed
    return DataLoader(VideoData(domain,split,'AA-YOLO'),batch_size=4,num_workers=2,collate_fn=collate,
        worker_init_fn=worker_seed,persistent_workers=False,pin_memory=False)


@torch.inference_mode()
def evaluate(model,name,loader,stats,mode,path):
    frames=[];predictions=[];device=torch.device('cuda')
    for batch in loader:
        if name.startswith('irstd_'):
            images,samples=batch;valid=torch.stack([s['valid_mask'] for s in samples]).to(device)
            output=model(images.to(device),valid_mask=valid)
            decoded=decode_centers(output,1e-5,{'box_nms_iou':None},stats['input_median'])
            raws=[];ids=[];trans=[]
            for b,(p,sample) in enumerate(zip(decoded,samples)):
                center=p['centers'].to(device);score=p['scores'].to(device);q=center.floor().long()
                value=output['log_size'][b,:,q[:,1],q[:,0]].T.float();ref=value.new_tensor(stats['input_median'])
                wh=ref*torch.minimum(value.clamp_min(-20),(value.new_tensor([512,512])/ref).log()).exp()
                raws.append(torch.cat((center,wh,score[:,None],torch.ones_like(score[:,None])),1))
                ids.append(sample['record_index']);trans.append(sample['trans'])
        elif name=='mpr':
            images,motion,_,ids,trans=batch
            raws=decode('MPR-Net',model(images.to(device),motion_diffs=motion.to(device)))
        else:
            from yolo26_matched.model import predict
            images,_,_,ids,trans=batch;raws=predict(model,images.to(device).float()/255)
        for raw,i,tr in zip(raws,ids,trans):
            # Only known geometric metadata changes the width/height. Labels
            # are read by the unchanged matching routine after prediction.
            record=loader.dataset.records[i];pred=postprocess(apply_prior(raw,tr,stats,mode),record,tr)
            frames.append(match_frame(pred,record))
            for x,y,x2,y2,score in pred.tolist():
                predictions.append({'image_id':record['id'],'category_id':1,'bbox':[x,y,x2-x,y2-y],'score':score})
    path.write_text(json.dumps({'frames':frames,'predictions':predictions},separators=(',',':')),encoding='utf-8')
    return frames


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=MODELS,required=True);parser.add_argument('--prior',choices=PRIORS,default='native_constant')
    parser.add_argument('--source-only',action='store_true');a=parser.parse_args()
    folder=HERE/f'native_unit_{a.model}_{a.prior}_v1';folder.mkdir(exist_ok=True)
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install();stats=source_statistics();geometry_check(stats)
    model,state,recipe,checkpoint=build(a.model);cfg=state['config']
    identity={'model':a.model,'prior':a.prior,'source':'DAUB-R','seed':3407,'checkpoint_sha256':sha(checkpoint),
        'source_statistics':stats,'split_hashes':split_hashes(),'script_sha256':sha(__file__),
        'decoder_helper_sha256':sha(ROOT/'benchmark_fastdecode.py'),'evaluation_sha256':sha(ROOT/'evaluation.py'),
        'bootstrap_helper_sha256':sha(ROOT/'benchmark_cluster_bootstrap.py'),'progress_helper_sha256':sha(ROOT/'benchmark_progress.py'),
        'optimization_updates':0,'role':'matched diagnostic of source-derived box units; not final mechanism/SOTA promotion',
        'source_mode_equivalence':'native_constant equals input_constant for all native256 source images; test-domain geometry distinguishes them'}
    if (folder/'config.json').exists():assert json.loads((folder/'config.json').read_text(encoding='utf-8'))==identity
    else:write_json(folder/'config.json',identity)
    path=folder/'source_val_predictions.json'
    frames=json.loads(path.read_text(encoding='utf-8'))['frames'] if path.exists() else evaluate(model,a.model,
        ReportingLoader(data(a.model,'DAUB-R','val',recipe),folder/'progress.json','source_val'),stats,a.prior,path)
    source=validation_summary(frames);write_json(folder/'source_validation.json',source)
    threshold=source['threshold'];manifest={**identity,'threshold':threshold,'source_val_predictions_sha256':sha(path)}
    write_json(folder/'source_complete.json',{'status':'completed','optimization_updates':0,'geometry_roundtrip_passed':True,
        'source_validation':source,'updated_at':now()})
    if a.source_only:return
    test=folder/'frozen_four_domain_test';test.mkdir(exist_ok=True)
    if (test/'freeze_manifest.json').exists():assert json.loads((test/'freeze_manifest.json').read_text(encoding='utf-8'))==manifest
    else:write_json(test/'freeze_manifest.json',manifest)
    rows=[]
    for target in ['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']:
        path=test/f'{target}_metrics.json'
        if path.exists():result=json.loads(path.read_text(encoding='utf-8'))
        else:
            tick=time.perf_counter();f=evaluate(model,a.model,ReportingLoader(data(a.model,target,'test',recipe),test/'progress.json',target),stats,a.prior,test/f'{target}_predictions.json')
            overall=metrics(f,threshold);ci=cluster_ci(f)
            if ci is not None:overall['AP50_cluster_CI95']=ci
            result={'source':'DAUB-R','target':target,'seed':3407,'overall':overall,
                'by_group':{g:metrics([r for r in f if r['group']==g],threshold) for g in sorted({r['group'] for r in f})},
                'elapsed_seconds':time.perf_counter()-tick,'updated_at':now()};write_json(path,result)
        assert sha(checkpoint)==identity['checkpoint_sha256']
        rows.append(result);print(json.dumps({'target':target,**result['overall']}),flush=True)
    assert all(torch.equal(v.cpu(),state['model'][n]) for n,v in model.state_dict().items())
    cross=[r['overall'] for r in rows if r['target']!='DAUB-R']
    summary={'status':'completed','source':'DAUB-R','seed':3407,'completed_cells':4,
        'cross_domain_macro':{k:sum(r[k] for r in cross)/3 for k in ['AP50','AP50_95','F1','center_Pd_3px']},
        'all_tensors_unchanged':True,'optimization_updates':0,'role':identity['role'],'updated_at':now()}
    write_json(test/'summary.json',summary);write_json(test/'progress.json',summary)


if __name__=='__main__':main()
