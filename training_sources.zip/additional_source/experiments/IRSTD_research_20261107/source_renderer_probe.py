"""Source-only paired interpolation control with frozen thresholds and weights."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import random
import sys
import numpy as np
from PIL import Image
import torch
from torch.utils.data import DataLoader, Dataset

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from native_unit_prior_evaluation import build, sha, source_statistics, apply_prior
from irstd_v2.data import Data, collate, choose_plan, render, original_boxes
from irstd_v2.settings import write_json, now, split_hashes
from irstd_population_t.model import PopulationTModel
from irstd.inference.decoder import decode
from evaluation import postprocess, match_frame, metrics
import benchmark_fastdecode as fast

HOME = HERE/'source_renderer_probe_v1'


def pil_render(record, plan):
    sx, sy, tx, ty = [plan[k] for k in ['sx', 'sy', 'tx', 'ty']]
    assert sx == sy and sx > 0 and tx == int(tx) and ty == int(ty)
    nw, nh = round(record['width']*sx), round(record['height']*sy)
    assert nw == record['width']*sx and nh == record['height']*sy
    with Image.open(record['path']) as image:
        image = image.convert('RGB').resize((nw, nh), Image.Resampling.BICUBIC)
        canvas = Image.new('RGB', (512, 512), (128, 128, 128))
        canvas.paste(image, (int(tx), int(ty)))
        value = torch.from_numpy(np.array(canvas.convert('L'), dtype=np.float32)/255.)[None]
    boxes = original_boxes(record)*sx+torch.tensor([tx, ty, tx, ty])
    valid = torch.zeros(1, 512, 512, dtype=torch.bool)
    valid[:, max(0, int(ty)):min(512, int(ty)+nh), max(0, int(tx)):min(512, int(tx)+nw)] = True
    return value, boxes, valid


class Probe(Dataset):
    def __init__(self, recipe):
        self.base = Data('DAUB-R', 'val', recipe)
        self.records = self.base.records
        spec = json.loads((HERE/'wide_scale_source_probe.json').read_text(encoding='utf-8'))
        self.rows = []
        for i, identity in zip(spec['source_indices'], spec['source_record_ids']):
            assert self.records[i]['id'] == identity
            self.rows.append((i, 'native', 'native'))
            for scale in [.25, .5, 1., 2.]:
                for renderer in ['pil', 'torch', 'torch8bit']:
                    self.rows.append((i, scale, renderer))
        self.geometry = dict(recipe['geometry'], maximum_attempts=1)

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        i, scale, renderer = self.rows[index]
        sample = self.base.base_sample(i)
        record = self.records[i]
        if renderer == 'native':
            replay, boxes, valid = pil_render(record, dict(sx=2., sy=2., tx=0, ty=0))
            assert torch.equal(replay, sample['image']) and torch.equal(boxes, sample['boxes'])
            assert torch.equal(valid, sample['valid_mask'])
        else:
            plan = choose_plan(record, self.geometry, random.Random(0), forced_scale=scale, flip_override=False)
            assert not plan['fallback']
            boxes = original_boxes(record)
            for axis, key in enumerate(['tx', 'ty']):
                low = int(np.ceil(float(-boxes[:, axis].min()*plan['sx'])))
                high = int(np.floor(float(512-boxes[:, axis+2].max()*plan['sx'])))
                plan[key] = max(low, min(high, round(plan[key])))
            image, boxes, valid = pil_render(record, plan) if renderer == 'pil' else render(record, plan)
            if renderer == 'torch8bit':
                image = image.mul(255).round().div(255)
            assert (boxes >= 0).all() and (boxes <= 512).all() and len(boxes) == len(record['boxes'])
            inverse = (boxes-torch.tensor([plan['tx'], plan['ty'], plan['tx'], plan['ty']]))/plan['sx']
            assert torch.allclose(inverse, original_boxes(record), atol=1e-5, rtol=0)
            sample = {**sample, 'image': image, 'boxes': boxes, 'valid_mask': valid, 'ignore_mask': ~valid,
                      'trans': (plan['sx'], plan['sy'], plan['tx'], plan['ty'])}
        return {**sample, 'probe_key': f'{renderer}/scale{scale}'}


@torch.inference_mode()
def main():
    HOME.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    fast.install()
    stats = source_statistics()
    manifest = {'script_sha256': sha(__file__), 'plan_sha256': sha(HERE/'缩放渲染一致性源域诊断方案.md'),
                'subset_sha256': sha(HERE/'wide_scale_source_probe.json'), 'split_hashes': split_hashes(),
                'optimization_updates': 0, 'target_frames': 0, 'threshold_policy': 'each full source validation frozen'}
    if (HOME/'config.json').exists():
        assert json.loads((HOME/'config.json').read_text(encoding='utf-8')) == manifest
    else:
        write_json(HOME/'config.json', manifest)
    results = {}
    for name in ['robust', 'population']:
        result_path = HOME/f'{name}.json'
        if result_path.exists():
            results[name] = json.loads(result_path.read_text(encoding='utf-8'))
            continue
        if name == 'robust':
            model, state, recipe, checkpoint = build('irstd_robust')
        else:
            checkpoint = HERE/'population_T_sourceAP_control_v1/best.pt'
            state = torch.load(checkpoint, map_location='cpu', weights_only=False)
            recipe = state['config']['recipe']
            model = PopulationTModel(recipe).cuda().eval()
            model.load_state_dict(state['model'], strict=True)
            model.set_mode(final=False)
        checkpoint_hash = sha(checkpoint)
        threshold = state['source_validation']['threshold']
        dataset = Probe(recipe)
        loader = DataLoader(dataset, batch_size=4, num_workers=2, collate_fn=collate)
        rows = {}
        for step, (images, samples) in enumerate(loader):
            out = model(images.cuda(), valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
            decoded = decode(out, 1e-5, {'box_nms_iou': None}, stats['input_median'])
            for b, (proposal, sample) in enumerate(zip(decoded, samples)):
                row = rows.setdefault(sample['probe_key'], {'learned': [], 'known_source_size': [], 'GT_peak': []})
                center, score = proposal['centers'].cuda(), proposal['scores'].cuda()
                q = center.floor().long()
                value = out['log_size'][b, :, q[:, 1], q[:, 0]].T.float()
                ref = value.new_tensor(stats['input_median'])
                wh = ref*torch.minimum(value.clamp_min(-20), (value.new_tensor([512, 512])/ref).log()).exp()
                raw = torch.cat((center, wh, score[:, None], torch.ones_like(score[:, None])), 1)
                record = dataset.records[sample['record_index']]
                for rule in ['learned', 'known_source_size']:
                    candidate = raw if rule == 'learned' else apply_prior(raw, sample['trans'], stats, 'native_constant')
                    row[rule].append(match_frame(postprocess(candidate, record, sample['trans']), record))
                for box in sample['boxes']:
                    x, y = ((box[:2]+box[2:])/2).floor().long().tolist()
                    row['GT_peak'].append(float(out['center_logits'][b, 0, max(y-3, 0):min(y+4, 512), max(x-3, 0):min(x+4, 512)].max().sigmoid()))
            write_json(HOME/'progress.json', {'model': name, 'batch': step+1, 'batches': len(loader), 'updated_at': now()})
        assert all(torch.equal(v.cpu(), state['model'][k]) for k, v in model.state_dict().items())
        assert sha(checkpoint) == checkpoint_hash
        result = {'checkpoint_sha256': checkpoint_hash, 'threshold': threshold, 'all_tensors_unchanged': True,
                  'results': {key: {**{rule: metrics(row[rule], threshold) for rule in ['learned', 'known_source_size']},
                              'mean_GT_peak': float(np.mean(row['GT_peak'])),
                              'GT_peaks_above_threshold': sum(s >= threshold for s in row['GT_peak'])} for key, row in rows.items()}}
        write_json(result_path, result)
        results[name] = result
        del model
        torch.cuda.empty_cache()
    write_json(HOME/'result.json', {'status': 'completed', 'results': results, 'optimization_updates': 0,
                                     'target_frames': 0, 'updated_at': now()})
    print(json.dumps(results), flush=True)


if __name__ == '__main__':
    main()
