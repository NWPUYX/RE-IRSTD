"""Refresh this review artifact as the already-frozen four-domain job completes."""
import json
from pathlib import Path
import time
from write_metric_review_20261110 import main as write_report

HERE=Path(__file__).resolve().parent;HOME=HERE/'paper_metric_review_consistent_teacher_v1'


def main():
    previous=None;deadline=time.monotonic()+3*3600
    while time.monotonic()<deadline:
        signature=tuple(sorted((p.name,p.stat().st_mtime_ns) for p in HOME.glob('*_metrics.json')))
        complete=(HOME/'summary.json').exists()
        if signature!=previous or complete:
            write_report();previous=signature
        if complete:
            print(json.dumps({'status':'completed','review_report_updated':True}),flush=True);return
        log=HERE/'paper_metric_review_consistent_teacher.log'
        if log.exists() and 'Traceback (most recent call last)' in log.read_text(encoding='utf-8',errors='replace')[-16000:]:
            write_report();raise RuntimeError('frozen evaluation failed; retained observed cells only')
        time.sleep(10)
    write_report();print(json.dumps({'status':'bounded_report_followup_ended','test_status_not_assumed':True}),flush=True)


if __name__=='__main__':main()
