"""Check source padding proposals before any target-rule experiment."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(HERE)]
from wide_source_detection_probe import Controlled, sha
from native_unit_prior_evaluation import build, source_statistics, apply_prior
from irstd_v2.data import collate
from irstd_v2.settings import write_json, now
from irstd.inference.decoder import decode
from evaluation import postprocess, match_frame, metrics
import benchmark_fastdecode as fast


@torch.inference_mode()
def main():
    home = HERE/'padding_candidate_source_v1'
    home.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    fast.install()
    model, state, recipe, checkpoint = build('irstd_robust')
    stats = source_statistics()
    threshold = state['source_validation']['threshold']
    dataset = Controlled(recipe)
    ids = [j for j, (_, _, scale, noise) in enumerate(dataset.rows) if noise == 0 and scale in ['native', .25, 1., 2.]]
    loader = DataLoader(Subset(dataset, ids), batch_size=4, num_workers=2, collate_fn=collate)
    result = {}
    for images, samples in loader:
        out = model(images.cuda(), valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
        decoded = decode(out, 1e-5, {'box_nms_iou': None}, stats['input_median'])
        for b, (proposal, sample) in enumerate(zip(decoded, samples)):
            center, score = proposal['centers'].cuda(), proposal['scores'].cuda()
            q = center.floor().long()
            size = out['log_size'][b, :, q[:, 1], q[:, 0]].T.float()
            ref = size.new_tensor(stats['input_median'])
            wh = ref*torch.minimum(size.clamp_min(-20), (size.new_tensor([512, 512])/ref).log()).exp()
            raw = torch.cat((center, wh, score[:, None], torch.ones_like(score[:, None])), 1)
            record = dataset.records[sample['record_index']]
            sx, sy, dx, dy = sample['trans']
            native_center = (center-center.new_tensor([dx, dy]))/center.new_tensor([sx, sy])
            inside = ((native_center >= 0) & (native_center < center.new_tensor([record['width'], record['height']]))).all(1)
            scale = sample['controlled_scale']
            row = result.setdefault(scale, {'frames': {k: [] for k in ['learned', 'learned_filtered', 'known', 'known_filtered']}, 'outside_high': []})
            row['outside_high'].append(int(((~inside) & (score >= threshold)).sum()))
            for rule in row['frames']:
                value = apply_prior(raw, sample['trans'], stats, 'native_constant') if rule.startswith('known') else raw
                if rule.endswith('_filtered'):
                    value = value[inside]
                prediction = postprocess(value, record, sample['trans'])
                row['frames'][rule].append(match_frame(prediction, record))
            if scale == 'native':
                assert inside.all()
                assert row['frames']['learned'][-1] == row['frames']['learned_filtered'][-1]
                assert row['frames']['known'][-1] == row['frames']['known_filtered'][-1]
    summary = {}
    for scale, row in result.items():
        assert all(len(f) == 16 for f in row['frames'].values())
        summary[scale] = {'metrics': {k: metrics(f, threshold) for k, f in row['frames'].items()},
                          'mean_outside_candidates_above_threshold': float(np.mean(row['outside_high']))}
    assert all(torch.equal(v.cpu(), state['model'][k]) for k, v in model.state_dict().items())
    report = {'status': 'completed', 'results': summary, 'checkpoint_sha256': sha(checkpoint),
              'script_sha256': sha(__file__), 'dataset_helper_sha256': sha(HERE/'wide_source_detection_probe.py'),
              'threshold': threshold, 'all_tensors_unchanged': True, 'optimization_updates': 0,
              'scope': 'source16 padding-proposal diagnostic only; no target rule selected', 'updated_at': now()}
    write_json(home/'result.json', report)
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
