"""Expose every reported benchmark metric and all18 engineering checks separately."""
import json
from pathlib import Path
import sys
from datetime import datetime
import torch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_geometry_repair.run import baseline
from irstd_geometry_balance.run import enlarge_limit

DOMAINS=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']
KEYS=['AP50','AP50_95','Precision','Recall','F1','FP_per_frame','center_Pd_3px']


def read(path):return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None
def pct(x):return f'{x*100:.4f}%'
def num(x):return f'{x:.8g}'
def average(values):return sum(values)/len(values)


def main():
    latest=read(HERE/'consistent_teacher_v1/epoch_01_row.json')
    done=read(HERE/'consistent_teacher_v1/training_complete.json')
    assert latest['epoch']==done['best_epoch']==1
    b=baseline();parent=torch.load(HERE/'robust_T_composed_v1/best.pt',map_location='cpu',weights_only=False)
    bg=read(HERE/'background_center_guarded_v1/background_baseline.json')
    noise=read(HERE/'noise_validation_diagnostic/baseline.json')['results']
    ext={str(r['scale']):r['log_size_MAE'] for r in read(HERE/'wide_scale_source_probe.json')['summary'] if r['model']=='Tsize_BG' and r['scale'] in [.25,2.]}
    mosaic=read(HERE/'source_mosaic_probe_v1/result.json')['results']['population']['results']
    v=latest['source_validation'];checks=[]
    def add(key,name,limit,value,role):
        checks.append({'key':key,'name':name,'threshold':limit,'latest_value':value,'passed':latest['gates'][key],'paper_role':role})
    add('macro_AP50_original','源验证按采集组宏AP50保护','≥'+pct(b['validation']['group_macro_AP50']-.02),pct(v['group_macro_AP50']),'内部保护')
    add('pooled_AP50_original','源验证整体AP50保护','≥'+pct(b['validation']['pooled']['AP50']-.02),pct(v['pooled']['AP50']),'内部保护')
    add('native_F1_parent','源验证F1保护','≥'+pct(parent['source_validation']['pooled']['F1']-.02),pct(v['pooled']['F1']),'内部保护')
    scopes=['pooled',*v['by_group']]
    limits={};current={}
    for scope in scopes:
        pv=parent['source_validation']['pooled'] if scope=='pooled' else parent['source_validation']['by_group'][scope]
        bv=b['validation']['pooled'] if scope=='pooled' else b['validation']['by_group'][scope]
        cv=v['pooled'] if scope=='pooled' else v['by_group'][scope]
        limits[scope]=max(pv['AP50_95']-.005,bv['AP50_95']-.02);current[scope]=cv['AP50_95']
    add('fine_AP95_parent_and_v1','源AP50:95整体及各组保护','；'.join(f'{k}≥{pct(x)}' for k,x in limits.items()),'；'.join(f'{k}={pct(x)}' for k,x in current.items()),'内部保护；对应测试AP50:95另报')
    add('background_logit_MSE_20percent','背景替换前后GT logit MSE降低20%','≤'+num(bg['GT_logit_pair_MSE']*.8),num(latest['background']['GT_logit_pair_MSE']),'机制诊断')
    add('background_AP50_no_worse','24帧背景替换AP50不退化','≥'+pct(bg['swapped_metrics']['AP50']),pct(latest['background']['swapped_metrics']['AP50']),'人工扰动稳健性')
    add('noise4_AP50_retained','24帧noise4 AP50保护','≥'+pct(noise['4']['box']['AP50']-.005),pct(latest['noise']['4']['box']['AP50']),'人工扰动稳健性')
    add('noise16_AP50_plus2pp','24帧noise16 AP50提高2个百分点','≥'+pct(noise['16']['box']['AP50']+.02),pct(latest['noise']['16']['box']['AP50']),'人为改进门槛')
    add('noise16_F1_plus10pp','24帧noise16 F1提高10个百分点','≥'+pct(noise['16']['box']['F1']+.10),pct(latest['noise']['16']['box']['F1']),'人为改进门槛')
    add('source_group_AP50_retained','源按组宏AP50再次保护','与第1项相同',pct(v['group_macro_AP50']),'与第1项重复')
    add('source_pooled_AP50_retained','源整体AP50再次保护','与第2项相同',pct(v['pooled']['AP50']),'与第2项重复')
    add('source_geometry_error_improved','GT锚点尺寸log误差降低20%','≤'+num(b['geometry']['log_size_error']*.8),num(latest['geometry_probe']['log_size_error']),'真值辅助几何诊断')
    add('enlarge_original','1.4倍缩放尺寸误差保护','≤'+num(enlarge_limit()),num(latest['per_scale']['1.4']['log_size_error']),'真值辅助几何诊断')
    add('extreme_scale_MAE_20percent','0.25与2倍极端缩放平均误差降低20%','≤'+num(.8*average(list(ext.values()))),num(average([latest['extreme_geometry'][k]['log_size_MAE'] for k in ext])),'真值辅助几何诊断')
    add('each_extreme_no_worse','两种极端缩放分别不恶化','；'.join(f'{k}≤{num(x+.02)}' for k,x in ext.items()),'；'.join(f"{k}={num(latest['extreme_geometry'][k]['log_size_MAE'])}" for k in ext),'真值辅助几何诊断')
    add('T_population_locality','24帧背景替换T局部配对MSE','≤1e-10',num(latest['T_pair_MSE']),'创新机制证据')
    add('mosaic_known_size_AP_retained','2/3/4阶拼接平均AP50保护（真值源尺寸辅助）','≥'+pct(average([mosaic[k]['known_source_size']['AP50'] for k in ['2','3','4']])),pct(average([latest['mosaics'][k]['known_source_size']['AP50'] for k in ['2','3','4']])),'真值辅助小目标诊断')
    add('mosaic_known_size_F1_plus5pp','上述拼接平均F1提高5个百分点','≥'+pct(average([mosaic[k]['known_source_size']['F1'] for k in ['2','3','4']])+.05),pct(average([latest['mosaics'][k]['known_source_size']['F1'] for k in ['2','3','4']])),'人为改进门槛；真值辅助')
    assert len(checks)==18 and sum(c['passed'] for c in checks)==sum(done['gates'].values())
    stages=[
        ('512原尺寸','场景E4',HERE/'scene_scale_sourceAP_control_v1/source_qualified_tests/original',''),
        ('512原尺寸','AA-YOLO',ROOT/'runs/AA-YOLO/DAUB-R/seed_3407','test_'),
        ('512原尺寸','YOLO26',HERE/'yolo26n_p2_DAUB_3407/frozen_four_domain_test',''),
        ('512尺寸残差','robust-T',HERE/'native_unit_irstd_robust_native_residual_v1/frozen_four_domain_test',''),
        ('512尺寸残差','场景E4',HERE/'scene_scale_sourceAP_control_v1/source_qualified_tests/native_residual',''),
        ('512尺寸残差','AA-YOLO',HERE/'native_unit_aa_yolo_native_residual_v1/frozen_four_domain_test',''),
        ('512尺寸残差','YOLO26',HERE/'native_unit_yolo26_native_residual_v1/frozen_four_domain_test',''),
        ('512原图固定尺寸','robust-T',HERE/'native_unit_irstd_robust_native_constant_v1/frozen_four_domain_test',''),
        ('512原图固定尺寸','AA-YOLO',HERE/'native_unit_aa_yolo_native_constant_v1/frozen_four_domain_test',''),
        ('512原图固定尺寸','YOLO26',HERE/'native_unit_yolo26_native_constant_v1/frozen_four_domain_test',''),
        ('512原尺寸/多帧额外对照','MPR-Net',HERE/'mpr_causal_DAUB_3407/frozen_four_domain_test',''),
        ('512最新主指标复核','数值一致教师E1',HERE/'paper_metric_review_consistent_teacher_v1','')]
    stages += [('大输入像素密度',name,HERE/f'native_pixel_{name}_v2','') for name in ['irstd_scene','irstd_population','aa_yolo','yolo26','irstd_robust']]
    rows=[];macros=[]
    for protocol,name,folder,prefix in stages:
        cells=[]
        for domain in DOMAINS:
            data=read(folder/f'{prefix}{domain}_metrics.json')
            if data:
                item={'protocol':protocol,'model':name,'domain':domain,'metrics':data['overall']}
                rows.append(item);cells.append(item)
        if len(cells)==4:
            cross=[x['metrics'] for x in cells if x['domain']!='DAUB-R']
            macros.append({'protocol':protocol,'model':name,'metrics':{k:average([x[k] for x in cross]) for k in KEYS}})
    lines=['# IRSTD全部评价指标与18项内部条件审查','',f'[COMPUTED｜HIGH] 更新时间：{datetime.now().astimezone().isoformat(timespec="seconds")}。最新训练候选：consistent_teacher_v1最佳E1，源验证阈值0.5791078209877014。',
        '', '[KNOWN｜HIGH] 18项是开发中添加的源域工程筛选条件，不是18个独立论文指标或通用发表门槛；第1/10、第2/11重复。2个百分点、10个百分点、20%等是本项目内部目标，不是SOTA定义。历史结果保留；本次不再以18项全通过阻止最新候选的主指标测试。',
        '', '## 1. 实际测试指标的完整定义',
        '', '| 指标 | 本工程定义 | 方向 | 建议论文位置 |','|---|---|---|---|',
        '| AP50 | 框IoU≥0.5，101点插值AP，使用固定候选分数排序 | ↑ | 跨域主指标 |',
        '| AP50:95 | IoU=0.50:0.05:0.95十档AP的平均 | ↑ | 主结果表的定位质量指标 |',
        '| Precision | IoU≥0.5，TP/(TP+FP)，使用源验证冻结阈值 | ↑ | 主结果完整报告 |',
        '| Recall | IoU≥0.5，TP/GT，同一冻结阈值 | ↑ | 主结果完整报告 |',
        '| F1 | 2TP/(预测数+GT)，同一冻结阈值 | ↑ | 跨域主指标 |',
        '| FP/帧 | 框匹配未命中的预测数/帧数，同一冻结阈值 | ↓ | 主结果误警指标 |',
        '| 中心Pd3px | 预测中心距真值中心≤原图3像素的检出比例 | ↑ | 辅助检出诊断；不同于框Recall |',
        '| center_AP3px | 按3像素中心匹配计算的101点AP | ↑ | 部分源诊断已计算，未作为所有模型完整跨域列 |',
        '| center_F1/Recall/FP每帧 | 相同中心匹配，阈值仍使用源框F1阈值 | ↑/↑/↓ | 部分源诊断已计算，非完整跨域比较 |',
        '| 参数量 | 当前IRSTD为808952个学习参数 | ↓（结合效果） | 模型开销 |',
        '| 输入像素、显存、耗时 | 部分运行有记录，含等待与共享负载 | 说明预算 | 当前记录不当作独占部署FPS |',
        '', '[KNOWN｜HIGH] AP50:95不是AP@0.95；旧内部key fine_AP95_parent_and_v1的命名容易误读。F1不在目标域重新选阈值。三个跨域宏指标为三个域对应指标的算术平均；宏F1不是从宏P/R再次计算。',
        '[KNOWN｜HIGH] 当前是框评价协议，尚未给出像素IoU/nIoU、像素级Fa或一套公平的独占FPS/FLOPs测量；不能将框AP、中心Pd或FP/帧替代为那些指标。',
        '', '## 2. 所有已完成设置的跨域主结果',
        '', '[COMPUTED｜HIGH] 全部下表为DAUB-R训练、3407种子、相同三个跨域的宏均值。不同输入/尺寸规则分列，同一行不拼接不同模型。',
        '', '| 协议 | 模型 | AP50 | AP50:95 | P | R | F1 | FP/帧 | 中心Pd3px |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
    def format_values(m):return ' | '.join(num(m[k]) if k=='FP_per_frame' else pct(m[k]) for k in KEYS)
    for item in macros:lines.append(f"| {item['protocol']} | {item['model']} | {format_values(item['metrics'])} |")
    progress=read(HERE/'paper_metric_review_consistent_teacher_v1/progress.json')
    if progress and progress.get('status')!='completed':
        lines+=['',f"[COMPUTED｜HIGH] 最新候选主指标测试正在运行：{progress.get('target')} {progress.get('frames_completed',0)}/{progress.get('total_frames',0)}帧。未完成四域前不填跨域宏均值，不据源验证分数猜测目标性能。"]
    elif progress and progress.get('status')=='completed':
        m=progress['cross_domain_macro']
        lines+=['',f"[COMPUTED｜HIGH] 最新候选四域主指标测试已完成：跨域宏AP50/F1为{m['AP50']*100:.4f}%/{m['F1']*100:.4f}%，均高于当前两个单帧主对照；完整分域和配对区间见IRSTD论文主指标测试结果_20261110.md。"]
    lines+=['','[COMPUTED｜HIGH] 固定512原尺寸的场景E4提高AP50，但F1低于AA-YOLO；robust-T在相同尺寸残差及原图固定尺寸控制中同时超过本轮两个单帧对照的AP50/F1。后者不等于覆盖所有当前SOTA，也没有给出四源三种子稳定性。',
        '[KNOWN｜HIGH] 原图固定尺寸旁路学习尺寸头；尺寸残差是额外的源先验再校准，保留尺寸头。两者不是原坐标错误修复。较大输入约用4.69—5.27倍像素。MPR使用多帧与CLIP信息，仅列额外对照。累计续调预算、数值实现与结构偏离另记，不能当作完全相同预算。',
        '', '## 3. 18项内部条件：定义、阈值与最新模型数值',
        '', f"[COMPUTED｜HIGH] 以下均为源验证或源人工扰动诊断，未使用跨域测试结果；最新模型通过{sum(c['passed'] for c in checks)}/18。百分比差为百分点。GT尺寸辅助、GT锚点等不代表部署时可获得真值。",
        '', '| 编号 | 内部条件 | 原阈值 | 最新候选实际值 | 结果 | 论文角色 |','|---|---|---|---|---|']
    for i,c in enumerate(checks,1):lines.append(f"| {i} | {c['name']} | {c['threshold']} | {c['latest_value']} | {'通过' if c['passed'] else '未通过'} | {c['paper_role']} |")
    lines+=['','[INFERRED｜HIGH] 建议主结论围绕跨域AP50、源阈值F1和误警/召回权衡；AP50:95、分域结果和开销完整报告。人工噪声/背景、极端缩放、已知尺寸拼接及局部性用于解释机制与限制，不要求其全部达到上述人为增幅才可撰写论文。',
        '[INFERRED｜HIGH] 可以开始研究问题、方法与实验设置的稿件；是否把“SOTA”写入摘要/结论，应以固定方法的同条件完整对照和必要稳定性/机制证据决定。当前已有部分主要指标领先，最新候选的跨域主指标仍需实际测试。',
        '', '## 4. 各域全部七项指标原始表',
        '', '| 协议 | 模型 | 域 | AP50 | AP50:95 | P | R | F1 | FP/帧 | 中心Pd3px |','|---|---|---|---:|---:|---:|---:|---:|---:|---:|']
    for item in rows:lines.append(f"| {item['protocol']} | {item['model']} | {item['domain']} | {format_values(item['metrics'])} |")
    lines+=['','## 5. 最新模型完整源验证记录',
        '', '[COMPUTED｜HIGH] 下方JSON逐项保留该候选源验证、噪声、背景、几何、拼接和18个布尔条件；其中center_AP3px等辅助字段也一并列出。','', '```json',json.dumps(latest,ensure_ascii=False,indent=2),'```']
    output=ROOT/'results/IRSTD全部测试指标审查_20261110.md'
    if progress and progress.get('status')=='completed':
        lines=[s.replace('最新候选的跨域主指标仍需实际测试。','最新候选的跨域主指标已经完成，当前单源单种子宏AP50/F1均超过两个单帧主对照，尚待稳定性和机制/预算验证。') for s in lines]
    output.write_text('\n'.join(lines),encoding='utf-8')
    data={'updated_at':datetime.now().astimezone().isoformat(timespec='seconds'),'metric_keys':KEYS,'internal_checks':checks,
        'completed_cross_domain_macros':macros,'domain_results':rows,'latest_complete_source_row':latest,'latest_test_progress':progress}
    (ROOT/'results/IRSTD全部测试指标审查_20261110.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'report':str(output),'test_cells':len(rows),'complete_settings':len(macros),'source_checks_passed':sum(c['passed'] for c in checks)}),flush=True)


if __name__=='__main__':main()
