"""Train-only two-teacher output transfer, plus student-local T correspondence."""
import torch
from torch.nn import functional as F
from irstd_adapter import targets, model_config
from irstd_scene_scale.loss import supervised_losses, relative_mse


def losses(model,clean_teacher,noise_teacher,images,samples,reference,cfg,device):
    features=[]
    handle=model.backbone.target_path.register_forward_hook(lambda m,args,value:features.append(value))
    try:loss,terms,out=supervised_losses(model,clean_teacher,images,samples,reference,cfg,device)
    finally:handle.remove()
    assert len(features)==1
    n=len(samples)//2;t=targets(samples,model_config(),reference,device,'shared_regression')
    paired=[];peak=[];shape=[];negative=[];geometry=[]
    ids=[b+n for b in range(n) if samples[b+n]['view_type'] in ['noise','background_noise']]
    if ids:
        valid=torch.stack([samples[b]['valid_mask'] for b in ids]).to(device)
        with torch.no_grad():fixed=noise_teacher(images[ids].to(device),valid_mask=valid)
        for j,b in enumerate(ids):
            anchors=t['anchors'][t['anchors'][:,0]==b]
            assert samples[b]['sample_id']==samples[b-n]['sample_id']
            for _,x,y in anchors.tolist():
                ys=slice(max(y-3,0),min(y+4,512));xs=slice(max(x-3,0),min(x+4,512))
                student=out['center_logits'][b,0,ys,xs];target=fixed['center_logits'][j,0,ys,xs]
                peak.append((student.max()-target.max()).square())
                shape.append(((student-student.max())-(target-target.max())).square().mean())
                paired.append(relative_mse(features[0][b,:,ys,xs],features[0][b-n,:,ys,xs].detach(),cfg['T_channel_RMS_floor']))
                point=int(target.argmax());py=ys.start+point//target.shape[1];px=xs.start+point%target.shape[1]
                for field in ['offsets','log_size']:
                    a=torch.stack((out[field][b,:,y,x],out[field][b,:,py,px]))
                    z=torch.stack((fixed[field][j,:,y,x],fixed[field][j,:,py,px]))
                    geometry.append(F.smooth_l1_loss(a,z))
            mask=t['negative'][b].flatten().bool()&(t['heatmap'][b].flatten()<.01)
            k=min(128,int(mask.sum()))
            if k:
                a=out['center_logits'][b].flatten();z=fixed['center_logits'][j].flatten()
                selected=torch.unique(torch.cat((a.detach().masked_fill(~mask,-torch.inf).topk(k).indices,
                    z.masked_fill(~mask,-torch.inf).topk(k).indices)))
                assert mask[selected].all()
                negative.append((a[selected]-z[selected]).square().mean())
    zero=loss*0;mean=lambda values:torch.stack(values).mean() if values else zero
    extra={'photo_teacher_peak':mean(peak),'photo_teacher_shape':mean(shape),
        'photo_teacher_negative':mean(negative),'photo_teacher_geometry':mean(geometry),
        'photo_T_self_local':mean(paired)}
    loss=loss+.5*extra['photo_teacher_peak']+.1*extra['photo_teacher_shape']+.05*extra['photo_teacher_negative']+.25*extra['photo_teacher_geometry']+extra['photo_T_self_local']
    assert torch.isfinite(loss)
    terms.update({k:float(v.detach()) for k,v in extra.items()})
    terms.update(actual_loss=float(loss.detach()),photo_teacher_images=len(ids))
    return loss,terms
