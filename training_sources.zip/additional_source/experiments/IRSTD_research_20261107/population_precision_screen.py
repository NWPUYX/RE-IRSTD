"""Source-only evidence arithmetic screen after complete-scene adaptation."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import json
from pathlib import Path
import sys
import torch
from torch.utils.data import DataLoader

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_population_t.model import PopulationTModel
from irstd_stable_evidence.model import StableEvidence
from irstd_adapter import model_config
from source_noise_geometry_probe import Clean
from anchor_preserving_decode import decode_raw
from irstd_scene_scale.run import locality_probe
from irstd_v2.data import collate
from irstd_noise_center.data import validation_loader
from irstd_background_center.data import swapped_loader
from irstd_v2.settings import write_json,now,split_hashes
from native_unit_prior_evaluation import sha
from evaluation import postprocess,match_frame,metrics
import benchmark_fastdecode as fast

HOME=HERE/'population_precision_screen_v1'


@torch.inference_mode()
def evaluate(model,loader,reference,threshold):
    frames=[]
    for images,samples in loader:
        out=model(images.cuda(),valid_mask=torch.stack([s['valid_mask'] for s in samples]).cuda())
        for item,sample in zip(decode_raw(out,reference),samples):
            record=loader.dataset.records[sample['record_index']]
            frames.append(match_frame(postprocess(item['raw'],record,sample['trans']),record))
    return metrics(frames,threshold)


@torch.inference_mode()
def main():
    HOME.mkdir(exist_ok=True);torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;fast.install()
    endpoints={str(epoch):HERE/f'scene_scale_joint_v1/epoch_{epoch:02d}_ema.pt' for epoch in [2,4]}
    noise=json.loads((HERE/'noise_validation_diagnostic/baseline.json').read_text(encoding='utf-8'))['results']
    bg=json.loads((HERE/'background_center_guarded_v1/background_baseline.json').read_text(encoding='utf-8'))
    config={'script_sha256':sha(__file__),'plan_sha256':sha(HERE/'固定统计T证据精度零训练预筛方案.md'),
        'checkpoint_sha256':{k:sha(p) for k,p in endpoints.items()},'split_hashes':split_hashes(),
        'source_helper_sha256':sha(HERE/'source_noise_geometry_probe.py'),'decoder_sha256':sha(HERE/'anchor_preserving_decode.py'),
        'evidence_module_sha256':sha(ROOT/'irstd_stable_evidence/model.py'),'optimization_updates':0,'target_frames':0}
    write_json(HOME/'config.json',config);results={}
    for epoch,path in endpoints.items():
        state=torch.load(path,map_location='cpu',weights_only=False);cfg=state['config']['recipe'];reference=state['config']['size_reference_512'];threshold=state['source_validation']['threshold']
        for mode in ['legacy','raw_IEEE','centered_IEEE']:
            model=PopulationTModel(cfg).cuda().eval()
            if mode!='legacy':model.evidence=StableEvidence(model_config()['model']['evidence'],mode).cuda()
            model.load_state_dict(state['model'],strict=True);model.set_mode(final=False)
            result={}
            for view in ['clean','noise4','noise16','swapped']:
                if view=='clean':loader=DataLoader(Clean(cfg),batch_size=4,num_workers=2,collate_fn=collate)
                elif view=='swapped':loader=swapped_loader(cfg)
                else:loader=validation_loader(cfg,int(view.removeprefix('noise')))
                result[view]=evaluate(model,loader,reference,threshold)
            if mode=='legacy':
                for factor in [4,16]:assert result[f'noise{factor}']['AP50']==state['noise'][str(factor)]['box']['AP50']
            result['T_pair_MSE']=locality_probe(model,cfg,'cuda')
            if mode!='legacy':
                base=results[f'{epoch}/legacy']
                result['prescreen']={'clean_AP_retained':result['clean']['AP50']>=base['clean']['AP50']-.02,
                    'noise4_AP_retained':result['noise4']['AP50']>=noise['4']['box']['AP50']-.005,
                    'noise16_AP_plus2pp':result['noise16']['AP50']>=noise['16']['box']['AP50']+.02,
                    'background_AP_retained':result['swapped']['AP50']>=bg['swapped_metrics']['AP50'],
                    'T_locality':result['T_pair_MSE']<=1e-10}
                result['prescreen_passed']=all(result['prescreen'].values())
            assert all(torch.equal(v.cpu(),state['model'][name]) for name,v in model.state_dict().items())
            assert torch.backends.cudnn.conv.fp32_precision=='tf32' and sha(path)==config['checkpoint_sha256'][epoch]
            results[f'{epoch}/{mode}']=result;write_json(HOME/'partial.json',{'results':results,'updated_at':now()})
            del model;torch.cuda.empty_cache()
    write_json(HOME/'result.json',{'status':'completed','results':results,'all_tensors_unchanged':True,
        'optimization_updates':0,'target_frames':0,'updated_at':now()})
    print(json.dumps({k:{'cleanAP':v['clean']['AP50'],'noise16AP':v['noise16']['AP50'],'prescreen':v.get('prescreen')} for k,v in results.items()}),flush=True)


if __name__=='__main__':main()
