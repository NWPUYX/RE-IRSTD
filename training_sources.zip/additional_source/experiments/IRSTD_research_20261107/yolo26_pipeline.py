"""One bounded local training/evaluation job; no remote training or notifications."""
import json
from pathlib import Path
import subprocess
import sys

HOME=Path(__file__).resolve().parent
ROOT=HOME.parents[1]


def main():
    check=json.loads((HOME/'yolo26n_p2_musgd_smoke/smoke_passed.json').read_text(encoding='utf-8'))
    assert check['passed'] and check['one2many_decode_format_verified']
    for name,args in [('training',['-m','yolo26_matched.run']),('test',[str(HOME/'evaluate_yolo26.py')])]:
        with (HOME/f'yolo26_formal_{name}.log').open('w',encoding='utf-8') as output:
            result=subprocess.run([sys.executable,'-u',*args],cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f'YOLO26 {name} failed; inspect yolo26_formal_{name}.log')


if __name__=='__main__':main()
