"""Completed fixed512 scene controls, matched single-frame comparisons and uncertainty."""
import json
from pathlib import Path
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from irstd_robust_t.run import sha
from benchmark_cluster_bootstrap import paired_ci
from matched_residual_round_report import paired_f1
from irstd_v2.settings import write_json,now

DOMAINS=['DAUB-R','IRDST-H','IRSTD-UAV','ITSDT-15K']
SCENE=HERE/'scene_scale_sourceAP_control_v1/source_qualified_tests'
STAGES={
    '场景E4/original':(SCENE/'original',''),
    '场景E4/residual':(SCENE/'native_residual',''),
    'AA-YOLO/original':(ROOT/'runs/AA-YOLO/DAUB-R/seed_3407','test_'),
    'YOLO26/original':(HERE/'yolo26n_p2_DAUB_3407/frozen_four_domain_test',''),
    'AA-YOLO/residual':(HERE/'native_unit_aa_yolo_native_residual_v1/frozen_four_domain_test',''),
    'YOLO26/residual':(HERE/'native_unit_yolo26_native_residual_v1/frozen_four_domain_test',''),
    'MPR/original（额外对照）':(HERE/'mpr_causal_DAUB_3407/frozen_four_domain_test','')}


def read(path):return json.loads(path.read_text(encoding='utf-8'))


def path_for(name,domain,suffix):
    folder,prefix=STAGES[name]
    return folder/f'{prefix}{domain}_{suffix}.json'


def main():
    home=HERE/'scene_round_report_v1';home.mkdir(exist_ok=True)
    rows=[];macros={}
    for name in STAGES:
        cells=[]
        for domain in DOMAINS:
            path=path_for(name,domain,'metrics')
            if not path.exists():continue
            value=read(path)['overall'];cells.append((domain,value))
            rows.append({'model':name,'domain':domain,'metrics':value,'metrics_sha256':sha(path)})
        if len(cells)==4:
            cross=[v for d,v in cells if d!='DAUB-R']
            macros[name]={key:float(np.mean([x[key] for x in cross])) for key in ['AP50','AP50_95','F1','center_Pd_3px','FP_per_frame']}
    pairs=[]
    for rule in ['original','residual']:
        left=f'场景E4/{rule}'
        for right in [f'AA-YOLO/{rule}',f'YOLO26/{rule}']:
            for domain in DOMAINS[1:]:
                paths=[path_for(name,domain,'predictions') for name in [left,right]]
                if not all(p.exists() for p in paths):continue
                digests=[sha(p) for p in paths]
                cache=home/f'{rule}_minus_{right.split("/")[0]}_{domain}.json'
                if cache.exists() and read(cache)['predictions_sha256']==digests:pair=read(cache)
                else:
                    a,b=[read(p)['frames'] for p in paths]
                    ta,tb=[read(path_for(name,domain,'metrics'))['overall']['threshold'] for name in [left,right]]
                    pair={'left':left,'right':right,'domain':domain,'predictions_sha256':digests,
                        'AP50_delta_CI95':paired_ci(a,b),'F1_delta_CI95':paired_f1(a,ta,b,tb),'draws':200,'seed':3407}
                    write_json(cache,pair)
                pairs.append(pair)
    lines=['# 完整场景阶段验证结果与单帧对照','',f'[COMPUTED｜HIGH] 更新时间：{now()}。本表仅DAUB-R训练、3407种子、固定512协议；三目标域宏均值。',
        '', '[COMPUTED｜HIGH] 完整场景四轮8364次更新完成，独立审计通过；最佳源约束轮次E2为17/18，强噪声AP失败。另立的源AP冻结诊断预先固定规则，选择E4最高源AP，保留其16/18失败。两种尺寸规则共享四次完整推理，8个测试单元均已完成。',
        '', '| 模型/尺寸规则 | 跨域宏AP50 | 跨域宏AP50:95 | 跨域宏F1 | 跨域宏中心Pd | 宏FP/帧 |', '|---|---:|---:|---:|---:|---:|']
    for name,value in macros.items():
        lines.append(f"| {name} | {value['AP50']*100:.4f}% | {value['AP50_95']*100:.4f}% | {value['F1']*100:.4f}% | {value['center_Pd_3px']*100:.4f}% | {value['FP_per_frame']:.5f} |")
    lines+=['','[KNOWN｜HIGH] original保留学习到的输入像素尺寸，residual为额外的源缩放先验再校准；分列比较，不能将它称为坐标错误修复。MPR额外使用多帧与CLIP信息。各阶段累计续调预算未与对照匹配，因此本表是开发比较，尚不能归因于结构或宣称SOTA。',
        '', '| 模型/规则 | 域 | AP50 | F1 | 召回 | FP/帧 |','|---|---|---:|---:|---:|---:|']
    for row in rows:
        m=row['metrics'];lines.append(f"| {row['model']} | {row['domain']} | {m['AP50']*100:.4f}% | {m['F1']*100:.4f}% | {m['Recall']*100:.4f}% | {m['FP_per_frame']:.5f} |")
    lines+=['','[COMPUTED｜HIGH] 成对场景组bootstrap的差值区间如下（百分点）。固定各自源阈值，200次重采样；这是固定一次训练下的场景不确定性，不能代表训练种子稳定性。',
        '', '| 场景E4尺寸规则 | 减去对照 | 域 | AP50差值95%区间 | F1差值95%区间 |','|---|---|---|---|---|']
    for pair in pairs:
        intervals=[]
        for key in ['AP50_delta_CI95','F1_delta_CI95']:
            ci=pair[key];intervals.append('组数不足' if ci is None else f'[{ci[0]*100:.4f}, {ci[1]*100:.4f}]')
        lines.append(f"| {pair['left']} | {pair['right']} | {pair['domain']} | {intervals[0]} | {intervals[1]} |")
    lines+=['','[COMPUTED｜HIGH] 原尺寸规则跨域宏AP50超过这里AA-YOLO，但F1仍低于该对照；本轮未达标。E4在ITSDT-15K的冻结阈值F1为0，不能用另外两个域或另一个尺寸规则补齐。',
        '', '[COMPUTED｜HIGH] 数值核查证明旧统计实现的常量响应和亮度平移误差不符合理想公式；FP64积分原型通过参考核查，但直接替换及源统计重校准未通过性能预筛。后续积分与噪声输出联合适配单列，不改本表既有权重与结果。',
        '', '[KNOWN｜HIGH] 五个模型的源像素密度测试仍按预先固定队列推进；较大输入的结果不能并入本固定512表。单帧同监督与外部信息是主要验收口径；仍需四训练源、三种子、相同预算配方对照、机制消融及未参与开发的独立确认。']
    (HERE/'完整场景阶段本轮验证结果.md').write_text('\n'.join(lines),encoding='utf-8')
    write_json(home/'summary.json',{'rows':rows,'cross_domain_macros':macros,'pairs':pairs,'updated_at':now()})
    print(json.dumps({'completed_cells':len(rows),'paired_rows':len(pairs),'macros':macros}),flush=True)


if __name__=='__main__':main()
