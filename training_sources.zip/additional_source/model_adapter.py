"""Adapters retain official architectures and auxiliary losses; no weight loading."""
from pathlib import Path
import importlib, os, sys
ROOT = Path(__file__).resolve().parent

def build(name):
    repo = ROOT/'repositories'/name
    if name == 'Tridos': repo = repo/'Tridos'
    sys.path.insert(0, str(repo)); os.chdir(repo)
    if name == 'AA-YOLO':
        import yaml
        from models.yolo import Model
        from utils.loss import ComputeLossOTA
        model = Model(str(repo/'cfg/training/AA-yolov7-tiny.yaml'), ch=3, nc=1)
        hyp = yaml.safe_load((repo/'data/hyp.scratch.AA_yolo.yaml').read_text())
        nl = model.model[-1].nl
        hyp['box'] *= 3/nl; hyp['cls'] *= 1/80*3/nl
        hyp['obj'] *= (512/640)**2*3/nl; hyp['label_smoothing'] = 0.0
        model.hyp=hyp; model.gr=1.0; model.nc=1; model.names=['target']
        return model, ComputeLossOTA(model.cuda())
    entries = {
        'CHAL': ('nets.slowfastnet', 'slowfastnet', 'nets.yolo_training'),
        'TDCNet': ('model.TDCNet.TDCNetwork', 'TDCNetwork', 'model.nets.yolo_training'),
        'STMENet': ('model.STME', 'STNetwork', 'model.nets.yolo_training'),
        'Tridos': ('nets.slowfastnet_9520', 'slowfastnet', 'nets.yolo_training'),
        'SSTNet': ('nets.Network', 'Network', 'nets.yolo_training'),
        'LASNet': ('nets.LASNet', 'LASNet', 'nets.training'),
    }
    if name not in entries: raise NotImplementedError(name)
    module, cls, loss_module = entries[name]
    mod = importlib.import_module(module)
    if name in ('TDCNet', 'STMENet'):
        mod.mcfg['pretrained_2d'] = False
        mod.mcfg['pretrained_3d'] = False
    model = getattr(mod, cls)(num_classes=1, num_frame=5)
    if name == 'LASNet':
        from las_loss_fix import BinaryMotionMaskLoss
        model.mm_loss = BinaryMotionMaskLoss()
    loss = importlib.import_module(loss_module).YOLOLoss(1, False, strides=[8])
    return model, loss

def training_loss(name, model, criterion, images, targets, multi_targets=None, amp=False):
    import torch
    if name == 'AA-YOLO':
        rows=[]
        for b, ann in enumerate(targets):
            if len(ann):
                rows.append(torch.cat((torch.full_like(ann[:,:1],b),ann[:,4:5],ann[:,:4]/images.shape[-1]),1))
        labels=torch.cat(rows) if rows else images.new_zeros((0,6))
        with torch.autocast('cuda',dtype=torch.bfloat16,enabled=amp): outputs=model(images)
        return criterion([x.float() for x in outputs], labels, images)[0]
    with torch.autocast('cuda',dtype=torch.bfloat16,enabled=amp):
        if name == 'LASNet':
            outputs, auxiliary = model(images, multi_targets)
        elif name == 'SSTNet':
            outputs, auxiliary = model(images)
        else:
            outputs = model(images); auxiliary = 0
    return criterion([x.float() for x in outputs], targets) + auxiliary
