import csv,json,hashlib,collections
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent
rows=list(csv.DictReader((ROOT.parent/'scene_generalization_audit/tiny_image_manifest.csv').open(encoding='utf8')))
def hash_image(r): return hashlib.sha256(Path(r['image']).read_bytes()).hexdigest(),r
hashes=collections.defaultdict(list)
with ThreadPoolExecutor(max_workers=8) as pool:
    for h,r in pool.map(hash_image,rows): hashes[h].append(r)
overlap=[{'sha256':h,'records':rr} for h,rr in hashes.items() if len({r['group'] for r in rr})>1]
classes=collections.defaultdict(collections.Counter)
for r in rows:
    for line in Path(r['annotation']).read_text().splitlines():
        if line.strip(): classes[r['group']][line.split()[0]]+=1
out={'frames':len(rows),'unique_file_hashes':len(hashes),'identical_files_across_folders':len(overlap),'overlap':overlap,'class_counts_by_group':{g:dict(v) for g,v in classes.items()},'status':'classification and capture-event mapping still required; no training split frozen'}
(ROOT/'tiny_preflight.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k not in {'overlap','class_counts_by_group'}},ensure_ascii=False))
