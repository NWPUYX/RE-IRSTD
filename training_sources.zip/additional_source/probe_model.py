import argparse, json, time, traceback
from pathlib import Path
import numpy as np
import torch
from model_adapter import build, training_loss, ROOT
p=argparse.ArgumentParser(); p.add_argument('model'); p.add_argument('--size',type=int,default=512); a=p.parse_args()
out={'model':a.model,'size':a.size,'kind':'synthetic execution check, not dataset evaluation'}
try:
    torch.set_num_threads(8); torch.manual_seed(3407)
    model, criterion = build(a.model); model.cuda().train()
    if hasattr(criterion,'cuda'): criterion.cuda()
    out['parameters']=sum(x.numel() for x in model.parameters())
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4)
    images=torch.rand((1,3,a.size,a.size) if a.model=='AA-YOLO' else (1,3,10 if a.model=='TDCNet' else 5,a.size,a.size),device='cuda')
    targets=[torch.tensor([[a.size*.5,a.size*.5,8.,8.,0.]],device='cuda')]
    multi=np.tile(np.array([[[[a.size*.5-4,a.size*.5-4,8.,8.,0.]]]],dtype=np.float32),(1,5,1,1))
    torch.cuda.synchronize(); start=time.perf_counter()
    for i in range(3):
        optimizer.zero_grad(set_to_none=True)
        loss=training_loss(a.model,model,criterion,images,targets,multi)
        if not torch.isfinite(loss): raise ValueError('nonfinite loss')
        loss.backward(); optimizer.step(); torch.cuda.synchronize()
        out['loss']=float(loss.detach())
        out[f'step_{i}_seconds']=time.perf_counter()-start; start=time.perf_counter()
    model.eval()
    with torch.no_grad(): pred=model(images)
    out['shapes']=[list(pred[0].shape)] if a.model=='AA-YOLO' else [list(x.shape) for x in pred]
    out['peak_memory_gb']=torch.cuda.max_memory_allocated()/2**30; out['status']='passed'
except Exception:
    out['status']='failed'; out['error']=traceback.format_exc()
path=ROOT/'execution_checks'; path.mkdir(exist_ok=True)
(path/f'{a.model}.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
