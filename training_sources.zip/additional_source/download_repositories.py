from pathlib import Path
import concurrent.futures,subprocess,json,datetime
R=Path(r'D:\Codex\Scenario_adaptability');dst=R/'repositories';dst.mkdir(exist_ok=True)
items=[('CHAL','https://github.com/UESTC-nnLab/CHAL'),('TDCNet','https://github.com/IVPLabs/TDCNet'),('S2MVP','https://github.com/UESTC-nnLab/S2MVP'),('STMENet','https://github.com/UESTC-nnLab/STME'),('Tridos','https://github.com/UESTC-nnLab/Tridos'),('SSTNet','https://github.com/UESTC-nnLab/SSTNet'),('LASNet','https://github.com/UESTC-nnLab/DMIST'),('AA-YOLO','https://github.com/AMIAD-Research/AA-YOLO')]
def get(item):
 name,url=item;p=dst/name
 if p.exists():return {'model':name,'url':url,'status':'directory already exists: inspect before reuse'}
 try:
  q=subprocess.run(['git','clone','--depth','1',url,str(p)],capture_output=True,text=True,timeout=300)
  o={'model':name,'url':url,'exit_code':q.returncode,'stderr':q.stderr[-3000:]}
  if q.returncode==0:o['commit']=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
  return o
 except Exception as e:return {'model':name,'url':url,'error':str(e)}
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for result in pool.map(get,items):
  results.append(result);(R/'download_manifest.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False),flush=True)
