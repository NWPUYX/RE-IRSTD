from pathlib import Path
import urllib.request,json,zipfile,io,concurrent.futures,hashlib
R=Path(r'D:\Codex\Scenario_adaptability');dst=R/'repositories';dst.mkdir(exist_ok=True)
items=[('CHAL','UESTC-nnLab/CHAL'),('TDCNet','IVPLabs/TDCNet'),('S2MVP','UESTC-nnLab/S2MVP'),('STMENet','UESTC-nnLab/STME'),('Tridos','UESTC-nnLab/Tridos'),('SSTNet','UESTC-nnLab/SSTNet'),('LASNet','UESTC-nnLab/DMIST'),('AA-YOLO','AMIAD-Research/AA-YOLO')]
def read(url):
 req=urllib.request.Request(url,headers={'User-Agent':'Scenario-adaptability-research','Accept':'application/vnd.github+json'})
 with urllib.request.urlopen(req,timeout=90) as f:return f.read()
def get(item):
 name,repo=item;p=dst/name
 if p.exists() and any(p.iterdir()):return {'model':name,'repo':repo,'status':'existing nonempty directory: inspect before reuse'}
 try:
  branch='main'
  try:blob=read('https://codeload.github.com/'+repo+'/zip/refs/heads/'+branch)
  except urllib.error.HTTPError as e:
   if e.code!=404:raise
   branch='master';blob=read('https://codeload.github.com/'+repo+'/zip/refs/heads/'+branch)
  with zipfile.ZipFile(io.BytesIO(blob)) as probe:sha=probe.comment.decode('ascii',errors='replace')
  archive=R/'downloads';archive.mkdir(exist_ok=True);(archive/(name+'-'+(sha[:12] or branch)+'.zip')).write_bytes(blob)
  p.mkdir(exist_ok=True)
  with zipfile.ZipFile(io.BytesIO(blob)) as z:
   for member in z.infolist():
    parts=Path(member.filename).parts[1:]
    if not parts or member.is_dir():continue
    target=(p.joinpath(*parts)).resolve()
    if not target.is_relative_to(p.resolve()):raise ValueError('Unsafe archive path')
    if member.file_size>2_000_000_000:raise ValueError('Oversized archive member')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(member))
  return {'model':name,'requested_repo':repo,'canonical_repo':repo,'commit':sha,'downloaded_branch':branch,'archive_sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'status':'downloaded'}
 except Exception as e:return {'model':name,'repo':repo,'status':'failed','error':str(e)}
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for result in pool.map(get,items):
  results.append(result);(R/'download_manifest.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False),flush=True)
