"""At most two epochs, four half-epoch source checks, no target tests."""
import os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import platform
import random
import shutil
import sys
import time
import traceback
import numpy as np
import torch
from irstd_adapter import model_config, source_audit, targets
from irstd_replay.data import training_loader
from irstd_replay.run import ranking_summary
from irstd_v2.data import make_loader
from irstd_v2.evaluate import evaluate, validation_summary, geometry_probe
from irstd_v2.losses import supervised
from irstd_v2.model import Model
from irstd_v2.settings import write_json, now, split_hashes
from irstd_v2.train import rng_state, restore_rng, save_checkpoint

ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / "experiments/IRSTD_v2/replay50_finetune5_v1"
HOME = ROOT / "experiments/IRSTD_v2/center_head_lr1e5_2epoch_v1"
START = PARENT / "best.pt"
SOURCE, SEED = "DAUB-R", 3407


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_hashes():
    parent = json.loads((PARENT / "config.json").read_text(encoding="utf-8"))["source_hashes"]
    result = {key: sha(ROOT.parent / key) for key in parent}
    if result != parent:
        raise ValueError("Parent's frozen sources changed")
    result.update({str(p.relative_to(ROOT.parent)): sha(p) for p in Path(__file__).parent.glob("*.py")})
    return result


def recipe():
    cfg = json.loads((PARENT / "recipe.json").read_text(encoding="utf-8"))
    cfg.update(name=HOME.name, initialization="replay_best_epoch1_EMA", epochs=2,
               learning_rate=1e-5, validation_interval=.5, trainable_prefix="heads.center.",
               maximum_validation_checks=4, automatic_matrix=False, automatic_fallback=False)
    return cfg


def freeze(model):
    for name, param in model.named_parameters():
        param.requires_grad_(name.startswith("heads.center."))
    assert sum(p.numel() for p in model.parameters() if p.requires_grad) == 5233
    assert sum(p.numel() for p in model.parameters()) == 808952
    # Match the parent's AdamW bias/weight decay policy, restricted to this head.
    groups = [{"params": [p for n,p in model.named_parameters() if p.requires_grad and not n.endswith(".bias")], "weight_decay": .0005},
              {"params": [p for n,p in model.named_parameters() if p.requires_grad and n.endswith(".bias")], "weight_decay": 0.}]
    return torch.optim.AdamW(groups, lr=1e-5, betas=tuple(model_config()["train"]["betas"]))


def assert_frozen(model, initial):
    for name, value in model.state_dict().items():
        if not name.startswith("heads.center.") and not torch.equal(value.detach().cpu(), initial[name]):
            raise AssertionError(f"Frozen state changed: {name}")


def new_model(cfg, device, initial):
    model = Model(cfg).to(device)
    model.load_state_dict(initial, strict=True)
    optimizer = freeze(model)
    return model, optimizer


def loss_for(model, images, samples, reference, cfg, device):
    target = targets(samples, model_config(), reference, device, "shared_regression")
    valid = torch.stack([s["valid_mask"] for s in samples]).to(device)
    output = model(images.to(device), valid_mask=valid)
    norm = {"images": len(samples), "targets": sum(len(s["boxes"]) for s in samples),
            "boxes": sum(len(s["boxes"]) for s in samples)}
    terms = supervised(output, target, model_config(), reference, cfg, normalizers=norm)
    # The original center term is the only parameter-dependent loss in this repair.
    loss = terms["center"] * model_config()["loss"]["center_weight"]
    if not torch.isfinite(loss):
        raise FloatingPointError("Nonfinite center loss")
    return loss, terms, output


def smoke(cfg, initial, reference, device, identity):
    home = HOME / "checks"
    home.mkdir(parents=True, exist_ok=True)
    model, optimizer = new_model(cfg, device, initial)
    data = training_loader(SOURCE, cfg, SEED)
    images, samples = next(iter(data))
    assert sorted(s["view_type"] for s in samples) == ["augmented", "augmented", "native", "native"]
    model.eval()
    with torch.no_grad():
        before = {k: v.clone() for k,v in model(images.to(device)).items() if v is not None}
    optimizer.zero_grad(set_to_none=True)
    loss, terms, _ = loss_for(model, images, samples, reference, cfg, device)
    loss.backward()
    assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith("heads.center."))
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.heads.center.parameters())
    torch.nn.utils.clip_grad_norm_(model.heads.center.parameters(), 10., error_if_nonfinite=True)
    optimizer.step()
    assert_frozen(model, initial)
    with torch.no_grad():
        after = model(images.to(device))
    for key in ("offsets", "log_size", "auxiliary_center_logits"):
        assert torch.equal(before[key], after[key])
    assert not torch.equal(before["center_logits"], after["center_logits"])
    assert sum(len(g["params"]) for g in optimizer.param_groups) == len(list(model.heads.center.parameters()))
    save_checkpoint(home / "smoke.pt", {"model": model.state_dict(), "optimizer": optimizer.state_dict()})
    saved = torch.load(home / "smoke.pt", map_location="cpu", weights_only=False)
    restored, opt = new_model(cfg, device, saved["model"])
    opt.load_state_dict(saved["optimizer"])
    restored.eval()
    with torch.no_grad():
        result = restored(images.to(device))
    assert all(torch.equal(result[k],v) for k,v in after.items() if v is not None)
    assert len(opt.state) == len(optimizer.state) == 4
    write_json(home / "preflight.json", {"passed":True, "identity": identity, "trainable_parameters":5233,
                "total_parameters":808952, "frozen_state_bitwise_equal":True,
                "geometry_and_aux_outputs_bitwise_equal":True, "center_output_updated":True,
                "optimizer_contains_only_center":True, "save_reload_bitwise_equal":True,
                "formal_optimizer_will_be_fresh":True, "updated_at":now()})
    print(json.dumps({"smoke_passed":True,"trainable_parameters":5233}),flush=True)


def promotion(candidate):
    base = json.loads((PARENT / "promotion.json").read_text(encoding="utf-8"))["baseline"]
    b, v = base["validation"], candidate["source_validation"]
    gates = {"source_group_AP50_retained": v["group_macro_AP50"] >= b["group_macro_AP50"]-.02,
             "source_pooled_AP50_retained":v["pooled"]["AP50"] >= b["pooled"]["AP50"]-.02,
             "source_geometry_error_improved": candidate["geometry_probe"]["log_size_error"] <= base["geometry"]["log_size_error"]*.8}
    return {"passed":all(gates.values()), "gates":gates, "baseline":base,
            "candidate":{k:candidate[k] for k in ("epoch","source_validation","geometry_probe","ranking")},
            "scope":"Source validation only; no target tests or automatic matrix", "updated_at":now()}


def report():
    best = torch.load(HOME / "best.pt",map_location="cpu",weights_only=False)
    result = promotion(best)
    write_json(HOME / "promotion.json",result)
    rows = [json.loads(x) for x in (HOME / "history.jsonl").read_text(encoding="utf-8").splitlines()]
    lines = ["# IRSTD 中心检测头受限微调", "",f"[KNOWN｜HIGH] 更新时间：{now()}；仅 DAUB-R/3407 源验证。",
             "", "[KNOWN｜HIGH] 起点为 replay50_finetune5_v1 第1轮最佳EMA；仅训练中心头5233参数，总参数808952；固定学习率1e-5，FP32/batch4，原始/增强2+2，最多2轮，每半轮完整源验证。",
             "", "| 本轮进度 | 组宏AP50 | pooled AP50 | data19 AP50 | data22 AP50 | pooled AP50:95 | data22 P@R50 | 尺寸压力误差 |",
             "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for row in rows:
        v = row["source_validation"]
        lines.append(f"| {row['epoch']} | {v['group_macro_AP50']*100:.4f}% | {v['pooled']['AP50']*100:.4f}% | {v['by_group']['data19']['AP50']*100:.4f}% | {v['by_group']['data22']['AP50']*100:.4f}% | {v['pooled']['AP50_95']*100:.4f}% | {row['ranking']['data22']['precision_at_recall_50']*100:.4f}% | {row['geometry_probe']['log_size_error']:.6f} |")
    lines += ["",f"[COMPUTED｜HIGH] 当前最佳进度：{best['epoch']}轮；原三项验收{'通过' if result['passed'] else '未通过'}：{result['gates']}。",
              "", "[KNOWN｜HIGH] 原门槛：组宏AP50≥77.3767%，pooled AP50≥76.8410%，尺寸压力误差≤0.339524；AP50:95与分组误检同步报告。未执行跨域测试、自动扩展或备用配方。",
              "", "[KNOWN｜HIGH] 每半轮保存EMA、原始权重、优化器、随机状态、完整验证预测；best.pt为按原规则选出的EMA，起点也参与选模。",
              "", "[KNOWN｜HIGH] 运行：在 D:\\Codex\\Scenario_adaptability 中使用 D:\\Miniconda3\\envs\\IRSTD\\python.exe -u -m irstd_center_repair.run；中断恢复加 --resume。"]
    (HOME / "结果与进度.md").write_text("\n".join(lines),encoding="utf-8")
    return result


def run(check_only=False, resume=False):
    cfg, device = recipe(), torch.device("cuda")
    HOME.mkdir(parents=True,exist_ok=True)
    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED)
    torch.backends.cudnn.benchmark = False
    parent = torch.load(START,map_location="cpu",weights_only=False)
    assert parent["epoch"] == 1
    reference = source_audit(SOURCE)["size_reference_512"]
    assert reference == parent["config"]["size_reference_512"]
    assert split_hashes() == parent["config"]["split_hashes"]
    identity = {"source_hashes":source_hashes(), "split_hashes":split_hashes(), "initial_checkpoint_sha256":sha(START), "recipe":cfg}
    if check_only:
        smoke(cfg,parent["model"],reference,device,identity)
        return
    check = json.loads((HOME / "checks/preflight.json").read_text(encoding="utf-8"))
    if not check["passed"] or check["identity"] != identity:
        raise ValueError("Smoke check missing or identity changed")
    config = {**identity,"source":SOURCE,"seed":SEED,"size_reference_512":reference,
              "initialization":{"checkpoint":str(START),"weights":"EMA","parent_epoch":1,"optimizer":"fresh"}}
    if (HOME / "config.json").exists():
        if json.loads((HOME / "config.json").read_text(encoding="utf-8")) != config or not resume:
            raise ValueError("Existing run requires identical config and --resume")
    if (HOME / "training_complete.json").exists():
        return
    write_json(HOME / "config.json",config); write_json(HOME / "recipe.json",cfg)
    snapshot = HOME / "source_snapshot"; snapshot.mkdir(exist_ok=True)
    for p in Path(__file__).parent.glob("*.py"):
        shutil.copyfile(p,snapshot / p.name)
    write_json(HOME / "environment.json",{"python":sys.version,"torch":torch.__version__,"cuda":torch.version.cuda,
                "gpu":torch.cuda.get_device_name(device),"platform":platform.platform(),"started_at":now()})
    model, optimizer = new_model(cfg,device,parent["model"])
    initial = {k:v.clone() for k,v in parent["model"].items()}
    ema = copy.deepcopy(model).eval()
    for p in ema.parameters(): p.requires_grad_(False)
    train = training_loader(SOURCE,cfg,SEED)
    val = make_loader(SOURCE,"val",cfg)
    updates, cursor, prior_seconds = 0, 0, 0.
    if not (HOME / "best.pt").exists():
        row = {"epoch":0.,"source_validation":parent["source_validation"],"geometry_probe":parent["geometry_probe"],"ranking":parent["ranking"]}
        save_checkpoint(HOME / "best.pt",{**row,"model":parent["model"],"config":config})
        shutil.copyfile(PARENT / "best_source_val_predictions.json",HOME / "best_source_val_predictions.json")
        (HOME / "history.jsonl").write_text(json.dumps(row)+"\n",encoding="utf-8")
    best = torch.load(HOME / "best.pt",map_location="cpu",weights_only=False)
    best_key = (best["source_validation"]["group_macro_AP50"],best["source_validation"]["pooled"]["AP50"])
    del best, parent
    if resume and (HOME / "last.pt").exists():
        state = torch.load(HOME / "last.pt",map_location="cpu",weights_only=False)
        if state["config"] != config: raise ValueError("Resume identity mismatch")
        model.load_state_dict(state["model"]); ema.load_state_dict(state["ema"])
        optimizer.load_state_dict(state["optimizer"]); restore_rng(state["rng"])
        cursor, updates, prior_seconds = state["next_batch_global"],state["updates"],state["elapsed_seconds"]
        del state
    write_json(HOME / "process.json",{"pid":os.getpid(),"started_at":now(),"resume":resume})
    started = time.perf_counter(); gate_passed = False; at = cursor / len(train)
    half = (len(train)+1)//2
    initial_promotion = report()
    if initial_promotion["passed"]:
        write_json(HOME / "training_complete.json", {"status":"completed_source_gate_passed", "epochs_run":at,
                   "updates":updates,"best_epoch":initial_promotion["candidate"]["epoch"],"promotion_passed":True,
                   "target_test_cells":0,"updated_at":now()})
        return
    for epoch in range(2):
        train.dataset.epoch = epoch
        counts = {"native":0,"augmented":0}; loss_sum = {}; batches = 0
        for iteration,(images,samples) in enumerate(train):
            global_index = epoch*len(train)+iteration
            if global_index < cursor: continue
            if len(samples) == 4: assert sum(s["view_type"]=="native" for s in samples)==2
            model.eval(); model.heads.center.train()
            optimizer.zero_grad(set_to_none=True)
            loss, terms, output = loss_for(model,images,samples,reference,cfg,device)
            loss.backward()
            assert all(p.grad is None for n,p in model.named_parameters() if not n.startswith("heads.center."))
            torch.nn.utils.clip_grad_norm_(model.heads.center.parameters(),10.,error_if_nonfinite=True)
            optimizer.step(); updates += 1
            decay = .9999*(1-math.exp(-updates/2000))
            with torch.no_grad():
                for a,b in zip(ema.heads.center.parameters(),model.heads.center.parameters()):
                    a.mul_(decay).add_(b,alpha=1-decay)
            for name,value in terms.items(): loss_sum[name] = loss_sum.get(name,0.)+float(value.detach())
            for sample in samples: counts[sample["view_type"]] += 1
            batches += 1
            if iteration%40==0:
                progress = {"status":"training","pid":os.getpid(),"epoch":epoch+1,"batch":iteration+1,"total_batches":len(train),
                            "updates":updates,"segment_views":counts,"center_loss":float(terms["center"].detach()),"updated_at":now()}
                write_json(HOME / "progress.json",progress); print(json.dumps(progress),flush=True)
            del loss, terms, output
            if iteration+1 not in (half,len(train)): continue
            check_index = 2*epoch+(1 if iteration+1==half else 2)
            at = epoch+(.5 if iteration+1==half else 1.)
            assert_frozen(model,initial); assert_frozen(ema,initial)
            if source_hashes() != identity["source_hashes"]: raise ValueError("Frozen source changed")
            write_json(HOME / "progress.json",{"status":"source_validation","epoch":at,"check":check_index,"updated_at":now()})
            tick = time.perf_counter()
            pred_path = HOME / f"check_{check_index:02d}_source_val_predictions.json"
            frames = evaluate(ema,val,device,reference,pred_path)
            summary = validation_summary(frames)
            probe = geometry_probe(ema,SOURCE,cfg,reference,device)
            expected = json.loads((PARENT / "promotion.json").read_text(encoding="utf-8"))["candidate"]["geometry_probe"]
            for key in ("log_size_error","center_error_input_px","mean_giou"):
                if abs(probe[key]-expected[key]) > 1e-7: raise AssertionError(f"Frozen geometry probe drift: {key}")
            stat = {"epoch":at,"check":check_index,"updates":updates,"source_validation":summary,"geometry_probe":probe,
                    "ranking":ranking_summary(frames),"segment_views":dict(counts),"segment_batches":batches,
                    "loss_mean_over_segment_batches":{k:v/batches for k,v in loss_sum.items()},
                    "validation_seconds":time.perf_counter()-tick,"elapsed_seconds":prior_seconds+time.perf_counter()-started,
                    "frozen_state_bitwise_equal":True,"geometry_probe_unchanged":True}
            save_checkpoint(HOME / f"check_{check_index:02d}_ema.pt",{**stat,"model":ema.state_dict(),"config":config})
            save_checkpoint(HOME / f"check_{check_index:02d}_raw.pt",{"model":model.state_dict(),"config":config,"epoch":at})
            key = (summary["group_macro_AP50"],summary["pooled"]["AP50"])
            if key > best_key:
                best_key = key
                save_checkpoint(HOME / "best.pt",{**stat,"model":ema.state_dict(),"config":config})
                shutil.copyfile(pred_path,HOME / "best_source_val_predictions.json")
            save_checkpoint(HOME / "last.pt",{"model":model.state_dict(),"ema":ema.state_dict(),"optimizer":optimizer.state_dict(),
                "next_batch_global":global_index+1,"updates":updates,"rng":rng_state(),"config":config,"elapsed_seconds":stat["elapsed_seconds"]})
            history_path = HOME / "history.jsonl"
            rows = [json.loads(x) for x in history_path.read_text(encoding="utf-8").splitlines()]
            rows = sorted([r for r in rows if r["epoch"] != at]+[stat],key=lambda r:r["epoch"])
            temp = history_path.with_suffix(".tmp"); temp.write_text("".join(json.dumps(r)+"\n" for r in rows),encoding="utf-8"); temp.replace(history_path)
            result = report()
            print(json.dumps({"validated_epoch":at,"group_macro_AP50":summary["group_macro_AP50"],"gates_passed":result["passed"]}),flush=True)
            gate_passed = result["passed"]
            write_json(HOME / "progress.json",{"status":"validation_completed","epoch":at,"promotion_passed":gate_passed,"updated_at":now()})
            counts = {"native":0,"augmented":0}; loss_sum = {}; batches = 0
            if gate_passed: break
        if gate_passed: break
    final = report()
    complete = {"status":"completed_source_gate_passed" if final["passed"] else "completed_source_gate_failed",
                "epochs_run":at,"updates":updates,"best_epoch":final["candidate"]["epoch"],"promotion_passed":final["passed"],
                "frozen_state_bitwise_equal":True,"elapsed_seconds":prior_seconds+time.perf_counter()-started,
                "target_test_cells":0,"automatic_fallback":False,"updated_at":now()}
    write_json(HOME / "training_complete.json",complete); write_json(HOME / "progress.json",complete)
    print(json.dumps(complete),flush=True)


def main():
    import msvcrt
    parser = argparse.ArgumentParser(); parser.add_argument("--check",action="store_true"); parser.add_argument("--resume",action="store_true")
    args = parser.parse_args(); HOME.mkdir(parents=True,exist_ok=True)
    with (HOME / "run.lock").open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1): lock.write(b"1"); lock.flush()
        lock.seek(0); msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        torch.set_num_threads(8)
        try:
            run(args.check,args.resume)
        except Exception:
            write_json(HOME / "failure.json",{"traceback":traceback.format_exc(),"updated_at":now()})
            write_json(HOME / "progress.json",{"status":"failed","updated_at":now()})
            raise


if __name__ == "__main__": main()
