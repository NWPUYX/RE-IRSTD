"""Bounded source-only center-head repair; the original model is unchanged."""
