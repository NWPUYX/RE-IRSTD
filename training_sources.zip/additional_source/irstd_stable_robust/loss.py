"""Retain teacher constraints; give clean geometry the native regression weight."""
import torch
from torch.nn import functional as F
from irstd_robust_t.run import losses as base_losses,deployed_geometry
from irstd_adapter import targets,model_config
from irstd.data.targets import gather_centers
from irstd_v2.losses import giou_pairs


def losses(model,teacher,images,samples,reference,cfg,device):
    loss,terms,out=base_losses(model,teacher,images,samples,reference,cfg,device)
    if not any(s['view_type'] in ['shrink','enlarge'] for s in samples):return loss,terms,out
    t=targets(samples,model_config(),reference,device,'shared_regression');anchor=t['anchors']
    old=images.new_tensor([4. if s['view_type']=='native' else 1. for s in samples]).to(device)
    new=images.new_tensor([4. if s['view_type'] in ['native','shrink','enlarge'] else 1. for s in samples]).to(device)
    nold=sum(float(old[i])*len(s['boxes']) for i,s in enumerate(samples))
    nnew=sum(float(new[i])*len(s['boxes']) for i,s in enumerate(samples))
    oldcoef=old[anchor[:,0]]/max(nold,1.);newcoef=new[anchor[:,0]]/max(nnew,1.)
    difference=newcoef-oldcoef;lc=model_config()['loss']
    off=F.smooth_l1_loss(gather_centers(out['offsets'],anchor),t['offsets'],beta=lc['smooth_l1_beta'],reduction='none').mean(1)
    size=F.smooth_l1_loss(gather_centers(out['log_size'],anchor),t['sizes'],beta=lc['smooth_l1_beta'],reduction='none').mean(1)
    center,wh=deployed_geometry(out,t,reference);gtc=anchor[:,1:]+t['offsets'];gtwh=t['sizes'].exp()*wh.new_tensor(reference)
    giou=1-giou_pairs(torch.cat((center-wh/2,center+wh/2),1),torch.cat((gtc-gtwh/2,gtc+gtwh/2),1))
    correction=(difference*(lc['offset_weight']*off+lc['size_weight']*size+.1*giou)).sum()
    loss=loss+correction;assert torch.isfinite(loss)
    terms={**terms,'offset':float((newcoef*off).sum().detach()),'size':float((newcoef*size).sum().detach()),
        'giou':float((newcoef*giou).sum().detach()),'regression_reweight_correction':float(correction.detach()),
        'actual_loss':float(loss.detach())}
    return loss,terms,out
