"""Keep geometric views clean; sample noisy/background views in the same epoch."""
from torch.utils.data import DataLoader
import torch
from irstd_robust_t.data import RobustPairs
from irstd_background_center.data import collate_pairs
from irstd_v2.data import render
from data_pipeline import worker_seed


class SeparatedPairs(RobustPairs):
    def __getitem__(self,index):
        native,augmented=super().__getitem__(index)
        if augmented['view_type'] in ['shrink_noise','enlarge_noise']:
            image,boxes,valid=render(self.records[self.indices[index]],augmented['geometry_plan'])
            assert torch.equal(boxes,augmented['boxes']) and torch.equal(valid,augmented['valid_mask'])
            augmented={**augmented,'image':image,'view_type':augmented['view_type'].removesuffix('_noise')}
            augmented.pop('noise_factor')
        return native,augmented


def training_loader(cfg):
    return DataLoader(SeparatedPairs(cfg),batch_size=2,shuffle=True,num_workers=cfg['workers'],collate_fn=collate_pairs,
        worker_init_fn=worker_seed,persistent_workers=False,pin_memory=False,drop_last=False,
        generator=torch.Generator().manual_seed(3407))
