"""RE-IRSTD-v1 under the frozen public benchmark protocol.

The model/losses are imported unchanged. Dataset transforms and evaluation
selection intentionally follow Scenario_adaptability rather than its native
resolution/F1-selected standalone training recipe.
"""
from pathlib import Path
import json
import random
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
from data_pipeline import load_frame, worker_seed
from evaluation import postprocess, match_frame
from irstd.config import load_config
from irstd.data.targets import build_targets
from irstd.inference.decoder import decode as decode_centers

ROOT = Path(__file__).resolve().parent
MODEL_ROOT = ROOT.parent / "IRSTD"


def model_config():
    cfg = load_config(MODEL_ROOT / "config_start.yaml", "D")
    cfg["task"]["size_head"] = True
    cfg["data"]["input_scale"] = 255.
    cfg["train"]["mixed_precision_backbone"] = False
    return cfg


def transformed_boxes(record, flip=False):
    w, h = record["width"], record["height"]
    ratio = min(512 / w, 512 / h)
    nw, nh = int(w * ratio), int(h * ratio)
    trans = (nw / w, nh / h, (512 - nw) // 2, (512 - nh) // 2)
    sx, sy, dx, dy = trans
    boxes = np.asarray(record["boxes"], dtype=np.float32).reshape(-1, 4).copy()
    boxes[:, 0] = boxes[:, 0] * sx + dx
    boxes[:, 1] = boxes[:, 1] * sy + dy
    boxes[:, 2] *= sx
    boxes[:, 3] *= sy
    if flip:
        boxes[:, 0] = 512 - boxes[:, 0] - boxes[:, 2]
    boxes[:, 2:] += boxes[:, :2]
    return boxes, trans


class PublicInfraredData(Dataset):
    def __init__(self, domain, split, training=False):
        self.records = json.loads((ROOT / "splits" / f"{domain}_{split}.json").read_text(encoding="utf-8"))
        self.training = training

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        record = self.records[index]
        array, trans = load_frame(record["path"])
        # Preserve exactly the benchmark RGB letterbox first. Conversion to L
        # is the explicit input adaptation required by the single-gray model.
        gray = np.array(Image.fromarray(array).convert("L"), dtype=np.float32) / 255.
        flip = self.training and random.random() < .5
        boxes, expected_trans = transformed_boxes(record, flip)
        if tuple(trans) != tuple(expected_trans):
            raise ValueError("Image dimensions differ from the frozen manifest")
        if flip:
            gray = gray[:, ::-1].copy()
        sample = {"image": torch.from_numpy(gray.copy())[None], "boxes": torch.from_numpy(boxes),
                  "points": torch.empty(0, 2), "complete": True,
                  "known_background_mask": torch.zeros(1, 512, 512, dtype=torch.bool),
                  "ignore_mask": torch.zeros(1, 512, 512, dtype=torch.bool),
                  "sample_id": str(record["id"]), "scene_id": record["group"],
                  "record_index": index, "trans": trans}
        return sample


def collate(samples):
    return torch.stack([sample["image"] for sample in samples]), samples


def loader(domain, split, batch=4, workers=2, training=False):
    return DataLoader(PublicInfraredData(domain, split, training), batch_size=batch, shuffle=training,
                      num_workers=workers, collate_fn=collate, pin_memory=False, persistent_workers=workers > 0,
                      worker_init_fn=worker_seed, drop_last=False)


def source_audit(source):
    records = json.loads((ROOT / "splits" / f"{source}_train.json").read_text(encoding="utf-8"))
    sizes, collisions = [], []
    for record in records:
        boxes, _ = transformed_boxes(record)
        sizes.extend((boxes[:, 2:] - boxes[:, :2]).tolist())
        for flip in (False, True):
            checked, _ = transformed_boxes(record, flip)
            centers = (checked[:, :2] + checked[:, 2:]) / 2
            q = np.floor(centers).astype(np.int64)
            if len(q) != len(np.unique(q, axis=0)):
                collisions.append({"image_id": record["id"], "path": record["path"], "horizontal_flip": flip,
                                   "boxes_xyxy_512": checked.tolist(), "cells": q.tolist()})
    if not sizes:
        raise ValueError("No source-train box sizes")
    return {"frames": len(records), "boxes": len(sizes), "size_reference_512": np.median(sizes, axis=0).tolist(),
            "collision_frames": collisions}


def targets(samples, cfg, reference, device, collision_policy="reject"):
    if collision_policy == "reject":
        return build_targets(samples, cfg, reference, device)
    if collision_policy != "shared_regression":
        raise ValueError("Unknown center-collision policy")
    # Explicit opt-in for the reviewed benchmark adaptation. All annotations
    # remain in regression and count denominators; only the same-cell P/G
    # rasterization is unique, as max-composed equal Gaussians are identical.
    unique_samples, all_anchors, all_offsets, all_sizes, counts = [], [], [], [], []
    for b, sample in enumerate(samples):
        boxes = sample["boxes"]
        centers = (boxes[:, :2] + boxes[:, 2:]) / 2
        q = centers.floor().long()
        seen, keep = set(), []
        for i, cell in enumerate(q.tolist()):
            key = tuple(cell)
            if key not in seen:
                keep.append(i)
                seen.add(key)
        unique_samples.append({**sample, "boxes": boxes[keep]})
        counts.append(len(boxes))
        all_anchors.append(torch.cat((torch.full((len(q), 1), b, dtype=torch.long), q), dim=1))
        all_offsets.append(centers - q)
        all_sizes.append(((boxes[:, 2:] - boxes[:, :2]) / torch.as_tensor(reference)).log())
    result = build_targets(unique_samples, cfg, reference, device)
    result.update(counts=torch.tensor(counts, device=device), anchors=torch.cat(all_anchors).to(device),
                  offsets=torch.cat(all_offsets).to(device), sizes=torch.cat(all_sizes).to(device),
                  has_box=torch.ones(sum(counts), dtype=torch.bool, device=device))
    return result


@torch.inference_mode()
def evaluate(model, data_loader, device, reference, save_path, max_batches=None):
    model.eval()
    frames, predictions = [], []
    for batch_index, (images, samples) in enumerate(data_loader):
        if max_batches is not None and batch_index >= max_batches:
            break
        output = model(images.to(device).float())
        # Keep architecture-specific 3x3 peaks/plateau handling. Common postprocess
        # then applies exactly the benchmark top1000/NMS0.5/max100/inverse transform.
        decoded = decode_centers(output, 1e-5, {"box_nms_iou": None}, reference)
        for image_index, (prediction, sample) in enumerate(zip(decoded, samples)):
            centers = prediction["centers"].to(device)
            scores = prediction["scores"].to(device)
            q = centers.floor().long()
            # Network-space boundary clipping belongs after common NMS, not
            # before it. Reconstruct unclipped widths from the sampled head.
            size = output["log_size"][image_index, :, q[:, 1], q[:, 0]].transpose(0, 1).float()
            ref = size.new_tensor(reference)
            wh = ref * torch.minimum(size.clamp_min(-20), (size.new_tensor([512, 512]) / ref).log()).exp()
            raw = torch.cat((centers, wh, scores[:, None], torch.ones_like(scores[:, None])), dim=1)
            record = data_loader.dataset.records[sample["record_index"]]
            pred = postprocess(raw, record, sample["trans"])
            frames.append(match_frame(pred, record))
            for row in pred:
                x, y, x2, y2, score = map(float, row)
                predictions.append({"image_id": record["id"], "category_id": 1, "bbox": [x, y, x2 - x, y2 - y], "score": score})
    if save_path is not None:
        save_path.write_text(json.dumps({"frames": frames, "predictions": predictions}, separators=(",", ":")), encoding="utf-8")
    return frames
