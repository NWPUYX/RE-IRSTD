"""Random-init RE-IRSTD-v1, frozen four-domain public comparison protocol."""
import os
from pathlib import Path
ROOT = Path(__file__).resolve().parent
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import argparse
import copy
import hashlib
import json
import math
import random
import time
import numpy as np
import torch
from irstd.models.detector import Detector
from irstd.losses.detection import detection_losses
from irstd.engine.optim import make_optimizer
from irstd_adapter import model_config, source_audit, targets, loader, evaluate
from evaluation import metrics, select_threshold
from train_public import write_json

DOMAINS = ["DAUB-R", "IRDST-H", "IRSTD-UAV", "ITSDT-15K"]


def shutdown(data_loader):
    if getattr(data_loader, "_iterator", None) is not None:
        data_loader._iterator._shutdown_workers()
        data_loader._iterator = None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=DOMAINS, required=True)
    parser.add_argument("--seed", type=int, choices=[3407, 2026, 17], default=3407)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--center-collision-policy", choices=["reject", "shared_regression"], default="reject")
    args = parser.parse_args()
    torch.set_num_threads(8)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = False  # identical setting to train_public.py
    device = torch.device("cuda")
    cfg = model_config()
    audit = source_audit(args.source)
    if audit["collision_frames"] and args.center_collision_policy == "reject":
        raise ValueError("Source-train center collisions require an explicit reviewed policy; no labels were dropped")
    reference = audit["size_reference_512"]
    run = ROOT / ("smoke_runs" if args.smoke else "runs") / "IRSTD" / args.source / f"seed_{args.seed}"
    run.mkdir(parents=True, exist_ok=True)
    hashes = {f"{domain}_{split}": hashlib.sha256((ROOT / "splits" / f"{domain}_{split}.json").read_bytes()).hexdigest()
              for domain in DOMAINS for split in ("train", "val", "test")}
    source_hashes = {str(path.relative_to(ROOT.parent)): hashlib.sha256(path.read_bytes()).hexdigest()
                     for path in sorted((ROOT.parent / "IRSTD" / "src" / "irstd").rglob("*.py"))}
    for filename in ("train_irstd.py", "irstd_adapter.py", "evaluation.py", "data_pipeline.py"):
        path = ROOT / filename
        source_hashes[str(path.relative_to(ROOT.parent))] = hashlib.sha256(path.read_bytes()).hexdigest()
    config = {"model": "IRSTD", "architecture": "RE-IRSTD-v1 D", "source": args.source, "seed": args.seed,
              "epochs": 100, "batch": 4, "workers": args.workers, "val_interval": 5, "patience": 10,
              "minimum_epochs": 30, "input_size": 512, "precision": "float32", "frames": 1,
              "input_adaptation": "benchmark RGB PIL-bicubic letterbox, fill128; then PIL L; divide255",
              "pretrained": False, "augmentation": "horizontal flip p=0.5 only", "background_swap": False,
              "optimizer": "AdamW", "initial_lr": .000625, "weight_decay": .0005, "betas": [.9, .999],
              "no_decay": ["bias", "GN affine", "residual gamma"], "warmup_epochs": 3,
              "scheduler": "same epoch-wise warmup/cosine as train_public.py", "gradient_clip_norm": 10.,
              "EMA": "0.9999*(1-exp(-updates/2000))", "checkpoint_selector": "source_val_AP50_ema",
              "threshold_selector": "exact pooled source-val maximum box F1 at IoU0.5",
              "NMS_IoU": .5, "confidence_floor": 1e-5, "pre_NMS_topk": 1000, "max_detections": 100,
              "center_peaks": "IRSTD 3x3 + deterministic equal-value plateau deduplication",
              "center_collision_policy": args.center_collision_policy,
              "split_hashes": hashes, "source_hashes": source_hashes, "size_reference_512": reference,
              "core_model_configuration": cfg, "smoke": args.smoke,
              "protocol": "same frozen splits, budget, EMA, AP selection and evaluation as Scenario_adaptability; single-gray single-frame architecture; native-resolution recipe intentionally overridden"}
    if (run / "config.json").exists():
        previous = json.loads((run / "config.json").read_text(encoding="utf-8"))
        if previous != config:
            raise ValueError("Existing run configuration/source/split changed; do not silently resume")
        if not args.resume:
            raise ValueError("Run exists; use --resume")
    write_json(run / "config.json", config)
    write_json(run / "source_audit.json", audit)
    write_json(run / "process.json", {"pid": os.getpid(), "source": args.source, "seed": args.seed, "model": "IRSTD"})
    model = Detector(cfg).to(device)
    optimizer_cfg = {**cfg["train"], "learning_rate": config["initial_lr"], "weight_decay": config["weight_decay"]}
    optimizer = make_optimizer(model, optimizer_cfg)
    ema = copy.deepcopy(model).eval()
    for parameter in ema.parameters():
        parameter.requires_grad_(False)
    parameter_names = set(dict(model.named_parameters()))
    training = loader(args.source, "train", workers=args.workers, training=True)
    validation = loader(args.source, "val", workers=args.workers)
    epoch_start, best, checks, updates, previous_seconds = 0, -1., 0, 0, 0.
    if args.resume and (run / "last.pt").exists():
        checkpoint = torch.load(run / "last.pt", map_location=device, weights_only=False)
        if checkpoint["config"] != config:
            raise ValueError("Checkpoint config changed")
        model.load_state_dict(checkpoint["model"])
        ema.load_state_dict(checkpoint["ema"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        epoch_start, best, checks, updates, previous_seconds = (checkpoint[key] for key in ("next_epoch", "best", "checks_since_best", "updates", "elapsed_seconds"))
        random.setstate(checkpoint["rng_python"])
        np.random.set_state(checkpoint["rng_numpy"])
        torch.set_rng_state(checkpoint["rng_torch"].cpu())
        torch.cuda.set_rng_state_all([state.cpu() for state in checkpoint["rng_cuda"]])
        del checkpoint
    started = time.perf_counter()
    early_stopped = False
    epoch = epoch_start - 1
    for epoch in range(epoch_start, 100):
        tick = time.perf_counter()
        model.train()
        loss_values, count = [], 0
        lr = config["initial_lr"] * (.01 + .99 * (1 + math.cos(math.pi * epoch / 99)) / 2)
        if epoch < 3:
            lr = config["initial_lr"] * (.1 + .9 * (epoch + 1) / 3)
        for group in optimizer.param_groups:
            group["lr"] = lr
        torch.cuda.reset_peak_memory_stats(device)
        for iteration, (images, samples) in enumerate(training):
            optimizer.zero_grad(set_to_none=True)
            target = targets(samples, cfg, reference, device, args.center_collision_policy)
            output = model(images.to(device).float())
            losses = detection_losses(output, target, cfg["loss"])
            loss = losses["total"]
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Non-finite loss epoch={epoch + 1} batch={iteration}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 10., error_if_nonfinite=True)
            optimizer.step()
            updates += 1
            decay = .9999 * (1 - math.exp(-updates / 2000))
            with torch.no_grad():
                current = model.state_dict()
                for key, value in ema.state_dict().items():
                    if key in parameter_names:
                        value.mul_(decay).add_(current[key].detach(), alpha=1 - decay)
                    else:
                        value.copy_(current[key])
            loss_values.append(float(loss.detach()))
            count += len(samples)
            if iteration % 100 == 0:
                print(json.dumps({"epoch": epoch + 1, "batch": iteration, "loss": loss_values[-1], "frames": count,
                                  "seconds": time.perf_counter() - tick}), flush=True)
            if args.smoke and iteration >= 1:
                break
        torch.cuda.synchronize(device)
        stat = {"epoch": epoch + 1, "train_loss": float(np.mean(loss_values)), "train_frames": count,
                "train_seconds": time.perf_counter() - tick, "updates": updates, "lr": lr,
                "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated(device)}
        if args.smoke or (epoch + 1) % 5 == 0 or epoch == 99:
            frames = evaluate(ema, validation, device, reference,
                              run / ("smoke_inference.json" if args.smoke else "source_val_predictions.json"), 2 if args.smoke else None)
            score = metrics(frames, .25)["AP50"]
            stat["source_val_AP50"] = score
            if score > best:
                best, checks = score, 0
                temporary = run / "best.tmp"
                torch.save({"model": ema.state_dict(), "epoch": epoch, "source_val_AP50": best, "config": config}, temporary)
                temporary.replace(run / "best.pt")
                write_json(run / "source_threshold.json", {"threshold": select_threshold(frames), "epoch": epoch + 1,
                                                            "selected_on": args.source + "_val"})
            else:
                checks += 1
        stat["elapsed_seconds"] = previous_seconds + time.perf_counter() - started
        with (run / "history.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(stat) + "\n")
        checkpoint = {"model": model.state_dict(), "ema": ema.state_dict(), "optimizer": optimizer.state_dict(),
                      "next_epoch": epoch + 1, "best": best, "checks_since_best": checks, "updates": updates,
                      "elapsed_seconds": stat["elapsed_seconds"], "config": config,
                      "rng_python": random.getstate(), "rng_numpy": np.random.get_state(),
                      "rng_torch": torch.get_rng_state(), "rng_cuda": torch.cuda.get_rng_state_all()}
        temporary = run / "last.tmp"
        torch.save(checkpoint, temporary)
        temporary.replace(run / "last.pt")
        del checkpoint
        write_json(run / "status.json", {"status": "smoke_passed" if args.smoke else "training", "pid": os.getpid(), **stat})
        print(json.dumps(stat), flush=True)
        if args.smoke:
            shutdown(training)
            shutdown(validation)
            return
        if epoch + 1 >= 30 and checks >= 10:
            early_stopped = True
            break
    best_state = torch.load(run / "best.pt", map_location=device, weights_only=False)
    ema.load_state_dict(best_state["model"])
    shutdown(training)
    shutdown(validation)
    del training, validation, optimizer, model
    threshold = json.loads((run / "source_threshold.json").read_text())["threshold"]
    results = []
    for target in DOMAINS:
        test = loader(target, "test", workers=args.workers)
        frames = evaluate(ema, test, device, reference, run / f"test_{target}_predictions.json")
        result = {"model": "IRSTD", "source": args.source, "target": target, "seed": args.seed,
                  "best_epoch": best_state["epoch"] + 1, **metrics(frames, threshold, bootstrap=200)}
        by_group = {group: metrics([frame for frame in frames if frame["group"] == group], threshold)
                    for group in sorted({frame["group"] for frame in frames})}
        write_json(run / f"test_{target}_metrics.json", {"overall": result, "by_group": by_group})
        results.append(result)
        print(json.dumps(result), flush=True)
        shutdown(test)
        del test
    write_json(run / "results.json", results)
    write_json(run / "status.json", {"status": "completed", "best_epoch": best_state["epoch"] + 1, "epochs_run": epoch + 1,
                                      "early_stopped": early_stopped, "updates": updates,
                                      "elapsed_seconds": previous_seconds + time.perf_counter() - started})


if __name__ == "__main__":
    main()
