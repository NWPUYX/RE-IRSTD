from pathlib import Path
import re
p=Path(r'D:\Codex\scene_generalization_audit\场景泛化实验方案.md');s=p.read_text(encoding='utf-8')
s=re.sub(r'### 4\.2 P2：补充合成域并扩展为 6×6\n.*?(?=\[INFERRED · HIGH\] Tiny-UAV-IR 可作为额外外部目标列：)','',s,flags=re.S)
s=s.replace('### 4.3 目标域访问规则','### 4.2 目标域访问规则').replace('无需为所有六域加大量无关消融。','无需为四个公开域加大量无关消融。').replace('Tiny 留一设备4轮；扩展公开6×6；合成／实测分组与MIST-Hard单列','Tiny 留一设备4轮；公开实验仅采用4×4，不使用MIST／NUDT-MIRSDT训练或测试')
p.write_text(s,encoding='utf-8')
w=Path(r'D:\Codex\Scenario_adaptability');(w/'实验方案.md').write_text(s,encoding='utf-8')
assert '6×6' not in s
print('4x4 protocol saved')
