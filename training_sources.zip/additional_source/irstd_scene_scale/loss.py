"""All-label supervision with recipient-only teacher correspondence."""
import torch
from torch.nn import functional as F
from irstd_adapter import targets,model_config
from irstd.data.targets import gather_centers
from irstd.losses.detection import detection_losses
from irstd_v2.losses import giou_pairs
from irstd_robust_t.run import deployed_geometry

def base_losses(model,teacher,images,samples,reference,cfg,device):
    n=len(samples)//2;assert all(s['view_type']=='native' for s in samples[:n])
    t=targets(samples,model_config(),reference,device,'shared_regression')
    valid=torch.stack([s['valid_mask'] for s in samples]).to(device)
    out=model(images.to(device),valid_mask=valid)
    with torch.no_grad():fixed=teacher(images[:n].to(device),valid_mask=valid[:n])
    weights=images.new_tensor([4.]*n+[1.]*n).to(device)
    count=sum(float(weights[i])*len(s['boxes']) for i,s in enumerate(samples))
    normalizers={'images':float(weights.sum()),'targets':count,'boxes':count}
    terms=detection_losses(out,t,model_config()['loss'],weights,normalizers)
    center,wh=deployed_geometry(out,t,reference);truth=t['anchors'][:,1:]+t['offsets']
    true_wh=t['sizes'].exp()*wh.new_tensor(reference)
    pred=torch.cat((center-wh/2,center+wh/2),1);gt=torch.cat((truth-true_wh/2,truth+true_wh/2),1)
    giou=((1-giou_pairs(pred,gt))*weights[t['anchors'][:,0]]).sum()/max(count,1.)
    peak=[];shape=[];augmented=[];negative=[];geometry=[]
    for b in range(n):
        assert samples[b]['sample_id']==samples[b+n]['sample_id']
        native_ids=(t['anchors'][:,0]==b).nonzero().flatten().tolist()
        aug_ids=(t['anchors'][:,0]==b+n).nonzero().flatten().tolist();assert len(aug_ids)>=len(native_ids)
        if samples[b+n]['view_type']=='mosaic':assert samples[b+n]['recipient_target_count']==len(native_ids)
        else:assert len(native_ids)==len(aug_ids)
        aug_ids=aug_ids[:len(native_ids)]
        for i,j in zip(native_ids,aug_ids):
            _,qx,qy=t['anchors'][i].tolist();_,ax,ay=t['anchors'][j].tolist()
            ys=slice(max(0,qy-3),min(512,qy+4));xs=slice(max(0,qx-3),min(512,qx+4))
            py=slice(max(0,ay-3),min(512,ay+4));px=slice(max(0,ax-3),min(512,ax+4))
            original=out['center_logits'][b,0,ys,xs];target=fixed['center_logits'][b,0,ys,xs]
            peak.append((original.max()-target.max()).square())
            shape.append(((original-original.max())-(target-target.max())).square().mean())
            augmented.append((out['center_logits'][b+n,0,py,px].max()-target.max()).square())
            point=int(target.argmax());height,width=target.shape
            peak_y=ys.start+point//width;peak_x=xs.start+point%width
            for field in ['offsets','log_size']:
                student=torch.stack((out[field][b,:,qy,qx],out[field][b,:,peak_y,peak_x]))
                baseline=torch.stack((fixed[field][b,:,qy,qx],fixed[field][b,:,peak_y,peak_x]))
                geometry.append(F.smooth_l1_loss(student,baseline))
        mask=t['negative'][b].flatten().bool()&(t['heatmap'][b].flatten()<.01)
        k=min(128,int(mask.sum()))
        if k:
            target=fixed['center_logits'][b].flatten();ids=target.masked_fill(~mask,-torch.inf).topk(k).indices
            negative.append((out['center_logits'][b].flatten()[ids]-target[ids]).square().mean())
    zero=terms['total']*0
    mean=lambda values:torch.stack(values).mean() if values else zero
    extra={'native_peak':mean(peak),'native_shape':mean(shape),'augmented_peak':mean(augmented),
        'native_negative':mean(negative),'native_geometry_teacher':mean(geometry)}
    loss=terms['total']+.1*giou+.5*extra['native_peak']+.1*extra['native_shape']+.05*extra['augmented_peak']+.05*extra['native_negative']+.25*extra['native_geometry_teacher']
    assert torch.isfinite(loss)
    return loss,{k:float(v.detach()) for k,v in {**terms,'giou':giou,**extra}.items()},out

def supervised_losses(model,teacher,images,samples,reference,cfg,device):
    loss,terms,out=base_losses(model,teacher,images,samples,reference,cfg,device)
    if not any(s['view_type'] in ['shrink','enlarge','mosaic'] for s in samples):return loss,terms,out
    t=targets(samples,model_config(),reference,device,'shared_regression');anchor=t['anchors']
    old=images.new_tensor([4. if s['view_type']=='native' else 1. for s in samples]).to(device)
    new=images.new_tensor([4. if s['view_type'] in ['native','shrink','enlarge','mosaic'] else 1. for s in samples]).to(device)
    nold=sum(float(old[i])*len(s['boxes']) for i,s in enumerate(samples))
    nnew=sum(float(new[i])*len(s['boxes']) for i,s in enumerate(samples))
    oldcoef=old[anchor[:,0]]/max(nold,1.);newcoef=new[anchor[:,0]]/max(nnew,1.)
    difference=newcoef-oldcoef;lc=model_config()['loss']
    off=F.smooth_l1_loss(gather_centers(out['offsets'],anchor),t['offsets'],beta=lc['smooth_l1_beta'],reduction='none').mean(1)
    size=F.smooth_l1_loss(gather_centers(out['log_size'],anchor),t['sizes'],beta=lc['smooth_l1_beta'],reduction='none').mean(1)
    center,wh=deployed_geometry(out,t,reference);gtc=anchor[:,1:]+t['offsets'];gtwh=t['sizes'].exp()*wh.new_tensor(reference)
    giou=1-giou_pairs(torch.cat((center-wh/2,center+wh/2),1),torch.cat((gtc-gtwh/2,gtc+gtwh/2),1))
    correction=(difference*(lc['offset_weight']*off+lc['size_weight']*size+.1*giou)).sum()
    loss=loss+correction;assert torch.isfinite(loss)
    terms={**terms,'offset':float((newcoef*off).sum().detach()),'size':float((newcoef*size).sum().detach()),
        'giou':float((newcoef*giou).sum().detach()),'regression_reweight_correction':float(correction.detach()),
        'actual_loss':float(loss.detach())}
    return loss,terms,out

def relative_mse(student, fixed, floor):
    scale = fixed.detach().square().mean((-2, -1), keepdim=True).sqrt().clamp_min(floor)
    return ((student-fixed.detach())/scale).square().mean()

def losses(model, teacher, images, samples, reference, cfg, device):
    student_features, teacher_features = [], []
    handles = [model.backbone.target_path.register_forward_hook(lambda m, args, result: student_features.append(result)),
               teacher.backbone.target_path.register_forward_hook(lambda m, args, result: teacher_features.append(result))]
    try:
        loss, terms, out = supervised_losses(model, teacher, images, samples, reference, cfg, device)
    finally:
        for handle in handles:
            handle.remove()
    assert len(student_features) == len(teacher_features) == 1
    student, fixed = student_features[0], teacher_features[0]
    n = len(samples)//2
    assert len(fixed) == n and len(student) == 2*n
    t = targets(samples, model_config(), reference, device, 'shared_regression')
    native, paired = [], []
    for b in range(n):
        clean_ids = (t['anchors'][:, 0] == b).nonzero().flatten().tolist()
        aug_ids = (t['anchors'][:, 0] == b+n).nonzero().flatten().tolist()
        assert len(aug_ids) >= len(clean_ids)
        photometric = samples[b+n]['view_type'] in ['noise', 'background_noise']
        for i, j in zip(clean_ids, aug_ids):
            _, x, y = t['anchors'][i].tolist()
            ys, xs = slice(max(y-3, 0), min(y+4, 512)), slice(max(x-3, 0), min(x+4, 512))
            target = fixed[b, :, ys, xs]
            native.append(relative_mse(student[b, :, ys, xs], target, cfg['T_channel_RMS_floor']))
            if photometric:
                assert torch.equal(t['anchors'][i, 1:], t['anchors'][j, 1:])
                paired.append(relative_mse(student[b+n, :, ys, xs], target, cfg['T_channel_RMS_floor']))
    zero = loss*0
    native_term = torch.stack(native).mean() if native else zero
    paired_term = torch.stack(paired).mean() if paired else zero
    global_term = relative_mse(student[:n, :, ::16, ::16], fixed[:, :, ::16, ::16], cfg['T_channel_RMS_floor'])
    loss = loss + cfg['native_T_local_weight']*native_term + cfg['paired_T_local_weight']*paired_term + cfg['native_T_global_weight']*global_term
    assert torch.isfinite(loss)
    terms.update(T_native_local=float(native_term.detach()), T_paired_local=float(paired_term.detach()),
                 T_native_global=float(global_term.detach()), actual_loss=float(loss.detach()))
    return loss, terms
