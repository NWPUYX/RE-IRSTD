"""Five source-only views, with all labels retained in full-image mosaics."""
import random
import numpy as np
from PIL import Image
import torch
from torch.utils.data import DataLoader
from irstd_background_center.data import Pairs, collate_pairs, union_swap
from irstd_geometry_balance.data import direction_plan
from irstd_v2.data import render, original_boxes
from irstd_noise_center.data import views
from data_pipeline import worker_seed


def mosaic(base, indices, k):
    assert len(indices) == k*k and len(set(indices)) == k*k
    assert base.split in ['source_train', 'source_val']
    canvas = Image.new('RGB', (256*k, 256*k))
    boxes = []
    for slot, index in enumerate(indices):
        record = base.records[index]
        assert record['width'] == record['height'] == 256
        with Image.open(record['path']) as image:
            assert image.size == (256, 256)
            canvas.paste(image.convert('RGB'), ((slot % k)*256, (slot//k)*256))
        value = original_boxes(record)+torch.tensor([(slot % k)*256, (slot//k)*256]*2)
        boxes.append(value*(2/k))
    value = canvas.resize((512, 512), Image.Resampling.BICUBIC).convert('L')
    image = torch.from_numpy(np.array(value, dtype=np.float32)/255.)[None]
    boxes = torch.cat(boxes)
    assert len(boxes) == sum(len(base.records[i]['boxes']) for i in indices)
    assert (boxes >= 0).all() and (boxes <= 512).all()
    return image, boxes


class ScenePairs(Pairs):
    def __getitem__(self, index):
        i = self.indices[index]
        native = self.base.base_sample(i)
        rng = random.Random(self.seed+self.epoch*1000003+i*97)
        flip = rng.random() < .5
        native = {**native, 'view_type': 'native', 'source_target_count': len(native['boxes'])}
        augmented = dict(native)
        mode = (index+self.epoch) % 5
        if mode == 1:
            donor_index = rng.choice(self.eligible[self.records[i]['group']])
            donor = self.donors.base_sample(donor_index)
            image, alpha, _ = union_swap(native, donor, self.cfg)
            assert alpha.max() > 0
            augmented.update(image=image, donor_id=donor['sample_id'])
        elif mode in [2, 3]:
            direction = 'shrink' if mode == 2 else 'enlarge'
            plan = direction_plan(self.records[i], self.cfg, rng, direction)
            if plan['sx'] < 0:
                plan = {**plan, 'sx': -plan['sx'], 'tx': 512-plan['tx']}
            image, boxes, valid = render(self.records[i], plan)
            augmented.update(image=image, boxes=boxes, valid_mask=valid, ignore_mask=~valid,
                             geometry_plan=plan, view_type=direction)
        elif mode == 4:
            k = [2, 3, 4][(index//5+self.epoch) % 3]
            pool = [j for j in range(len(self.base)) if j != i]
            indices = [i]+rng.sample(pool, k*k-1)
            image, boxes = mosaic(self.base, indices, k)
            valid = torch.ones_like(native['valid_mask'])
            augmented.update(image=image, boxes=boxes, valid_mask=valid, ignore_mask=~valid,
                             view_type='mosaic', mosaic_grid=k, mosaic_indices=indices,
                             mosaic_ids=[self.records[j]['id'] for j in indices],
                             mosaic_split=self.base.split, recipient_target_count=len(native['boxes']),
                             geometry_plan={'sx':2/k,'sy':2/k,'tx':0,'ty':0,'fallback':False},
                             mosaic_transforms=[(2/k,2/k,(slot%k)*512/k,(slot//k)*512/k) for slot in range(k*k)])
            assert len(boxes) == sum(len(self.records[j]['boxes']) for j in indices)
            assert torch.allclose(boxes[:len(native['boxes'])], native['boxes']/k, atol=5e-5, rtol=0)
        if mode in [0, 1]:
            images, _ = views(augmented, index+(self.epoch+31)*1000003)
            factor = 4 if (index//5+self.epoch) % 2 == 0 else 16
            augmented.update(image=images[1 if factor == 4 else 2], noise_factor=factor,
                             view_type='noise' if mode == 0 else 'background_noise')
        if flip:
            def horizontal(sample):
                boxes = sample['boxes'][:, [2, 1, 0, 3]].clone()
                boxes[:, [0, 2]] = 512-boxes[:, [0, 2]]
                result = {**sample, 'image': sample['image'].flip(-1), 'boxes': boxes}
                for key in ['valid_mask', 'ignore_mask', 'known_background_mask']:
                    result[key] = sample[key].flip(-1)
                plan=sample['geometry_plan']
                result['geometry_plan']={**plan,'sx':-plan['sx'],'tx':512-plan['tx']}
                if 'mosaic_transforms' in sample:
                    result['mosaic_transforms']=[(-sx,sy,512-tx,ty) for sx,sy,tx,ty in sample['mosaic_transforms']]
                return result
            native, augmented = horizontal(native), horizontal(augmented)
        assert torch.isfinite(augmented['image']).all()
        assert len(augmented['boxes']) >= len(native['boxes'])
        return native, augmented


def training_loader(cfg):
    return DataLoader(ScenePairs(cfg), batch_size=2, shuffle=True, num_workers=cfg['workers'],
        collate_fn=collate_pairs, worker_init_fn=worker_seed, persistent_workers=False,
        pin_memory=False, drop_last=False, generator=torch.Generator().manual_seed(3407))
