"""Source-only complete-scene scale adaptation; original core operators retained."""
