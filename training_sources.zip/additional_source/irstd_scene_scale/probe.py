"""Same frozen source-val mosaic pressure test used before training."""
import numpy as np
import torch
from torch.utils.data import DataLoader
from experiments.IRSTD_research_20261107.source_mosaic_probe import Probe
from irstd_v2.data import collate
from irstd.inference.decoder import decode
from evaluation import postprocess, match_frame, metrics


@torch.inference_mode()
def evaluate_mosaics(model, cfg, reference, device, threshold):
    rows={}
    for images,samples in DataLoader(Probe(cfg),batch_size=4,num_workers=cfg['workers'],collate_fn=collate):
        out=model(images.to(device))
        decoded=decode(out,1e-5,{'box_nms_iou':None},reference)
        for b,(proposal,sample) in enumerate(zip(decoded,samples)):
            k=sample['k'];row=rows.setdefault(str(k),{'learned':[],'known_source_size':[]})
            center,score=proposal['centers'].to(device),proposal['scores'].to(device)
            q=center.floor().long();value=out['log_size'][b,:,q[:,1],q[:,0]].T.float();ref=value.new_tensor(reference)
            wh=ref*torch.minimum(value.clamp_min(-20),(value.new_tensor([512,512])/ref).log()).exp()
            raw=torch.cat((center,wh,score[:,None],torch.ones_like(score[:,None])),1)
            for rule in row:
                candidate=raw.clone()
                if rule=='known_source_size':candidate[:,2:4]=candidate.new_tensor(reference)/k
                row[rule].append(match_frame(postprocess(candidate,sample['record'],(1.,1.,0,0)),sample['record']))
    return {k:{rule:metrics(frames,threshold) for rule,frames in row.items()} for k,row in rows.items()}
