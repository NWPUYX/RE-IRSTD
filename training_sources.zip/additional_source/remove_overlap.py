"""Conservatively exclude lower-priority whole groups connected by exact duplicates."""
import json, hashlib, collections
from pathlib import Path
OUT=Path(__file__).resolve().parent/'splits'
leaks=json.loads((OUT/'exact_file_overlap.json').read_text(encoding='utf8'))
priority={'train':0,'val':1,'test':2}; removed=set()
for leak in leaks:
    items=leak['items']; domains={x[0] for x in items}
    assert len(domains)==1, 'Cross-domain overlap requires a separate shared-video exclusion policy'
    top=max(priority[x[1]] for x in items)
    for name,split,path in items:
        if priority[split]<top: removed.add((name,split,Path(path).parent.name))
summary={}; keep_hashes=collections.defaultdict(set)
all_removed=[]
for file in sorted(OUT.glob('*.json')):
    if not any(file.stem.endswith('_'+s) for s in priority): continue
    name,split=file.stem.rsplit('_',1)
    rr=json.loads(file.read_text(encoding='utf8'))
    drop=[r for r in rr if (name,split,r['group']) in removed]
    rr=[r for r in rr if (name,split,r['group']) not in removed]
    all_removed.extend({'dataset':name,'split':split,**r} for r in drop)
    for i,r in enumerate(rr):
        r['id']=i+1
        keep_hashes[hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()].add((name,split))
    blob=json.dumps(rr,ensure_ascii=False,separators=(',',':')).encode('utf8'); file.write_bytes(blob)
    summary.setdefault(name,{})[split]={'frames':len(rr),'boxes':sum(len(r['boxes']) for r in rr),'groups':sorted({r['group'] for r in rr}),'sha256':hashlib.sha256(blob).hexdigest()}
assert all(len(s)==1 for s in keep_hashes.values())
(OUT/'excluded_overlap_groups.json').write_text(json.dumps({'groups':sorted(removed),'frames':len(all_removed),'records':all_removed},ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'verification.json').write_text(json.dumps({'exact_overlap_after_exclusion':0,'excluded_groups':sorted(removed),'excluded_frames':len(all_removed),'unique_file_hashes':len(keep_hashes)},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'excluded_groups':sorted(removed),'excluded_frames':len(all_removed),'remaining_counts':{k:{s:v['frames'] for s,v in vv.items()} for k,vv in summary.items()}},ensure_ascii=False,indent=2))
