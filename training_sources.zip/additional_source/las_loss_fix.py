"""Fix official LAS motion-mask target scale; retain architecture and IoU formula."""
import numpy as np
import torch
from torch import nn
class BinaryMotionMaskLoss(nn.Module):
    def forward(self,pred_m,multi_targets):
        boxes=np.asarray(multi_targets)
        target=torch.zeros_like(pred_m,dtype=torch.float32)
        for b in range(boxes.shape[0]):
            for f in range(boxes.shape[1]):
                for box in boxes[b,f]:
                    x,y,w,h=map(int,box[:4])
                    target[b,0,y:y+h,x:x+w]=1.
        pred=pred_m.float().sigmoid(); dims=(1,2,3)
        intersection=(pred*target).sum(dims)
        union=pred.sum(dims)+target.sum(dims)-intersection
        return 1-((intersection+1)/(union+1)).mean()
