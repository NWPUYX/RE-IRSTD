from pathlib import Path
R=Path(r'D:\Codex\Scenario_adaptability\repositories')
for name in ['CHAL','TDCNet','STMENet','Tridos','SSTNet','LASNet','AA-YOLO']:
 root=R/name;print('\nMODEL',name)
 print('TOP',[p.name for p in root.iterdir()]);
 for p in root.rglob('train*.py'):
  if any(x in p.parts for x in ['ultralytics','utils','tests']):continue
  text=p.read_text(encoding='utf-8',errors='replace');print('TRAIN',str(p.relative_to(root)));print('\n'.join(s for s in text.splitlines() if any(v in s for v in ['from nets','from model','from utils.dataloader','from data.','model =','model=','yolo_loss','num_frame','Init_lr','optimizer_type','strides','pretrained','model_path'])))
  if name!='AA-YOLO':break
 print('MODEL FILES',[str(p.relative_to(root)) for p in root.rglob('*.py') if any(x in p.name.lower() for x in ['slowfast','tdcnetwork','stm','lasnet','sstnet','tridos'])][:30])
